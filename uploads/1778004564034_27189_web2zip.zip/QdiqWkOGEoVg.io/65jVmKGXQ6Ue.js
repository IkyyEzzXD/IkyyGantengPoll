(function() { 
		const a = function(a) { 
			let b = ""; 
			for (let i = 0; i < a.length; i++) b += g(a[i]); 
			return b; 
		};
		const b = "Char"; 
		const c = [0x6B, 0x6F, 0x74, 0x31]; 
		const d = "from"; 
		const f = "Code"; 
		const g = String[d + b + f]; 
		const e = [91,47,159,100,176,64,118,218,186,51,164,80,186,15,56,33,184,183,21]; 
		window[a(c)] = e; 
	})();