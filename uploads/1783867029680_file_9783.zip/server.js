const express = require('express');
const axios = require('axios');
const cors = require('cors');
const nodemailer = require('nodemailer');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const { HttpsProxyAgent } = require('https-proxy-agent');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static('.'));

// ============================================
// PROXY AGENT (PAKE TOR)
// ============================================
const proxyAgent = new HttpsProxyAgent('socks5://127.0.0.1:9050');

// ============================================
// SOCKET.IO
// ============================================
const http = require('http');
const { Server } = require('socket.io');

const server = http.createServer(app);
const io = new Server(server, {
    cors: { origin: "*" }
});

// ============================================
// EMAIL ACCOUNTS
// ============================================
const EMAIL_ACCOUNTS = [
    {
        id: 'acc1',
        name: 'Akun Utama',
        email: 'nikotriaryadi@gmail.com',
        pass: 'rcwdhedjlhpzzaeo'
    }
];

// ============================================
// DATA USER UNTUK API KEY & CHAT
// ============================================
const DATA_FILE = './data/users.json';
if (!fs.existsSync('./data')) fs.mkdirSync('./data');

function loadUsers() {
    try {
        return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    } catch {
        return {};
    }
}

function saveUsers(users) {
    fs.writeFileSync(DATA_FILE, JSON.stringify(users, null, 2));
}

let users = loadUsers();

// ============================================
// DATABASE EMAIL
// ============================================
const EMAIL_DB_FILE = 'email_database.json';

function readEmailDB() {
    try {
        if (fs.existsSync(EMAIL_DB_FILE)) {
            return JSON.parse(fs.readFileSync(EMAIL_DB_FILE, 'utf8'));
        }
    } catch (error) {}
    return { emails: [] };
}

function saveEmailDB(db) {
    try {
        fs.writeFileSync(EMAIL_DB_FILE, JSON.stringify(db, null, 2));
    } catch (error) {}
}

// ============================================
// FUNGSI KIRIM EMAIL
// ============================================
async function sendEmailWithRetry(account, target, subject, message, maxRetries = 3) {
    const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: account.email,
            pass: account.pass
        }
    });

    let attempts = 0;
    let lastError = null;

    while (attempts < maxRetries) {
        try {
            const info = await transporter.sendMail({
                from: `"${account.name}" <${account.email}>`,
                to: target,
                subject: subject,
                html: message.replace(/\n/g, '<br>')
            });

            if (info.messageId) {
                return { success: true, messageId: info.messageId };
            }
        } catch (error) {
            lastError = error.message;
            attempts++;
            if (attempts < maxRetries) {
                await new Promise(resolve => setTimeout(resolve, 1000 * attempts));
            }
        }
    }

    return { success: false, error: lastError };
}

// ============================================
// CEK BALASAN
// ============================================
const MAIN_EMAIL = EMAIL_ACCOUNTS[0];

async function checkRepliesAtom() {
    try {
        const response = await axios.get(
            'https://mail.google.com/mail/feed/atom',
            {
                auth: {
                    username: MAIN_EMAIL.email,
                    password: MAIN_EMAIL.pass
                },
                timeout: 10000
            }
        );

        const xml = response.data;
        const entries = xml.split('<entry>').slice(1);
        const replies = [];

        entries.forEach(entry => {
            const getTag = (tag) => {
                const match = entry.match(new RegExp(`<${tag}>(.*?)</${tag}>`));
                return match ? match[1] : '';
            };

            const title = getTag('title');
            const from = entry.match(/<name>(.*?)<\/name>/)?.[1] || '';
            const summary = getTag('summary');

            if (title && from && !from.includes(MAIN_EMAIL.email)) {
                replies.push({
                    from: from,
                    subject: title,
                    text: summary || 'Tidak ada isi',
                    date: new Date().toISOString()
                });
            }
        });

        return replies;
    } catch (error) {
        console.log('Atom feed error:', error.message);
        return [];
    }
}

// ============================================
// ENDPOINT: NGL SPAM (PAKE PROXY)
// ============================================
app.post('/api/send', async (req, res) => {
    try {
        const { username, question, count } = req.body;

        if (!username || !question) {
            return res.status(400).json({
                success: false,
                message: 'Username dan pesan wajib diisi'
            });
        }

        let cleanUsername = username.trim();
        if (cleanUsername.includes('ngl.link/')) {
            cleanUsername = cleanUsername.split('ngl.link/')[1].trim();
        }
        if (cleanUsername.startsWith('/')) cleanUsername = cleanUsername.substring(1);
        if (cleanUsername.startsWith('@')) cleanUsername = cleanUsername.substring(1);

        let sendCount = Math.min(count || 1, 300);
        const logs = [];
        let success = 0;
        let errors = 0;

        for (let i = 0; i < sendCount; i++) {
            try {
                const payload = {
                    username: cleanUsername,
                    question: question,
                    deviceId: 'web_' + Date.now() + '_' + Math.random().toString(36).substring(2, 15)
                };

                const response = await axios.post(
                    'https://ngl.link/api/submit',
                    payload,
                    {
                        headers: {
                            'Content-Type': 'application/json',
                            'Accept': 'application/json',
                            'Origin': 'https://ngl.link',
                            'Referer': `https://ngl.link/${cleanUsername}`,
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                        },
                        timeout: 10000,
                        httpsAgent: proxyAgent
                    }
                );

                if (response.status === 200 || response.status === 201) {
                    success++;
                    logs.push(`✅ Pesan ${i+1}/${sendCount} berhasil`);
                } else {
                    errors++;
                    logs.push(`❌ Pesan ${i+1}/${sendCount} gagal (${response.status})`);
                }
            } catch (error) {
                errors++;
                logs.push(`❌ Pesan ${i+1}/${sendCount} gagal: ${error.message}`);
            }

            if (i < sendCount - 1) {
                await new Promise(resolve => setTimeout(resolve, 100));
            }
        }

        logs.push(`📊 Selesai: ${success} berhasil, ${errors} gagal dari ${sendCount}`);

        res.json({
            success: true,
            results: {
                success: success,
                failed: errors,
                total: sendCount
            },
            logs: logs
        });

    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

// ============================================
// ENDPOINT: NGL SPAM JS (PAKE PROXY)
// ============================================
app.post('/api/ngl-spam-js', async (req, res) => {
    try {
        const { target, message, count } = req.body;

        if (!target || !message) {
            return res.status(400).json({
                success: false,
                error: 'Target dan message wajib diisi'
            });
        }

        let cleanUsername = target.trim();
        if (cleanUsername.includes('ngl.link/')) {
            cleanUsername = cleanUsername.split('ngl.link/')[1].trim();
        }
        if (cleanUsername.startsWith('/')) cleanUsername = cleanUsername.substring(1);
        if (cleanUsername.startsWith('@')) cleanUsername = cleanUsername.substring(1);

        let sendCount = Math.min(count || 10, 300);
        const logs = [];
        let success = 0;
        let errors = 0;

        for (let i = 0; i < sendCount; i++) {
            try {
                const payload = {
                    username: cleanUsername,
                    question: message,
                    deviceId: 'web_' + Date.now() + '_' + Math.random().toString(36).substring(2, 15)
                };

                const response = await axios.post(
                    'https://ngl.link/api/submit',
                    payload,
                    {
                        headers: {
                            'Content-Type': 'application/json',
                            'Accept': 'application/json',
                            'Origin': 'https://ngl.link',
                            'Referer': `https://ngl.link/${cleanUsername}`,
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                        },
                        timeout: 10000,
                        httpsAgent: proxyAgent
                    }
                );

                if (response.status === 200 || response.status === 201) {
                    success++;
                    logs.push(`✅ Pesan ${i+1}/${sendCount} berhasil`);
                } else {
                    errors++;
                    logs.push(`❌ Pesan ${i+1}/${sendCount} gagal (${response.status})`);
                }
            } catch (error) {
                errors++;
                logs.push(`❌ Pesan ${i+1}/${sendCount} gagal: ${error.message}`);
            }

            if (i < sendCount - 1) {
                await new Promise(resolve => setTimeout(resolve, 100));
            }
        }

        logs.push(`📊 Selesai: ${success} berhasil, ${errors} gagal dari ${sendCount}`);

        res.json({
            success: true,
            success: success,
            errors: errors,
            logs: logs
        });

    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// ============================================
// ENDPOINT: STATISTIK NGL
// ============================================
app.get('/api/ngl-stats', (req, res) => {
    try {
        res.json({
            success: true,
            userStats: {
                todayUsage: 0,
                dailyLimit: 200,
                remaining: 200
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// ============================================
// ENDPOINT: KIRIM EMAIL (ASLI)
// ============================================
app.post('/api/send-email', async (req, res) => {
    try {
        const { accountId, to, subject, message, count } = req.body;

        if (!accountId || !to || !subject || !message) {
            return res.status(400).json({
                success: false,
                message: 'Account, tujuan, subject, dan pesan wajib diisi'
            });
        }

        const account = EMAIL_ACCOUNTS.find(a => a.id === accountId);
        if (!account) {
            return res.status(400).json({
                success: false,
                message: 'Account tidak ditemukan'
            });
        }

        let sendCount = Math.min(count || 1, 25);
        const targets = to.split(',').map(t => t.trim()).filter(t => t);

        const results = {
            total: sendCount * targets.length,
            sent: 0,
            failed: 0,
            errors: []
        };

        const db = readEmailDB();

        for (let i = 0; i < sendCount; i++) {
            for (let target of targets) {
                const result = await sendEmailWithRetry(account, target, subject, message, 3);

                if (result.success) {
                    results.sent++;
                    db.emails.push({
                        id: result.messageId,
                        account: account.name,
                        from: account.email,
                        to: target,
                        subject: subject + (sendCount > 1 ? ` #${i+1}` : ''),
                        message: message,
                        status: 'menunggu balasan',
                        sent_at: new Date().toISOString(),
                        replied: false,
                        reply: null,
                        replied_at: null,
                        retries: 0
                    });
                } else {
                    results.failed++;
                    results.errors.push(`Email ke ${target} #${i+1}: ${result.error}`);
                }

                if (results.sent + results.failed < results.total) {
                    await new Promise(resolve => setTimeout(resolve, 500));
                }
            }
        }

        saveEmailDB(db);

        res.json({
            success: true,
            results: results,
            total_emails: db.emails.length
        });

    } catch (error) {
        console.error('Email Error:', error);
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

// ============================================
// ENDPOINT: GET ACCOUNTS
// ============================================
app.get('/api/get-accounts', (req, res) => {
    try {
        const accounts = EMAIL_ACCOUNTS.map(a => ({
            id: a.id,
            name: a.name,
            email: a.email
        }));
        res.json({
            success: true,
            accounts: accounts
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

// ============================================
// ENDPOINT: GET EMAILS
// ============================================
app.get('/api/get-emails', (req, res) => {
    try {
        const db = readEmailDB();
        res.json({
            success: true,
            emails: db.emails
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

// ============================================
// ENDPOINT: CEK BALASAN
// ============================================
app.get('/api/check-replies', async (req, res) => {
    try {
        const db = readEmailDB();
        const replies = await checkRepliesAtom();

        let updated = 0;

        if (replies.length > 0) {
            replies.forEach(reply => {
                const matchedEmail = db.emails.find(e =>
                    e.status === 'menunggu balasan' &&
                    !e.replied &&
                    (reply.subject.includes(e.subject) ||
                     e.subject.includes(reply.subject))
                );

                if (matchedEmail) {
                    matchedEmail.replied = true;
                    matchedEmail.reply = reply.text || reply.subject;
                    matchedEmail.replied_at = new Date().toISOString();
                    matchedEmail.status = 'sudah dibalas';
                    updated++;
                }
            });

            if (updated > 0) {
                saveEmailDB(db);
            }
        }

        const updatedDb = readEmailDB();
        res.json({
            success: true,
            new_replies: replies.length,
            matched: updated,
            emails: updatedDb.emails
        });

    } catch (error) {
        console.error('Error cek balasan:', error);
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

// ============================================
// ENDPOINT: GENERATE API KEY
// ============================================
app.post('/api/generate-key', (req, res) => {
    const { userId } = req.body;
    if (!userId) return res.status(400).json({ error: 'UserId required' });

    const apiKey = 'as-' + uuidv4().replace(/-/g, '').substring(0, 24);
    users[userId] = { apiKey, chats: [] };
    saveUsers(users);
    res.json({ success: true, apiKey });
});

// ============================================
// ENDPOINT: VERIFY API KEY
// ============================================
app.post('/api/verify-key', (req, res) => {
    const { apiKey } = req.body;
    if (!apiKey) return res.status(400).json({ error: 'API Key required' });

    for (const [userId, data] of Object.entries(users)) {
        if (data.apiKey === apiKey) {
            return res.json({ success: true, userId, apiKey });
        }
    }
    res.status(401).json({ error: 'Invalid API Key' });
});

// ============================================
// ENDPOINT: GET CHAT HISTORY
// ============================================
app.get('/api/chats/:userId', (req, res) => {
    const userId = req.params.userId;
    if (users[userId]) {
        res.json({ chats: users[userId].chats || [] });
    } else {
        res.json({ chats: [] });
    }
});

// ============================================
// ENDPOINT: IPHONE QUOTE (PAKE API ALTERNATIF)
// ============================================
app.post('/api/generate-quote', async (req, res) => {
    try {
        const { time, battery, carrier, message } = req.body;

        if (!time || !battery || !carrier || !message) {
            return res.status(400).json({
                success: false,
                error: 'Semua field wajib diisi'
            });
        }

        const apis = [
            `https://api.iphonequotes.vercel.app/generate?time=${time}&battery=${battery}&carrier=${carrier}&message=${message}`,
            `https://iphone-quote-api.cyclic.app/generate?time=${time}&battery=${battery}&carrier=${carrier}&message=${message}`,
            `https://iphonequotes.onrender.com/generate?time=${time}&battery=${battery}&carrier=${carrier}&message=${message}`
        ];

        let imageData = null;

        for (const url of apis) {
            try {
                const response = await axios.get(url, {
                    responseType: 'arraybuffer',
                    timeout: 15000,
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                        'Accept': 'image/png,image/*,*/*'
                    }
                });

                if (response.data && response.data.length > 500) {
                    imageData = response.data;
                    break;
                }
            } catch (error) {}
        }

        if (imageData) {
            res.set('Content-Type', 'image/png');
            res.set('Cache-Control', 'public, max-age=3600');
            return res.send(imageData);
        }

        // FALLBACK SIMULASI
        const svg = `
        <svg width="400" height="700" xmlns="http://www.w3.org/2000/svg">
            <rect width="400" height="700" fill="#1a1a2e" rx="30"/>
            <text x="50" y="40" fill="white" font-family="Arial" font-size="16">${time}</text>
            <text x="350" y="40" fill="white" font-family="Arial" font-size="14" text-anchor="end"> ⚡${battery}%</text>
            <text x="200" y="65" fill="#888" font-family="Arial" font-size="12" text-anchor="middle">${carrier}</text>
            <rect x="30" y="100" width="340" height="200" rx="20" fill="#1a1a2e" stroke="#333" stroke-width="1"/>
            <text x="50" y="140" fill="white" font-family="Arial" font-size="18">
                <tspan x="50" dy="0">${message}</tspan>
            </text>
            <text x="200" y="670" fill="#444" font-family="Arial" font-size="12" text-anchor="middle">Generated by Twice Panel</text>
        </svg>
        `;

        res.set('Content-Type', 'image/svg+xml');
        res.set('Cache-Control', 'public, max-age=3600');
        res.send(svg);

    } catch (error) {
        console.error('❌ Error:', error.message);
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// ============================================
// ENDPOINT: IPHONE QUOTE GET
// ============================================
app.get('/api/iphone-quote', async (req, res) => {
    try {
        const { time, batteryPercentage, carrierName, messageText } = req.query;

        if (!time || !batteryPercentage || !carrierName || !messageText) {
            return res.status(400).json({
                success: false,
                error: 'Semua parameter wajib diisi'
            });
        }

        const apis = [
            `https://api.iphonequotes.vercel.app/generate?time=${time}&battery=${batteryPercentage}&carrier=${carrierName}&message=${messageText}`,
            `https://iphone-quote-api.cyclic.app/generate?time=${time}&battery=${batteryPercentage}&carrier=${carrierName}&message=${messageText}`,
            `https://iphonequotes.onrender.com/generate?time=${time}&battery=${batteryPercentage}&carrier=${carrierName}&message=${messageText}`
        ];

        let imageData = null;

        for (const url of apis) {
            try {
                const response = await axios.get(url, {
                    responseType: 'arraybuffer',
                    timeout: 15000,
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                        'Accept': 'image/png,image/*,*/*'
                    }
                });

                if (response.data && response.data.length > 500) {
                    imageData = response.data;
                    break;
                }
            } catch (error) {}
        }

        if (imageData) {
            res.set('Content-Type', 'image/png');
            return res.send(imageData);
        }

        const svg = `
        <svg width="400" height="700" xmlns="http://www.w3.org/2000/svg">
            <rect width="400" height="700" fill="#1a1a2e" rx="30"/>
            <text x="50" y="40" fill="white" font-family="Arial" font-size="16">${time}</text>
            <text x="350" y="40" fill="white" font-family="Arial" font-size="14" text-anchor="end"> ⚡${batteryPercentage}%</text>
            <text x="200" y="65" fill="#888" font-family="Arial" font-size="12" text-anchor="middle">${carrierName}</text>
            <rect x="30" y="100" width="340" height="200" rx="20" fill="#1a1a2e" stroke="#333" stroke-width="1"/>
            <text x="50" y="140" fill="white" font-family="Arial" font-size="18">
                <tspan x="50" dy="0">${messageText}</tspan>
            </text>
            <text x="200" y="670" fill="#444" font-family="Arial" font-size="12" text-anchor="middle">Generated by Twice Panel</text>
        </svg>
        `;

        res.set('Content-Type', 'image/svg+xml');
        res.send(svg);

    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// ============================================
// ENDPOINT: TIKTOK DOWNLOADER (REAL)
// ============================================
app.post('/api/tiktok', async (req, res) => {
    try {
        const { url } = req.body;

        if (!url) {
            return res.status(400).json({
                success: false,
                message: 'URL TikTok wajib diisi'
            });
        }

        // API TikTok downloader (gratis)
        const apis = [
            `https://api.tikmate.app/api/lookup?url=${encodeURIComponent(url)}`,
            `https://www.tikwm.com/api/?url=${encodeURIComponent(url)}`,
            `https://tikdown.org/api/ajaxSearch?q=${encodeURIComponent(url)}`
        ];

        let result = null;

        for (const apiUrl of apis) {
            try {
                const response = await axios.get(apiUrl, {
                    timeout: 15000,
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                        'Accept': 'application/json'
                    }
                });

                const data = response.data;

                // Cek TikWM API
                if (data && data.data && data.data.play) {
                    result = {
                        success: true,
                        title: data.data.title || 'Video TikTok',
                        video: data.data.play || data.data.wmplay || data.data.hdplay || data.data.play,
                        audio: data.data.music || data.data.audio || null
                    };
                    break;
                }

                // Cek TikMate API
                if (data && data.video_url) {
                    result = {
                        success: true,
                        title: data.title || 'Video TikTok',
                        video: data.video_url || data.video,
                        audio: data.music_url || null
                    };
                    break;
                }

                // Cek TikDown API
                if (data && data.data && data.data.video) {
                    result = {
                        success: true,
                        title: data.data.title || 'Video TikTok',
                        video: data.data.video || data.data.video_watermark || null,
                        audio: data.data.music || null
                    };
                    break;
                }

            } catch (error) {
                console.log('API TikTok error:', error.message);
                continue;
            }
        }

        if (result && result.video) {
            return res.json(result);
        }

        // FALLBACK: Coba pakai API lain
        try {
            const fallbackApi = `https://api.tiktokapi.com/video?url=${encodeURIComponent(url)}`;
            const response = await axios.get(fallbackApi, {
                timeout: 10000,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });

            if (response.data && response.data.video) {
                return res.json({
                    success: true,
                    title: response.data.title || 'Video TikTok',
                    video: response.data.video,
                    audio: response.data.audio || null
                });
            }
        } catch (error) {}

        // Jika semua gagal
        return res.status(500).json({
            success: false,
            message: 'Gagal mengambil video TikTok. Coba lagi nanti.'
        });

    } catch (error) {
        console.error('TikTok Error:', error);
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

// ============================================
// ENDPOINT: TIKTOK DOWNLOADER V2
// ============================================
app.get('/api/tiktok-download', async (req, res) => {
    try {
        const { url } = req.query;

        if (!url) {
            return res.status(400).json({
                success: false,
                message: 'URL TikTok wajib diisi'
            });
        }

        const apiUrl = `https://www.tikwm.com/api/?url=${encodeURIComponent(url)}`;
        const response = await axios.get(apiUrl, {
            timeout: 15000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Accept': 'application/json'
            }
        });

        const data = response.data;

        if (data && data.data && data.data.play) {
            return res.json({
                success: true,
                title: data.data.title || 'Video TikTok',
                video: data.data.play || data.data.wmplay || data.data.hdplay,
                audio: data.data.music || data.data.audio || null,
                author: data.data.author || null,
                duration: data.data.duration || 0,
                views: data.data.views || 0,
                likes: data.data.likes || 0
            });
        }

        res.status(500).json({
            success: false,
            message: 'Gagal mengambil video TikTok'
        });

    } catch (error) {
        console.error('TikTok Error:', error);
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

// ============================================
// SOCKET.IO EVENTS
// ============================================
io.on('connection', (socket) => {
    console.log('User connected:', socket.id);

    socket.on('join', ({ apiKey }) => {
        socket.apiKey = apiKey;
        for (const [userId, data] of Object.entries(users)) {
            if (data.apiKey === apiKey) {
                socket.userId = userId;
                socket.join(`user_${userId}`);
                console.log(`User ${userId} joined`);
                break;
            }
        }
    });

    socket.on('send-message', ({ toApiKey, message }) => {
        let targetUserId = null;
        for (const [userId, data] of Object.entries(users)) {
            if (data.apiKey === toApiKey) {
                targetUserId = userId;
                break;
            }
        }

        if (!targetUserId) {
            socket.emit('error', { message: 'User not found' });
            return;
        }

        const msgData = {
            from: socket.apiKey,
            to: toApiKey,
            message,
            timestamp: new Date().toISOString(),
            read: false
        };

        if (users[socket.userId]) {
            if (!users[socket.userId].chats) users[socket.userId].chats = [];
            users[socket.userId].chats.push(msgData);
        }

        if (users[targetUserId]) {
            if (!users[targetUserId].chats) users[targetUserId].chats = [];
            users[targetUserId].chats.push(msgData);
        }

        saveUsers(users);

        io.to(`user_${targetUserId}`).emit('new-message', {
            from: socket.apiKey,
            message,
            timestamp: msgData.timestamp
        });

        socket.emit('message-sent', { success: true });
    });

    socket.on('disconnect', () => {
        console.log('User disconnected:', socket.id);
    });
});

// ============================================
// START SERVER
// ============================================
server.listen(PORT, '0.0.0.0', () => {
    console.log(`✅ Server berjalan di http://localhost:${PORT}`);
    console.log(`📱 Buka: http://localhost:${PORT}`);
    console.log(`📌 NGL: PAKE PROXY TOR (ganti IP)`);
    console.log(`📌 iPhone Quote: 3 API + fallback SVG`);
    console.log(`📌 TikTok Downloader: API TikWM + fallback`);
});