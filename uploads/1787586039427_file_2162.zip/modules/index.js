// STABILITAS: Jangan biarkan unhandled error bikin proses mati total,
// tapi JANGAN ditelan diam-diam. Catat ke stderr supaya kelihatan di log
// PM2 / journalctl / terminal. Sebelumnya error ditelan total (handler
// kosong + console.error di-no-op) sehingga bug sulit dilacak.
process.on('unhandledRejection', (reason, promise) => {
  try {
    const msg = reason && reason.stack ? reason.stack : String(reason);
    process.stderr.write(`[unhandledRejection] ${msg}\n`);
  } catch (_) {}
});
process.on('uncaughtException', (err) => {
  try {
    const msg = err && err.stack ? err.stack : String(err);
    process.stderr.write(`[uncaughtException] ${msg}\n`);
  } catch (_) {}
});
process.on('warning', (warning) => {
  try {
    process.stderr.write(`[warning] ${warning && warning.stack ? warning.stack : warning}\n`);
  } catch (_) {}
});
// Jangan no-op console.error/warn lagi — biarkan error terlihat.
// (logger.js sendiri sudah handle logging ke file)

const TelegramBot = require('node-telegram-bot-api');
const sqlite3 = require('sqlite3').verbose();
const { open } = require('sqlite');
const fs = require('fs');
const os = require('os');
const path = require('path');
const axios = require('axios');
const archiver = require('archiver');
const AdmZip = require('adm-zip');
const { TelegramClient } = require('telegram');
const { StringSession } = require('telegram/sessions');
const lazyUbot = require('../system/lazyUbot');
const { Api } = require('telegram');
const { computeCheck } = require('telegram/Password');
const crypto = require('crypto');
const QRCode = require('qrcode');
const chalk = require('chalk');
const moment = require('moment');
const input = require('input');

// ===== DEPOSIT OTOMATIS (PAKASIR) =====
const {
  PAKASIR_SLUG,
  PAKASIR_APIKEY,
  PAKASIR_METHOD,
  PAKASIR_ADMIN_FEE,
  PAKASIR_EXPIRY_MS,
  PAKASIR_POLL_INTERVAL_MS,
} = require('../setting/config');

// Deposit otomatis hanya aktif kalau slug & api key sudah diisi di config.js.
// Kalau kosong, menu otomatis otomatis disembunyikan dan bot tetap jalan
// normal dengan deposit manual saja (tidak crash).
const PAKASIR_ENABLED = !!(PAKASIR_SLUG && PAKASIR_APIKEY);
const pakasir = PAKASIR_ENABLED ? require('../system/pakasir')(PAKASIR_SLUG, PAKASIR_APIKEY) : null;

// Menyimpan payment yang sedang berjalan supaya checkFelixStatus /
// cancelFelixOrder tahu nominal aslinya (dibutuhkan API Pakasir).
global.activePayments = global.activePayments || {};
global.produkPayments = global.produkPayments || {};

// BUG FIX: sebelumnya semua path ini pakai path relatif ('./database/...'),
// yang di-resolve relatif terhadap process.cwd() (direktori tempat proses
// dijalankan), BUKAN relatif terhadap lokasi file ini. Kalau bot dijalankan
// dari cwd yang berbeda (mis. lewat pm2 start dari /root), './database'
// jadi menunjuk ke folder yang salah/tidak ada -> ENOENT spam terus tiap
// interval nyoba nulis. Diganti ke path absolut berbasis __dirname biar
// selalu konsisten ke folder database/ project ini, gak peduli dari mana
// proses dijalankan.
const databaseDir = path.join(__dirname, '../database');
const DB_PATH = path.join(databaseDir, 'database.sqlite');
const backupsDir = path.join(databaseDir, 'backups');
const STATE_FILE = path.join(databaseDir, 'state.json');
const AUTO_RESTORE_FILE = path.join(databaseDir, 'auto_restore_state.json');
const AUTO_RESTART_FILE = path.join(databaseDir, 'auto_restart.json');
const PRODUK_BARU_FILE = path.join(databaseDir, 'produk_baru.json');
const ORDER_BARU_FILE = path.join(databaseDir, 'order_baru.json');
const PRODUK_BALANCE_FILE = path.join(databaseDir, 'produk_balance.json');
const PRODUK_TRANSACTIONS_FILE = path.join(databaseDir, 'produk_transactions.json');
const LIST_ACCESS_FILE = path.join(databaseDir, 'list_access.json');

// Pengaman tambahan: pastikan folder database/ (dan backups/) selalu ada
// sebelum dipakai, biar gak ENOENT walau folder belum pernah dibuat manual.
try {
  if (!fs.existsSync(databaseDir)) {
    fs.mkdirSync(databaseDir, { recursive: true });
  }
  if (!fs.existsSync(backupsDir)) {
    fs.mkdirSync(backupsDir, { recursive: true });
  }
} catch (e) {
  console.error('Gagal membuat folder database:', e);
}

// Bikin file list_access.json kalo belum ada
if (!fs.existsSync(LIST_ACCESS_FILE)) {
  fs.writeFileSync(LIST_ACCESS_FILE, JSON.stringify([], null, 2));
}

const logger = require('../system/logger.js');

// ===== FUNGSI LIST ACCESS =====
// Source of truth untuk semua akses premium
// Biar aman walau database direset

function loadListAccess() {
  try {
    if (fs.existsSync(LIST_ACCESS_FILE)) {
      const data = fs.readFileSync(LIST_ACCESS_FILE, 'utf8');
      return JSON.parse(data);
    }
    return [];
  } catch (error) {
    logger.error('loadListAccess error:', error);
    return [];
  }
}

function saveListAccess(accessList) {
  try {
    fs.writeFileSync(LIST_ACCESS_FILE, JSON.stringify(accessList, null, 2));
    return true;
  } catch (error) {
    logger.error('saveListAccess error:', error);
    return false;
  }
}

function findAccessByUserId(userId, accessList = null) {
  if (!accessList) accessList = loadListAccess();
  return accessList.find(item => item.id === userId);
}

function findActiveAccessByUserId(userId, accessList = null) {
  if (!accessList) accessList = loadListAccess();
  const now = Math.floor(Date.now() / 1000);
  
  // Ambil semua akses aktif user
  const activeAccess = accessList.filter(item => item.id === userId && item.expired_at > now);
  
  if (activeAccess.length === 0) return null;
  if (activeAccess.length === 1) return activeAccess[0];
  
  // Urutan prioritas dari tertinggi ke terendah
  const priority = {
    'reseller': 4,
    'pro': 3,
    'basic': 2,
    'trial': 1
  };
  
  // Sortir berdasarkan prioritas tertinggi
  activeAccess.sort((a, b) => (priority[b.role] || 0) - (priority[a.role] || 0));
  
  return activeAccess[0];
}

function addAccess(userId, duration, role, accessList = null) {
  if (!accessList) accessList = loadListAccess();
  
  const now = Math.floor(Date.now() / 1000);
  let durationSeconds = 0;
  let durationText = duration;
  
  // Kasus khusus: lifetime (akses seumur hidup)
  if (duration === 'lifetime') {
    durationSeconds = 100 * 365 * 86400; // 100 tahun
    durationText = 'lifetime';
  } else {
    // BUG FIX (v10.2): dulu ada regex duplikat di sini yang terpisah dari
    // parseDurationToSeconds() -- dua salinan logika yang sama gampang jadi
    // tidak sinkron kalau salah satu diubah tanpa yang lain (seperti yang
    // sempat terjadi pada bug format durasi /addprem). Sekarang addAccess()
    // memakai fungsi parser yang sama dengan /addprem & /addreseller supaya
    // hasilnya selalu konsisten di seluruh bot.
    const parsedSeconds = parseDurationToSeconds(duration);
    if (parsedSeconds) {
      durationSeconds = parsedSeconds;
    } else {
      // fallback: anggap hari
      durationSeconds = parseInt(duration) * 86400 || 86400;
      durationText = duration + 'd';
    }
  }
  
  const expiredAt = now + durationSeconds;
  
  // Cek udah ada, update
  const existing = accessList.find(item => item.id === userId);
  if (existing) {
    existing.duration = durationText;
    existing.role = role;
    existing.expired_at = expiredAt;
    existing.updated_at = now;
  } else {
    accessList.push({
      id: userId,
      duration: durationText,
      role: role,
      expired_at: expiredAt,
      added_at: now,
      updated_at: now
    });
  }
  
  saveListAccess(accessList);
  return accessList;
}

function removeAccess(userId, accessList = null) {
  if (!accessList) accessList = loadListAccess();
  const filtered = accessList.filter(item => item.id !== userId);
  if (filtered.length !== accessList.length) {
    saveListAccess(filtered);
    return filtered;
  }
  return accessList;
}

// Bersihin user yang punya multiple akses - ambil yang tertinggi
function cleanupUserAccess(userId) {
  const accessList = loadListAccess();
  const userAccess = accessList.filter(item => item.id === userId);
  
  if (userAccess.length <= 1) return accessList;
  
  const now = Math.floor(Date.now() / 1000);
  const priority = { 'reseller': 4, 'pro': 3, 'basic': 2, 'trial': 1 };
  
  // Urutkan dari tertinggi
  userAccess.sort((a, b) => (priority[b.role] || 0) - (priority[a.role] || 0));
  
  // Ambil akses tertinggi yang masih aktif
  const bestAccess = userAccess.find(item => item.expired_at > now) || userAccess[0];
  
  // Hapus semua akses user, terus tambahin yang terbaik aja
  const filtered = accessList.filter(item => item.id !== userId);
  filtered.push(bestAccess);
  
  saveListAccess(filtered);
  return filtered;
}

function isUserHasAccess(userId, role = null, accessList = null) {
  if (!accessList) accessList = loadListAccess();
  const now = Math.floor(Date.now() / 1000);
  const active = accessList.filter(item => item.id === userId && item.expired_at > now);
  if (active.length === 0) return false;
  if (role) {
    return active.some(item => item.role === role);
  }
  return true;
}

function getAccessInfo(userId, accessList = null) {
  if (!accessList) accessList = loadListAccess();
  const now = Math.floor(Date.now() / 1000);
  return accessList.find(item => item.id === userId && item.expired_at > now);
}

// Sync dari database ke list_access (buat migrasi data lama)
async function syncDatabaseToAccessList() {
  const accessList = loadListAccess();
  let changed = false;
  
  // Ambil dari premium_wm
  const wmUsers = await db.all('SELECT user_id, expired FROM premium_wm');
  for (const u of wmUsers) {
    const now = Math.floor(Date.now() / 1000);
    if (u.expired > now) {
      const duration = Math.ceil((u.expired - now) / 86400) + 'd';
      const existing = accessList.find(item => item.id === u.user_id);
      if (!existing || existing.role !== 'basic') {
        accessList.push({
          id: u.user_id,
          duration: duration,
          role: 'basic',
          expired_at: u.expired,
          added_at: now,
          updated_at: now
        });
        changed = true;
      } else if (existing.expired_at < u.expired) {
        existing.expired_at = u.expired;
        existing.duration = duration;
        existing.updated_at = now;
        changed = true;
      }
    }
  }
  
  // Ambil dari premium_no_wm
  const nowmUsers = await db.all('SELECT user_id, expired FROM premium_no_wm');
  for (const u of nowmUsers) {
    const now = Math.floor(Date.now() / 1000);
    if (u.expired > now) {
      const duration = Math.ceil((u.expired - now) / 86400) + 'd';
      const existing = accessList.find(item => item.id === u.user_id);
      if (!existing || existing.role !== 'pro') {
        accessList.push({
          id: u.user_id,
          duration: duration,
          role: 'pro',
          expired_at: u.expired,
          added_at: now,
          updated_at: now
        });
        changed = true;
      } else if (existing.expired_at < u.expired) {
        existing.expired_at = u.expired;
        existing.duration = duration;
        existing.updated_at = now;
        changed = true;
      }
    }
  }
  
  // Ambil dari reseller_list dengan expired
  const resellerUsers = await db.all('SELECT user_id, expired FROM reseller_list');
  for (const u of resellerUsers) {
    const now = Math.floor(Date.now() / 1000);
    let expiredAt = u.expired || (now + (100 * 365 * 86400));
    let duration = 'lifetime';
    
    // Kalo ada expired, itung durasi
    if (u.expired && u.expired > now) {
      const diffDays = Math.ceil((u.expired - now) / 86400);
      duration = diffDays + 'd';
    }
    
    const existing = accessList.find(item => item.id === u.user_id);
    if (!existing || existing.role !== 'reseller') {
      accessList.push({
        id: u.user_id,
        duration: duration,
        role: 'reseller',
        expired_at: expiredAt,
        added_at: now,
        updated_at: now
      });
      changed = true;
    } else if (existing.expired_at < expiredAt) {
      existing.expired_at = expiredAt;
      existing.duration = duration;
      existing.updated_at = now;
      changed = true;
    }
  }
  
  if (changed) {
    saveListAccess(accessList);
    logger.info('List access synced from database');
  }
  
  return accessList;
}

// ===== AKHIR FUNGSI LIST ACCESS =====

const {
  sendStartupNotification, 
  sendShutdownNotification 
} = require('../system/notifUserbot.js');

const { 
  BOT_TOKEN,
  OWNER_ID,
  OWNER_USERNAME,
  LOG_GROUP,
  REQUIRED_CHANNEL,
  REQUIRED_GROUP,
  JOIN_CHECK_CHAT_ID,
  JOIN_FOLDER_LINK,
  API_ID,
  API_HASH,
  WM,
  QRIS_IMAGE,
  menuEffects,
  getRandomEffect,
  config,
  getTelegramClientConfig,
  maintenanceMode,
} = require('../setting/config.js');

// Helper aman untuk cek owner (hindari mismatch number vs string dari Telegram API)
function isOwnerId(id) {
  return String(id) === String(OWNER_ID);
}

// BUG FIX (RACE CONDITION SAAT STARTUP): sebelumnya `autoStart: true`,
// artinya bot LANGSUNG mulai nerima & memproses pesan/klik user dari
// Telegram begitu file ini di-load — padahal `initDatabase()` (yang bikin
// & isi tabel-tabel termasuk tabel `prices`) baru jalan belakangan di
// dalam startBot(), secara ASYNC. Kalau ada user yang mancing bot dalam
// beberapa saat pertama setelah restart (misal klik tombol paket/harga),
// query kayak `SELECT * FROM prices WHERE type = ?` bisa balik `undefined`
// karena tabelnya belum sempat ke-seed, lalu kode berikutnya yang akses
// `prices.price_1` CRASH (`Cannot read properties of undefined`). Ini
// persis pola error "callback_query handler error" yang muncul tanpa
// jelas penyebabnya di awal-awal restart.
// Sekarang polling TIDAK auto-start; baru dimulai manual di akhir
// startBot(), SETELAH semua proses init (termasuk initDatabase) selesai.
const bot = new TelegramBot(BOT_TOKEN, {
  polling: {
    autoStart: false,
    interval: 1000,
    params: {
      timeout: 10,
      limit: 10,
      allowed_updates: ['message', 'callback_query', 'chat_member']
    }
  }
});

// BUG FIX: logger.js butuh instance bot buat kirim notifikasi error ke
// owner (sendErrorToOwner). Sebelumnya logger.js require balik index.js
// buat ambil .bot, tapi index.js gak pernah export bot -> selalu undefined,
// notif error ke owner gak pernah kekirim. Sekarang di-set langsung di sini.
logger.setBotInstance(bot);
logger.setOwnerId(OWNER_ID);

// BUG FIX (v10.3 - STABILITAS): SEMUA 13 command handler `bot.onText(...)`
// di file ini (mis. /addprem, /addreseller, /ping, /start, dst) TIDAK punya
// try/catch pembungkus sama sekali. Beda dengan bot.on('message', ...) dan
// bot.on('callback_query', ...) yang sudah dibungkus try/catch global -
// kalau ada exception tak terduga di dalam command handler (mis. DB lagi
// locked, network error dari Telegram API, null reference), exception itu
// jadi UnhandledPromiseRejection: proses TIDAK crash (sudah ditangkap
// process.on('unhandledRejection') di paling atas file), TAPI orang yang
// menjalankan command itu SAMA SEKALI tidak dapat respons apa pun - kelihatan
// seperti bot "hang"/tidak merespons, padahal sebenarnya cuma command itu
// yang gagal diam-diam.
//
// safeOnText() adalah pengganti drop-in untuk bot.onText(): perilaku
// pencocokan pattern & pemanggilan callback-nya identik, cuma ditambah
// try/catch yang (a) mencatat error lewat logger supaya kelihatan di log,
// dan (b) memberi tahu user "coba lagi" alih-alih diam total.
function safeOnText(pattern, handler) {
  bot.onText(pattern, async (msg, match) => {
    try {
      await handler(msg, match);
    } catch (error) {
      const chatId = msg && msg.chat && msg.chat.id;
      const cmdLabel = (msg && msg.text) ? msg.text.split(' ')[0] : String(pattern);
      logger.error(`command handler error (${cmdLabel}):`, error && error.stack ? error.stack : error);
      if (chatId) {
        try {
          await bot.sendMessage(chatId, `<blockquote>⚠️ <b><u>TERJADI ERROR</u></b>
🔄 <b>Coba lagi ya. Kalau masih error, cek log server.</b></blockquote>`, { parse_mode: 'HTML' });
        } catch (sendErr) {}
      }
    }
  });
}


// PERFORMANCE FIX: sebelumnya bot.getMe() dipanggil ULANG ke Telegram API di
// ~16 tempat berbeda (hampir di setiap handler menu/command), padahal data
// bot (username, first_name, dst) praktis nggak pernah berubah selama bot
// hidup. Kalau user rame & banyak yang klik menu bersamaan, semua request
// numpuk manggil getMe() secara paralel dan gampang kena rate limit Telegram
// (429), yang bikin SEMUA respon bot ikut ketunda/ngelag. Sekarang di-cache
// sekali di memori, jadi cuma 1 API call per proses (auto-refresh tiap 1 jam
// buat jaga-jaga kalau ada perubahan profil bot).
let _cachedBotInfo = null;
let _cachedBotInfoAt = 0;
const BOT_INFO_CACHE_TTL = 60 * 60 * 1000; // 1 jam

async function getCachedBotInfo() {
  if (_cachedBotInfo && (Date.now() - _cachedBotInfoAt) < BOT_INFO_CACHE_TTL) {
    return _cachedBotInfo;
  }
  try {
    _cachedBotInfo = await bot.getMe();
    _cachedBotInfoAt = Date.now();
  } catch (e) {
    logger.warn(`getCachedBotInfo: gagal ambil getMe(), pakai cache lama kalau ada: ${e.message}`);
    if (_cachedBotInfo) return _cachedBotInfo;
    throw e;
  }
  return _cachedBotInfo;
}

// BUG FIX (v10.1): bot.deleteMessage() lempar ETELEGRAM 400 kalau pesan yang
// mau dihapus sudah tidak ada lagi (mis. user tap tombol dua kali dengan cepat,
// pesan sudah >48 jam, atau sudah dihapus manual/oleh handler lain). Sebelumnya
// hampir semua pemanggilan bot.deleteMessage() di file ini TIDAK dibungkus
// try/catch, jadi error semacam ini bikin seluruh handler callback_query/message
// berhenti di tengah jalan (tombol jadi kelihatan macet/tidak merespons).
// safeDeleteMessage() dipakai sebagai pengganti drop-in: kalau pesannya memang
// sudah hilang, itu bukan kegagalan yang perlu dipedulikan (tujuan akhirnya --
// pesan tidak ada -- sudah tercapai), jadi cukup diabaikan. Error lain yang
// tidak terduga tetap dicatat lewat logger biar tidak sepenuhnya senyap.
async function safeDeleteMessage(chatId, messageId, options) {
  try {
    await bot.deleteMessage(chatId, messageId, options);
    return true;
  } catch (err) {
    const msg = (err && err.message) || '';
    const isBenign = /message to delete not found/i.test(msg) ||
      /message can.?t be deleted/i.test(msg) ||
      /message identifier is not specified/i.test(msg) ||
      /chat not found/i.test(msg);
    if (!isBenign) {
      logger.warn(`safeDeleteMessage gagal (chatId=${chatId}, messageId=${messageId}): ${msg}`);
    }
    return false;
  }
}

// BUG FIX (v10.4 - STABILITAS): Telegram cuma mengizinkan SATU jawaban
// (answerCallbackQuery) per callback_query. Handler utama bot.on('callback_query')
// sudah menjawab kosong di awal (supaya loading spinner di tombol langsung
// hilang), TAPI ada 113 titik lain di file ini (banyak di antaranya berupa
// validasi seperti "❌ Maksimal 150 hari") yang mencoba menjawab LAGI dengan
// teks alert. Jawaban kedua itu selalu gagal (exception), dan karena tidak
// ditangkap lokal, exception itu MENGHENTIKAN sisa kode di branch tersebut --
// jadi aksi yang seharusnya jalan (edit pesan, simpan data, dst) tidak pernah
// tereksekusi sama sekali. Ini akar dari keluhan "tombol ditekan tapi gak ada
// respons": bukan bot-nya diam, tapi kodenya berhenti di tengah jalan tanpa
// suara. safeAnswerCallbackQuery menggantikan bot.answerCallbackQuery secara
// drop-in: kalau jawabannya gagal karena sudah pernah dijawab, sisa kode tetap
// lanjut jalan seperti biasa, dan kalau ada teks alert yang seharusnya dilihat
// user, itu dikirim sebagai pesan chat biasa supaya user tetap dapat feedback.
async function safeAnswerCallbackQuery(callbackQuery, text, showAlert) {
  try {
    await bot.answerCallbackQuery(callbackQuery.id, text, showAlert);
    return true;
  } catch (err) {
    // Ekstrak teks yang mau ditampilkan, baik gaya lama (text sebagai
    // string) maupun gaya objek options { text, show_alert } yang juga
    // dipakai di beberapa tempat di file ini.
    let fallbackText = null;
    if (typeof text === 'string') fallbackText = text;
    else if (text && typeof text === 'object' && typeof text.text === 'string') fallbackText = text.text;

    if (fallbackText) {
      try {
        const chatId = callbackQuery.message && callbackQuery.message.chat && callbackQuery.message.chat.id;
        if (chatId) {
          const plainText = fallbackText.replace(/<[^>]+>/g, '');
          await bot.sendMessage(chatId, plainText);
        }
      } catch (e) {}
    }
    return false;
  }
}

// BUG FIX (v10.5 - STABILITAS): bot.editMessageText()/editMessageReplyMarkup()
// lempar ETELEGRAM 400 "message is not modified" kalau konten baru yang mau
// ditulis PERSIS SAMA dengan konten pesan yang sekarang (mis. user tap tombol
// yang sama dua kali, atau state-nya belum berubah). Dari 76 pemanggilan
// editMessageText/editMessageReplyMarkup di file ini, 71 di antaranya TIDAK
// dibungkus try/catch -- persis pola bug yang sama dengan deleteMessage dan
// answerCallbackQuery yang sudah diperbaiki sebelumnya. Errornya bikin sisa
// kode di branch tersebut berhenti total, jadi tombol kelihatan "gak ada
// respons" (ini yang menyebabkan error "use_token" yang dilaporkan).
// safeEditMessageText/safeEditMessageReplyMarkup menggantikan drop-in:
// kalau memang gagal karena isinya sama persis, itu bukan kegagalan nyata
// (tujuannya -- pesan menampilkan konten X -- sudah tercapai), jadi cukup
// diabaikan. Error lain yang tidak terduga tetap dicatat.
function isBenignEditError(err) {
  const msg = (err && err.message) || '';
  return /message is not modified/i.test(msg) ||
    /message to edit not found/i.test(msg) ||
    /message can.?t be edited/i.test(msg) ||
    /query is too old/i.test(msg);
}

async function safeEditMessageText(text, options) {
  try {
    return await bot.editMessageText(text, options);
  } catch (err) {
    if (!isBenignEditError(err)) {
      logger.warn(`safeEditMessageText gagal (chatId=${options && options.chat_id}, messageId=${options && options.message_id}): ${err.message}`);
    }
    return null;
  }
}

async function safeEditMessageReplyMarkup(replyMarkup, options) {
  try {
    return await bot.editMessageReplyMarkup(replyMarkup, options);
  } catch (err) {
    if (!isBenignEditError(err)) {
      logger.warn(`safeEditMessageReplyMarkup gagal (chatId=${options && options.chat_id}, messageId=${options && options.message_id}): ${err.message}`);
    }
    return null;
  }
}

let db;
let userbots = [];
let chatSessions = {};
let promosiProgress = {};
let waitingForGiveUserId = {};
let userExtendData = {};

let produkBaruData = [];
let produkBaruUserCart = {};
let produkBaruCurrentPage = {};
let produkBaruWaitingAdd = false;
let produkBaruWaitingFile = null;
let produkBaruEditId = null;
let produkBaruWaitingCustomDeposit = {};
let produkBaruDepositAmount = {};
let produkBalance = {};
let produkTransactions = [];

const userPayments = {};
const pendingNotifCooldown = new Map();
const pendingManualPayments = new Map();

function escapeHtml(text) {
  if (typeof text !== "string") return text ?? "";
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

// Konversi ID mentah dari GramJS (userbot) ke format ID ala Bot API (negatif / -100 prefix
// untuk channel & supergroup, negatif untuk grup biasa). WAJIB dipakai setiap kali nyimpen
// group_id hasil ubot.client.getEntity(), karena GramJS ngasih ID mentah (positif) yang beda
// dari yang dipake buat filter grup valid pas mulai broadcast (parseInt(group_id) < 0).
function getMarkedGroupId(entity) {
  const rawId = entity.id.toString();
  if (entity.className === 'Channel' || entity.className === 'ChannelForbidden') {
    return '-100' + rawId;
  } else if (entity.className === 'Chat' || entity.className === 'ChatForbidden') {
    return '-' + rawId;
  }
  return rawId;
}

async function initDatabase() {
  db = await open({
    filename: DB_PATH,
    driver: sqlite3.Database
  });

  // WAL mode + busy timeout: penting banget pas banyak user pakai bareng-bareng.
  // Tanpa ini, dua write yang barengan bakal langsung throw SQLITE_BUSY dan gagal diam-diam.
  await db.exec('PRAGMA journal_mode = WAL;');
  await db.exec('PRAGMA busy_timeout = 10000;');
  await db.exec('PRAGMA synchronous = NORMAL;');

  await db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      user_id TEXT PRIMARY KEY,
      username TEXT,
      full_name TEXT,
      role TEXT DEFAULT 'FREE',
      expired INTEGER,
      has_userbot INTEGER DEFAULT 0,
      phone TEXT,
      created_at INTEGER,
      last_active INTEGER,
      trial_used INTEGER DEFAULT 0,
      added_by TEXT
    );
    
    CREATE TABLE IF NOT EXISTS admin_controls (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      owner_id TEXT NOT NULL,
      admin_id TEXT NOT NULL,
      added_by TEXT NOT NULL,
      created_at INTEGER NOT NULL,
      UNIQUE(owner_id, admin_id),
      FOREIGN KEY (owner_id) REFERENCES users(user_id) ON DELETE CASCADE,
      FOREIGN KEY (admin_id) REFERENCES users(user_id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS orders (
      order_id TEXT PRIMARY KEY,
      user_id TEXT,
      product_id INTEGER,
      product_name TEXT,
      quantity INTEGER,
      total_price INTEGER,
      payment_method TEXT,
      status TEXT DEFAULT 'pending',
      payment_url TEXT,
      qr_code TEXT,
      created_at INTEGER,
      paid_at INTEGER,
      delivered_at INTEGER,
      FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS userbots (
      ubot_id TEXT PRIMARY KEY,
      owner_id TEXT,
      phone TEXT,
      session_string TEXT,
      status TEXT DEFAULT 'AKTIF',
      created_at INTEGER,
      expired INTEGER,
      last_active INTEGER,
      total_sent INTEGER DEFAULT 0,
      FOREIGN KEY (owner_id) REFERENCES users(user_id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      owner_id TEXT,
      local_id INTEGER,
      type TEXT CHECK(type IN ('text', 'photo', 'video', 'document', 'audio', 'voice', 'sticker', 'animation', 'forward')),
      content TEXT,
      file_id TEXT,
      caption TEXT,
      entities_json TEXT,
      from_chat TEXT,
      forward_message_id INTEGER,
      created_at INTEGER,
      FOREIGN KEY (owner_id) REFERENCES users(user_id) ON DELETE CASCADE,
      UNIQUE(owner_id, local_id)
    );

    CREATE TABLE IF NOT EXISTS groups (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      owner_id TEXT,
      group_id TEXT,
      group_title TEXT,
      group_username TEXT,
      added_at INTEGER,
      last_sent INTEGER,
      FOREIGN KEY (owner_id) REFERENCES users(user_id) ON DELETE CASCADE,
      UNIQUE(owner_id, group_id)
    );

    CREATE TABLE IF NOT EXISTS blacklist_groups (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      owner_id TEXT,
      group_id TEXT,
      group_title TEXT,
      reason TEXT,
      added_at INTEGER,
      FOREIGN KEY (owner_id) REFERENCES users(user_id) ON DELETE CASCADE,
      UNIQUE(owner_id, group_id)
    );

    CREATE TABLE IF NOT EXISTS blacklist_users (
      user_id TEXT PRIMARY KEY,
      reason TEXT,
      added_by TEXT,
      added_at INTEGER
    );

    CREATE TABLE IF NOT EXISTS payments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      tx_id TEXT UNIQUE,
      user_id TEXT,
      target_id TEXT,
      type TEXT CHECK(type IN ('wm', 'nowm', 'reseller')),
      duration INTEGER,
      amount INTEGER,
      status TEXT DEFAULT 'PENDING',
      created_at INTEGER,
      expired_at INTEGER,
      paid_at INTEGER,
      pay_url TEXT,
      qr_string TEXT
    );

    CREATE TABLE IF NOT EXISTS prices (
      type TEXT PRIMARY KEY,
      price_1 INTEGER DEFAULT 2000,
      price_2 INTEGER DEFAULT 4000,
      price_3 INTEGER DEFAULT 6000,
      price_4 INTEGER DEFAULT 8000,
      price_5 INTEGER DEFAULT 10000
    );

    INSERT OR REPLACE INTO prices (type, price_1, price_2, price_3, price_4, price_5) VALUES
      ('wm', 2000, 4000, 6000, 8000, 10000),
      ('nowm', 4000, 8000, 12000, 16000, 20000),
      ('reseller', 7000, 14000, 21000, 28000, 35000);

    CREATE TABLE IF NOT EXISTS settings (
      owner_id TEXT PRIMARY KEY,
      delay INTEGER DEFAULT 300,
      jeda INTEGER DEFAULT 20,
      promosi_status TEXT DEFAULT 'OFF',
      watermark TEXT DEFAULT '',
      watermark_status TEXT DEFAULT 'OFF',
      selected_message_id INTEGER,
      safemode INTEGER DEFAULT 1,
      notifikasi TEXT DEFAULT 'all',
      total_rounds INTEGER DEFAULT 0,
      promosi_active INTEGER DEFAULT 0,
      promosi_round_data TEXT,
      FOREIGN KEY (owner_id) REFERENCES users(user_id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS premium_wm (
      user_id TEXT PRIMARY KEY,
      expired INTEGER,
      added_by TEXT,
      created_at INTEGER,
      FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS premium_no_wm (
      user_id TEXT PRIMARY KEY,
      expired INTEGER,
      added_by TEXT,
      created_at INTEGER,
      FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS reseller_list (
      user_id TEXT PRIMARY KEY,
      added_by TEXT,
      added_at INTEGER,
      expired INTEGER,
      FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS reseller_added (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      reseller_id TEXT,
      user_id TEXT,
      type TEXT CHECK(type IN ('wm', 'nowm')),
      expired INTEGER,
      added_at INTEGER,
      FOREIGN KEY (reseller_id) REFERENCES reseller_list(user_id) ON DELETE CASCADE,
      FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
      UNIQUE(reseller_id, user_id)
    );

    CREATE TABLE IF NOT EXISTS tokens (
      token TEXT PRIMARY KEY,
      owner_id TEXT,
      ubot_id TEXT,
      role TEXT DEFAULT 'PREMIUM_WM',
      created_at INTEGER,
      expired_at INTEGER,
      used INTEGER DEFAULT 0,
      used_by TEXT,
      used_at INTEGER,
      FOREIGN KEY (owner_id) REFERENCES users(user_id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS promo_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      owner_id TEXT,
      round_number INTEGER,
      total_groups INTEGER,
      success INTEGER,
      failed INTEGER,
      errors TEXT,
      started_at INTEGER,
      finished_at INTEGER,
      FOREIGN KEY (owner_id) REFERENCES users(user_id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS activity_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT,
      action TEXT,
      details TEXT,
      timestamp INTEGER
    );

    CREATE TABLE IF NOT EXISTS bot_config (
      key TEXT PRIMARY KEY,
      value TEXT,
      updated_at INTEGER,
      updated_by TEXT
    );

    CREATE TABLE IF NOT EXISTS temp_payments (
      order_id TEXT PRIMARY KEY,
      user_id TEXT,
      amount INTEGER,
      type TEXT,
      metadata TEXT,
      message_id INTEGER,
      chat_id INTEGER,
      status TEXT,
      created_at INTEGER
    );

    CREATE TABLE IF NOT EXISTS deposit_orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id TEXT UNIQUE,
      user_id TEXT NOT NULL,
      amount INTEGER NOT NULL,
      proof_file_id TEXT,
      proof_caption TEXT,
      status TEXT DEFAULT 'pending',
      pin_message_id INTEGER,
      created_at INTEGER,
      processed_at INTEGER,
      FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
    );

    CREATE INDEX IF NOT EXISTS idx_deposit_orders_user ON deposit_orders(user_id);
    CREATE INDEX IF NOT EXISTS idx_deposit_orders_status ON deposit_orders(status);

    CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);
    CREATE INDEX IF NOT EXISTS idx_users_expired ON users(expired);
    CREATE INDEX IF NOT EXISTS idx_userbots_owner ON userbots(owner_id);
    CREATE INDEX IF NOT EXISTS idx_userbots_status ON userbots(status);
    CREATE INDEX IF NOT EXISTS idx_groups_owner ON groups(owner_id);
    CREATE INDEX IF NOT EXISTS idx_messages_owner ON messages(owner_id);
    CREATE INDEX IF NOT EXISTS idx_promo_logs_owner ON promo_logs(owner_id);
    CREATE INDEX IF NOT EXISTS idx_promo_logs_timestamp ON promo_logs(started_at);
    CREATE INDEX IF NOT EXISTS idx_reseller_added_reseller ON reseller_added(reseller_id);
    CREATE INDEX IF NOT EXISTS idx_temp_payments_user ON temp_payments(user_id);
    CREATE INDEX IF NOT EXISTS idx_temp_payments_status ON temp_payments(status);
  `);

// ===== MIGRASI KOLOM EXPIRED DI RESELLER_LIST =====
// Buat database lama yang ga punya kolom expired
const resellerColumns = await db.all("PRAGMA table_info(reseller_list)");
const hasResellerExpired = resellerColumns.some(col => col.name === 'expired');
if (!hasResellerExpired) {
  await db.exec("ALTER TABLE reseller_list ADD COLUMN expired INTEGER");
  logger.info('Added expired column to reseller_list');
}
// ===== AKHIR MIGRASI =====

// ===== MIGRASI: RESET trial_used LAMA =====
// Dulu trial_used dikunci ke 1 abis dipake sekali / abis userbot dibersihin, jadi user
// ke-block permanen dari deploy gratis. Sekarang deploy gratis boleh dipake berkali-kali,
// tapi data lama (dari sebelum perbaikan ini) masih nyimpen trial_used = 1. Migrasi
// sekali jalan ini nge-reset semua biar user yang kena block gara-gara data lama langsung kepake lagi.
const migrationFlagFile = path.join(path.dirname(DB_PATH), '.trial_used_reset_done');
if (!fs.existsSync(migrationFlagFile)) {
  const resetResult = await db.run('UPDATE users SET trial_used = 0 WHERE trial_used = 1');
  logger.info(`Migrasi trial_used: ${resetResult.changes || 0} user direset biar bisa deploy gratis lagi`);
  fs.writeFileSync(migrationFlagFile, JSON.stringify({ resetAt: Date.now() }));
}
// ===== AKHIR MIGRASI =====

const columns = await db.all("PRAGMA table_info(settings)");
const hasSelectedMessage = columns.some(col => col.name === 'selected_message_id');
  
  if (!hasSelectedMessage) {
    await db.exec("ALTER TABLE settings ADD COLUMN selected_message_id INTEGER");
  }
  
  const hasPromosiActive = columns.some(col => col.name === 'promosi_active');
  if (!hasPromosiActive) {
    await db.exec("ALTER TABLE settings ADD COLUMN promosi_active INTEGER DEFAULT 0");
    await db.exec("ALTER TABLE settings ADD COLUMN promosi_round_data TEXT");
  }
  
  const notifColumns = await db.all("PRAGMA table_info(settings)");
  const hasNotifTarget = notifColumns.some(col => col.name === 'notif_target');
  const hasNotifToSaved = notifColumns.some(col => col.name === 'notif_to_saved');

  if (!hasNotifTarget) {
    await db.exec("ALTER TABLE settings ADD COLUMN notif_target TEXT");
  }
  if (!hasNotifToSaved) {
    await db.exec("ALTER TABLE settings ADD COLUMN notif_to_saved INTEGER DEFAULT 0");
  }

  const msgColumns = await db.all("PRAGMA table_info(messages)");
  const hasEntitiesJson = msgColumns.some(col => col.name === 'entities_json');
  
  if (!hasEntitiesJson) {
    await db.exec("ALTER TABLE messages ADD COLUMN entities_json TEXT");
  }

  const tableInfo = await db.all("PRAGMA table_info(messages)");
  const hasLocalId = tableInfo.some(col => col.name === 'local_id');
  const hasFromChat = tableInfo.some(col => col.name === 'from_chat');
  const hasForwardMessageId = tableInfo.some(col => col.name === 'forward_message_id');

  if (!hasLocalId || !hasFromChat || !hasForwardMessageId) {
    logger.info('Migrating messages table to add new columns...');
    
    await db.exec(`
      BEGIN TRANSACTION;
      
      CREATE TABLE messages_new (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        owner_id TEXT,
        local_id INTEGER,
        type TEXT CHECK(type IN ('text', 'photo', 'video', 'document', 'audio', 'voice', 'sticker', 'animation', 'forward')),
        content TEXT,
        file_id TEXT,
        caption TEXT,
        entities_json TEXT,
        from_chat TEXT,
        forward_message_id INTEGER,
        created_at INTEGER,
        FOREIGN KEY (owner_id) REFERENCES users(user_id) ON DELETE CASCADE,
        UNIQUE(owner_id, local_id)
      );
      
      INSERT INTO messages_new (id, owner_id, local_id, type, content, file_id, caption, created_at)
      SELECT id, owner_id, local_id, type, content, file_id, caption, created_at FROM messages;
      
      DROP TABLE messages;
      
      ALTER TABLE messages_new RENAME TO messages;
      
      CREATE INDEX IF NOT EXISTS idx_messages_owner ON messages(owner_id);
      
      COMMIT;
    `);
    
    const owners = await db.all('SELECT DISTINCT owner_id FROM messages WHERE owner_id IS NOT NULL');
    for (const owner of owners) {
      const messages = await db.all('SELECT id FROM messages WHERE owner_id = ? ORDER BY created_at', owner.owner_id);
      for (let i = 0; i < messages.length; i++) {
        await db.run('UPDATE messages SET local_id = ? WHERE id = ?', i + 1, messages[i].id);
      }
    }
    
    logger.info('Messages table migration completed');
  }

  await loadUserbots();
  logger.info('Database initialized');
}

async function loadProdukBalance() {
  try {
    if (fs.existsSync(PRODUK_BALANCE_FILE)) {
      const data = fs.readFileSync(PRODUK_BALANCE_FILE, 'utf8');
      produkBalance = JSON.parse(data);
    } else {
      produkBalance = {};
      fs.writeFileSync(PRODUK_BALANCE_FILE, JSON.stringify(produkBalance, null, 2));
    }
  } catch (error) {
    logger.error('loadProdukBalance error:', error);
    produkBalance = {};
  }
}

async function produkBaruCekSaldo(userId) {
  return getProdukBalance(userId);
}

async function produkBaruKurangiSaldo(userId, amount) {
  return await updateProdukBalance(userId, amount, false);
}

async function saveProdukBalance() {
  try {
    fs.writeFileSync(PRODUK_BALANCE_FILE, JSON.stringify(produkBalance, null, 2));
  } catch (error) {
    logger.error('saveProdukBalance error:', error);
  }
}

async function loadProdukTransactions() {
  try {
    if (fs.existsSync(PRODUK_TRANSACTIONS_FILE)) {
      const data = fs.readFileSync(PRODUK_TRANSACTIONS_FILE, 'utf8');
      produkTransactions = JSON.parse(data);
    } else {
      produkTransactions = [];
      fs.writeFileSync(PRODUK_TRANSACTIONS_FILE, JSON.stringify(produkTransactions, null, 2));
    }
  } catch (error) {
    logger.error('loadProdukTransactions error:', error);
    produkTransactions = [];
  }
}

async function saveProdukTransactions() {
  try {
    fs.writeFileSync(PRODUK_TRANSACTIONS_FILE, JSON.stringify(produkTransactions, null, 2));
  } catch (error) {
    logger.error('saveProdukTransactions error:', error);
  }
}

function getProdukBalance(userId) {
  return produkBalance[userId] || 0;
}

async function updateProdukBalance(userId, amount, isAdd, orderId = null, details = '') {
  try {
    if (!produkBalance[userId]) produkBalance[userId] = 0;
    
    const oldBalance = produkBalance[userId];
    
    if (isAdd) {
      produkBalance[userId] += amount;
    } else {
      if (produkBalance[userId] >= amount) {
        produkBalance[userId] -= amount;
      } else {
        return false;
      }
    }
    
    await saveProdukBalance();
    
    produkTransactions.push({
      user_id: userId,
      type: isAdd ? 'DEPOSIT' : 'PURCHASE',
      amount: amount,
      old_balance: oldBalance,
      new_balance: produkBalance[userId],
      order_id: orderId,
      details: details,
      timestamp: Date.now()
    });
    
    if (produkTransactions.length > 1000) {
      produkTransactions = produkTransactions.slice(-500);
    }
    
    await saveProdukTransactions();
    return true;
    
  } catch (error) {
    logger.error('updateProdukBalance error:', error);
    return false;
  }
}

async function getProdukUserTransactions(userId, limit = 20) {
  const userTransactions = produkTransactions.filter(t => t.user_id === userId);
  return userTransactions.reverse().slice(0, limit);
}

function produkBaruLoad() {
  try {
    if (fs.existsSync(PRODUK_BARU_FILE)) {
      const data = fs.readFileSync(PRODUK_BARU_FILE, 'utf8');
      produkBaruData = JSON.parse(data);
      console.log(`Loaded ${produkBaruData.length} products from file`);
    } else {
      produkBaruData = [];
      fs.writeFileSync(PRODUK_BARU_FILE, JSON.stringify([], null, 2));
      console.log('Created new products file');
    }
  } catch (e) {
    console.error('Error loading products:', e);
    produkBaruData = [];
  }
}

function produkBaruSave() {
  try {
    fs.writeFileSync(PRODUK_BARU_FILE, JSON.stringify(produkBaruData, null, 2));
    console.log(`Saved ${produkBaruData.length} products to file`);
  } catch (e) {
    console.error('Error saving products:', e);
  }
}

function produkBaruLoadOrders() {
  try {
    if (fs.existsSync(ORDER_BARU_FILE)) {
      return JSON.parse(fs.readFileSync(ORDER_BARU_FILE, 'utf8'));
    }
    return [];
  } catch (e) {
    return [];
  }
}

function produkBaruSaveOrders(orders) {
  fs.writeFileSync(ORDER_BARU_FILE, JSON.stringify(orders, null, 2));
}

function produkBaruAdd(product) {
  const newId = produkBaruData.length > 0 ? Math.max(...produkBaruData.map(p => p.id)) + 1 : 1;
  produkBaruData.push({
    id: newId,
    ...product,
    sold: 0,
    is_active: 1,
    created_at: Date.now(),
    updated_at: Date.now()
  });
  produkBaruSave();
  return newId;
}

function produkBaruUpdate(id, updates) {
  const index = produkBaruData.findIndex(p => p.id === id);
  if (index !== -1) {
    produkBaruData[index] = { ...produkBaruData[index], ...updates, updated_at: Date.now() };
    produkBaruSave();
    return true;
  }
  return false;
}

function produkBaruDelete(id) {
  produkBaruData = produkBaruData.filter(p => p.id !== id);
  produkBaruSave();
}

function produkBaruUpdateStock(id, qty) {
  const index = produkBaruData.findIndex(p => p.id === id);
  if (index !== -1) {
    produkBaruData[index].stock -= qty;
    produkBaruData[index].sold = (produkBaruData[index].sold || 0) + qty;
    produkBaruSave();
    return true;
  }
  return false;
}

async function produkBaruSendFile(chatId, fileId, fileName, caption) {
  const ext = fileName ? fileName.split('.').pop().toLowerCase() : '';
  const imageExt = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
  const videoExt = ['mp4', 'mkv', 'avi', 'mov', 'webm'];
  const audioExt = ['mp3', 'ogg', 'wav', 'm4a'];
  
  if (imageExt.includes(ext)) {
    await bot.sendPhoto(chatId, fileId, { caption: caption, parse_mode: 'HTML' });
  } else if (videoExt.includes(ext)) {
    await bot.sendVideo(chatId, fileId, { caption: caption, parse_mode: 'HTML' });
  } else if (audioExt.includes(ext)) {
    await bot.sendAudio(chatId, fileId, { caption: caption, parse_mode: 'HTML' });
  } else {
    await bot.sendDocument(chatId, fileId, { caption: caption, parse_mode: 'HTML' });
  }
}

function validateDelay(delay) {
  delay = parseInt(delay);
  if (isNaN(delay) || delay < 100 || delay > 5000) return false;
  return delay;
}

function validateJeda(jeda) {
  jeda = parseInt(jeda);
  if (isNaN(jeda) || jeda < 1) return false;
  return jeda;
}

async function loadUserbots() {
  userbots = [];
  const ubots = await db.all('SELECT * FROM userbots WHERE status = "AKTIF"');
  
  for (const ubot of ubots) {
    try {
      // Client "lazy": nyambung otomatis pas dipanggil, dan otomatis
      // disconnect kalau nganggur (hemat memori). Lihat system/lazyUbot.js
      const client = lazyUbot.createLazyClient(
        ubot.owner_id,
        ubot.session_string,
        API_ID,
        API_HASH,
        getTelegramClientConfig()
      );
      
      try {
        const me = await client.getMe(); // ini otomatis trigger connect on-demand
        if (!me) throw new Error('Could not get me');
        
        userbots.push({
          id: ubot.ubot_id,
          owner_id: ubot.owner_id,
          client: client,
          phone: ubot.phone,
          status: 'AKTIF'
        });
        
        logger.info(`Userbot ${ubot.ubot_id} loaded for user ${ubot.owner_id}`);
      } catch (e) {
        logger.error(`Userbot ${ubot.ubot_id} is invalid, cleaning up...`);
        await cleanupUserData(ubot.owner_id, 'invalid_session');
      }
    } catch (error) {
      logger.error(`Failed to load userbot ${ubot.ubot_id}:`, error);
      await cleanupUserData(ubot.owner_id, 'load_failed');
    }
  }
}

function handleApiError(error) {
  const status = error.response?.status;
  const data = error.response?.data;
  
  if (status === 400) return 'Parameter tidak valid atau tidak lengkap';
  if (status === 401) return 'API Key tidak valid atau tidak ditemukan';
  if (status === 403) return 'Akun diblokir. Hubungi admin.';
  if (status === 404) return 'Transaksi tidak ditemukan';
  if (status === 429) return 'Terlalu banyak request. Coba lagi nanti.';
  if (status === 500) return 'Kesalahan server. Coba lagi beberapa saat.';
  if (data?.message) return data.message;
  if (error.code === 'ECONNABORTED') return 'Koneksi timeout. Coba lagi.';
  if (error.code === 'ENOTFOUND') return 'Tidak dapat terhubung ke server.';
  
  return error.message || 'Terjadi kesalahan';
}

// Buat pesanan deposit manual via QRIS - dengan fitur kirim bukti
async function createDepositOrder(userId, amount) {
  try {
    const orderId = `DEP-${Date.now()}-${Math.random().toString(36).substr(2, 6).toUpperCase()}`;
    
    // Simpan ke deposit_orders
    await db.run(
      `INSERT INTO deposit_orders (order_id, user_id, amount, status, created_at)
       VALUES (?, ?, ?, ?, ?)`,
      orderId, userId, amount, 'pending', Date.now()
    );
    
    // Kirim QRIS ke user dengan instruksi kirim bukti
    let qrBuffer = null;
    let qrUrl = null;
    
    if (typeof QRIS_IMAGE === 'string') {
      if (QRIS_IMAGE.startsWith('http://') || QRIS_IMAGE.startsWith('https://')) {
        qrUrl = QRIS_IMAGE;
      } else if (fs.existsSync(QRIS_IMAGE)) {
        qrBuffer = fs.readFileSync(QRIS_IMAGE);
      } else {
        console.warn('QRIS file not found:', QRIS_IMAGE);
      }
    } else if (Buffer.isBuffer(QRIS_IMAGE)) {
      qrBuffer = QRIS_IMAGE;
    }

    const userMsg = `
<blockquote>💰 <b><u>DEPOSIT VIA QRIS</u></b></blockquote>
<blockquote><b>💰 Nominal</b> : <b>Rp ${amount.toLocaleString()}</b>
🆔 <b>Order ID</b> : <code>${orderId}</code></blockquote>

📌 <b>Langkah Pembayaran:</b>
 1️⃣ Scan QRIS di bawah
 2️⃣ Transfer sesuai nominal <b>Rp ${amount.toLocaleString()}</b>
 3️⃣ Kirim <b>FOTO BUKTI TRANSFER</b> ke chat ini

⚠️ <i>Pastikan nominal sesuai untuk verifikasi otomatis</i>
⏳ <i>Order akan diproses dalam 1x24 jam</i>`;

    let qrisMsg;
    if (qrBuffer) {
      qrisMsg = await bot.sendPhoto(userId, qrBuffer, { caption: userMsg, parse_mode: 'HTML' });
    } else if (qrUrl) {
      qrisMsg = await bot.sendPhoto(userId, qrUrl, { caption: userMsg, parse_mode: 'HTML' });
    } else {
      qrisMsg = await bot.sendMessage(userId, userMsg + '\n\n⚠️ QRIS tidak tersedia, hubungi owner', { parse_mode: 'HTML' });
    }

    // Kirim tombol batalkan deposit
    await bot.sendMessage(userId, `
<i>Tekan tombol di bawah untuk membatalkan deposit</i>`, {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [{ text: '❌ Batalkan Deposit', callback_data: `batal_deposit_${orderId}` }]
        ]
      }
    });

    // HAPUS NOTIFIKASI KE OWNER - CEGAH SPAM
    // Owner hanya akan lihat deposit saat user kirim bukti

    // Simpan state agar user bisa kirim bukti
    global.waitingForDepositProof = global.waitingForDepositProof || {};
    global.waitingForDepositProof[userId] = { 
      orderId: orderId,
      qrisMsgId: qrisMsg.message_id
    };

    return {
      success: true,
      order_id: orderId,
      amount: amount,
      status: 'PENDING'
    };
    
  } catch (error) {
    console.error('Create deposit order error:', error.message);
    return { success: false, message: error.message || 'Gagal membuat pesanan deposit' };
  }
}

// ------------------------------------------------------------------
// DEPOSIT OTOMATIS VIA PAKASIR (QRIS)
// ------------------------------------------------------------------

/**
 * Bikin order pembayaran otomatis lewat Pakasir.
 * `amount` di sini adalah nominal FINAL (sudah termasuk PAKASIR_ADMIN_FEE
 * kalau caller menambahkannya sebelum manggil fungsi ini).
 */
async function createFelixOrder(amount) {
  try {
    if (!PAKASIR_ENABLED) {
      return { success: false, message: 'Deposit otomatis belum diaktifkan. Hubungi owner untuk info deposit manual.' };
    }

    const orderId = `ORD-${Date.now()}-${Math.random().toString(36).substr(2, 6).toUpperCase()}`;

    const payment = await pakasir.createPayment(PAKASIR_METHOD, orderId, amount);

    if (!payment || !payment.order_id) {
      return { success: false, message: 'Gagal membuat pesanan via Pakasir' };
    }

    let qrBuffer = null;
    if (payment.payment_number) {
      try {
        qrBuffer = await QRCode.toBuffer(payment.payment_number, { type: 'png', width: 512 });
      } catch (e) {
        logger.error('QR generate error:', e.message);
      }
    }

    return {
      success: true,
      checkout_url: payment.payment_url || '',
      qrBuffer: qrBuffer,
      order_id: payment.order_id,
      amount: payment.amount,
      totalTransfer: payment.total_payment,
      expired_at: payment.expired_at ? new Date(payment.expired_at).getTime() : Date.now() + PAKASIR_EXPIRY_MS
    };
  } catch (error) {
    logger.error('Create Pakasir order error:', error.message);
    return { success: false, message: error.message || 'Gagal membuat pesanan' };
  }
}

/**
 * Cek status transaksi Pakasir. `global.activePayments` /
 * `global.produkPayments` dipakai untuk mengingat nominal asli
 * (dibutuhkan API Pakasir buat verifikasi order_id + amount).
 */
async function checkFelixStatus(orderId) {
  try {
    if (!PAKASIR_ENABLED) return null;

    const activePayment = global.activePayments?.[orderId] || global.produkPayments?.[orderId];
    const amount = activePayment?.amount || 0;

    const detail = await pakasir.detailPayment(orderId, amount);

    if (!detail || !detail.order_id) {
      return { status: 'NOT_FOUND', error: 'Transaksi tidak ditemukan' };
    }

    let status = 'PENDING';
    if (detail.status === 'completed') {
      status = 'SETTLED';
    } else if (detail.status === 'canceled') {
      status = 'CANCELED';
    } else if (detail.status === 'pending') {
      if (detail.expired_at && new Date(detail.expired_at) < new Date()) {
        status = 'EXPIRED';
      } else {
        status = 'PENDING';
      }
    }

    return {
      status: status,
      amount: detail.total_payment,
      order_id: orderId,
      message: detail.status
    };
  } catch (error) {
    logger.error('Check Pakasir status error:', error.message);
    return null;
  }
}

/**
 * Batalkan order Pakasir yang masih pending.
 */
async function cancelFelixOrder(orderId) {
  try {
    if (!PAKASIR_ENABLED) return { success: false, message: 'Deposit otomatis belum diaktifkan' };

    const activePayment = global.activePayments?.[orderId] || global.produkPayments?.[orderId];
    const amount = activePayment?.amount || 0;

    const result = await pakasir.cancelPayment(orderId, amount);

    if (result && (result.success || result.order_id)) {
      return { success: true, message: 'Berhasil dibatalkan' };
    }

    // cancelPayment() balik null kalau memang tidak ada penanda sukses.
    // Sebelum dianggap gagal total, cek status transaksi terkini dulu --
    // kalau ternyata sudah SETTLED/EXPIRED/CANCELED (mis. sudah kepencet
    // "Cek Status" duluan, atau memang sudah kedaluwarsa di sisi Pakasir),
    // itu bukan kegagalan pembatalan, cuma sudah tidak relevan lagi
    // dibatalkan.
    const current = await checkFelixStatus(orderId);
    if (current && ['SETTLED', 'CANCELED', 'EXPIRED'].includes(current.status)) {
      return {
        success: current.status !== 'SETTLED',
        message: current.status === 'SETTLED'
          ? 'Pembayaran sudah keburu masuk, tidak bisa dibatalkan.'
          : 'Order ini sudah tidak aktif (sudah dibatalkan/kedaluwarsa).',
      };
    }

    return { success: false, message: 'Gagal membatalkan pesanan. Coba lagi sebentar atau hubungi owner.' };
  } catch (error) {
    logger.error('Cancel Pakasir order error:', error.message);
    return { success: false, message: error.message || 'Gagal membatalkan' };
  }
}

/**
 * Bikin deposit otomatis end-to-end: hitung fee admin, buat order Pakasir,
 * kirim QR + tombol Cek Status / Cek Otomatis / Batalkan ke user.
 * `baseAmount` = nominal yang DIMINTA user (sebelum fee).
 */
async function createAutoDepositOrder(userId, chatId, baseAmount) {
  const totalAmount = baseAmount + PAKASIR_ADMIN_FEE;
  const order = await createFelixOrder(totalAmount);

  if (!order.success) {
    await bot.sendMessage(chatId, `<blockquote>❌ ${order.message}</blockquote>`, { parse_mode: 'HTML' });
    return null;
  }

  // Simpan konteks order supaya checkFelixStatus/cancelFelixOrder tahu amount-nya,
  // dan supaya job polling background tahu siapa yang harus ditambah saldonya.
  global.activePayments[order.order_id] = {
    userId,
    chatId,
    amount: totalAmount,
    baseAmount,
    createdAt: Date.now(),
    expiredAt: order.expired_at,
    status: 'PENDING',
  };

  const caption = `
<blockquote>⚡ <b><u>DEPOSIT OTOMATIS — QRIS</u></b></blockquote>
<blockquote><b>💰 Nominal Deposit</b> : Rp ${baseAmount.toLocaleString()}
<b>⚙️ Biaya Layanan</b> : Rp ${PAKASIR_ADMIN_FEE.toLocaleString()}
<b>💳 Total Bayar</b> : <b>Rp ${totalAmount.toLocaleString()}</b>
<b>🆔 Order ID</b> : <code>${order.order_id}</code></blockquote>

📌 <b>Langkah Pembayaran:</b>
 1️⃣ Scan QRIS di bawah ini
 2️⃣ Bayar tepat <b>Rp ${totalAmount.toLocaleString()}</b>
 3️⃣ Saldo masuk otomatis dalam hitungan detik

⏳ <i>Kadaluarsa dalam ${Math.round(PAKASIR_EXPIRY_MS / 60000)} menit</i>`;

  const keyboard = {
    inline_keyboard: [
      [{ text: '🔄 Cek Status', callback_data: `felix_check_${order.order_id}` }],
      [{ text: '❌ Batalkan', callback_data: `felix_cancel_${order.order_id}` }],
    ],
  };

  if (order.qrBuffer) {
    await bot.sendPhoto(chatId, order.qrBuffer, { caption, parse_mode: 'HTML', reply_markup: keyboard });
  } else if (order.checkout_url) {
    await bot.sendMessage(chatId, `${caption}\n\n🔗 <a href="${order.checkout_url}">Buka Halaman Pembayaran</a>`, {
      parse_mode: 'HTML',
      reply_markup: keyboard,
      disable_web_page_preview: false,
    });
  } else {
    await bot.sendMessage(chatId, caption, { parse_mode: 'HTML', reply_markup: keyboard });
  }

  startFelixAutoCheck(order.order_id);
  return order;
}

/**
 * Job polling background: cek status order Pakasir secara berkala sampai
 * SETTLED / EXPIRED / CANCELED / batas waktu habis. Begitu SETTLED, saldo
 * user ditambah otomatis dan notifikasi dikirim ke user + LOG_GROUP.
 */
function startFelixAutoCheck(orderId) {
  const payment = global.activePayments[orderId];
  if (!payment) return;

  const deadline = payment.expiredAt || (Date.now() + PAKASIR_EXPIRY_MS);

  const interval = setInterval(async () => {
    try {
      const current = global.activePayments[orderId];
      if (!current || current.status !== 'PENDING') {
        clearInterval(interval);
        return;
      }

      if (Date.now() > deadline) {
        current.status = 'EXPIRED';
        clearInterval(interval);
        try {
          await bot.sendMessage(current.chatId, `
<blockquote>⏰ <b><u>DEPOSIT KEDALUARSA</u></b>
🆔 <b>Order ID</b> : <code>${orderId}</code></blockquote>

<i>Silakan buat deposit baru jika masih ingin top up.</i>`, { parse_mode: 'HTML' });
        } catch (e) {}
        delete global.activePayments[orderId];
        return;
      }

      const result = await checkFelixStatus(orderId);
      if (!result) return; // error sementara, coba lagi di interval berikutnya

      if (result.status === 'SETTLED') {
        current.status = 'SETTLED';
        clearInterval(interval);
        await handleFelixPaymentSettled(orderId, current);
      } else if (result.status === 'CANCELED' || result.status === 'EXPIRED') {
        current.status = result.status;
        clearInterval(interval);
        delete global.activePayments[orderId];
      }
    } catch (e) {
      logger.error(`startFelixAutoCheck error (${orderId}):`, e.message);
    }
  }, PAKASIR_POLL_INTERVAL_MS);

  if (interval.unref) interval.unref();
}

/**
 * Dipanggil begitu pembayaran Pakasir dinyatakan SETTLED (lunas), baik
 * dari polling background maupun dari tombol "Cek Status" manual.
 * Idempotent -> aman dipanggil dua kali untuk order_id yang sama.
 */
async function handleFelixPaymentSettled(orderId, payment) {
  // Cegah double-credit kalau dipanggil dua kali (mis. polling + manual check
  // hampir bersamaan).
  if (payment.credited) return;
  payment.credited = true;

  const success = await updateProdukBalance(payment.userId, payment.baseAmount, true, orderId, 'deposit_otomatis_pakasir');

  if (!success) {
    logger.error(`Gagal menambah saldo otomatis untuk order ${orderId}`);
    try {
      await bot.sendMessage(payment.chatId, `<blockquote>⚠️ Pembayaran diterima tapi gagal menambah saldo otomatis. Hubungi owner dengan Order ID: <code>${orderId}</code></blockquote>`, { parse_mode: 'HTML' });
    } catch (e) {}
    return;
  }

  const newBalance = getProdukBalance(payment.userId);

  try {
    await bot.sendMessage(payment.chatId, `
<blockquote>✅ <b><u>DEPOSIT OTOMATIS BERHASIL</u></b></blockquote>
<blockquote><b>💰 Nominal Masuk</b> : Rp ${payment.baseAmount.toLocaleString()}
<b>💳 Saldo Sekarang</b> : <b>Rp ${newBalance.toLocaleString()}</b>
<b>🆔 Order ID</b> : <code>${orderId}</code></blockquote>

<i>Terima kasih, saldo sudah aktif dan siap dipakai belanja.</i>`, { parse_mode: 'HTML' });
  } catch (e) {
    logger.error('Gagal kirim notif settle ke user:', e.message);
  }

  if (LOG_GROUP) {
    try {
      await bot.sendMessage(LOG_GROUP, `
<blockquote>⚡ <b><u>DEPOSIT OTOMATIS MASUK</u></b></blockquote>
<blockquote>👤 <b>User</b> : <code>${payment.userId}</code>
💰 <b>Nominal</b> : Rp ${payment.baseAmount.toLocaleString()}
🆔 <b>Order ID</b> : <code>${orderId}</code></blockquote>`, { parse_mode: 'HTML' });
    } catch (e) {}
  }

  delete global.activePayments[orderId];
}

// Handle user kirim bukti deposit
async function handleDepositProof(userId, chatId, msg) {
  if (!global.waitingForDepositProof?.[userId]) return;
  
  const orderData = global.waitingForDepositProof[userId];
  const orderId = orderData.orderId;
  
  const order = await db.get('SELECT * FROM deposit_orders WHERE order_id = ? AND user_id = ?', orderId, userId);
  
  if (!order) {
    delete global.waitingForDepositProof[userId];
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
📌 Order tidak ditemukan. Silakan buat deposit baru.</blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  if (order.status !== 'pending') {
    delete global.waitingForDepositProof[userId];
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ORDER SUDAH DIPROSES</u></b>
📌 Status: ${order.status}</blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  if (!msg.photo) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>BUKTI HARUS GAMBAR</u></b>
📸 Kirim dalam bentuk FOTO/SCREENSHOT bukti transfer.</blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const fileId = msg.photo[msg.photo.length - 1].file_id;
  const caption = msg.caption || '';
  
  await db.run(
    'UPDATE deposit_orders SET proof_file_id = ?, proof_caption = ? WHERE order_id = ?',
    fileId, caption || 'Bukti pembayaran', orderId
  );
  
  delete global.waitingForDepositProof[userId];
  
  // Ambil data user terbaru
  let user = await db.get('SELECT * FROM users WHERE user_id = ?', userId);
  let userFullName = 'Unknown', userUsername = '';
  try {
    const chatInfo = await bot.getChat(userId);
    userFullName = chatInfo.first_name || 'User';
    if (chatInfo.last_name) userFullName += ` ${chatInfo.last_name}`;
    userUsername = chatInfo.username || '';
  } catch (e) {}
  
  if (user) {
    await db.run('UPDATE users SET username = ?, full_name = ? WHERE user_id = ?', 
      userUsername, userFullName, userId);
  } else {
    await db.run('INSERT OR IGNORE INTO users (user_id, username, full_name, created_at, last_active) VALUES (?, ?, ?, ?, ?)',
      userId, userUsername, userFullName, Math.floor(Date.now() / 1000), Math.floor(Date.now() / 1000));
  }
  
  user = await db.get('SELECT * FROM users WHERE user_id = ?', userId);
  const username = user?.username ? `@${user.username.replace('@', '')}` : '-';
  const fullName = user?.full_name || 'Unknown';
  const now = moment().format('DD/MM/YYYY HH:mm:ss');
  
  // Kirim ke owner dengan tombol ACC/TOLAK
  const ownerMessage = await bot.sendPhoto(OWNER_ID, fileId, {
    caption: `
💳 <b>Deposit Verification</b>

<b>User</b> : <a href="tg://user?id=${userId}">${fullName}</a>
<b>Username</b> : ${username}
<b>ID</b> : <code>${userId}</code>
<b>Amount</b> : <b>Rp ${order.amount.toLocaleString()}</b>
<b>Order ID</b> : <code>${orderId}</code>
<b>Status</b> : ⏳ Pending Verification
<b>Time</b> : ${now}

📸 <i>Payment proof attached above</i>
<i>Click button below to verify</i>`,
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [{ text: '✅ Terima & Tambah Saldo', callback_data: `deposit_accept_${orderId}` }],
        [{ text: '❌ Tolak', callback_data: `deposit_reject_${orderId}` }]
      ]
    }
  });
  
  // Pin pesan di owner
  try {
    await bot.pinChatMessage(OWNER_ID, ownerMessage.message_id, { disable_notification: false });
    await db.run('UPDATE deposit_orders SET pin_message_id = ? WHERE order_id = ?', ownerMessage.message_id, orderId);
  } catch (err) {}
  
  const effectId = getRandomEffect();
  await bot.sendMessage(chatId, `
<blockquote>✅ <b><u>BUKTI TERKIRIM!</u></b></blockquote>
<blockquote>📸 Bukti pembayaran berhasil dikirim ke owner.
⏳ <b>Status</b> : Menunggu verifikasi owner
🆔 <b>Order ID</b> : <code>${orderId}</code></blockquote>

<i>Owner akan memproses dalam 1x24 jam.</i>
<i>Kamu akan dapat notifikasi jika saldo sudah masuk.</i>`, {
    parse_mode: 'HTML',
    message_effect_id: effectId,
    reply_markup: await getMainMenuKeyboard(userId)
  });
}

async function handleDepositAccept(callbackQuery, userId, chatId, messageId, data) {
  if (!isOwnerId(userId)) {
    await safeAnswerCallbackQuery(callbackQuery, { text: '❌ Hanya owner yang bisa verifikasi', show_alert: true });
    return;
  }
  
  const orderId = data.replace('deposit_accept_', '');
  const order = await db.get('SELECT * FROM deposit_orders WHERE order_id = ?', orderId);
  
  if (!order) {
    await safeAnswerCallbackQuery(callbackQuery, { text: '❌ Order tidak ditemukan', show_alert: true });
    return;
  }
  
  if (order.status !== 'pending') {
    await safeAnswerCallbackQuery(callbackQuery, { text: `⚠️ Order sudah ${order.status}`, show_alert: true });
    return;
  }
  
  // Ambil data user
  const user = await db.get('SELECT full_name, username FROM users WHERE user_id = ?', order.user_id);
  const userName = user?.full_name || 'Unknown';
  const userUsername = user?.username ? `@${user.username.replace('@', '')}` : '-';
  
  // Tambah saldo user
  const success = await updateProdukBalance(order.user_id, order.amount, true, orderId, 'deposit_manual');
  
  if (!success) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>GAGAL TAMBAH SALDO</u></b>
⚠️ Terjadi kesalahan saat menambah saldo.</blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  // Update status order
  await db.run('UPDATE deposit_orders SET status = "accepted", processed_at = ? WHERE order_id = ?', 
    Date.now(), orderId);
  
  // UNPIN pesan (tombol tetap ada)
  try {
    if (order.pin_message_id) {
      await bot.unpinChatMessage(OWNER_ID, { message_id: order.pin_message_id });
    }
  } catch (err) {
    try { await bot.unpinChatMessage(OWNER_ID); } catch (e) {}
  }
  
  const newBalance = getProdukBalance(order.user_id);
  const now = moment().format('DD/MM/YYYY HH:mm:ss');
  const botInfo = await getCachedBotInfo();
  const botUsername = botInfo.username || 'XavierJasebBot';
  
  // Notif user
  const effectId = getRandomEffect();
  await bot.sendMessage(order.user_id, `
<blockquote>✅ <b><u>DEPOSIT BERHASIL!</u></b></blockquote>
<blockquote>💰 <b>Nominal</b> : <b>Rp ${order.amount.toLocaleString()}</b>
💳 <b>Saldo Saat Ini</b> : <b>Rp ${newBalance.toLocaleString()}</b>
🆔 <b>Order ID</b> : <code>${orderId}</code></blockquote>

<i>Saldo sudah masuk, silakan lanjutkan pembelian produk.</i>`, {
    parse_mode: 'HTML',
    message_effect_id: effectId
  });
  
  // Kirim notif ke log group dengan 2 tombol
  if (LOG_GROUP) {
    const logMessage = `
<blockquote>✅ <b><u>DEPOSIT BERHASIL DIKONFIRMASI</u></b></blockquote>
<blockquote>🆔 <b>Order ID</b> : <code>${orderId}</code>
👤 <b>User</b> : <a href="tg://user?id=${order.user_id}">${escapeHtml(userName)}</a>
👥 <b>Username</b> : ${escapeHtml(userUsername)}
🆔 <b>ID User</b> : <code>${order.user_id}</code>
💰 <b>Nominal</b> : <b>Rp ${order.amount.toLocaleString()}</b>
💳 <b>Saldo Baru</b> : <b>Rp ${newBalance.toLocaleString()}</b>
🕐 <b>Waktu</b> : ${now}</blockquote>`;

    try {
      await bot.sendMessage(LOG_GROUP, logMessage, { 
        parse_mode: 'HTML', 
        disable_web_page_preview: true,
        reply_markup: {
          inline_keyboard: [
            [
              { text: '📱 Buka Bot', url: `https://t.me/${botUsername}` },
              { text: '👤 Owner', url: `tg://user?id=${OWNER_ID}` }
            ]
          ]
        }
      });
    } catch (err) {
      logger.error(`Gagal kirim notif deposit ke log group: ${err.message}`);
    }
  }
  
  await safeAnswerCallbackQuery(callbackQuery, { text: `✅ Deposit Rp ${order.amount.toLocaleString()} diterima`, show_alert: false });
}

// Owner TOLAK deposit dari tombol inline
async function handleDepositReject(callbackQuery, userId, chatId, messageId, data) {
  if (!isOwnerId(userId)) {
    await safeAnswerCallbackQuery(callbackQuery, { text: '❌ Hanya owner yang bisa verifikasi', show_alert: true });
    return;
  }
  
  const orderId = data.replace('deposit_reject_', '');
  const order = await db.get('SELECT * FROM deposit_orders WHERE order_id = ?', orderId);
  
  if (!order) {
    await safeAnswerCallbackQuery(callbackQuery, '❌ Order tidak ditemukan', true);
    return;
  }
  
  if (order.status !== 'pending') {
    await safeAnswerCallbackQuery(callbackQuery, `⚠️ Order sudah ${order.status}`, true);
    return;
  }
  
  await db.run('UPDATE deposit_orders SET status = "rejected", processed_at = ? WHERE order_id = ?', 
    Date.now(), orderId);
  
  // Unpin pesan
  try {
    if (order.pin_message_id) {
      await bot.unpinChatMessage(OWNER_ID, { message_id: order.pin_message_id });
    }
  } catch (err) {
    try { await bot.unpinChatMessage(OWNER_ID); } catch (e) {}
  }
  
  // Hapus tombol
  try {
    await safeEditMessageReplyMarkup(
      { chat_id: chatId, message_id: messageId },
      { reply_markup: { inline_keyboard: [] } }
    );
  } catch (err) {}
  
  await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>DEPOSIT DITOLAK</u></b></blockquote>
<blockquote>🆔 <b>Order ID</b> : <code>${orderId}</code>
👤 <b>User</b> : <code>${order.user_id}</code>
💰 <b>Nominal</b> : <b>Rp ${order.amount.toLocaleString()}</b>
❌ <b>Status</b> : DITOLAK</blockquote>`, { parse_mode: 'HTML' });
  
  await bot.sendMessage(order.user_id, `
<blockquote>❌ <b><u>DEPOSIT DITOLAK</u></b></blockquote>
<blockquote>Maaf, deposit Anda ditolak oleh owner.</blockquote>
<blockquote>🆔 <b>Order ID</b> : <code>${orderId}</code>
💰 <b>Nominal</b> : <b>Rp ${order.amount.toLocaleString()}</b></blockquote>
<blockquote><b>Kemungkinan alasan:</b>
 • Bukti transfer tidak jelas
 • Nominal tidak sesuai
 • Bukti transfer tidak valid</blockquote>

<i>Silakan buat deposit ulang dengan bukti yang jelas.</i>`, { parse_mode: 'HTML' });
  
  await safeAnswerCallbackQuery(callbackQuery, `❌ Deposit Rp ${order.amount.toLocaleString()} ditolak`);
}

// Restore pending deposit orders saat bot restart
async function restorePendingDepositOrders() {
  try {
    const pendingOrders = await db.all(
      "SELECT * FROM deposit_orders WHERE status = 'pending' ORDER BY created_at ASC"
    );
    
    if (pendingOrders.length === 0) return;
    
    for (const order of pendingOrders) {
      if (order.pin_message_id) {
        try {
          await bot.getChat(OWNER_ID);
          continue;
        } catch (err) {}
      }
      
      const user = await db.get('SELECT username, full_name FROM users WHERE user_id = ?', order.user_id);
      const username = user?.username ? `@${user.username.replace('@', '')}` : '-';
      const fullName = user?.full_name || 'Unknown';
      
      if (order.proof_file_id) {
        const ownerMessage = await bot.sendPhoto(OWNER_ID, order.proof_file_id, {
          caption: `
╭─❒ <b>💳 VERIFIKASI DEPOSIT</b>
⚠️ <i>Notifikasi ini dikirim ulang karena bot restart</i>

├ <b>User</b> : <a href="tg://user?id=${order.user_id}">${fullName}</a>
├ <b>Username</b> : ${username}
├ <b>ID</b> : <code>${order.user_id}</code>
├ <b>Nominal</b> : <b>Rp ${order.amount.toLocaleString()}</b>
├ <b>Order ID</b> : <code>${order.order_id}</code>
├ <b>Status</b> : ⏳ MENUNGGU VERIFIKASI
╰ <b>Waktu</b> : ${moment(order.created_at).format('DD/MM/YYYY HH:mm:ss')}

📸 <i>Bukti pembayaran di atas</i>
<i>Klik tombol di bawah untuk verifikasi</i>`,
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [{ text: '✅ Terima & Tambah Saldo', callback_data: `deposit_accept_${order.order_id}` }],
              [{ text: '❌ Tolak', callback_data: `deposit_reject_${order.order_id}` }]
            ]
          }
        });
        
        try {
          await bot.pinChatMessage(OWNER_ID, ownerMessage.message_id, { disable_notification: false });
          await db.run('UPDATE deposit_orders SET pin_message_id = ? WHERE order_id = ?', ownerMessage.message_id, order.order_id);
        } catch (err) {}
      }
    }
  } catch (error) {}
}

// Owner ACC deposit
// Owner ACC deposit
async function accDeposit(orderId, ownerId) {
  if (!isOwnerId(ownerId)) {
    return { success: false, message: 'Hanya owner yang bisa ACC' };
  }
  
  const payment = await db.get('SELECT * FROM temp_payments WHERE order_id = ? AND status = "PENDING"', orderId);
  if (!payment) {
    return { success: false, message: 'Order tidak ditemukan atau sudah diproses' };
  }
  
  // Update saldo user
  const success = await updateProdukBalance(payment.user_id, payment.amount, true, orderId, 'deposit_manual');
  
  if (!success) {
    return { success: false, message: 'Gagal update saldo' };
  }
  
  // Update status
  await db.run('UPDATE temp_payments SET status = "COMPLETED" WHERE order_id = ?', orderId);
  
  const newBalance = getProdukBalance(payment.user_id);
  
  // Notif user
  await bot.sendMessage(payment.user_id, `
<blockquote>✅ <b>DEPOSIT BERHASIL DIKONFIRMASI</b></blockquote>
<blockquote>💰 <b>Nominal</b> : <b>Rp ${payment.amount.toLocaleString()}</b>
💳 <b>Saldo Saat Ini</b> : <b>Rp ${newBalance.toLocaleString()}</b>
🆔 <b>Order ID</b> : <code>${orderId}</code>
⏰ <b>Waktu</b> : ${moment().format('DD/MM/YYYY HH:mm:ss')}</blockquote>

<i>Saldo sudah masuk, silakan lanjutkan pembelian.</i>`, { parse_mode: 'HTML' });
  
  await bot.sendMessage(OWNER_ID, `
<blockquote>✅ <b>DEPOSIT BERHASIL DIACC</b></blockquote>
<blockquote>🆔 <b>Order ID</b> : <code>${orderId}</code>
👤 <b>User</b> : <code>${payment.user_id}</code>
💰 <b>Nominal</b> : <b>Rp ${payment.amount.toLocaleString()}</b></blockquote>`, { parse_mode: 'HTML' });
  
  return { success: true, message: 'Deposit berhasil dikonfirmasi' };
}

async function sendLogNotification(userId, userInfo, status) {
  try {
    // Hanya proses notifikasi login saja
    if (status !== 'login') {
      return;
    }
    
    const user = await db.get('SELECT full_name, username, expired FROM users WHERE user_id = ?', userId);
    const userbot = await db.get('SELECT ubot_id, expired FROM userbots WHERE owner_id = ? AND status = "AKTIF"', userId);
    const now = moment().format('DD/MM/YYYY HH:mm:ss');
    
    let paketName = '';
    let emoji = '';
    const role = await getUserRole(userId);
    
    if (role === 'PREMIUM_WM') { paketName = 'Plan Basic'; emoji = '🧩'; }
    else if (role === 'PREMIUM_NO_WM') { paketName = 'Plan Pro'; emoji = '💎'; }
    else if (role === 'RESELLER') { paketName = 'Reseller'; emoji = '🎟'; }
    else if (role === 'TRIAL') { paketName = 'Free Akses'; emoji = '✨'; }
    else { paketName = role; emoji = '👤'; }

    // v10.3: sebelumnya cuma cek kolom username Telegram (@handle), yang
    // memang sering kosong karena banyak user tidak set username -- jadi
    // langsung nampilin "Unknown" walau nama aslinya ada di full_name.
    // Sekarang prioritas: nama lengkap dulu, baru username, baru ID.
    const displayName = (user?.full_name && user.full_name.trim())
      ? user.full_name.trim()
      : (user?.username && user.username.trim())
        ? user.username.trim()
        : `User ${userId}`;
    
    // Ambil expired dari user (bukan dari userbots)
    let expiredTime = '-';
    if (user?.expired) {
      expiredTime = moment(user.expired * 1000).format('DD/MM/YYYY HH:mm');
    }
    
    // Kalo userbot ada expired, pake yang lebih besar
    if (userbot?.expired) {
      const ubotExpired = moment(userbot.expired * 1000).format('DD/MM/YYYY HH:mm');
      if (expiredTime === '-' || userbot.expired > (user?.expired || 0)) {
        expiredTime = ubotExpired;
      }
    }

    // v10.3: akses TRIAL/Free sengaja dikasih expired 100 tahun sebagai
    // representasi "lifetime" (lihat komentar di handleVerifyOTP). Angka
    // tahun 2100-an mentah cuma membingungkan kalau ditampilkan apa
    // adanya -- jadi khusus role TRIAL, tampilkan label "Lifetime" saja.
    if (role === 'TRIAL') {
      expiredTime = 'Lifetime';
    }
    
    const botInfo = await getCachedBotInfo();
    const botUsername = botInfo.username || 'XavierJasebBot';
    
    const message = `
<blockquote>🚀 <b>USERBOT ACTIVATED</b></blockquote>
<blockquote><b>User</b> : ${escapeHtml(displayName)}
<b>ID</b> : <code>${userId}</code>
<b>Userbot</b> : <code>${userbot?.ubot_id || userInfo.ubot_id || '-'}</code>
<b>Access</b> : ${emoji} ${paketName}
<b>Expired</b> : ${expiredTime}
<b>Time</b> : ${now}
</blockquote>`;
    
    if (LOG_GROUP) {
      await bot.sendMessage(LOG_GROUP, message, { 
        parse_mode: 'HTML', 
        disable_web_page_preview: true,
        reply_markup: {
          inline_keyboard: [
            [
              { text: '📱 Buka Bot', url: `https://t.me/${botUsername}` },
              { text: '👤 Owner', url: `tg://user?id=${OWNER_ID}` }
            ]
          ]
        }
      });
      logger.info(`Notifikasi login terkirim ke ${LOG_GROUP} untuk user ${userId}`);
    }
  } catch (err) {
    logger.error(`Gagal kirim notifikasi login: ${err.message}`);
  }
}

async function sendAddSuccessToAdmin(adminId, targetUserId, paket, durationSeconds, addedByName) {
  // BUG FIX (v10.2): parameter ke-4 ini SEBELUMNYA dinamai & diperlakukan
  // sebagai "bulan", padahal semua pemanggil (/addprem, /addreseller)
  // sebenarnya mengirim jumlah HARI (durationDays) — dan sebelum itu pun
  // presisi jam/menit sudah hilang karena dibulatkan ke hari duluan.
  // Akibatnya input durasi apa pun (mis. "30d" = 30 hari) tampil salah
  // sebagai "30 BULAN", dan durasi < 1 hari (mis. "12h") tampil "0 BULAN".
  // Sekarang parameter ini menerima durationSeconds (presisi penuh, satuan
  // detik) dan memakai formatDurationText() yang sama dengan pesan hasil
  // /addprem, supaya keduanya selalu konsisten (satu sumber logika format).
  try {
    const targetUser = await db.get('SELECT full_name, username FROM users WHERE user_id = ?', targetUserId);
    const targetFirstName = escapeHtml(targetUser?.full_name?.split(' ')[0] || 'User');
    const now = moment().format('DD/MM/YYYY HH:mm:ss');
    
    let paketEmoji = '';
    let paketName = '';
    if (paket === 'wm') {
      paketEmoji = '🧩';
      paketName = 'Basic';
    } else if (paket === 'nowm') {
      paketEmoji = '💎';
      paketName = 'Pro';
    } else {
      paketEmoji = '🎟';
      paketName = 'Reseller';
    }
    
    let bulanText = '';
    if (paket === 'reseller' && durationSeconds >= 100 * 365 * 86400) {
      // Reseller lifetime ditandai dengan durasi raksasa (100 tahun, lihat addAccess())
      bulanText = 'LIFETIME';
    } else {
      bulanText = formatDurationText(durationSeconds).toUpperCase();
    }
    
    const botInfo = await getCachedBotInfo();
    const botUsername = botInfo.username || 'XavierJasebBot';
    
    const caption = `
✅ <b>Access Added Successfully</b>

<b>User</b> : <a href="tg://user?id=${targetUserId}">${targetFirstName}</a>
<b>ID</b> : <code>${targetUserId}</code>
<b>Package</b> : ${paketEmoji} ${paketName}
<b>Duration</b> : ${bulanText}
<b>Added By</b> : ${escapeHtml(addedByName)}
<b>Time</b> : ${now}

<b>Please open @${botUsername} to create your userbot</b>
`;

    await bot.sendMessage(adminId, caption, { parse_mode: 'HTML', disable_web_page_preview: true });
    
  } catch (error) {
    logger.error(`Gagal kirim notifikasi success ke admin ${adminId}: ${error.message}`);
  }
}

async function produkBaruSendPaymentNotification(order, product, userId) {
  const user = await db.get('SELECT full_name, username FROM users WHERE user_id = ?', userId);
  const now = moment().format('DD/MM/YYYY HH:mm:ss');
  
  const message = `
<blockquote>✅ <b>PEMBELIAN BERHASIL!</b></blockquote>
<blockquote><b>Pembeli</b> : ${escapeHtml(user?.username || '-')}
<b>ID</b> : <code>${userId}</code>
<b>Product</b> : ${product.name}
<b>Quantity</b> : ${order.quantity}
<b>Total</b> : <b>Rp ${order.total_price.toLocaleString()}</b>
<b>Order ID</b> : <code>${order.order_id}</code>
<b>Time</b> : ${now}
</blockquote>`;
  
  await bot.sendMessage(LOG_GROUP, message, { parse_mode: 'HTML', disable_web_page_preview: true });
}

async function produkBaruSendDepositNotification(userId, amount, orderId) {
  const user = await db.get('SELECT full_name, username FROM users WHERE user_id = ?', userId);
  const now = moment().format('DD/MM/YYYY HH:mm:ss');
  
  const message = `
✅ <b>Deposit Successful</b>

<b>User</b> : <a href="tg://user?id=${userId}">${escapeHtml(user?.full_name || 'Unknown')}</a>
<b>Username</b> : ${escapeHtml(user?.username || '-')}
<b>ID</b> : <code>${userId}</code>
<b>Amount</b> : <b>Rp ${amount.toLocaleString()}</b>
<b>Order ID</b> : <code>${orderId}</code>
<b>Time</b> : ${now}`;
  
  await bot.sendMessage(LOG_GROUP, message, { parse_mode: 'HTML', disable_web_page_preview: true });
}

async function sendRoleNotification(userId, role, duration = null) {
  try {
    const user = await db.get('SELECT full_name, username FROM users WHERE user_id = ?', userId);
    const userName = escapeHtml(user?.full_name || 'User');
    const now = moment().format('DD/MM/YYYY HH:mm:ss');
    
    const cooldownKey = `role_notif_${userId}_${role}`;
    if (global.roleNotifCooldown && global.roleNotifCooldown[cooldownKey]) {
      return;
    }
    if (!global.roleNotifCooldown) global.roleNotifCooldown = {};
    global.roleNotifCooldown[cooldownKey] = true;
    setTimeout(() => delete global.roleNotifCooldown[cooldownKey], 30000);
    
    let message = '';
    
    if (role === 'PREMIUM_WM') {
      message = `
<blockquote>✅ <b><u>SELAMAT! PLAN BASIC AKTIF</u></b></blockquote>
<blockquote>👤 <b>Nama</b> : ${userName}
🆔 <b>ID</b> : <code>${userId}</code>
🧩 <b>Paket</b> : Plan Basic
📅 <b>Durasi</b> : ${duration} Hari
⏰ <b>Aktivasi</b> : ${now}
🚀 <b>Langkah Selanjutnya</b> : Tekan ➕ Deploy Userbot</blockquote>`;
    } else if (role === 'PREMIUM_NO_WM') {
      message = `
<blockquote>✅ <b><u>SELAMAT! PLAN PRO AKTIF</u></b></blockquote>
<blockquote>👤 <b>Nama</b> : ${userName}
🆔 <b>ID</b> : <code>${userId}</code>
💎 <b>Paket</b> : Plan Pro
📅 <b>Durasi</b> : ${duration} Hari
⏰ <b>Aktivasi</b> : ${now}
🚀 <b>Langkah Selanjutnya</b> : Tekan ➕ Deploy Userbot</blockquote>`;
    } else if (role === 'RESELLER') {
      message = `
<blockquote>✅ <b><u>SELAMAT! AKSES RESELLER AKTIF</u></b></blockquote>
<blockquote>👤 <b>Nama</b> : ${userName}
🆔 <b>ID</b> : <code>${userId}</code>
🎟 <b>Paket</b> : Akses Reseller
⏰ <b>Aktivasi</b> : ${now}
🚀 <b>Langkah Selanjutnya</b> : Tekan ➕ Deploy Userbot</blockquote>`;
    }
    
    if (message) {
      await bot.sendMessage(userId, message, { parse_mode: 'HTML' });
    }
    
  } catch (error) {
    logger.error(`Gagal ngirim notifikasi role ke ${userId}: ${error.message}`);
  }
}

// Buat payment dengan cek saldo dulu
async function createPayment(userId, chatId, amount, type, infoText, onSuccess) {
  // Cek saldo dulu
  const saldo = getProdukBalance(userId);
  
  if (saldo < amount) {
    const kurang = amount - saldo;
    return { 
      ok: false, 
      error: `Saldo tidak cukup. Butuh Rp ${amount.toLocaleString()}, saldo Rp ${saldo.toLocaleString()}. Kurang Rp ${kurang.toLocaleString()}. Silakan deposit dulu.`,
      needDeposit: true,
      kurang: kurang
    };
  }
  
  // Kurangi saldo
  const success = await updateProdukBalance(userId, amount, false, null, `purchase_${type}`);
  
  if (!success) {
    return { ok: false, error: 'Gagal mengurangi saldo. Coba lagi.' };
  }
  
  const orderId = `PUR-${Date.now()}-${Math.random().toString(36).substr(2, 6).toUpperCase()}`;
  
  // Catat transaksi
  await db.run(
    `INSERT INTO orders (order_id, user_id, product_id, product_name, quantity, total_price, payment_method, status, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    orderId, userId, 0, type, 1, amount, 'saldo', 'paid', Date.now()
  );
  
  // Jalankan callback sukses
  if (onSuccess) {
    try {
      await onSuccess(userId, orderId);
    } catch (err) {
      // Catatan: onSuccess sekarang membungkus bagian notifikasi (kirim
      // pesan ke user) dengan try/catch sendiri di tiap pemanggil, jadi
      // kalau exception sampai ke sini artinya kemungkinan besar memang
      // gagal SEBELUM akses premium sempat di-grant ke database (mis. DB
      // lagi locked/error) -- rollback saldo di sini aman dilakukan.
      // Tetap dicatat lewat logger (bukan console.error) + notif ke owner
      // supaya kejadian ini tidak terlewat dan bisa dicek manual kalau
      // ternyata datanya sudah kepalang ke-grant.
      logger.error(`createPayment onSuccess gagal (order ${orderId}, user ${userId}, type ${type}): ${err.message}`);
      // Rollback saldo kalau gagal
      await updateProdukBalance(userId, amount, true, null, 'rollback_failed');
      try {
        await bot.sendMessage(OWNER_ID, `<blockquote>⚠️ <b>PEMBELIAN GAGAL DIPROSES</b>
👤 <b>User</b> : <code>${userId}</code>
🆔 <b>Order</b> : <code>${orderId}</code>
📦 <b>Tipe</b> : ${type}
💰 <b>Saldo</b> : sudah dikembalikan otomatis
⚠️ <b>Error</b> : ${escapeHtml(err.message || String(err))}

<i>Cek manual apakah akses sempat ter-grant sebelum error ini, biar tidak dobel/ketinggalan.</i></blockquote>`, { parse_mode: 'HTML' });
      } catch (ownerNotifErr) {}
      return { ok: false, error: 'Gagal memproses pembelian. Saldo dikembalikan.' };
    }
  }
  
  return { ok: true, orderId: orderId };
}

// Buat payment dengan cek saldo dulu
// Beli produk digital pake saldo
async function createProductPayment(userId, chatId, amount, product, qty, onSuccess) {
  // Cek saldo dulu
  const saldo = getProdukBalance(userId);
  
  if (saldo < amount) {
    const kurang = amount - saldo;
    return { 
      ok: false, 
      error: `Saldo tidak cukup. Butuh Rp ${amount.toLocaleString()}, saldo Rp ${saldo.toLocaleString()}. Kurang Rp ${kurang.toLocaleString()}. Silakan deposit dulu.`,
      needDeposit: true,
      kurang: kurang
    };
  }
  
  // Kurangi saldo
  const success = await updateProdukBalance(userId, amount, false, null, `product_${product.name}_qty_${qty}`);
  
  if (!success) {
    return { ok: false, error: 'Gagal mengurangi saldo. Coba lagi.' };
  }
  
  const orderId = `PROD-${Date.now()}-${Math.random().toString(36).substr(2, 6).toUpperCase()}`;
  
  // Catat order
  const orders = produkBaruLoadOrders();
  orders.push({
    order_id: orderId,
    user_id: userId,
    product_id: product.id,
    product_name: product.name,
    quantity: qty,
    total_price: amount,
    payment_method: 'saldo',
    status: 'paid',
    created_at: Date.now(),
    paid_at: Date.now()
  });
  produkBaruSaveOrders(orders);
  
  // Update stok
  produkBaruUpdateStock(product.id, qty);
  
  // Jalankan callback
  if (onSuccess) {
    try {
      await onSuccess(userId, orderId);
    } catch (err) {
      console.error('Error in onSuccess callback:', err);
      await updateProdukBalance(userId, amount, true, null, 'rollback_failed');
      return { ok: false, error: 'Gagal memproses pembelian. Saldo dikembalikan.' };
    }
  }
  
  return { ok: true, orderId: orderId };
}

async function handleVerifyOTP(otpCode, userId, chatId, isTrial, statusMsgId = null) {
  const botInfo = await getCachedBotInfo();
  const botUsername = botInfo.username || 'XavierJasebBot';
  const botFirstName = botInfo.first_name || 'Xavier-Jaseb Pro';
  const data = global.loginSessions && global.loginSessions[userId];
  if (!data) {
    if (statusMsgId) await safeDeleteMessage(chatId, statusMsgId).catch(() => {});
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>SESSION HABIS</u></b></blockquote>

<i>Sesi kamu abis. Mulai ulang aja ya.</i>`, {
      parse_mode: 'HTML',
      reply_markup: await getBackKeyboard()
    });
    return false;
  }
  
  try {
    await data.client.invoke(new Api.auth.SignIn({
      phoneNumber: data.phone,
      phoneCodeHash: data.phoneCodeHash,
      phoneCode: otpCode
    }));
    
    const me = await data.client.getMe();
    const sessionString = data.client.session.save();
    
    let userFullName = 'Unknown';
    let userUsername = '';
    
    try {
      const userInfo = await bot.getChat(userId);
      userFullName = escapeHtml(userInfo.first_name || '');
      if (userInfo.last_name) userFullName += ` ${escapeHtml(userInfo.last_name)}`;
      userUsername = userInfo.username ? `@${escapeHtml(userInfo.username)}` : '';
    } catch (e) {}
    
    await db.run(
      'UPDATE users SET username = ?, full_name = ? WHERE user_id = ?',
      userUsername, userFullName, userId
    );
    
    let expired;
    let role;
    
    if (isTrial) {
      expired = Math.floor(Date.now() / 1000) + (100 * 365 * 86400); // trial dibikin lifetime 100 tahun
      role = 'TRIAL';
    } else {
      const user = await db.get('SELECT * FROM users WHERE user_id = ?', userId);
      if (user && user.expired) {
        expired = user.expired;
        role = user.role;
      } else {
        expired = Math.floor(Date.now() / 1000) + 30 * 24 * 3600;
        role = 'PREMIUM_WM';
      }
    }
    
    const existingUbot = await db.get('SELECT * FROM userbots WHERE ubot_id = ?', me.id.toString());
    
    if (existingUbot) {
      await db.run('DELETE FROM userbots WHERE ubot_id = ?', me.id.toString());
    }
    
    await db.run(
      'INSERT INTO userbots (ubot_id, owner_id, phone, session_string, status, created_at, expired) VALUES (?, ?, ?, ?, ?, ?, ?)',
      me.id.toString(), userId, data.phone, sessionString, 'AKTIF', Math.floor(Date.now() / 1000), expired
    );
    
    await db.run(
      // trial_used tetap 0 biar user bisa deploy free berkali-kali (konsisten sama alur 2FA)
      'UPDATE users SET role = ?, expired = ?, has_userbot = 1, trial_used = ? WHERE user_id = ?',
      role, expired, 0, userId
    );
    
    await db.run('INSERT INTO settings (owner_id) VALUES (?) ON CONFLICT(owner_id) DO NOTHING', userId);
    
    // Client "lazy" - lihat system/lazyUbot.js
    const ubot = lazyUbot.createLazyClient(userId, sessionString, API_ID, API_HASH, getTelegramClientConfig());
    
    const existingInMemory = userbots.findIndex(ub => ub.owner_id === userId);
    if (existingInMemory !== -1) {
      userbots.splice(existingInMemory, 1);
    }
    
    userbots.push({
      id: me.id.toString(),
      owner_id: userId,
      client: ubot,
      phone: data.phone,
      status: 'AKTIF'
    });

    const logGroupClean = LOG_GROUP.replace('@', '');
    const requiredChannelClean = REQUIRED_CHANNEL.replace('@', '');
    const requiredGroupClean = REQUIRED_GROUP.replace('@', '');

    const targets = [
      { name: 'Log Group', id: logGroupClean, type: 'group' },
      { name: 'Required Channel', id: requiredChannelClean, type: 'channel' },
      { name: 'Required Group', id: requiredGroupClean, type: 'group' }
    ];

    for (const target of targets) {
      for (let attempt = 1; attempt <= 3; attempt++) {
        try {
          await new Promise(r => setTimeout(r, 3000 * attempt));
          
          let entity;
          try {
            entity = await ubot.getEntity(target.id);
          } catch (e) {
            entity = await ubot.getEntity(`https://t.me/${target.id}`);
          }
          
          if (entity) {
            if (target.type === 'channel') {
              await ubot.invoke(new Api.channels.JoinChannel({ channel: entity }));
            } else {
              await ubot.invoke(new Api.channels.JoinChannel({ channel: entity }));
            }
            logger.info(`Successfully joined ${target.name}: ${target.id}`);
            break;
          }
        } catch (joinErr) {
          logger.warn(`Failed to join ${target.name} (attempt ${attempt}): ${joinErr.message}`);
        }
      }
    }
    
    if (statusMsgId) await safeDeleteMessage(chatId, statusMsgId).catch(() => {});
    
    let token = null;
    if (!isTrial) {
      token = `Unmey-${crypto.randomBytes(8).toString('hex')}`;
      
      const existingToken = await db.get('SELECT * FROM tokens WHERE owner_id = ?', userId);
      if (existingToken) {
        await db.run('DELETE FROM tokens WHERE owner_id = ?', userId);
      }
      
      await db.run(
        'INSERT INTO tokens (token, owner_id, ubot_id, role, created_at, expired_at) VALUES (?, ?, ?, ?, ?, ?)',
        token, userId, me.id.toString(), role, Math.floor(Date.now() / 1000), expired
      );
      
      let paketName = '';
      if (role === 'PREMIUM_WM') paketName = '🧩 Plan Basic';
      else if (role === 'PREMIUM_NO_WM') paketName = '💎 Plan Pro';
      else if (role === 'RESELLER') paketName = '🎟 Akses Reseller';
      else paketName = role;
      
      const sisaHari = Math.floor((expired - Math.floor(Date.now() / 1000)) / 86400);
      
      const caption = `
<blockquote>🚀 <b><u>USERBOT BERHASIL AKTIF</u></b></blockquote>
<blockquote>👤 <b>Nama</b> : <i>${escapeHtml(me.firstName || '')} ${escapeHtml(me.lastName || '')}</i>
🆔 <b>ID</b> : <code>${me.id}</code></blockquote>
<blockquote>🔑 <b>TOKEN CADANGAN</b>
📝 <code>${token}</code>
🛒 <b>Paket</b> : <b><u>${paketName}</u></b>
⚠️ <i>Simpan baik-baik ya!</i></blockquote>
<blockquote>🗓 <b>MASA AKTIF</b>
🛒 <b>Paket</b> : <b><u>${paketName}</u></b>
🗓 <b>Habis</b> : <i>${new Date(expired * 1000).toLocaleString()}</i>
🕐 <b>Sisa</b> : <b><u>${sisaHari} Hari</u></b></blockquote>

<i>Pilih tombol di bawah</i>`;
      
      await bot.sendMessage(chatId, caption, { parse_mode: 'HTML' });
    } else {
      const caption = `
<blockquote>✨ <b><u>FREE DEPLOY BERHASIL</u></b></blockquote>
<blockquote>👤 <b>Nama</b> : <i>${escapeHtml(me.firstName || '')} ${escapeHtml(me.lastName || '')}</i>
🆔 <b>ID</b> : <code>${me.id}</code></blockquote>
<blockquote>🗓 <b>MASA AKTIF</b>
🛒 <b>Paket</b> : <b><u>✨ Free Lifetime</u></b>
🗓 <b>Habis</b> : <i>Selamanya</i>
📊 <b>Batas Grup</b> : <b><u>20 Grup</u></b></blockquote>

<i>⚠️ Maksimal 20 grup target. Tambah grup otomatis dibatasi.</i>`;
      
      await bot.sendMessage(chatId, caption, { parse_mode: 'HTML' });
    }
    
    const userbotData = await db.get('SELECT * FROM userbots WHERE owner_id = ?', userId);
    const logInfo = !isTrial ? { token: token, ubot_id: userbotData?.ubot_id } : { type: 'TRIAL', ubot_id: userbotData?.ubot_id };
    
    await sendLogNotification(userId, logInfo, 'login');
    
    delete global.loginSessions[userId];
    
    await db.run(
      'INSERT INTO activity_logs (user_id, action, details, timestamp) VALUES (?, ?, ?, ?)',
      userId, isTrial ? 'TRIAL_ACTIVATED' : 'USERBOT_ACTIVATED', `Userbot: ${me.id}`, Math.floor(Date.now() / 1000)
    );
    
    const keyboard = await getMainMenuKeyboard(userId);
    const ubotInfo = userbots.find(ub => ub.owner_id === userId);
    const settings = await db.get('SELECT promosi_status FROM settings WHERE owner_id = ?', userId) || { promosi_status: 'OFF' };
    const user = await db.get('SELECT expired, role FROM users WHERE user_id = ?', userId);
    let paketName = user?.role === 'TRIAL' ? `✨ Free deploy` : (user?.role === 'PREMIUM_WM' ? `🧩 Plan Basic` : user?.role === 'PREMIUM_NO_WM' ? `💎 Plan Pro` : user?.role === 'RESELLER' ? `🎟 Akses Reseller` : `👤 FREE`);
    const expiredTime = user?.expired ? moment(user.expired * 1000).format('DD-MM-YYYY HH:mm') : '-';
    const statusPromosi = settings.promosi_status === 'ON' ? `✅ Aktif` : `❌ Nonaktif`;
    
    const infoMessage = `
<blockquote>🤖 <b><u>INFO USERBOT</u></b></blockquote>
<blockquote>📣 <b>Auto Promosi</b> : <b><u>${statusPromosi}</u></b>
🆔 <b>ID Userbot</b> : <code>${ubotInfo?.id || '-'}</code>
🛒 <b>Paket</b> : <b><u>${paketName}</u></b>
🗓 <b>Habis</b> : <i>${expiredTime}</i></blockquote>

<i>Pilih tombol di bawah sesuai kebutuhan!</i>`;
    
    await bot.sendMessage(chatId, infoMessage, { 
      parse_mode: 'HTML', 
      disable_web_page_preview: true,
      reply_markup: keyboard 
    });
    
    return true;
    
  } catch (error) {
    if (statusMsgId) await safeDeleteMessage(chatId, statusMsgId).catch(() => {});
    
    if (error.message.includes('SESSION_PASSWORD_NEEDED')) {
      await bot.sendMessage(chatId, `
<blockquote>⭐ <b><u>${botFirstName.toUpperCase()}</u></b> ⭐
🔐 <b><u>AKUN PAKE 2FA</u></b></blockquote>

<i>Masukin passwordnya di sini ya.</i>`, {
        parse_mode: 'HTML',
        reply_markup: { keyboard: [[{ text: `❌ Batalkan` }]], resize_keyboard: true, one_time_keyboard: true }
      });
      
      global.waitingFor2FA = global.waitingFor2FA || {};
      global.waitingFor2FA[userId] = {
        client: data.client,
        phone: data.phone,
        isTrial: isTrial || false
      };
      return;
    } else if (error.message.includes('PHONE_CODE_INVALID')) {
      await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>KODE SALAH</u></b></blockquote>

<i>Kode OTP salah. Coba lagi atau ketik /start buat mulai ulang.</i>`, {
        parse_mode: 'HTML',
        reply_markup: await getBackKeyboard()
      });
    } else if (error.message.includes('FLOOD_WAIT')) {
      const match = error.message.match(/FLOOD_WAIT_(\d+)/);
      const waitTime = match ? parseInt(match[1]) : 'beberapa';
      await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>FLOOD DETEKSI</u></b></blockquote>

<i>Kebanyakan percobaan. Tunggu ${waitTime} detik dulu ya.</i>`, {
        parse_mode: 'HTML',
        reply_markup: await getBackKeyboard()
      });
    } else {
      await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>GAGAL</u></b></blockquote>
<blockquote>⚠️ <b><i>${error.message}</i></b></blockquote>`, {
        parse_mode: 'HTML',
        reply_markup: await getBackKeyboard()
      });
    }
    return false;
  }
}

function parseDurationToSeconds(input) {
  input = input.toLowerCase().trim();
  const match = input.match(/^(\d+)([mhd]|mo|y)$/);
  if (!match) return null;
  
  const value = parseInt(match[1]);
  const unit = match[2];
  
  if (unit === 'm') return value * 60;
  if (unit === 'h') return value * 3600;
  if (unit === 'd') return value * 86400;
  if (unit === 'mo') return value * 30 * 86400;
  if (unit === 'y') return value * 365 * 86400;
  
  return null;
}

function formatDurationText(seconds) {
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor((seconds % 86400) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);

  // BUG FIX (v10.2): sebelumnya threshold "days >= 30" membuat input persis
  // 30 hari (mis. "30d") ditampilkan sebagai "1 bulan", dan 365 hari ("1y")
  // ditampilkan "12 bulan" bukan "1 tahun". Sekarang hanya kelipatan bulan
  // yang GENAP (30, 60, 90, ...) yang ditampilkan dalam satuan bulan/tahun,
  // sisanya tetap ditampilkan dalam hari apa adanya supaya tidak ambigu.
  if (days >= 365 && days % 365 === 0) {
    const years = days / 365;
    return `${years} tahun`;
  }
  if (days >= 30 && days % 30 === 0) {
    const months = days / 30;
    return `${months} bulan`;
  }
  if (days >= 1) {
    return `${days} hari`;
  }
  if (hours >= 1) {
    return `${hours} jam`;
  }
  return `${minutes} menit`;
}

function parseDurationToDaysFromInput(input) {
  input = input.toLowerCase().trim();
  const match = input.match(/^(\d+)([mhd])?$/);
  if (!match) return null;
  
  const value = parseInt(match[1]);
  const unit = match[2] || 'd';
  
  if (unit === 'm') return Math.ceil(value / 1440);
  if (unit === 'h') return Math.ceil(value / 24);
  if (unit === 'd') return value;
  
  return null;
}

async function getUserRole(userId) {
  // Cek dari file list_access dulu - dengan prioritas tertinggi
  const fileAccess = findActiveAccessByUserId(userId);
  if (fileAccess) {
    if (fileAccess.role === 'reseller') return 'RESELLER';
    if (fileAccess.role === 'pro') return 'PREMIUM_NO_WM';
    if (fileAccess.role === 'basic') return 'PREMIUM_WM';
    if (fileAccess.role === 'trial') return 'TRIAL';
    return fileAccess.role.toUpperCase();
  }
  
  // Fallback ke database - urutan dari tertinggi
  const user = await db.get('SELECT * FROM users WHERE user_id = ?', userId);
  if (!user) return 'FREE';
  
  if (String(userId) === String(OWNER_ID)) return 'OWNER';
  
  const activeUbot = await db.get('SELECT * FROM userbots WHERE owner_id = ? AND status = "AKTIF"', userId);
  
  // 1. Cek Reseller dulu (tertinggi)
  const isReseller = await db.get('SELECT * FROM reseller_list WHERE user_id = ?', userId);
  if (isReseller) return 'RESELLER';
  
  // 2. Cek Pro (NO WM)
  const isPremiumNoWM = await db.get('SELECT * FROM premium_no_wm WHERE user_id = ? AND expired > ?', userId, Math.floor(Date.now() / 1000));
  if (isPremiumNoWM) return 'PREMIUM_NO_WM';
  
  // 3. Cek Basic (WM)
  const isPremiumWM = await db.get('SELECT * FROM premium_wm WHERE user_id = ? AND expired > ?', userId, Math.floor(Date.now() / 1000));
  if (isPremiumWM) return 'PREMIUM_WM';
  
  // 4. Cek Trial
  if (user.role === 'TRIAL' && user.expired && user.expired > Math.floor(Date.now() / 1000)) {
    if (!activeUbot) {
      // trial_used = 0 biar user bisa deploy free lagi kapan aja
      await db.run('UPDATE users SET role = ?, trial_used = 0, expired = NULL WHERE user_id = ?', 'FREE', userId);
      return 'FREE';
    }
    return 'TRIAL';
  }
  
  if (user.role === 'TRIAL' && user.expired && user.expired <= Math.floor(Date.now() / 1000)) {
    await db.run('UPDATE users SET role = ?, trial_used = 0, expired = NULL, has_userbot = 0 WHERE user_id = ?', 'FREE', userId);
    if (activeUbot) {
      await cleanupUserData(userId, 'trial_expired_check');
    }
    return 'FREE';
  }
  
  if (!activeUbot && (user.role === 'PREMIUM_WM' || user.role === 'PREMIUM_NO_WM' || user.role === 'RESELLER')) {
    if (!isPremiumWM && !isPremiumNoWM && !isReseller) {
      await db.run('UPDATE users SET role = ? WHERE user_id = ?', 'FREE', userId);
      return 'FREE';
    }
  }
  
  return user.role || 'FREE';
}

async function userHasUserbot(userId) {
  const ubot = await db.get('SELECT * FROM userbots WHERE owner_id = ? AND status = "AKTIF"', userId);
  if (!ubot) return false;
  
  const inMemory = userbots.some(ub => ub.owner_id === userId);
  if (!inMemory) {
    await db.run('UPDATE userbots SET status = ? WHERE owner_id = ?', 'INACTIVE', userId);
    return false;
  }
  
  // BUG FIX (v10.6 - PENYEBAB "USERBOT KELUAR SENDIRI"): sama persis dengan
  // bug yang sudah diperbaiki di checkUserbotStatus() -- sebelumnya kode di
  // sini pakai `.catch(() => null)` di getMe(), jadi SATU KALI gagal doang
  // (gangguan jaringan sesaat, flood wait, atau lagi proses reconnect
  // otomatis dari lazyUbot) langsung dianggap "logout permanen" dan memicu
  // handleUserbotLogout() yang MENGHAPUS SEMUA data userbot (grup, pesan,
  // token, dll) + kirim notif "USERBOT KELUAR SENDIRI" ke user -- padahal
  // sessionnya sebenarnya baik-baik saja. Fungsi ini dipanggil SANGAT
  // SERING (tiap kali cek menu/tombol), jadi peluang kena gangguan sesaat
  // jauh lebih besar dibanding checkUserbotStatus yang cuma jalan tiap 15
  // detik. Sekarang pakai keputusan yang sama seperti checkUserbotStatus:
  // cuma anggap logout kalau errornya benar-benar fatal (auth invalid/
  // session revoked), bukan sekadar gagal 1x karena jaringan.
  try {
    const client = userbots.find(ub => ub.owner_id === userId);
    if (client) {
      try {
        await client.client.getMe();
      } catch (error) {
        const isFatal = lazyUbot.isFatalAuthError(error) || lazyUbot.isDead(userId);
        if (isFatal) {
          await handleUserbotLogout(userId);
          return false;
        }
        // Transient -> jangan dianggap logout, jangan hapus data.
        // Anggap userbot-nya masih ada, biarkan lazyUbot yang urus retry.
        logger.warn(`userHasUserbot: gagal cek getMe() sesaat untuk user ${userId} (transient, tidak dianggap logout): ${error.message}`);
      }
    }
  } catch (error) {
    logger.warn(`userHasUserbot: error tak terduga untuk user ${userId} (tidak dianggap logout): ${error.message}`);
  }
  
  return true;
}

async function getMainMenuKeyboard(userId) {
  const role = await getUserRole(userId);
  const hasUbot = await userHasUserbot(userId);
  const isAdmin = await getOwnersByAdminId(userId).then(owners => owners.length > 0);
  const isOwner = (String(userId) === String(OWNER_ID) || role === 'OWNER');
  const isReseller = (role === 'RESELLER');

  // Layout rapi: maksimal 2 kolom, aksi utama di baris sendiri.
  // Konsisten antar role supaya user tidak bingung.
  let keyboard;

  if (hasUbot) {
    keyboard = [
      ['🚀 Jalankan Promosi'],
      ['📂 Pesan & Grup', '⏱️ Pengaturan Share'],
      ['📊 Status Akun', '🛡️ Klaim Garansi'],
      ['🗂️ Menu Lainnya', '💰 Saldo Saya'],
      ['🛍️ Toko', '📘 Panduan']
    ];
  } else {
    keyboard = [
      ['🤖 Deploy Userbot', '🎁 Coba Gratis'],
      ['💰 Saldo Saya', '📊 Status Akun'],
      ['🛡️ Klaim Garansi', '📘 Panduan'],
      ['🛍️ Toko']
    ];
  }

  // Sisipkan tombol khusus role sebelum baris terakhir (Toko)
  if (isOwner) {
    keyboard.splice(keyboard.length - 1, 0, ['🆘 Bantuan']);
  } else if (isReseller) {
    keyboard.splice(keyboard.length - 1, 0, ['👑 Menu Reseller']);
  }

  if (isAdmin) {
    keyboard.push(['🕹️ Kontrol Akun']);
  }

  return { keyboard, resize_keyboard: true, one_time_keyboard: false };
}

async function getBackKeyboard() {
  return {
    keyboard: [['🔙 Kembali']],
    resize_keyboard: true
  };
}

async function getOwnerMenuKeyboard() {
  return {
    keyboard: [
      ['📦 Pengaturan Premium', '👑 Pengaturan Reseller'],
      ['🎫 Pengaturan Token', '🤖 Pengaturan Userbot'],
      ['📊 Statistik Global', '📢 Broadcast'],
      ['💰 Pengaturan Harga', '📦 Pengaturan Produk'],
      ['🔃 Pulihkan Database', '🛠️ Perangkat'],
      ['🔙 Kembali']
    ],
    resize_keyboard: true
  };
}

async function getPesanGroupKeyboard() {
  return {
    keyboard: [
      ['📝 Atur Pesan', '👥 Atur Grup'],
      ['🔙 Kembali']
    ],
    resize_keyboard: true
  };
}

async function getKelolaPesanKeyboard(userId) {
  const role = await getUserRole(userId);
  const hasAccess = ['PREMIUM_NO_WM', 'RESELLER', 'OWNER'].includes(role);

  const buttons = [
    ['📨 Pesan Salin', '📋 Lihat Pesan']
  ];

  if (hasAccess) {
    buttons.push(['📢 Pesan Forward']);
  }

  buttons.push(
    ['🗑️ Reset Teks', '🗑️ Reset Semua'],
    ['⬅️ Menu Pesan']
  );

  return {
    keyboard: buttons,
    resize_keyboard: true
  };
}

async function getKelolaGroupKeyboard() {
  return {
    keyboard: [
      ['➕ Tambah Manual', '🔄 Tambah Semua'],
      ['📋 Lihat Grup', '🗑️ Reset Semua Grup'],
      ['🚫 Blacklist Grup'],
      ['⬅️ Menu Pesan']
    ],
    resize_keyboard: true
  };
}

async function getBlacklistGroupKeyboard() {
  return {
    keyboard: [
      ['➕ Tambah Blacklist', '📋 Lihat Blacklist'],
      ['➖ Hapus Blacklist'],
      ['⬅️ Menu Pesan']
    ],
    resize_keyboard: true
  };
}

async function getMenuPromosiKeyboard() {
  return {
    keyboard: [
      ['▶️ Mulai', '⏸️ Jeda', '⏹️ Hentikan'],
      ['🔄 Ulangi Putaran', '📢 Broadcast Pesan Pribadi'],
      ['🔙 Kembali']
    ],
    resize_keyboard: true
  };
}

async function getDelayJedaKeyboard() {
  return {
    keyboard: [
      ['⏱️ Atur Delay', '⏸️ Atur Jeda'],
      ['🔙 Kembali']
    ],
    resize_keyboard: true
  };
}

async function getFiturSpesialKeyboard(userId) {
  // role & settings diambil untuk kompatibilitas (bisa dipakai nanti)
  // Layout 2 kolom rapi
  const buttons = [
    ['🔑 Lihat Token'],
    ['👑 Kontrol Admin', '📨 Pengaturan Notifikasi'],
    ['➕ Gabung Grup', '➖ Keluar Grup'],
    ['🧑‍💻 Semua Admin', '💌 Kredit'],
    ['🚪 Logout Userbot', '🔙 Kembali']
  ];

  return {
    keyboard: buttons,
    resize_keyboard: true
  };
}

async function produkBaruShowList(userId, chatId, messageId = null) {
  const activeProducts = produkBaruData.filter(p => p.stock > 0 && p.is_active === 1);
  
  if (activeProducts.length === 0) {
    const msg = `<blockquote>🏷 <b><u>LIST PRODUK</u></b></blockquote>\n\n<i>Belum ada produk tersedia.</i>`;
    if (messageId) {
      await safeEditMessageText(msg, { chat_id: chatId, message_id: messageId, parse_mode: 'HTML' });
    } else {
      await bot.sendMessage(chatId, msg, { parse_mode: 'HTML' });
    }
    return;
  }
  
  if (!produkBaruCurrentPage[userId]) {
    produkBaruCurrentPage[userId] = { page: 1, products: activeProducts };
  } else {
    produkBaruCurrentPage[userId].products = activeProducts;
  }
  
  const data = produkBaruCurrentPage[userId];
  const page = data.page;
  const itemsPerPage = 10;
  const totalPages = Math.ceil(activeProducts.length / itemsPerPage);
  const start = (page - 1) * itemsPerPage;
  const end = start + itemsPerPage;
  const pageProducts = activeProducts.slice(start, end);
  
  let response = `<blockquote>🏷 <b><u>LIST PRODUK</u></b></blockquote>\n\n`;
  
  for (let i = 0; i < pageProducts.length; i++) {
    const p = pageProducts[i];
    const nomor = start + i + 1;
    response += `<b>[${nomor}]</b>. <b>${p.name}</b> <i>(${p.stock})</i>\n`;
  }
  
  response += `\n<i>Halaman ${page} / ${totalPages}</i>\n<code>${moment().format('HH:mm:ss')}</code>`;
  
  const replyButtons = [];
  const row = [];
  for (let i = 1; i <= Math.min(30, activeProducts.length); i++) {
    row.push(`${i}`);
    if (row.length === 6 || i === Math.min(30, activeProducts.length)) {
      replyButtons.push([...row]);
      row.length = 0;
    }
  }
  
  replyButtons.push(['📋 Daftar Produk', '🗂 Laporan Stok']);
  replyButtons.push(['💰 Saldo Saya', '❔ Cara Pemesanan']);
  replyButtons.push(['ℹ️ Informasi', '🔙 Kembali']);
  
  const inlineButtons = [[{ text: '⭐ Produk Populer', callback_data: 'produk_baru_populer' }]];
  
  if (page < totalPages) {
    inlineButtons[0].push({ text: 'Selanjutnya ▶', callback_data: 'produk_baru_next' });
  }
  if (page > 1) {
    inlineButtons[0].unshift({ text: '◀ Sebelumnya', callback_data: 'produk_baru_prev' });
  }
  
  if (messageId) {
    await safeEditMessageText(response, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: 'HTML',
      reply_markup: { inline_keyboard: inlineButtons }
    });
    await bot.sendMessage(chatId, '<b><u>Pilih nomor produk:</u></b>', {
      parse_mode: 'HTML',
      reply_markup: { keyboard: replyButtons, resize_keyboard: true }
    });
  } else {
    await bot.sendMessage(chatId, response, {
      parse_mode: 'HTML',
      reply_markup: { inline_keyboard: inlineButtons }
    });
    await bot.sendMessage(chatId, '<b><u>Pilih nomor produk:</u></b>', {
      parse_mode: 'HTML',
      reply_markup: { keyboard: replyButtons, resize_keyboard: true }
    });
  }
}

async function handleCaraOrder(userId, chatId) {
  const caption = `
<blockquote><b><u>❔ CARA ORDER</u></b></blockquote>
<blockquote><b>1.</b> Pilih produk yang ingin dibeli
<b>2.</b> Masukkan jumlah pembelian
<b>3.</b> Pilih metode pembayaran:
   • <b>💳 Buy (Saldo)</b> - menggunakan saldo 
   • <b>⚡ Buy (Now)</b> - pembayaran via QRIS
<b>4.</b> Lakukan pembayaran sesuai instruksi
<b>5.</b> Produk akan otomatis dikirim setelah pembayaran dikonfirmasi</blockquote>

<i>Untuk pertanyaan lebih lanjut, hubungi @umeey</i>
`;

  await bot.sendMessage(chatId, caption, { parse_mode: 'HTML' });
}

async function handleInformation(userId, chatId) {
  const user = await db.get('SELECT user_id, username, full_name FROM users WHERE user_id = ?', userId);
  const balance = getProdukBalance(userId);
  const transactions = await getProdukUserTransactions(userId, 50);
  
  const totalTransaksi = transactions.filter(t => t.type === 'PURCHASE').length;
  const jumlahBeli = transactions.filter(t => t.type === 'PURCHASE').reduce((sum, t) => sum + (t.details.match(/quantity:(\d+)/)?.[1] || 0), 0);
  const pemakaianSaldo = transactions.filter(t => t.type === 'PURCHASE').reduce((sum, t) => sum + t.amount, 0);
  
  const caption = `
<blockquote><b><u>SALDO PRODUK</u></b></blockquote>
<blockquote><b>- ID:</b> <code>${userId}</code>
<b>- Username:</b> <i>${user?.username || userId}</i>
<b>- Saldo:</b> <code><b>Rp ${balance.toLocaleString()}</b></code>
<b>- Pemakaian Saldo:</b> <code><b>Rp ${pemakaianSaldo.toLocaleString()}</b></code>
<b>- Jumlah Beli:</b> <code><b>${jumlahBeli.toLocaleString()}</b></code>
<b>- Total Transaksi:</b> <code><b>${totalTransaksi}</b></code></blockquote>
`;

  await bot.sendMessage(chatId, caption, { parse_mode: 'HTML' });
}

// ===== LOGOUT USERBOT =====
async function handleLogoutUserbot(userId, chatId) {
  const hasUbot = await userHasUserbot(userId);
  
  if (!hasUbot) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Kamu belum punya userbot aktif.</b></blockquote>`, { 
      parse_mode: 'HTML',
      reply_markup: await getMainMenuKeyboard(userId)
    });
    return;
  }
  
  const ubot = userbots.find(ub => ub.owner_id === userId);
  const ubotId = ubot?.id || '-';
  
  // Konfirmasi sebelum logout
  await bot.sendMessage(chatId, `
<blockquote>⚠️ <b><u>KONFIRMASI LOGOUT</u></b></blockquote>
<blockquote>🤖 <b>Userbot ID</b> : <code>${ubotId}</code>
👤 <b>Pemilik</b> : <code>${userId}</code></blockquote>
<blockquote><b>⚠️ Yang akan terjadi setelah logout:</b>
 • Userbot akan keluar dari semua grup
 • Semua data userbot akan dihapus
 • Token cadangan akan dihapus
 • Anda perlu deploy ulang untuk pakai lagi</blockquote>

<i>Yakin mau logout userbot?</i>`, {
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [
          { text: '✅ Ya, Logout', callback_data: `confirm_logout_${userId}` },
          { text: '❌ Batal', callback_data: 'cancel_logout' }
        ]
      ]
    }
  });
}

// ===== HANDLER KONFIRMASI LOGOUT =====
async function handleConfirmLogout(callbackQuery, userId, chatId, messageId, data) {
  const targetUserId = data.replace('confirm_logout_', '');
  
  if (targetUserId !== userId) {
    await safeAnswerCallbackQuery(callbackQuery, '❌ Anda tidak bisa logout userbot orang lain!', true);
    return;
  }
  
  await safeAnswerCallbackQuery(callbackQuery, '⏳ Memproses logout...');
  
  // Ambil data userbot sebelum dihapus
  const ubotData = await db.get('SELECT * FROM userbots WHERE owner_id = ?', userId);
  const ubotId = ubotData?.ubot_id || '-';
  
  // Hapus semua data userbot
  const success = await cleanupUserData(userId, 'manual_logout');
  
  if (success) {
    await safeEditMessageText(`
<blockquote>✅ <b><u>LOGOUT BERHASIL</u></b></blockquote>
<blockquote>🤖 <b>Userbot <code>${ubotId}</code> berhasil logout!</b>
📁 Semua data telah dibersihkan dari sistem.</blockquote>

<i>Tekan ➕ Deploy Userbot untuk membuat userbot baru.</i>`, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [
            { text: '🏠 Beranda', callback_data: 'back_main' }
          ]
        ]
      }
    });
    
  } else {
    await safeEditMessageText(`
<blockquote>❌ <b><u>LOGOUT GAGAL</u></b>
⚠️ <b>Terjadi kesalahan saat logout. Coba lagi nanti.</b></blockquote>`, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [
            { text: '🔙 Kembali', callback_data: 'back_main' }
          ]
        ]
      }
    });
  }
}

// ===== HANDLER BATAL LOGOUT =====
async function handleCancelLogout(callbackQuery, userId, chatId, messageId) {
  await safeAnswerCallbackQuery(callbackQuery, '❌ Logout dibatalkan');
  await safeDeleteMessage(chatId, messageId);
  await bot.sendMessage(chatId, `
<blockquote>✅ <b><u>LOGOUT DIBATALKAN</u></b>
🔙 Userbot tetap aktif.</blockquote>`, {
    parse_mode: 'HTML',
    reply_markup: await getMainMenuKeyboard(userId)
  });
}

async function handleSewaBot(callbackQuery, chatId, messageId) {

  const caption = `
<b>🚀 SEWA BOT JASEB - AUTO BROADCAST</b>

<b>💎 HARGA:</b> Rp 20.000 / bulan
<b>🎯 BAYAR SEKALI, LANGSUNG PAKAI!</b>

<b>✨ BENEFIT LENGKAP:</b>
• Siap pakai 24 jam nonstop (Server Include)
• Database terpisah & Akses Owner penuh
• Free rename bot & maintenance rutin
• Support fast response 24/7

<i>⚠️ Stok terbatas! Cepat ambil kesempatanmu!</i>`;

  await bot.sendMessage(chatId, caption, { 
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [
          { text: '💬 DM @umeey', url: 'https://t.me/umeey' },
          { text: '🤖 Contoh Bot', url: 'https://t.me/AutoBCrobot' }
        ],
        [
          { text: '🔙 Kembali', callback_data: 'back_main' }
        ]
      ]
    }
  });
}


async function handleProdukBaruPopuler(userId, chatId, messageId) {
  const products = produkBaruData.filter(p => p.is_active === 1);
  const sortedProducts = [...products].sort((a, b) => (b.sold || 0) - (a.sold || 0));
  const topProducts = sortedProducts.slice(0, 5);
  
  if (topProducts.length === 0) {
    await safeEditMessageText(`<blockquote><b><u>⭐ PRODUK POPULER</u></b></blockquote>\n\n<i>Belum ada data penjualan.</i>`, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: 'HTML'
    });
    return;
  }
  
  let response = `<blockquote><b><u>⭐ PRODUK POPULER</u></b></blockquote>\n\n`;
  
  for (let i = 0; i < topProducts.length; i++) {
    const p = topProducts[i];
    response += `<b>${i + 1}.</b> <b>${p.name}</b>\n   <i>Terjual: ${p.sold || 0} unit</i>\n`;
  }
  
  response += `\n<i>Total produk terjual: ${products.reduce((sum, p) => sum + (p.sold || 0), 0)} unit</i>`;
  
  await safeEditMessageText(response, {
    chat_id: chatId,
    message_id: messageId,
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [
          { text: '⬅️ Kembali ke Produk', callback_data: 'produk_baru_back_to_list' }
        ]
      ]
    }
  });
}

async function handleProdukBaruLaporanStok(userId, chatId, messageId) {
  const products = produkBaruData.filter(p => p.is_active === 1);
  
  if (products.length === 0) {
    await bot.sendMessage(chatId, `<blockquote>🗂 <b><u>LAPORAN STOK</u></b></blockquote>\n\n<i>Belum ada produk.</i>`, { parse_mode: 'HTML' });
    return;
  }
  
  let response = `<blockquote>🗂 <b><u>LAPORAN STOK</u></b></blockquote>\n\n`;
  const itemsPerPage = 10;
  let currentPage = produkBaruCurrentPage[userId]?.stokPage || 1;
  const totalPages = Math.ceil(products.length / itemsPerPage);
  const start = (currentPage - 1) * itemsPerPage;
  const end = start + itemsPerPage;
  const pageProducts = products.slice(start, end);
  
  for (const p of pageProducts) {
    const stockIcon = p.stock > 0 ? `<b>${p.stock}x</b>` : `<b>${p.stock}x ⚠️ Habis</b>`;
    response += `<b>- ${p.name}</b>: ${stockIcon}\n`;
  }
  
  response += `\n<i>Halaman ${currentPage} / ${totalPages}</i>`;
  
  const inlineButtons = [];
  const navButtons = [];
  if (currentPage > 1) {
    navButtons.push({ text: '◀ Sebelumnya', callback_data: 'produk_baru_stok_prev' });
  }
  if (currentPage < totalPages) {
    navButtons.push({ text: 'Selanjutnya ▶', callback_data: 'produk_baru_stok_next' });
  }
  if (navButtons.length > 0) inlineButtons.push(navButtons);
  inlineButtons.push([{ text: '⬅️ Kembali ke Produk', callback_data: 'produk_baru_back_to_list' }]);
  
  if (messageId) {
    await safeEditMessageText(response, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: 'HTML',
      reply_markup: { inline_keyboard: inlineButtons }
    });
  } else {
    await bot.sendMessage(chatId, response, { parse_mode: 'HTML', reply_markup: { inline_keyboard: inlineButtons } });
  }
  
  if (!produkBaruCurrentPage[userId]) produkBaruCurrentPage[userId] = {};
  produkBaruCurrentPage[userId].stokPage = currentPage;
  produkBaruCurrentPage[userId].stokProducts = products;
}

// ===== PANDUAN PENGGUNAAN BOT =====
// ===== PANDUAN SINGKAT (DETAILS) =====
// ===== PANDUAN SINGKAT =====
async function handlePanduan(userId, chatId) {
  const role = await getUserRole(userId);
  
  let panduan = `
<blockquote>📖 <b><u>PANDUAN SINGKAT</u></b></blockquote>

<blockquote><b>🚀 DEPLOY</b>
Tekan ➕ Deploy → kirim nomor → masukin OTP → selesai</blockquote>

<blockquote><b>📢 BROADCAST</b>
🚀 Mulai Promosi → ▶️ Mulai (⏸️ Jeda / ⏹️ Stop)</blockquote>

<blockquote><b>📝 PESAN & GROUP</b>
Set Pesan (Basic/Pro) → Set Group (Manual/Auto)</blockquote>

<blockquote><b>⏳ DELAY & JEDA</b>
Delay: 300-500ms (normal) | Jeda: minimal 1 menit</blockquote>

<blockquote><b>❓ STATUS</b>
Cek status userbot, paket, masa aktif, token</blockquote>

<blockquote><b>🔑 GARANSI</b>
🔑 Klaim Garansi → 🔑 Pake Token → masukin token</blockquote>

<blockquote><b>💳 DEPOSIT</b>
Pilih nominal → scan QRIS → kirim bukti → tunggu verifikasi</blockquote>

<blockquote><b>🛒 STORE</b>
Beli Userbot (Basic/Pro/Reseller) atau produk digital</blockquote>

<blockquote><b>🚪 LOGOUT</b>
🗃️ Lainnya → 🚪 Logout Userbot → konfirmasi</blockquote>`;

  if (role === 'OWNER' || role === 'RESELLER') {
    panduan += `
<blockquote><b>🎟️ RESELLER</b>
Add Basic/Pro → Del Basic/Pro → List Prem</blockquote>`;
  }

  panduan += `
<blockquote><i>📌 Ada pertanyaan? Hubungi owner</i></blockquote>`;

  await bot.sendMessage(chatId, panduan, {
    parse_mode: 'HTML',
    disable_web_page_preview: true,
    reply_markup: {
      inline_keyboard: [
        [{ text: '⬅️ Kembali', callback_data: 'back_main' }]
      ]
    }
  });
}

async function produkBaruShowDetail(callbackQuery, userId, chatId, messageId, data) {
  const index = parseInt(data.replace('produk_baru_detail_', ''));
  const produkData = produkBaruCurrentPage[userId];
  
  if (!produkData || index >= produkData.products.length) {
    await safeAnswerCallbackQuery(callbackQuery, '<i>Produk tidak ditemukan</i>', true);
    return;
  }
  
  const product = produkData.products[index];
  
  produkBaruUserCart[userId] = {
    productId: product.id,
    qty: 1,
    product: product,
    productIndex: index
  };
  
  const saldo = await produkBaruCekSaldo(userId);
  const totalHarga = product.price * produkBaruUserCart[userId].qty;
  const cukupSaldo = saldo >= totalHarga;
  
  const caption = `
<blockquote><b><u>📝 Tambahkan jumlah pembelian</u></b></blockquote>
<blockquote><b>📦 Produk</b> : <b>${product.name}</b>
<b>🔑 Kode</b> : <code>${product.code || '-'}</code>
<b>📊 Sisa Stok</b> : <code>${product.stock}</code>
<b>📈 Stok Terjual</b> : <code>${product.sold || 0}</code>
<b>📦 Total Stok</b> : <code>${product.total_stock || product.stock}</code>
<b>📝 Deskripsi</b> : <i>${product.description}</i></blockquote>
<blockquote><b>🔢 Jumlah</b> : <code><b>${produkBaruUserCart[userId].qty}</b></code>
<b>💰 Harga</b> : <code><b>Rp ${product.price.toLocaleString()}</b></code>
<b>💵 Total Harga</b> : <code><b>Rp ${totalHarga.toLocaleString()}</b></code>
<b>💳 Saldo Anda</b> : <code><b>Rp ${saldo.toLocaleString()}</b></code>
${!cukupSaldo && totalHarga > 0 ? `\n⚠️ <i>Saldo tidak mencukupi, silakan deposit atau bayar via QRIS</i>` : ''}</blockquote>

<i>⏰ ${moment().format('HH:mm:ss')}</i>`;

  await safeEditMessageText(caption, {
    chat_id: chatId,
    message_id: messageId,
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [
          { text: '➖', callback_data: 'produk_baru_qty_dec' },
          { text: `${produkBaruUserCart[userId].qty}`, callback_data: 'produk_baru_qty_show' },
          { text: '➕', callback_data: 'produk_baru_qty_inc' }
        ],
        [
          { text: '💳 Buy (Saldo)', callback_data: `produk_baru_buy_saldo_${product.id}_${produkBaruUserCart[userId].qty}` },
          { text: '⚡ Buy (Now)', callback_data: `produk_baru_buy_now_${product.id}_${produkBaruUserCart[userId].qty}` }
        ],
        [
          { text: '💰 Cek Saldo', callback_data: 'produk_baru_cek_saldo' },
          { text: '❌ Batal', callback_data: 'produk_baru_back_to_list' }
        ]
      ]
    }
  });
  
  await safeAnswerCallbackQuery(callbackQuery);
}

async function produkBaruQtyInc(callbackQuery, userId, chatId, messageId) {
  const cart = produkBaruUserCart[userId];
  if (cart && cart.product) {
    if (cart.qty < cart.product.stock) {
      cart.qty++;
      await produkBaruUpdateDetailDisplay(callbackQuery, userId, chatId, messageId);
    } else {
      await safeAnswerCallbackQuery(callbackQuery, `<i>Stok maksimal ${cart.product.stock}</i>`, true);
    }
  }
}

async function produkBaruQtyDec(callbackQuery, userId, chatId, messageId) {
  const cart = produkBaruUserCart[userId];
  if (cart && cart.qty > 1) {
    cart.qty--;
    await produkBaruUpdateDetailDisplay(callbackQuery, userId, chatId, messageId);
  } else {
    await safeAnswerCallbackQuery(callbackQuery, '<i>Minimal 1</i>', true);
  }
}

async function produkBaruUpdateDetailDisplay(callbackQuery, userId, chatId, messageId) {
  const cart = produkBaruUserCart[userId];
  if (!cart || !cart.product) return;
  
  const product = cart.product;
  const saldo = await produkBaruCekSaldo(userId);
  const totalHarga = product.price * cart.qty;
  const cukupSaldo = saldo >= totalHarga;
  
  const caption = `
<blockquote><b><u>📝 Tambahkan jumlah pembelian</u></b></blockquote>
<blockquote><b>📦 Produk</b> : <b>${product.name}</b>
<b>🔑 Kode</b> : <code>${product.code || '-'}</code>
<b>📊 Sisa Stok</b> : <code>${product.stock}</code>
<b>📈 Stok Terjual</b> : <code>${product.sold || 0}</code>
<b>📝 Deskripsi</b> : <i>${product.description}</i></blockquote>
<blockquote><b>🔢 Jumlah</b> : <code><b>${cart.qty}</b></code>
<b>💰 Harga</b> : <code><b>Rp ${product.price.toLocaleString()}</b></code>
<b>💵 Total Harga</b> : <code><b>Rp ${totalHarga.toLocaleString()}</b></code>
<b>💳 Saldo Anda</b> : <code><b>Rp ${saldo.toLocaleString()}</b></code>
${!cukupSaldo && totalHarga > 0 ? `\n⚠️ <i>Saldo tidak mencukupi, silakan deposit atau bayar via QRIS</i>` : ''}</blockquote>

<i>⏰ ${moment().format('HH:mm:ss')}</i>`;

  const keyboard = {
    inline_keyboard: [
      [
        { text: '➖', callback_data: 'produk_baru_qty_dec' },
        { text: `${cart.qty}`, callback_data: 'produk_baru_qty_show' },
        { text: '➕', callback_data: 'produk_baru_qty_inc' }
      ],
      [
        { text: '💳 Buy (Saldo)', callback_data: `produk_baru_buy_saldo_${product.id}_${cart.qty}` },
        { text: '⚡ Buy (Now)', callback_data: `produk_baru_buy_now_${product.id}_${cart.qty}` }
      ],
      [
        { text: '💰 Cek Saldo', callback_data: 'produk_baru_cek_saldo' },
        { text: '❌ Batal', callback_data: 'produk_baru_back_to_list' }
      ]
    ]
  };
  
  await safeEditMessageText(caption, {
    chat_id: chatId,
    message_id: messageId,
    parse_mode: 'HTML',
    reply_markup: keyboard
  });
}

async function produkBaruKirimProduk(userId, product, order) {
  let noteMessage = '';
  if (product.note) {
    noteMessage = `\n📌 <b>Catatan</b>: ${product.note}`;
  }
  
  const sisaSaldo = await produkBaruCekSaldo(userId);
  
  const successCaption = `
<blockquote>✅ <b><u>Pembayaran Berhasil!</u></b></blockquote>
<blockquote><b>📦 Produk</b> : <b>${product.name}</b>
<b>🔢 Jumlah</b> : <code>${order.quantity}</code>
<b>💰 Total</b> : <code><b>Rp ${order.total_price.toLocaleString()}</b></code>
<b>💳 Sisa Saldo</b> : <code><b>Rp ${sisaSaldo.toLocaleString()}</b></code>${noteMessage}</blockquote>
<blockquote><b>📎 Berikut detail produk Anda:</b></blockquote>

<i>⭐ Terima kasih telah berbelanja!</i>`;

  if (product.media_type === 'text' && product.content_text) {
    await bot.sendMessage(userId, `${successCaption}\n\n<code>${product.content_text}</code>`, { parse_mode: 'HTML' });
  } else if (product.file_id) {
    try {
      await produkBaruSendFile(userId, product.file_id, product.file_name, successCaption);
    } catch (err) {
      await bot.sendMessage(userId, successCaption + `\n\n<i>⚠️ File gagal dikirim otomatis. Hubungi owner.</i>`, { parse_mode: 'HTML' });
    }
  } else {
    await bot.sendMessage(userId, successCaption, { parse_mode: 'HTML' });
  }
}

async function produkBaruBuyWithSaldo(callbackQuery, userId, chatId, messageId, data) {
  const parts = data.replace('produk_baru_buy_saldo_', '').split('_');
  const productId = parseInt(parts[0]);
  const qty = parseInt(parts[1]);
  
  const product = produkBaruData.find(p => p.id === productId);
  
  if (!product) {
    await safeAnswerCallbackQuery(callbackQuery, '<i>❌ Produk tidak ditemukan</i>', true);
    return;
  }
  
  if (product.stock < qty) {
    await safeAnswerCallbackQuery(callbackQuery, '<i>❌ Stok tidak mencukupi</i>', true);
    return;
  }
  
  const totalPrice = product.price * qty;
  const saldo = getProdukBalance(userId);
  
  if (saldo < totalPrice) {
    const kekurangan = totalPrice - saldo;
    
    const caption = `
<blockquote>❌ <b><u>SALDO TIDAK MENCUKUPI</u></b></blockquote>
<blockquote><b>📦 Produk</b> : <b>${product.name}</b>
<b>🔢 Jumlah</b> : <code>${qty}</code>
<b>💰 Total</b> : <code><b>Rp ${totalPrice.toLocaleString()}</b></code>
<b>💳 Saldo Anda</b> : <code><b>Rp ${saldo.toLocaleString()}</b></code>
<b>⚠️ Kekurangan</b> : <code><b>Rp ${kekurangan.toLocaleString()}</b></code></blockquote>

<i>Silakan deposit atau kurangi jumlah pembelian</i>`;

    const keyboard = {
      inline_keyboard: [
        [
          { text: '💳 Deposit Sekarang', callback_data: 'produk_baru_deposit_menu' },
          { text: '💰 Cek Saldo', callback_data: 'produk_baru_cek_saldo' },
        ],
        [
          { text: '🔙 Kembali', callback_data: 'produk_baru_back_to_list' }
        ]
      ]
    };
    
    await safeEditMessageText(caption, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: 'HTML',
      reply_markup: keyboard
    });
    
    await safeAnswerCallbackQuery(callbackQuery, '<i>⚠️ Saldo tidak mencukupi</i>', true);
    return;
  }
  
  await safeAnswerCallbackQuery(callbackQuery, '<i>⏳ Memproses pembayaran...</i>');
  
  const success = await updateProdukBalance(userId, totalPrice, false, null, `product:${product.name} quantity:${qty}`);
  
  if (!success) {
    await safeEditMessageText(`
<blockquote>❌ <b><u>GAGAL MEMPROSES</u></b>
⚠️ Terjadi kesalahan. Silakan coba lagi.</blockquote>`, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: 'HTML'
    });
    return;
  }
  
  produkBaruUpdateStock(product.id, qty);
  
  const orderId = `PROD-${Date.now()}-${userId}`;
  const orders = produkBaruLoadOrders();
  orders.push({
    order_id: orderId,
    user_id: userId,
    product_id: productId,
    product_name: product.name,
    quantity: qty,
    total_price: totalPrice,
    payment_method: 'saldo',
    status: 'paid',
    created_at: Date.now(),
    paid_at: Date.now()
  });
  produkBaruSaveOrders(orders);
  
  await produkBaruSendPaymentNotification({ order_id: orderId, user_id: userId, quantity: qty, total_price: totalPrice }, product, userId);
  
  await safeDeleteMessage(chatId, messageId);
  
  const sisaSaldo = getProdukBalance(userId);
  let noteMessage = '';
  if (product.note) {
    noteMessage = `\n📌 <b>Catatan</b>: ${product.note}`;
  }
  
  const successCaption = `
<blockquote>✅ <b><u>PEMBELIAN BERHASIL!</u></b></blockquote>
<blockquote><b>📦 Produk</b> : <b>${product.name}</b>
<b>🔢 Jumlah</b> : <code>${qty}</code>
<b>💰 Total</b> : <code><b>Rp ${totalPrice.toLocaleString()}</b></code>
<b>💳 Sisa Saldo</b> : <code><b>Rp ${sisaSaldo.toLocaleString()}</b></code>${noteMessage}</blockquote>
<blockquote><b>📎 Berikut detail produk Anda:</b></blockquote>

<i>⭐ Terima kasih telah berbelanja!</i>`;

  if (product.media_type === 'text' && product.content_text) {
    await bot.sendMessage(userId, `${successCaption}\n\n<code>${product.content_text}</code>`, { parse_mode: 'HTML' });
  } else if (product.file_id) {
    try {
      await produkBaruSendFile(userId, product.file_id, product.file_name, successCaption);
    } catch (err) {
      await bot.sendMessage(userId, successCaption + `\n\n<i>⚠️ File gagal dikirim otomatis. Hubungi owner.</i>`, { parse_mode: 'HTML' });
    }
  } else {
    await bot.sendMessage(userId, successCaption, { parse_mode: 'HTML' });
  }
  
  await bot.sendMessage(chatId, `<i>✅ Pembelian berhasil! Cek PM untuk detail produk.</i>`, { parse_mode: 'HTML' });
  
  delete produkBaruUserCart[userId];
}

async function produkBaruBuyWithNow(callbackQuery, userId, chatId, messageId, data) {
  const parts = data.replace('produk_baru_buy_now_', '').split('_');
  const productId = parseInt(parts[0]);
  const qty = parseInt(parts[1]);
  const product = produkBaruData.find(p => p.id === productId);
  
  if (!product || product.stock < qty) {
    await safeAnswerCallbackQuery(callbackQuery, '<i>❌ Stok tidak mencukupi</i>', true);
    return;
  }
  
  await safeDeleteMessage(chatId, messageId);
  
  const totalPrice = product.price * qty;
  const infoText = `<blockquote>📦 ${product.name} | ${qty}x | Rp ${product.price.toLocaleString()}/unit</blockquote>`;

  const result = await createPayment(userId, chatId, totalPrice, 'PROD', infoText, async (userId, orderId) => {
    produkBaruUpdateStock(product.id, qty);
    
    const orders = produkBaruLoadOrders();
    orders.push({
      order_id: orderId,
      user_id: userId,
      product_id: productId,
      product_name: product.name,
      quantity: qty,
      total_price: totalPrice,
      status: 'paid',
      payment_method: 'qris',
      created_at: Date.now(),
      paid_at: Date.now()
    });
    produkBaruSaveOrders(orders);
    
    let note = product.note ? `\n📌 <b>Catatan</b> : ${product.note}` : '';
    
    const successMsg = `
<blockquote>✅ <b>PEMBELIAN BERHASIL</b></blockquote>
<blockquote>📦 <b>Produk</b> : ${product.name}
🔢 <b>Jumlah</b> : ${qty}
💰 <b>Total</b> : Rp ${totalPrice.toLocaleString()}
🆔 <b>Order ID</b> : <code>${orderId}</code>${note}</blockquote>`;
    
    if (product.file_id) {
      await produkBaruSendFile(userId, product.file_id, product.file_name, successMsg);
    } else if (product.media_type === 'text' && product.content_text) {
      await bot.sendMessage(userId, `${successMsg}\n<code>${product.content_text}</code>`, { parse_mode: 'HTML' });
    } else {
      await bot.sendMessage(userId, successMsg, { parse_mode: 'HTML' });
    }
    
    await produkBaruSendPaymentNotification({ order_id: orderId, user_id: userId, quantity: qty, total_price: totalPrice }, product, userId);
  });
  
  if (!result.ok) {
    await bot.sendMessage(chatId, `<blockquote>❌ ${result.error}</blockquote>`, { parse_mode: 'HTML' });
  }
}

async function produkBaruShowDepositMenu(userId, chatId, messageId = null) {
  if (!produkBaruDepositAmount[userId]) {
    produkBaruDepositAmount[userId] = 5000;
  }
  
  const nominal = produkBaruDepositAmount[userId];
  const totalOtomatis = nominal + PAKASIR_ADMIN_FEE;

  const caption = `
<blockquote>💰 <b><u>ISI SALDO</u></b></blockquote>
<blockquote><b>Nominal</b> : Rp ${nominal.toLocaleString()}</blockquote>
${PAKASIR_ENABLED ? `<i>Otomatis: Rp ${totalOtomatis.toLocaleString()} (termasuk biaya layanan Rp ${PAKASIR_ADMIN_FEE.toLocaleString()})</i>\n` : ''}
<i>Minimal Rp 2.000 · Maksimal Rp 20.000</i>`;

  const keyboard = {
    inline_keyboard: [
      [
        { text: '➖', callback_data: 'produk_deposit_minus' },
        { text: `Rp ${nominal.toLocaleString()}`, callback_data: 'produk_deposit_custom' },
        { text: '➕', callback_data: 'produk_deposit_plus' }
      ],
      PAKASIR_ENABLED
        ? [{ text: '⚡ Bayar Otomatis (QRIS)', callback_data: `produk_deposit_now_${nominal}` }]
        : [{ text: '✅ Buat Deposit', callback_data: `produk_deposit_now_${nominal}` }],
      PAKASIR_ENABLED
        ? [{ text: '🧾 Bayar Manual (Upload Bukti)', callback_data: `produk_deposit_manual_${nominal}` }]
        : [],
      [{ text: '⬅️ Kembali', callback_data: 'produk_baru_back_to_list' }]
    ].filter(row => row.length > 0)
  };

  if (messageId) {
    await safeEditMessageText(caption, { chat_id: chatId, message_id: messageId, parse_mode: 'HTML', reply_markup: keyboard });
  } else {
    await bot.sendMessage(chatId, caption, { parse_mode: 'HTML', reply_markup: keyboard });
  }
}

// Deposit produk — otomatis (Pakasir/QRIS) jika tersedia, fallback manual.
async function produkBaruDeposit(callbackQuery, userId, chatId, messageId, amount) {
  const nominal = parseInt(amount);
  if (isNaN(nominal) || nominal < 2000 || nominal > 20000) {
    await safeAnswerCallbackQuery(callbackQuery, '❌ Minimal Rp 2.000, Maksimal Rp 20.000', true);
    return;
  }

  await safeDeleteMessage(chatId, messageId).catch(() => {});
  await safeAnswerCallbackQuery(callbackQuery).catch(() => {});

  if (PAKASIR_ENABLED) {
    await createAutoDepositOrder(userId, chatId, nominal);
    return;
  }

  // BUG FIX: sebelumnya kalau Pakasir belum dikonfigurasi, bot langsung diam-diam
  // switch ke alur manual tanpa bilang apa-apa ke user. Sekarang kasih tahu
  // eksplisit dulu alasannya (belum diaktifkan untuk sementara), baru lanjut
  // ke deposit manual. Ini juga jaga-jaga kalau tombol lama "⚡ Bayar Otomatis"
  // masih ke-klik dari pesan lama (sebelum config diubah jadi kosong).
  await bot.sendMessage(chatId, `<blockquote>⚠️ <b>Deposit Otomatis (QRIS)</b> belum diaktifkan untuk sementara.\nMengalihkan ke deposit manual...</blockquote>`, { parse_mode: 'HTML' });

  const result = await createDepositOrder(userId, nominal);
  if (!result.success) {
    await bot.sendMessage(chatId, `<blockquote>❌ ${result.message}</blockquote>`, { parse_mode: 'HTML' });
  }
}

// Deposit produk — paksa jalur manual (upload bukti transfer) walau
// deposit otomatis tersedia. Dipakai tombol "Bayar Manual".
async function produkBaruDepositManual(callbackQuery, userId, chatId, messageId, amount) {
  const nominal = parseInt(amount);
  if (isNaN(nominal) || nominal < 2000 || nominal > 20000) {
    await safeAnswerCallbackQuery(callbackQuery, '❌ Minimal Rp 2.000, Maksimal Rp 20.000', true);
    return;
  }

  await safeDeleteMessage(chatId, messageId).catch(() => {});
  await safeAnswerCallbackQuery(callbackQuery).catch(() => {});

  const result = await createDepositOrder(userId, nominal);
  if (!result.success) {
    await bot.sendMessage(chatId, `<blockquote>❌ ${result.message}</blockquote>`, { parse_mode: 'HTML' });
  }
}

async function produkBaruConfirm(callbackQuery, userId, chatId, messageId) {
  const cart = produkBaruUserCart[userId];
  if (!cart || !cart.productId) {
    await safeAnswerCallbackQuery(callbackQuery, '<i>Data pesanan tidak ditemukan</i>', true);
    return;
  }
  
  const product = cart.product;
  const qty = cart.qty;
  const totalPrice = product.price * qty;
  
  const caption = `
<blockquote><b><u>📋 Konfirmasi Pesanan</u></b></blockquote>
<blockquote><b>📦 Produk</b> : <b>${product.name}</b>
<b>🔢 Qty</b> : <code>${qty}</code>
<b>📝 Catatan untuk penjual</b> : <i>(tidak ada)</i></blockquote>
<blockquote><b>💰 Total</b> : <code><b>Rp ${totalPrice.toLocaleString()}</b></code></blockquote>

<i>Pastikan pesanan Anda sudah benar!</i>`;

  await safeEditMessageText(caption, {
    chat_id: chatId,
    message_id: messageId,
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [
          { text: '✅ Konfirmasi & Proses', callback_data: `produk_baru_payment_${product.id}_${qty}` },
          { text: '❌ Batal', callback_data: 'produk_baru_back_to_list' }
        ]
      ]
    }
  });
  
  await safeAnswerCallbackQuery(callbackQuery);
}

async function produkBaruProcessPayment(callbackQuery, userId, chatId, messageId, data) {
  const parts = data.replace('produk_baru_payment_', '').split('_');
  const productId = parseInt(parts[0]);
  const qty = parseInt(parts[1]);
  
  const product = produkBaruData.find(p => p.id === productId);
  
  if (!product || product.stock < qty) {
    await bot.sendMessage(chatId, `<blockquote><b>❌ Stok tidak mencukupi!</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  await safeDeleteMessage(chatId, messageId);
  
  const totalPrice = product.price * qty;
  const saldo = getProdukBalance(userId);
  
  // Cek saldo dulu
  if (saldo < totalPrice) {
    const kurang = totalPrice - saldo;
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>SALDO TIDAK MENCUKUPI</u></b></blockquote>
<blockquote>💰 <b>Total</b> : <b>Rp ${totalPrice.toLocaleString()}</b>
💳 <b>Saldo Anda</b> : <b>Rp ${saldo.toLocaleString()}</b>
⚠️ <b>Kekurangan</b> : <b>Rp ${kurang.toLocaleString()}</b></blockquote>

<i>Silakan deposit dulu atau kurangi jumlah pembelian.</i>`, { parse_mode: 'HTML' });
    return;
  }
  
  // Kurangi saldo
  const success = await updateProdukBalance(userId, totalPrice, false, null, `product:${product.name} qty:${qty}`);
  
  if (!success) {
    await bot.sendMessage(chatId, `<blockquote>❌ <b>Gagal mengurangi saldo. Coba lagi.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  // Update stok
  produkBaruUpdateStock(product.id, qty);
  
  const orderId = `PROD-${Date.now()}-${Math.random().toString(36).substr(2, 6).toUpperCase()}`;
  
  // Catat order
  const orders = produkBaruLoadOrders();
  orders.push({
    order_id: orderId,
    user_id: userId,
    product_id: productId,
    product_name: product.name,
    quantity: qty,
    total_price: totalPrice,
    status: 'paid',
    payment_method: 'saldo',
    created_at: Date.now(),
    paid_at: Date.now()
  });
  produkBaruSaveOrders(orders);
  
  // Kirim produk ke user
  let note = '';
  if (product.note) note = `\n📌 <b>Catatan</b> : ${product.note}`;
  
  const sisaSaldo = getProdukBalance(userId);
  const successMsg = `
<blockquote>✅ <b><u>PEMBELIAN BERHASIL!</u></b></blockquote>
<blockquote><b>📦 Produk</b> : <b>${product.name}</b>
<b>🔢 Jumlah</b> : <code>${qty}</code>
<b>💰 Total</b> : <code><b>Rp ${totalPrice.toLocaleString()}</b></code>
<b>💳 Sisa Saldo</b> : <code><b>Rp ${sisaSaldo.toLocaleString()}</b></code>${note}
<b>🆔 Order ID</b> : <code>${orderId}</code></blockquote>

<i>⭐ Terima kasih telah berbelanja!</i>`;
  
  if (product.file_id) {
    await produkBaruSendFile(userId, product.file_id, product.file_name, successMsg);
  } else if (product.media_type === 'text' && product.content_text) {
    await bot.sendMessage(userId, `${successMsg}\n\n<code>${product.content_text}</code>`, { parse_mode: 'HTML' });
  } else {
    await bot.sendMessage(userId, successMsg, { parse_mode: 'HTML' });
  }
  
  // Notif ke log group
  await produkBaruSendPaymentNotification({ order_id: orderId, user_id: userId, quantity: qty, total_price: totalPrice }, product, userId);
  
  await bot.sendMessage(chatId, `
<blockquote>✅ <b><u>PEMBELIAN BERHASIL!</u></b></blockquote>
<i>Produk sudah dikirim ke PM kamu. Cek chat pribadi.</i>`, { parse_mode: 'HTML' });
}

async function produkBaruOwnerMenu(userId, chatId) {
  if (!isOwnerId(userId)) return;
  
  const products = produkBaruData;
  const totalProducts = products.length;
  const totalSold = products.reduce((sum, p) => sum + (p.sold || 0), 0);
  
  const caption = `
<blockquote><b><u>📦 Manajemen Produk (Baru)</u></b></blockquote>
<blockquote><b>📊 Total Produk</b> : <code>${totalProducts}</code>
<b>📈 Total Terjual</b> : <code>${totalSold}</code></blockquote>

<i>Pilih menu di bawah:</i>`;

  await bot.sendMessage(chatId, caption, {
    parse_mode: 'HTML',
    reply_markup: {
      keyboard: [
        ['➕ Tambah Produk', '📝 Edit Produk'],
        ['🗑️ Hapus Produk Baru', '📋 Daftar Produk'],
        ['🔙 Kembali']
      ],
      resize_keyboard: true
    }
  });
}

async function produkBaruTambah(userId, chatId) {
  if (!isOwnerId(userId)) return;
  
  await bot.sendMessage(chatId, `
<blockquote><b><u>➕ Tambah Produk Baru</u></b></blockquote>

<i>Kirim detail produk dengan format:</i>
<code>Nama|Kode|Harga|Stok|Deskripsi|Catatan</code>

<i>Contoh:</i>
<code>Akun ChatGPT Plus|GPT001|25000|10|Akun ChatGPT Plus Premium 1 Bulan|Garansi 30 hari</code>

<i>Ketik <b>Batal</b> untuk membatalkan.</i>`, {
    parse_mode: 'HTML',
    reply_markup: { keyboard: [['❌ Batal']], resize_keyboard: true, one_time_keyboard: true }
  });
  
  produkBaruWaitingAdd = true;
}

async function produkBaruTambahInput(userId, chatId, text) {
  if (!produkBaruWaitingAdd) return;
  produkBaruWaitingAdd = false;
  
  if (text === '❌ Batal') {
    await bot.sendMessage(chatId, `<blockquote><b>❌ Penambahan produk dibatalkan.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const parts = text.split('|');
  if (parts.length < 5) {
    await bot.sendMessage(chatId, `<blockquote><b>❌ Format salah. Gunakan: Nama|Kode|Harga|Stok|Deskripsi|Catatan</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const name = parts[0].trim();
  const code = parts[1].trim();
  const price = parseInt(parts[2].trim());
  const stock = parseInt(parts[3].trim());
  const description = parts[4].trim();
  const note = parts[5] ? parts[5].trim() : '';
  
  if (isNaN(price) || price <= 0) {
    await bot.sendMessage(chatId, `<blockquote><b>❌ Harga harus angka positif</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  if (isNaN(stock) || stock < 0) {
    await bot.sendMessage(chatId, `<blockquote><b>❌ Stok harus angka</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const productId = produkBaruAdd({
    name, code, description, price, stock, note,
    file_id: null, file_name: null, file_mime: null, file_size: null
  });
  
  produkBaruWaitingFile = productId;
  
  await bot.sendMessage(chatId, `
<blockquote>✅ <b><u>Produk "${name}" berhasil dibuat!</u></b></blockquote>
<blockquote><b>🆔 ID Produk</b> : <code>${productId}</code>
<b>💰 Harga</b> : <code><b>Rp ${price.toLocaleString()}</b></code>
<b>📦 Stok</b> : <code>${stock}</code></blockquote>

<i>Sekarang kirim file produk (foto, video, dokumen, zip, dll).</i>
<i>Atau kirim <b>Skip</b> jika tidak ada file.</i>`, {
    parse_mode: 'HTML',
    reply_markup: { keyboard: [['Skip'], ['❌ Batal']], resize_keyboard: true }
  });
}

async function produkBaruUploadFile(userId, chatId, msg) {
  if (!produkBaruWaitingFile) return;
  
  const productId = produkBaruWaitingFile;
  
  if (msg.text && msg.text.toLowerCase() === 'skip') {
    produkBaruWaitingFile = null;
    await bot.sendMessage(chatId, `<blockquote><b>✅ Produk berhasil ditambahkan tanpa konten.</b></blockquote>`, { parse_mode: 'HTML' });
    await produkBaruOwnerMenu(userId, chatId);
    return;
  }
  
  let fileId = null;
  let fileName = null;
  let mimeType = null;
  let fileSize = null;
  let mediaType = 'text';
  let contentText = null;
  
  if (msg.text) {
    contentText = msg.text;
    mediaType = 'text';
    fileName = null;
    
    await bot.sendMessage(chatId, `<blockquote><b>✅ Konten teks berhasil disimpan!</b></blockquote>\n\n<i>Preview:</i>\n<code>${contentText.substring(0, 300)}${contentText.length > 300 ? '...' : ''}</code>`, { parse_mode: 'HTML' });
    
  } else if (msg.document) {
    fileId = msg.document.file_id;
    fileName = msg.document.file_name;
    mimeType = msg.document.mime_type;
    fileSize = msg.document.file_size;
    mediaType = 'document';
    
    const sizeKB = (fileSize / 1024).toFixed(2);
    const sizeMB = (fileSize / (1024 * 1024)).toFixed(2);
    const sizeText = fileSize > 1024 * 1024 ? `${sizeMB} MB` : `${sizeKB} KB`;
    
    await bot.sendMessage(chatId, `<blockquote><b>✅ File berhasil diupload!</b></blockquote>\n\n<i>📎 Nama file: ${fileName}</i>\n<i>📦 Ukuran: ${sizeText}</i>`, { parse_mode: 'HTML' });
    
  } else if (msg.photo) {
    fileId = msg.photo[msg.photo.length - 1].file_id;
    fileName = `photo_${Date.now()}.jpg`;
    mimeType = 'image/jpeg';
    fileSize = msg.photo[msg.photo.length - 1].file_size;
    mediaType = 'photo';
    
    await bot.sendMessage(chatId, `<blockquote><b>✅ Foto berhasil diupload!</b></blockquote>`, { parse_mode: 'HTML' });
    
  } else if (msg.video) {
    fileId = msg.video.file_id;
    fileName = msg.video.file_name || `video_${Date.now()}.mp4`;
    mimeType = msg.video.mime_type;
    fileSize = msg.video.file_size;
    mediaType = 'video';
    
    await bot.sendMessage(chatId, `<blockquote><b>✅ Video berhasil diupload!</b></blockquote>`, { parse_mode: 'HTML' });
    
  } else {
    await bot.sendMessage(chatId, `<blockquote><b>❌ Tipe tidak didukung!</b></blockquote>\n\n<i>Kirim: teks, foto, video, atau dokumen.</i>`, { parse_mode: 'HTML' });
    return;
  }
  
  produkBaruUpdate(productId, {
    file_id: fileId,
    file_name: fileName,
    file_mime: mimeType,
    file_size: fileSize,
    media_type: mediaType,
    content_text: contentText
  });
  
  produkBaruWaitingFile = null;
  await produkBaruOwnerMenu(userId, chatId);
}

async function produkBaruLihat(userId, chatId) {
  if (!isOwnerId(userId)) return;
  
  const products = produkBaruData;
  
  if (products.length === 0) {
    await bot.sendMessage(chatId, `<blockquote><b>📭 Belum ada produk.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  let response = `<blockquote><b><u>📋 Daftar Produk (Baru)</u></b></blockquote>\n\n`;
  
  for (let i = 0; i < products.length; i++) {
    const p = products[i];
    const statusIcon = p.is_active === 1 ? (p.stock > 0 ? '✅' : '⚠️ Habis') : '❌ Nonaktif';
    response += `
<b>${i + 1}.</b> <b>${p.name}</b> ${statusIcon}
   <b>🆔 ID</b>: <code>${p.id}</code>
   <b>🔑 Kode</b>: <code>${p.code || '-'}</code>
   <b>📝</b> ${p.description}
   <b>💰</b> <code><b>Rp ${p.price.toLocaleString()}</b></code>
   <b>📦 Stok</b>: <code>${p.stock}</code> | <b>Terjual</b>: <code>${p.sold || 0}</code>
   <b>📎 File</b>: ${p.file_id ? '✅ Ada' : '❌ Tidak ada'}
   ${p.note ? `<b>📌 Catatan</b>: ${p.note}` : ''}
`;
  }
  
  response += `\n<i>Total: ${products.length} produk</i>`;
  
  await bot.sendMessage(chatId, response, { parse_mode: 'HTML' });
}

async function produkBaruEdit(userId, chatId) {
  if (!isOwnerId(userId)) return;
  
  const products = produkBaruData;
  
  if (products.length === 0) {
    await bot.sendMessage(chatId, `<blockquote><b>📭 Belum ada produk.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  let response = `<blockquote><b><u>✏️ Edit Produk</u></b></blockquote>\n\n`;
  const buttons = [];
  
  for (let i = 0; i < products.length; i++) {
    const p = products[i];
    response += `<b>${i + 1}.</b> <b>ID</b>: <code>${p.id}</code> - <b>${p.name}</b>\n`;
    buttons.push([{ text: `Edit ${p.name}`, callback_data: `produk_baru_edit_${p.id}` }]);
  }
  
  response += `\n<i>Pilih produk yang mau diedit</i>`;
  
  buttons.push([{ text: '⬅️ Kembali', callback_data: 'back_to_owner_menu' }]);
  
  await bot.sendMessage(chatId, response, {
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard: buttons }
  });
}

async function produkBaruEditForm(callbackQuery, userId, chatId, messageId, productId) {
  if (!isOwnerId(userId)) return;
  
  const product = produkBaruData.find(p => p.id === productId);
  if (!product) {
    await safeAnswerCallbackQuery(callbackQuery, '<i>Produk tidak ditemukan</i>', true);
    return;
  }
  
  produkBaruEditId = productId;
  
  const caption = `
<blockquote><b><u>✏️ Edit Produk: ${product.name}</u></b></blockquote>
<blockquote><b>🆔 ID</b> : <code>${product.id}</code>
<b>📝 Nama</b> : <b>${product.name}</b>
<b>🔑 Kode</b> : <code>${product.code || '-'}</code>
<b>📝 Deskripsi</b> : <i>${product.description}</i>
<b>💰 Harga</b> : <code><b>Rp ${product.price.toLocaleString()}</b></code>
<b>📦 Stok</b> : <code>${product.stock}</code>
<b>📌 Catatan</b> : <i>${product.note || '-'}</i>
<b>📎 File</b> : ${product.file_id ? '✅ Ada' : '❌ Tidak ada'}</blockquote>

<i>Klik tombol di bawah untuk mengedit:</i>`;

  const keyboard = {
    inline_keyboard: [
      [
        { text: '📝 Nama', callback_data: 'produk_baru_edit_nama' },
        { text: '🔑 Kode', callback_data: 'produk_baru_edit_kode' }
      ],
      [
        { text: '📄 Deskripsi', callback_data: 'produk_baru_edit_deskripsi' },
        { text: '💰 Harga', callback_data: 'produk_baru_edit_harga' }
      ],
      [
        { text: '📦 Stok', callback_data: 'produk_baru_edit_stok' },
        { text: '📌 Catatan', callback_data: 'produk_baru_edit_note' }
      ],
      [
        { text: '📎 Ganti File', callback_data: 'produk_baru_edit_file' },
        { text: '🗑️ Hapus File', callback_data: 'produk_baru_edit_file_hapus' }
      ],
      [
        { text: '🗑️ Hapus Produk', callback_data: `produk_baru_hapus_${productId}` }
      ],
      [
        { text: '⬅️ Kembali', callback_data: 'back_to_owner_menu' }
      ]
    ]
  };
  
  await safeEditMessageText(caption, {
    chat_id: chatId,
    message_id: messageId,
    parse_mode: 'HTML',
    reply_markup: keyboard
  });
  
  await safeAnswerCallbackQuery(callbackQuery);
}

async function produkBaruHapus(callbackQuery, userId, chatId, messageId, productId) {
  if (!isOwnerId(userId)) return;
  
  const product = produkBaruData.find(p => p.id === productId);
  if (!product) {
    await safeAnswerCallbackQuery(callbackQuery, '<i>Produk tidak ditemukan</i>', true);
    return;
  }
  
  produkBaruDelete(productId);
  
  await safeEditMessageText(`<blockquote><b>✅ Produk "${product.name}" berhasil dihapus!</b></blockquote>`, {
    chat_id: chatId,
    message_id: messageId,
    parse_mode: 'HTML'
  });
  
  setTimeout(async () => {
    await safeDeleteMessage(chatId, messageId);
    await produkBaruOwnerMenu(userId, chatId);
  }, 2000);
}

async function handleSettingHarga(userId, chatId) {
  if (!isOwnerId(userId)) return;
  
  const pricesWm = await db.get(`SELECT * FROM prices WHERE type = 'wm'`);
  const pricesNowm = await db.get(`SELECT * FROM prices WHERE type = 'nowm'`);
  const pricesReseller = await db.get(`SELECT * FROM prices WHERE type = 'reseller'`);
  
  const caption = `
<blockquote>💰 <b><u>SETTING HARGA</u></b></blockquote>
<blockquote>🧩 <b>Plan Basic</b>
 • 1 Bulan : <code><b>Rp ${pricesWm?.price_1?.toLocaleString() || 3000}</b></code>
 • 2 Bulan : <code><b>Rp ${pricesWm?.price_2?.toLocaleString() || 6000}</b></code>
 • 3 Bulan : <code><b>Rp ${pricesWm?.price_3?.toLocaleString() || 9000}</b></code>
 • 4 Bulan : <code><b>Rp ${pricesWm?.price_4?.toLocaleString() || 12000}</b></code>
 • 5 Bulan : <code><b>Rp ${pricesWm?.price_5?.toLocaleString() || 15000}</b></code></blockquote>
<blockquote>💎 <b>Plan Pro</b>
 • 1 Bulan : <code><b>Rp ${pricesNowm?.price_1?.toLocaleString() || 5000}</b></code>
 • 2 Bulan : <code><b>Rp ${pricesNowm?.price_2?.toLocaleString() || 10000}</b></code>
 • 3 Bulan : <code><b>Rp ${pricesNowm?.price_3?.toLocaleString() || 15000}</b></code>
 • 4 Bulan : <code><b>Rp ${pricesNowm?.price_4?.toLocaleString() || 20000}</b></code>
 • 5 Bulan : <code><b>Rp ${pricesNowm?.price_5?.toLocaleString() || 25000}</b></code></blockquote>
<blockquote>🎟 <b>Akses Reseller</b>
 • 1 Bulan : <code><b>Rp ${pricesReseller?.price_1?.toLocaleString() || 10000}</b></code>
 • 2 Bulan : <code><b>Rp ${pricesReseller?.price_2?.toLocaleString() || 12000}</b></code>
 • 3 Bulan : <code><b>Rp ${pricesReseller?.price_3?.toLocaleString() || 15000}</b></code>
 • 4 Bulan : <code><b>Rp ${pricesReseller?.price_4?.toLocaleString() || 18000}</b></code>
 • 5 Bulan : <code><b>Rp ${pricesReseller?.price_5?.toLocaleString() || 20000}</b></code></blockquote>

<i>Pilih paket yang mau diatur harganya</i>`;

  const keyboard = {
    inline_keyboard: [
      [
        { text: '🧩 Basic', callback_data: 'set_harga_wm' },
        { text: '💎 Pro', callback_data: 'set_harga_nowm' }
      ],
      [
        { text: '🎟 Reseller', callback_data: 'set_harga_reseller' }
      ],
      [
        { text: '💰 Cek Saldo', callback_data: 'produk_baru_cek_saldo' },
      ],
      [
        { text: '⬅️ Kembali', callback_data: 'back_to_owner_menu' }
      ]
    ]
  };
  
  await bot.sendMessage(chatId, caption, {
    parse_mode: 'HTML',
    reply_markup: keyboard
  });
}

async function handleSetHargaWm(callbackQuery, userId, chatId, messageId) {
  if (!isOwnerId(userId)) return;
  
  const prices = await db.get(`SELECT * FROM prices WHERE type = 'wm'`);
  
  if (!global.hargaPage) global.hargaPage = {};
  global.hargaPage[userId] = { type: 'wm', page: 1 };
  
  await showHargaPage(userId, chatId, messageId, 'wm', 1);
}

async function handleSetHargaNowm(callbackQuery, userId, chatId, messageId) {
  if (!isOwnerId(userId)) return;
  
  const prices = await db.get(`SELECT * FROM prices WHERE type = 'nowm'`);
  
  if (!global.hargaPage) global.hargaPage = {};
  global.hargaPage[userId] = { type: 'nowm', page: 1 };
  
  await showHargaPage(userId, chatId, messageId, 'nowm', 1);
}

async function handleSetHargaReseller(callbackQuery, userId, chatId, messageId) {
  if (!isOwnerId(userId)) return;
  
  const prices = await db.get(`SELECT * FROM prices WHERE type = 'reseller'`);
  
  if (!global.hargaPage) global.hargaPage = {};
  global.hargaPage[userId] = { type: 'reseller', page: 1 };
  
  await showHargaPage(userId, chatId, messageId, 'reseller', 1);
}

async function showHargaPage(userId, chatId, messageId, type, page) {
  const prices = await db.get(`SELECT * FROM prices WHERE type = ?`, type);
  
  let typeName = '';
  let emoji = '';
  if (type === 'wm') {
    typeName = 'Basic (WM)';
    emoji = '🧩';
  } else if (type === 'nowm') {
    typeName = 'Pro (NO WM)';
    emoji = '💎';
  } else {
    typeName = 'Reseller';
    emoji = '🎟';
  }
  
  const itemsPerPage = 3;
  const durations = [1, 2, 3, 4, 5];
  const totalPages = Math.ceil(durations.length / itemsPerPage);
  const start = (page - 1) * itemsPerPage;
  const end = start + itemsPerPage;
  const pageDurations = durations.slice(start, end);
  
  let caption = `
<blockquote>${emoji} <b><u>SETTING HARGA ${typeName}</u></b></blockquote>
<blockquote><b>Harga saat ini:</b>`;

  for (const dur of durations) {
    const priceField = `price_${dur}`;
    const price = prices[priceField] || 0;
    caption += `
 • ${dur} Bulan : <code><b>Rp ${price.toLocaleString()}</b></code>`;
  }

  caption += `</blockquote>
<blockquote><b>Pilih durasi yang mau diubah harganya:</b>
<i>Halaman ${page} / ${totalPages}</i></blockquote>`;

  const buttons = [];
  const row = [];
  
  for (const dur of pageDurations) {
    row.push({ text: `${dur} Bulan`, callback_data: `edit_harga_${type}_${dur}` });
    if (row.length === 3) {
      buttons.push([...row]);
      row.length = 0;
    }
  }
  if (row.length > 0) buttons.push([...row]);
  
  const navButtons = [];
  if (page > 1) {
    navButtons.push({ text: '◀️', callback_data: `harga_prev_${type}` });
  }
  if (page < totalPages) {
    navButtons.push({ text: '▶️', callback_data: `harga_next_${type}` });
  }
  if (navButtons.length > 0) {
    buttons.push(navButtons);
  }
  
  buttons.push([{ text: '⬅️ Kembali', callback_data: 'back_to_harga_menu' }]);
  
  await safeEditMessageText(caption, {
    chat_id: chatId,
    message_id: messageId,
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard: buttons }
  });
}

async function handleHargaPrev(callbackQuery, userId, chatId, messageId, type) {
  if (!global.hargaPage) global.hargaPage = {};
  if (!global.hargaPage[userId]) global.hargaPage[userId] = { type: type, page: 1 };
  
  let page = global.hargaPage[userId].page || 1;
  if (page > 1) {
    page--;
    global.hargaPage[userId].page = page;
    await showHargaPage(userId, chatId, messageId, type, page);
  }
}

async function handleHargaNext(callbackQuery, userId, chatId, messageId, type) {
  if (!global.hargaPage) global.hargaPage = {};
  if (!global.hargaPage[userId]) global.hargaPage[userId] = { type: type, page: 1 };
  
  let page = global.hargaPage[userId].page || 1;
  const durations = [1, 2, 3, 4, 5];
  const totalPages = Math.ceil(durations.length / 3);
  
  if (page < totalPages) {
    page++;
    global.hargaPage[userId].page = page;
    await showHargaPage(userId, chatId, messageId, type, page);
  }
}

async function handleEditHargaWm(callbackQuery, userId, chatId, messageId, data) {
  const duration = parseInt(data.replace('edit_harga_wm_', ''));
  await showEditHarga(userId, chatId, messageId, 'wm', duration);
}

async function handleEditHargaNowm(callbackQuery, userId, chatId, messageId, data) {
  const duration = parseInt(data.replace('edit_harga_nowm_', ''));
  await showEditHarga(userId, chatId, messageId, 'nowm', duration);
}

async function handleEditHargaReseller(callbackQuery, userId, chatId, messageId, data) {
  const duration = parseInt(data.replace('edit_harga_reseller_', ''));
  await showEditHarga(userId, chatId, messageId, 'reseller', duration);
}

async function showEditHarga(userId, chatId, messageId, type, duration) {
  if (!isOwnerId(userId)) return;
  
  const currentPrice = await getCurrentPrice(type, duration);
  
  let typeName = '';
  let emoji = '';
  if (type === 'wm') {
    typeName = 'Basic (WM)';
    emoji = '🧩';
  } else if (type === 'nowm') {
    typeName = 'Pro (NO WM)';
    emoji = '💎';
  } else {
    typeName = 'Reseller';
    emoji = '🎟';
  }
  
  await safeEditMessageText(`
<blockquote>💰 <b><u>EDIT HARGA ${typeName} - ${duration} Bulan</u></b></blockquote>
<blockquote><b>📝 Kirim harga baru dalam angka Rupiah.</b>
 <i>Contoh:</i> <code>5000</code> untuk <b>Rp 5.000</b></blockquote>
<blockquote><b>💰 Harga saat ini</b> : <code><b>Rp ${currentPrice.toLocaleString()}</b></code>
<b>⚠️ Minimal harga</b> : <code><b>Rp 1.000</b></code></blockquote>`, {
    chat_id: chatId,
    message_id: messageId,
    parse_mode: 'HTML'
  });
  
  global.waitingForEditHarga = { type: type, duration: duration, userId: userId };
}

async function getPriceByType(type, duration) {
  const prices = await db.get(`SELECT * FROM prices WHERE type = ?`, type);
  if (!prices) return 0;
  
  const priceMap = {
    1: prices.price_1,
    2: prices.price_2,
    3: prices.price_3,
    4: prices.price_4,
    5: prices.price_5
  };
  return (priceMap[duration] || 0) * duration;
}

async function getCurrentPrice(type, duration) {
  const prices = await db.get(`SELECT * FROM prices WHERE type = ?`, type);
  if (!prices) return 0;
  
  const priceMap = {
    1: prices.price_1,
    2: prices.price_2,
    3: prices.price_3,
    4: prices.price_4,
    5: prices.price_5
  };
  
  return priceMap[duration] || 0;
}

async function updatePrice(type, duration, newPrice) {
  const field = `price_${duration}`;
  await db.run(`UPDATE prices SET ${field} = ? WHERE type = ?`, newPrice, type);
}

async function processEditHargaInput(userId, chatId, text) {
  if (!global.waitingForEditHarga) return;
  if (global.waitingForEditHarga.userId !== userId) return;
  
  const { type, duration } = global.waitingForEditHarga;
  delete global.waitingForEditHarga;
  
  const newPrice = parseInt(text.replace(/[^0-9]/g, ''));
  
  if (isNaN(newPrice) || newPrice < 1000) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>HARGA MINIMAL</u></b>
💰 <b>Harga minimal Rp 1.000</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  await updatePrice(type, duration, newPrice);
  
  let typeName = '';
  let emoji = '';
  if (type === 'wm') {
    typeName = 'Basic (WM)';
    emoji = '🧩';
  } else if (type === 'nowm') {
    typeName = 'Pro (NO WM)';
    emoji = '💎';
  } else {
    typeName = 'Reseller';
    emoji = '🎟';
  }
  
  await bot.sendMessage(chatId, `
<blockquote>✅ <b><u>HARGA BERHASIL DIUPDATE!</u></b>
${emoji} <b>Paket</b> : ${typeName}
🗓 <b>Durasi</b> : ${duration} Bulan
💰 <b>Harga Baru</b> : <code><b>Rp ${newPrice.toLocaleString()}</b></code></blockquote>`, { parse_mode: 'HTML' });
  
  await handleSettingHarga(userId, chatId);
}

async function handleBackToHargaMenu(callbackQuery, userId, chatId, messageId) {
  await safeDeleteMessage(chatId, messageId);
  await handleSettingHarga(userId, chatId);
}

async function getOwnersByAdminId(adminId) {
  try {
    const results = await db.all('SELECT owner_id FROM admin_controls WHERE admin_id = ?', adminId);
    return results.map(r => r.owner_id);
  } catch (error) {
    logger.error('Error getting owners by admin id:', error);
    return [];
  }
}

// ===== FUNGSI CEK AKSES PRIORITAS (FILE DULU) =====
async function getUserRoleFromFile(userId) {
  // Cek di file list_access dulu
  const access = findActiveAccessByUserId(userId);
  if (access) {
    if (access.role === 'basic') return 'PREMIUM_WM';
    if (access.role === 'pro') return 'PREMIUM_NO_WM';
    if (access.role === 'reseller') return 'RESELLER';
    if (access.role === 'trial') return 'TRIAL';
    return access.role.toUpperCase();
  }
  
  // Fallback ke database kalo ga ada di file
  const user = await db.get('SELECT role FROM users WHERE user_id = ?', userId);
  if (user) return user.role || 'FREE';
  return 'FREE';
}

async function isUserHasAccessFromFile(userId, requiredRole = null) {
  const access = findActiveAccessByUserId(userId);
  if (!access) return false;
  if (!requiredRole) return true;
  return access.role === requiredRole;
}

async function isAdminUser(adminId, ownerId) {
  try {
    const result = await db.get('SELECT id FROM admin_controls WHERE admin_id = ? AND owner_id = ?', adminId, ownerId);
    return !!result;
  } catch (error) {
    logger.error('Error checking admin user:', error);
    return false;
  }
}

async function getAdminList(ownerId) {
  try {
    return await db.all(`
      SELECT ac.*, u.full_name, u.username 
      FROM admin_controls ac 
      LEFT JOIN users u ON ac.admin_id = u.user_id 
      WHERE ac.owner_id = ? 
      ORDER BY ac.created_at DESC
    `, ownerId);
  } catch (error) {
    logger.error('Error getting admin list:', error);
    return [];
  }
}

async function addAdmin(ownerId, adminId, addedBy) {
  try {
    const existing = await db.get('SELECT id FROM admin_controls WHERE owner_id = ?', ownerId);
    if (existing) {
      return { success: false, message: 'Kamu sudah punya 1 admin. Hapus dulu yang lama.' };
    }
    
    await db.run(
      'INSERT INTO admin_controls (owner_id, admin_id, added_by, created_at) VALUES (?, ?, ?, ?)',
      ownerId, adminId, addedBy, Math.floor(Date.now() / 1000)
    );
    
    return { success: true, message: 'Admin berhasil ditambahkan' };
  } catch (error) {
    logger.error('Error adding admin:', error);
    return { success: false, message: error.message };
  }
}

async function removeAdmin(ownerId, adminId) {
  try {
    const result = await db.run('DELETE FROM admin_controls WHERE owner_id = ? AND admin_id = ?', ownerId, adminId);
    return result.changes > 0;
  } catch (error) {
    logger.error('Error removing admin:', error);
    return false;
  }
}

async function removeAllAdminsByAdminId(adminId) {
  try {
    await db.run('DELETE FROM admin_controls WHERE admin_id = ?', adminId);
    return true;
  } catch (error) {
    logger.error('Error removing all admins by admin id:', error);
    return false;
  }
}

async function getAllUserbotsByOwner(ownerId) {
  try {
    return await db.all('SELECT * FROM userbots WHERE owner_id = ? ORDER BY created_at DESC', ownerId);
  } catch (error) {
    logger.error('Error getting userbots by owner:', error);
    return [];
  }
}

async function handleToolsMenu(userId, chatId) {
  const role = await getUserRole(userId);
  
  if (!isOwnerId(userId) && role !== 'OWNER') {
    await bot.sendMessage(chatId, `<blockquote>❌ <b><u>No Permission</u></b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const caption = `
<blockquote>🛠️ <b><u>TOOLS MENU</u></b></blockquote>
<blockquote><code>/maintenance on/off/status</code>
<code>/ping</code>
<code>/addsaldo userid 3000</code>
<code>/delsaldo userid</code>
<code>/ceksaldo</code></blockquote>
`;

  await bot.sendMessage(chatId, caption, {
    parse_mode: 'HTML',
    reply_markup: {
      keyboard: [['🔙 Kembali']],
      resize_keyboard: true
    }
  });
}

async function handleExpertExtraAdmin(userId, chatId) {
  const hasUbot = await userHasUserbot(userId);
  
  if (!hasUbot) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>No Permission</u></b>
🤖 <b>Kamu belum punya userbot.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const adminCount = (await getAdminList(userId)).length;
  
  const caption = `
<blockquote>⚙️ <b><u>ADMIN CONTROL</u></b></blockquote>
<blockquote><b>Status Admin</b> : <b>${adminCount > 0 ? `✅ Aktif (${adminCount}/1)` : `❌ Belum ada`}</b></blockquote>

<i>Pilih menu di bawah</i>`;

  await bot.sendMessage(chatId, caption, {
    parse_mode: 'HTML',
    reply_markup: {
      keyboard: [
        ['👑 Tambah Admin', '🗑️ Hapus Admin'],
        ['📋 Daftar Admin'],
        ['🔙 Kembali']
      ],
      resize_keyboard: true
    }
  });
}

async function handleAddAdmin(userId, chatId) {
  const adminCount = (await getAdminList(userId)).length;
  
  if (adminCount >= 1) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>GAGAL</u></b>
👑 <b>Kamu cuma bisa punya 1 admin. Hapus yang lama dulu.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  await bot.sendMessage(chatId, `
<blockquote>➕ <b><u>TAMBAH ADMIN</u></b></blockquote>
<blockquote>📝 <b>Kirim username atau ID Telegram</b>
 <i>Contoh:</i> <code>useridname</code> atau <code>123456789</code></blockquote>

<i>Admin akan bisa mengontrol SEMUA userbot milikmu</i>`, {
    parse_mode: 'HTML',
    reply_markup: { keyboard: [[`❌ Batalkan`]], resize_keyboard: true, one_time_keyboard: true }
  });
  
  global.waitingForAddAdminInput = global.waitingForAddAdminInput || {};
  global.waitingForAddAdminInput[userId] = true;
}

async function handleAddAdminInput(userId, chatId, text) {
  if (!global.waitingForAddAdminInput[userId]) return;
  delete global.waitingForAddAdminInput[userId];
  
  let adminId = text.trim();
  
  if (adminId.startsWith('@')) {
    const username = adminId.replace('@', '');
    try {
      const chat = await bot.getChat(username);
      adminId = chat.id.toString();
    } catch (error) {
      await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>GAGAL</u></b>
👤 <b>Username tidak ditemukan.</b></blockquote>`, { parse_mode: 'HTML' });
      return;
    }
  }
  
  if (!/^\d+$/.test(adminId)) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>FORMAT SALAH</u></b>
📝 <b>Gunakan username atau ID angka.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  if (adminId === userId) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>GA BISA</u></b>
👤 <b>Tidak bisa menjadikan diri sendiri sebagai admin.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const adminExists = await db.get('SELECT user_id FROM users WHERE user_id = ?', adminId);
  
  if (!adminExists) {
    await db.run(
      'INSERT OR IGNORE INTO users (user_id, role, created_at) VALUES (?, ?, ?)',
      adminId, 'FREE', Math.floor(Date.now() / 1000)
    );
  }
  
  const result = await addAdmin(userId, adminId, userId);
  
  if (result.success) {
    await bot.sendMessage(chatId, `
<blockquote>✅ <b><u>BERHASIL</u></b>
👤 <b>${result.message}</b>
🆔 <b>User ID</b> : <code>${adminId}</code></blockquote>`, { parse_mode: 'HTML' });
    
    try {
      await bot.sendMessage(adminId, `
<blockquote>⚙️ <b><u>KAMU DIJADIKAN ADMIN!</u></b>
👤 <b>Userbot milik</b> : <code>${userId}</code>
🤖 <b>Akses</b> : <i>Mengontrol semua userbot</i>
📣 <b>Menu</b> : <b>🕹️ Control Akun</b></blockquote>

<i>Klik tombol di bawah untuk mulai</i>`, {
        parse_mode: 'HTML',
        reply_markup: await getMainMenuKeyboard(adminId)
      });
    } catch (e) {}
  } else {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>GAGAL</u></b>
⚠️ <b>${result.message}</b></blockquote>`, { parse_mode: 'HTML' });
  }
}

async function handleRemoveAdmin(userId, chatId) {
  const admins = await getAdminList(userId);
  
  if (admins.length === 0) {
    await bot.sendMessage(chatId, `
<blockquote>📭 <b><u>KOSONG</u></b>
👑 <b>Belum ada admin.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  let response = `
<blockquote>🗑 <b><u>HAPUS ADMIN</u></b></blockquote>
<blockquote><b>Pilih admin yang mau dihapus:</b>
`;

  for (let i = 0; i < admins.length; i++) {
    const a = admins[i];
    response += `

<b>${i + 1}.</b> <code>${a.admin_id}</code> - <b>${a.full_name || 'Unknown'}</b>`;
  }

  response += `</blockquote>

<i>📝 Kirim nomor atau ID admin yang mau dihapus.</i>`;
  
  await bot.sendMessage(chatId, response, { parse_mode: 'HTML' });
  
  global.waitingForRemoveAdminInput = global.waitingForRemoveAdminInput || {};
  global.waitingForRemoveAdminInput[userId] = { admins: admins };
}

async function handleRemoveAdminInput(userId, chatId, text) {
  const data = global.waitingForRemoveAdminInput[userId];
  if (!data) return;
  
  delete global.waitingForRemoveAdminInput[userId];
  
  let adminId = text.trim();
  let adminToRemove = null;
  
  if (/^\d+$/.test(adminId)) {
    adminToRemove = data.admins.find(a => a.admin_id === adminId);
  } else {
    const index = parseInt(adminId) - 1;
    if (!isNaN(index) && index >= 0 && index < data.admins.length) {
      adminToRemove = data.admins[index];
      adminId = adminToRemove.admin_id;
    }
  }
  
  if (!adminToRemove) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>GAGAL</u></b>
👤 <b>Admin tidak ditemukan.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const success = await removeAdmin(userId, adminId);
  
  if (success) {
    await bot.sendMessage(chatId, `
<blockquote>✅ <b><u>BERHASIL DIHAPUS</u></b>
👤 <b>Admin</b> : <code>${adminId}</code>
🗑 <b>Status</b> : <i>Berhasil dihapus dari sistem</i>
🤖 <b>Akses admin telah dicabut</b></blockquote>`, { parse_mode: 'HTML' });
    
    try {
      await bot.sendMessage(adminId, `
<blockquote>⚠️ <b><u>STATUS ADMIN DICABUT</u></b>
👤 <b>Userbot milik</b> : <code>${userId}</code>
🗑 <b>Status</b> : <i>Admin telah dihapus</i>
📣 <b>Menu Control Akun</b> : <i>Akan otomatis hilang</i></blockquote>

<i>➡️ Terima kasih atas bantuannya</i>`, { parse_mode: 'HTML' });
    } catch (e) {}
  } else {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>GAGAL</u></b>
👤 <b>Admin</b> : <code>${adminId}</code>
⚠️ <b>Gagal menghapus admin. Coba lagi nanti.</b></blockquote>`, { parse_mode: 'HTML' });
  }
}

async function handleListAdmin(userId, chatId) {
  const admins = await getAdminList(userId);
  
  if (admins.length === 0) {
    await bot.sendMessage(chatId, `
<blockquote>📭 <b><u>KOSONG</u></b>
👑 <b>Belum ada admin.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  let response = `
<blockquote>📖 <b><u>DAFTAR ADMIN</u></b></blockquote>
`;

  for (let i = 0; i < admins.length; i++) {
    const a = admins[i];
    const addedDate = moment(a.created_at * 1000).format('DD/MM/YYYY HH:mm');
    response += `

<blockquote><b>${i + 1}.</b> <b>${escapeHtml(a.full_name || 'Unknown')}</b>
 🆔 ID: <code>${a.admin_id}</code>
 👤 Username: ${escapeHtml(a.username || '-')}
 🗓 Ditambah: ${addedDate}</blockquote>`;
  }

  response += `
<i>Total: ${admins.length} admin (max 1)</i>`;
  
  await bot.sendMessage(chatId, response, { parse_mode: 'HTML' });
}

async function handleAdminControlAccount(userId, chatId) {
  const owners = await getOwnersByAdminId(userId);
  
  if (owners.length === 0) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>No Permission</u></b>
👑 <b>Kamu bukan admin siapa-siapa.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  if (owners.length === 1) {
    const ownerId = owners[0];
    const userbots = await getAllUserbotsByOwner(ownerId);
    
    if (userbots.length === 0) {
      await bot.sendMessage(chatId, `
<blockquote>📭 <b><u>KOSONG</u></b>
🤖 <b>Tidak ada userbot yang bisa dikontrol.</b></blockquote>`, { parse_mode: 'HTML' });
      return;
    }
    
    if (userbots.length === 1) {
      await showAdminControlMenu(userId, chatId, userbots[0].ubot_id, ownerId);
    } else {
      let response = `
<blockquote>🤖 <b><u>PILIH USERBOT</u></b></blockquote>
`;
      const buttons = [];
      const row = [];
      
      for (let i = 0; i < userbots.length; i++) {
        const ubot = userbots[i];
        response += `

<blockquote><b>${i + 1}.</b> <code>${ubot.ubot_id}</code></blockquote>`;
        row.push({ text: `${i + 1}`, callback_data: `admin_select_ubot_${ubot.ubot_id}_${ownerId}` });
        if (row.length === 3 || i === userbots.length - 1) {
          buttons.push([...row]);
          row.length = 0;
        }
      }
      
      response += `
<i>Pilih nomor userbot yang mau dikontrol</i>`;
      
      buttons.push([{ text: '⬅️ Kembali', callback_data: 'back_main' }]);
      
      await bot.sendMessage(chatId, response, {
        parse_mode: 'HTML',
        reply_markup: { inline_keyboard: buttons }
      });
    }
  } else {
    let currentPage = global.adminOwnerListPage?.[userId] || 1;
    const itemsPerPage = 5;
    const totalPages = Math.ceil(owners.length / itemsPerPage);
    
    if (currentPage > totalPages) currentPage = totalPages;
    if (currentPage < 1) currentPage = 1;
    
    const start = (currentPage - 1) * itemsPerPage;
    const end = start + itemsPerPage;
    const pageOwners = owners.slice(start, end);
    
    let response = `
<blockquote>🤖 <b><u>PILIH PEMILIK USERBOT</u></b></blockquote>

<i>Kamu adalah admin untuk beberapa pemilik:</i>`;
    
    const buttons = [];
    const row = [];
    
    for (let i = 0; i < pageOwners.length; i++) {
      const ownerId = pageOwners[i];
      const user = await db.get('SELECT full_name, username FROM users WHERE user_id = ?', ownerId);
      const fullName = user?.full_name || 'Unknown';
      const username = user?.username ? `@${user.username.replace('@', '')}` : '-';
      const nomor = start + i + 1;
      
      response += `

<blockquote><b>${nomor}.</b> <b>${fullName}</b>
 🆔 <b>ID</b> : <code>${ownerId}</code>
 👤 <b>Username</b> : ${username}</blockquote>`;
      
      row.push({ text: `${nomor}`, callback_data: `admin_select_owner_${ownerId}` });
      if (row.length === 2 || i === pageOwners.length - 1) {
        buttons.push([...row]);
        row.length = 0;
      }
    }
    
    response += `

<i>Halaman ${currentPage} / ${totalPages}</i>
<i>Klik tombol pemilik untuk memilih</i>`;
    
    const navButtons = [];
    if (currentPage > 1) {
      navButtons.push({ text: '◀️', callback_data: 'admin_owner_prev_page' });
    }
    if (currentPage < totalPages) {
      navButtons.push({ text: '▶️', callback_data: 'admin_owner_next_page' });
    }
    
    if (navButtons.length > 0) {
      buttons.unshift(navButtons);
    }
    
    buttons.push([{ text: '⬅️ Kembali', callback_data: 'back_main' }]);
    
    await bot.sendMessage(chatId, response, {
      parse_mode: 'HTML',
      reply_markup: { inline_keyboard: buttons }
    });
    
    global.adminOwnerListPage = global.adminOwnerListPage || {};
    global.adminOwnerListPage[userId] = currentPage;
    global.adminOwnersData = global.adminOwnersData || {};
    global.adminOwnersData[userId] = { owners: owners, totalPages: totalPages };
  }
}

async function showAdminControlMenu(userId, chatId, ubotId, ownerId) {
  const ubot = userbots.find(ub => ub.owner_id === ownerId && ub.id === ubotId);
  
  if (!ubot) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Userbot tidak ditemukan atau offline.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const totalGroups = await db.get('SELECT COUNT(*) as count FROM groups WHERE owner_id = ?', ownerId);
  const totalMessages = await db.get('SELECT COUNT(*) as count FROM messages WHERE owner_id = ?', ownerId);
  const settings = await db.get('SELECT delay, jeda, promosi_status FROM settings WHERE owner_id = ?', ownerId) || { delay: 300, jeda: 20, promosi_status: 'OFF' };
  
  let statusText = '';
  if (settings.promosi_status === 'ON') {
    statusText = `✅ AKTIF`;
  } else if (settings.promosi_status === 'PAUSE') {
    statusText = `⏸️ PAUSE`;
  } else {
    statusText = `❌ NONAKTIF`;
  }
  
  const caption = `
<blockquote>⚙️ <b><u>KONTROL USERBOT</u></b></blockquote>
<blockquote>🆔 <b>ID Userbot</b> : <code>${ubotId}</code>
👤 <b>Pemilik</b> : <code>${ownerId}</code></blockquote>
<blockquote>👥 <b>Grup Target</b> : <b>${totalGroups.count || 0}</b>
📖 <b>Pesan Tersimpan</b> : <b>${totalMessages.count || 0}</b>
⏰ <b>Delay</b> : <b>${settings.delay} ms</b>
🕐 <b>Jeda</b> : <b>${settings.jeda} menit</b>
📣 <b>Status Promosi</b> : <b>${statusText}</b></blockquote>

<i>Pilih menu di bawah</i>`;

  const controlKeyboard = {
    reply_markup: {
      keyboard: [
        ['📄 Kelola Teks', '💬 Kelola Grup'],
        ['⏱️ Delay & Jeda', '📢 Menu Broadcast'],
        ['🔙 Kembali']
      ],
      resize_keyboard: true
    }
  };
  
  await bot.sendMessage(chatId, caption, { parse_mode: 'HTML', ...controlKeyboard });
  
  global.adminSelectedUbot = global.adminSelectedUbot || {};
  global.adminSelectedUbot[userId] = { ubotId, ownerId };
}

async function showAdminKelolaPesanMenu(userId, chatId) {
  const data = global.adminSelectedUbot[userId];
  if (!data) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Pilih userbot dulu.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const totalMessages = await db.get('SELECT COUNT(*) as count FROM messages WHERE owner_id = ?', data.ownerId);
  const settings = await db.get('SELECT selected_message_id FROM settings WHERE owner_id = ?', data.ownerId);
  const role = await getUserRole(data.ownerId);
  const hasAccess = ['PREMIUM_NO_WM', 'RESELLER', 'OWNER'].includes(role);
  
  let selectedInfo = '-';
  if (settings && settings.selected_message_id) {
    const selectedMsg = await db.get('SELECT local_id FROM messages WHERE id = ? AND owner_id = ?', settings.selected_message_id, data.ownerId);
    if (selectedMsg) selectedInfo = `<code>#${selectedMsg.local_id}</code>`;
  }
  
  let caption = `
<blockquote>📝 <b><u>KELOLA PESAN (ADMIN)</u></b></blockquote>
<blockquote><b>Total Pesan</b> : <b>${totalMessages.count || 0}</b>
<b>Pesan Aktif</b> : ${selectedInfo}</blockquote>

<i>Pilih opsi di bawah</i>`;

  let keyboard = [
    ['➕ Tambah Pesan', '🗑️ Hapus Pesan'],
    ['📋 Daftar Pesan']
  ];
  
  if (hasAccess) {
    keyboard.push(['↗️ Atur Forward']);
  }
  
  keyboard.push(['🔙 Kembali']);
  
  await bot.sendMessage(chatId, caption, {
    parse_mode: 'HTML',
    reply_markup: {
      keyboard: keyboard,
      resize_keyboard: true
    }
  });
}

async function handleAdminModeForward(userId, chatId) {
  const data = global.adminSelectedUbot[userId];
  if (!data) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Pilih userbot dulu.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const role = await getUserRole(data.ownerId);
  const hasAccess = ['PREMIUM_NO_WM', 'RESELLER', 'OWNER'].includes(role);
  
  if (!hasAccess) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>No Permission</u></b>
↗️ <b>User ini tidak memiliki akses NO WM/PRO/Reseller.</b></blockquote>`, {
      parse_mode: 'HTML',
      reply_markup: await getKelolaPesanKeyboard(data.ownerId)
    });
    return;
  }
  
  await bot.sendMessage(chatId, `
<blockquote>↗️ <b><u>FORWARD PESAN (ADMIN)</u></b></blockquote>
<blockquote>📨 Kirim link pesan Telegram yang mau di-forward.</blockquote>
<blockquote>📌 Contoh: <code>https://t.me/username/1234</code></blockquote>

<i>⚠️ Pesan akan disimpan sebagai Set Forward (tanpa watermark)</i>`, {
    parse_mode: 'HTML',
    reply_markup: { keyboard: [[`❌ Batalkan`]], resize_keyboard: true }
  });
  
  global.waitingForAdminForwardLink = global.waitingForAdminForwardLink || {};
  global.waitingForAdminForwardLink[userId] = { ownerId: data.ownerId };
}

async function handleAdminForwardLinkInput(userId, chatId, text) {
  const data = global.waitingForAdminForwardLink[userId];
  if (!data) return;
  
  delete global.waitingForAdminForwardLink[userId];
  
  const ubot = userbots.find(ub => ub.owner_id === data.ownerId);
  if (!ubot) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Userbot ga ketemu.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  try {
    let entity;
    let messageId;
    
    const urlPattern = /https?:\/\/t\.me\/(?:c\/)?([^\/]+)\/(\d+)/;
    const match = text.match(urlPattern);
    
    if (!match) {
      await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🔗 <b>Link ga valid. Pake format: https://t.me/username/1234</b></blockquote>`, { parse_mode: 'HTML' });
      return;
    }
    
    const chatPart = match[1];
    messageId = parseInt(match[2]);
    
    try {
      entity = await ubot.client.getEntity(chatPart);
    } catch {
      entity = await ubot.client.getEntity(`https://t.me/${chatPart}`);
    }
    
    const messages = await ubot.client.getMessages(entity, { ids: messageId });
    const msgForward = messages[0];
    
    if (!msgForward) {
      await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
📝 <b>Pesan ga ketemu.</b></blockquote>`, { parse_mode: 'HTML' });
      return;
    }
    
    const lastMessage = await db.get('SELECT MAX(local_id) as max FROM messages WHERE owner_id = ?', data.ownerId);
    const nextLocalId = (lastMessage?.max || 0) + 1;
    
    await db.run(
      'INSERT INTO messages (owner_id, local_id, type, content, file_id, caption, from_chat, forward_message_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
      data.ownerId, nextLocalId, 'forward', msgForward.message || '', null, msgForward.message || '', entity.id.toString(), messageId, Math.floor(Date.now() / 1000)
    );
    
    const newMessage = await db.get('SELECT id FROM messages WHERE owner_id = ? AND local_id = ?', data.ownerId, nextLocalId);
    
    if (newMessage) {
      await db.run('UPDATE settings SET selected_message_id = ? WHERE owner_id = ?', newMessage.id, data.ownerId);
    }
    
    await bot.sendMessage(chatId, `
<blockquote>✅ <b><u>BERHASIL</u></b></blockquote>
<blockquote>📝 <b>Pesan #${nextLocalId} berhasil disimpan!</b>
✅ Otomatis dipilih jadi pesan aktif</blockquote>

<i>Pesan akan di-forward ke grup target (tanpa watermark).</i>`, {
      parse_mode: 'HTML',
      reply_markup: {
        keyboard: [['🔙 Kembali']],
        resize_keyboard: true
      }
    });
    
  } catch (error) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>GAGAL</u></b>
⚠️ <b>${error.message}</b></blockquote>`, { parse_mode: 'HTML' });
  }
}

async function showAdminKelolaGroupMenu(userId, chatId) {
  const data = global.adminSelectedUbot[userId];
  if (!data) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Pilih userbot dulu.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const totalGroups = await db.get('SELECT COUNT(*) as count FROM groups WHERE owner_id = ?', data.ownerId);
  
  const caption = `
<blockquote>👥 <b><u>KELOLA GROUP (ADMIN)</u></b></blockquote>
<blockquote><b>Total Group</b> : <b>${totalGroups.count || 0}</b></blockquote>

<i>Pilih opsi di bawah</i>`;

  await bot.sendMessage(chatId, caption, {
    parse_mode: 'HTML',
    reply_markup: {
      keyboard: [
        ['➕ Tambah Grup', '🗑️ Hapus Grup'],
        ['📋 Daftar Grup'],
        ['🔙 Kembali']
      ],
      resize_keyboard: true
    }
  });
}

async function showAdminDelayJedaMenu(userId, chatId) {
  const data = global.adminSelectedUbot[userId];
  if (!data) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Pilih userbot dulu.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const settings = await db.get('SELECT delay, jeda FROM settings WHERE owner_id = ?', data.ownerId) || { delay: 300, jeda: 20 };
  
  const caption = `
<blockquote>⏳ <b><u>DELAY & JEDA (ADMIN)</u></b></blockquote>
<blockquote>⏰ <b>Delay Antar Grup</b> : <b>${settings.delay} ms</b>
🕐 <b>Jeda Antar Round</b> : <b>${settings.jeda} menit</b></blockquote>

<i>Pilih opsi di bawah</i>`;

  await bot.sendMessage(chatId, caption, {
    parse_mode: 'HTML',
    reply_markup: {
      keyboard: [
        ['⏱️ Atur Delay (Admin)', '⏸️ Atur Jeda (Admin)'],
        ['🔙 Kembali']
      ],
      resize_keyboard: true
    }
  });
}

async function showAdminBroadcastMenu(userId, chatId) {
  const data = global.adminSelectedUbot[userId];
  if (!data) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Pilih userbot dulu.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const settings = await db.get('SELECT promosi_status FROM settings WHERE owner_id = ?', data.ownerId) || { promosi_status: 'OFF' };
  
  let statusText = '';
  if (settings.promosi_status === 'ON') statusText = `✅ AKTIF`;
  else if (settings.promosi_status === 'PAUSE') statusText = `⏸️ PAUSE`;
  else statusText = `❌ NONAKTIF`;
  
  const caption = `
<blockquote>📣 <b><u>BROADCAST MENU (ADMIN)</u></b></blockquote>
<blockquote><b>Status AutoBC</b> : <b>${statusText}</b></blockquote>

<i>Pilih opsi di bawah</i>`;

  await bot.sendMessage(chatId, caption, {
    parse_mode: 'HTML',
    reply_markup: {
      keyboard: [
        ['▶️ Aktifkan Auto Share', '⏸️ Jeda Auto Share'],
        ['⏹️ Hentikan Auto Share', '🔄 Nonaktifkan Auto Share'],
        ['🔙 Kembali']
      ],
      resize_keyboard: true
    }
  });
}

async function handleAdminSetPesan(userId, chatId) {
  const data = global.adminSelectedUbot[userId];
  if (!data) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Pilih userbot dulu.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  await bot.sendMessage(chatId, `
<blockquote>📝 <b><u>SET PESAN (ADMIN)</u></b></blockquote>
<blockquote>📨 Kirim pesan yang mau disimpan.
📱 Support: teks, foto, video, dokumen, audio.</blockquote>
<blockquote><b>Contoh teks:</b>
<code>Jual VPS murah, minat? chat @admin</code></blockquote>`, {
    parse_mode: 'HTML',
    reply_markup: { keyboard: [[`❌ Batalkan`]], resize_keyboard: true, one_time_keyboard: true }
  });
  
  global.waitingForAdminSetPesan = global.waitingForAdminSetPesan || {};
  global.waitingForAdminSetPesan[userId] = true;
}

async function handleAdminDelPesan(userId, chatId) {
  const data = global.adminSelectedUbot[userId];
  if (!data) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Pilih userbot dulu.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const caption = `
<blockquote>🗑 <b><u>DEL PESAN (ADMIN)</u></b></blockquote>
<blockquote><b>Pilih cara hapus pesan:</b></blockquote>`;

  await bot.sendMessage(chatId, caption, {
    parse_mode: 'HTML',
    reply_markup: {
      keyboard: [
        ['📝 Delete Manual', '🗑️ Hapus Semua'],
        ['🔙 Kembali']
      ],
      resize_keyboard: true
    }
  });
  
  global.waitingForAdminDelPesanChoice = global.waitingForAdminDelPesanChoice || {};
  global.waitingForAdminDelPesanChoice[userId] = { ownerId: data.ownerId };
}

async function handleAdminDelPesanManual(userId, chatId) {
  const data = global.waitingForAdminDelPesanChoice?.[userId];
  if (!data) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Sesi habis. Pilih userbot dulu.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const messages = await db.all('SELECT * FROM messages WHERE owner_id = ? ORDER BY local_id DESC', data.ownerId);
  
  if (messages.length === 0) {
    await bot.sendMessage(chatId, `
<blockquote>📭 <b><u>KOSONG</u></b>
📝 <b>Belum ada pesan tersimpan.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  if (!global.adminDelPesanPage) global.adminDelPesanPage = {};
  if (!global.adminDelPesanPage[userId]) {
    global.adminDelPesanPage[userId] = { page: 1, ownerId: data.ownerId, messages: messages };
  }
  
  global.adminDelPesanPage[userId].messages = messages;
  
  const itemsPerPage = 5;
  const totalPages = Math.ceil(messages.length / itemsPerPage);
  let currentPage = global.adminDelPesanPage[userId].page;
  
  if (currentPage > totalPages) currentPage = totalPages;
  if (currentPage < 1) currentPage = 1;
  
  const start = (currentPage - 1) * itemsPerPage;
  const end = start + itemsPerPage;
  const pageMessages = messages.slice(start, end);
  
  let response = `
<blockquote>🗑 <b><u>HAPUS PESAN MANUAL</u></b></blockquote>
<blockquote><b>Pilih pesan yang mau dihapus:</b>
<i>Halaman ${currentPage} / ${totalPages}</i></blockquote>`;

  for (let i = 0; i < pageMessages.length; i++) {
    const msg = pageMessages[i];
    const nomor = start + i + 1;
    let typeIcon = '';
    if (msg.type === 'text') typeIcon = '📝';
    else if (msg.type === 'photo') typeIcon = '📸';
    else if (msg.type === 'video') typeIcon = '🎥';
    else if (msg.type === 'document') typeIcon = '📄';
    else if (msg.type === 'forward') typeIcon = '↗️';
    else typeIcon = '📎';
    
    response += `

<blockquote><b>${nomor}.</b> ${typeIcon} <b>ID</b>: <code>#${msg.local_id}</code> | <b>${msg.type}</b></blockquote>`;
  }

  response += `

<i>📝 Kirim NOMOR pesan yang mau dihapus.</i>`;
  
  const buttons = [];
  const navButtons = [];
  
  if (currentPage > 1) {
    navButtons.push({ text: '◀️', callback_data: 'admin_del_pesan_prev' });
  }
  if (currentPage < totalPages) {
    navButtons.push({ text: '▶️', callback_data: 'admin_del_pesan_next' });
  }
  
  if (navButtons.length > 0) {
    buttons.push(navButtons);
  }
  
  buttons.push([{ text: '⬅️ Kembali', callback_data: 'admin_back_to_del_pesan' }]);
  
  const sentMsg = await bot.sendMessage(chatId, response, {
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard: buttons }
  });
  
  if (global.adminDelPesanMsgId && global.adminDelPesanMsgId[userId]) {
    try {
      await safeDeleteMessage(chatId, global.adminDelPesanMsgId[userId]);
    } catch (e) {}
  }
  
  if (!global.adminDelPesanMsgId) global.adminDelPesanMsgId = {};
  global.adminDelPesanMsgId[userId] = sentMsg.message_id;
  
  global.waitingForAdminDelPesan = global.waitingForAdminDelPesan || {};
  global.waitingForAdminDelPesan[userId] = { messages: messages, ownerId: data.ownerId };
}

async function handleAdminDelPesanSemua(userId, chatId) {
  const data = global.waitingForAdminDelPesanChoice?.[userId];
  if (!data) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Sesi habis. Pilih userbot dulu.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const totalPesan = await db.get('SELECT COUNT(*) as count FROM messages WHERE owner_id = ?', data.ownerId);
  
  if (totalPesan.count === 0) {
    await bot.sendMessage(chatId, `
<blockquote>📭 <b><u>KOSONG</u></b>
📝 <b>Belum ada pesan tersimpan.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  await bot.sendMessage(chatId, `
<blockquote>⚠️ <b><u>PERHATIAN!</u></b></blockquote>
<blockquote>Kamu akan menghapus <b>${totalPesan.count} pesan</b> secara permanen.</blockquote>

<i>Yakin mau lanjut?</i>`, {
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [
          { text: '✅ Ya, Hapus Semua', callback_data: `admin_confirm_delete_all_pesan_${data.ownerId}` },
          { text: '❌ Batal', callback_data: 'admin_cancel_delete_all_pesan' }
        ]
      ]
    }
  });
}

async function handleAdminConfirmDeleteAllPesan(callbackQuery, userId, chatId, messageId, data) {
  const ownerId = data.replace('admin_confirm_delete_all_pesan_', '');
  
  await safeAnswerCallbackQuery(callbackQuery, `<i>⏳ Menghapus semua pesan...</i>`);
  
  await db.run('DELETE FROM messages WHERE owner_id = ?', ownerId);
  await db.run('UPDATE settings SET selected_message_id = NULL WHERE owner_id = ?', ownerId);
  
  await safeEditMessageText(`
<blockquote>✅ <b><u>SEMUA PESAN DIHAPUS</u></b>
🗑️ <b>${await db.get('SELECT COUNT(*) as count FROM messages WHERE owner_id = ?', ownerId)} pesan berhasil dihapus!</b></blockquote>`, {
    chat_id: chatId,
    message_id: messageId,
    parse_mode: 'HTML'
  });
  
  setTimeout(async () => {
    await safeDeleteMessage(chatId, messageId);
    await showAdminKelolaPesanMenu(userId, chatId);
  }, 2000);
}

async function handleAdminCancelDeleteAllPesan(callbackQuery, userId, chatId, messageId) {
  await safeAnswerCallbackQuery(callbackQuery, `<i>❌ Penghapusan dibatalkan</i>`);
  await safeDeleteMessage(chatId, messageId);
  await showAdminKelolaPesanMenu(userId, chatId);
}

async function handleAdminBackToDelPesan(callbackQuery, userId, chatId, messageId) {
  await safeDeleteMessage(chatId, messageId);
  await handleAdminDelPesan(userId, chatId);
}

async function handleAdminDelPesanPrev(callbackQuery, userId, chatId, messageId) {
  await safeAnswerCallbackQuery(callbackQuery);
  
  if (global.adminDelPesanPage && global.adminDelPesanPage[userId]) {
    if (global.adminDelPesanPage[userId].page > 1) {
      global.adminDelPesanPage[userId].page--;
      await safeDeleteMessage(chatId, messageId);
      await handleAdminDelPesanManual(userId, chatId);
    }
  }
}

async function handleAdminDelPesanNext(callbackQuery, userId, chatId, messageId) {
  await safeAnswerCallbackQuery(callbackQuery);
  
  if (global.adminDelPesanPage && global.adminDelPesanPage[userId]) {
    const messages = await db.all('SELECT * FROM messages WHERE owner_id = ? ORDER BY local_id DESC', global.adminDelPesanPage[userId].ownerId);
    const totalPages = Math.ceil(messages.length / 5);
    if (global.adminDelPesanPage[userId].page < totalPages) {
      global.adminDelPesanPage[userId].page++;
      await safeDeleteMessage(chatId, messageId);
      await handleAdminDelPesanManual(userId, chatId);
    }
  }
}

async function handleAdminListPesan(userId, chatId) {
  const data = global.adminSelectedUbot[userId];
  if (!data) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Pilih userbot dulu.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const messages = await db.all('SELECT * FROM messages WHERE owner_id = ? ORDER BY local_id DESC', data.ownerId);
  
  if (messages.length === 0) {
    await bot.sendMessage(chatId, `
<blockquote>📭 <b><u>KOSONG</u></b>
📝 <b>Belum ada pesan tersimpan.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  if (!global.adminListPesanPage) global.adminListPesanPage = {};
  if (!global.adminListPesanPage[userId]) {
    global.adminListPesanPage[userId] = { page: 1, ownerId: data.ownerId };
  }
  
  const itemsPerPage = 5;
  const totalPages = Math.ceil(messages.length / itemsPerPage);
  let currentPage = global.adminListPesanPage[userId].page;
  
  if (currentPage > totalPages) currentPage = totalPages;
  if (currentPage < 1) currentPage = 1;
  
  const start = (currentPage - 1) * itemsPerPage;
  const end = start + itemsPerPage;
  const pageMessages = messages.slice(start, end);
  
  let response = `
<blockquote>📖 <b><u>LIST PESAN</u></b></blockquote>
<blockquote><i>Halaman ${currentPage} / ${totalPages}</i></blockquote>
`;

  for (let i = 0; i < pageMessages.length; i++) {
    const msg = pageMessages[i];
    const nomor = start + i + 1;
    let preview = '';
    if (msg.type === 'text') {
      preview = msg.content ? msg.content.substring(0, 50) + (msg.content.length > 50 ? '...' : '') : '(kosong)';
    } else if (msg.type === 'photo') {
      preview = '📸 [FOTO]';
    } else if (msg.type === 'video') {
      preview = '🎥 [VIDEO]';
    } else if (msg.type === 'document') {
      preview = '📄 [DOKUMEN]';
    } else if (msg.type === 'forward') {
      preview = '↗️ [FORWARD]';
    } else {
      preview = `[${msg.type.toUpperCase()}]`;
    }
    
    response += `

<blockquote><b>${nomor}.</b> <b>ID</b>: <code>#${msg.local_id}</code> | <b>${msg.type}</b>
 <i>${preview}</i></blockquote>`;
  }

  response += `

<i>Klik tombol di bawah untuk memilih pesan aktif</i>`;
  
  const buttons = [];
  const row = [];
  
  for (let i = 0; i < pageMessages.length; i++) {
    const msg = pageMessages[i];
    row.push({ text: `${start + i + 1}`, callback_data: `admin_select_message_${msg.id}_${data.ownerId}` });
    if (row.length === 3 || i === pageMessages.length - 1) {
      buttons.push([...row]);
      row.length = 0;
    }
  }
  
  const navButtons = [];
  if (currentPage > 1) {
    navButtons.push({ text: '◀️', callback_data: 'admin_list_pesan_prev' });
  }
  if (currentPage < totalPages) {
    navButtons.push({ text: '▶️', callback_data: 'admin_list_pesan_next' });
  }
  if (navButtons.length > 0) {
    buttons.push(navButtons);
  }
  
  buttons.push([{ text: '⬅️ Kembali', callback_data: 'admin_back_to_kelola_pesan' }]);
  
  const sentMsg = await bot.sendMessage(chatId, response, {
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard: buttons }
  });
  
  if (global.adminListPesanMsgId && global.adminListPesanMsgId[userId]) {
    try {
      await safeDeleteMessage(chatId, global.adminListPesanMsgId[userId]);
    } catch (e) {}
  }
  
  if (!global.adminListPesanMsgId) global.adminListPesanMsgId = {};
  global.adminListPesanMsgId[userId] = sentMsg.message_id;
}

async function handleAdminTambahGroup(userId, chatId) {
  const data = global.adminSelectedUbot[userId];
  if (!data) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Pilih userbot dulu.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const caption = `
<blockquote>➕ <b><u>TAMBAH GROUP (ADMIN)</u></b></blockquote>
<blockquote><b>Pilih cara tambah group:</b></blockquote>`;

  await bot.sendMessage(chatId, caption, {
    parse_mode: 'HTML',
    reply_markup: {
      keyboard: [
        ['📝 Tambah Manual', '🔄 Tambah Otomatis'],
        ['🔙 Kembali']
      ],
      resize_keyboard: true
    }
  });
}

async function handleAdminTambahGroupManual(userId, chatId) {
  const data = global.adminSelectedUbot[userId];
  if (!data) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Pilih userbot dulu.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  await bot.sendMessage(chatId, `
<blockquote>➕ <b><u>TAMBAH GROUP MANUAL (ADMIN)</u></b></blockquote>
<blockquote>📝 Kirim username, ID grup, atau invite link grup.</blockquote>
<blockquote>📌 Contoh: <code>@grupku, -100123456789, https://t.me/+invite123</code></blockquote>

<i>Gunakan koma untuk memisahkan beberapa grup</i>`, {
    parse_mode: 'HTML',
    reply_markup: { keyboard: [[`❌ Batalkan`]], resize_keyboard: true, one_time_keyboard: true }
  });
  
  global.waitingForAdminTambahGroupManual = global.waitingForAdminTambahGroupManual || {};
  global.waitingForAdminTambahGroupManual[userId] = { ownerId: data.ownerId };
}

async function handleAdminTambahGroupOtomatis(userId, chatId) {
  const data = global.adminSelectedUbot[userId];
  if (!data) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Pilih userbot dulu.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const ubot = userbots.find(ub => ub.owner_id === data.ownerId);
  if (!ubot) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Userbot tidak ditemukan atau offline.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const statusMsg = await bot.sendMessage(chatId, `
<blockquote>⚙️ <b><u>MENGAMBIL DAFTAR GRUP</u></b>
⏳ <i>Sedang memproses...</i></blockquote>`, { parse_mode: 'HTML' });
  
  try {
    const dialogs = await ubot.client.getDialogs();
    let added = 0;
    let alreadyExists = 0;
    let failed = 0;
    
    for (const dialog of dialogs) {
      if (dialog.isGroup) {
        const groupId = dialog.id.toString();
        const groupTitle = dialog.title;
        const groupUsername = dialog.username || '';
        
        const exists = await db.get('SELECT * FROM groups WHERE owner_id = ? AND group_id = ?', data.ownerId, groupId);
        
        if (!exists) {
          await db.run(
            'INSERT INTO groups (owner_id, group_id, group_title, group_username, added_at) VALUES (?, ?, ?, ?, ?)',
            data.ownerId, groupId, groupTitle, groupUsername, Math.floor(Date.now() / 1000)
          );
          added++;
        } else {
          alreadyExists++;
        }
      }
    }
    
    await safeDeleteMessage(chatId, statusMsg.message_id);
    await bot.sendMessage(chatId, `
<blockquote>✅ <b><u>HASIL SYNC GRUP</u></b></blockquote>
<blockquote>✅ Berhasil menambah: <b>${added}</b> grup
📋 Sudah ada: <b>${alreadyExists}</b> grup
❌ Gagal: <b>${failed}</b> grup</blockquote>`, { parse_mode: 'HTML' });
    await showAdminKelolaGroupMenu(userId, chatId);
    
  } catch (error) {
    await safeDeleteMessage(chatId, statusMsg.message_id);
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>GAGAL SYNC GRUP</u></b>
⚠️ <b>${error.message}</b></blockquote>`, { parse_mode: 'HTML' });
  }
}

async function handleAdminHapusGroup(userId, chatId) {
  const data = global.adminSelectedUbot[userId];
  if (!data) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Pilih userbot dulu.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const caption = `
<blockquote>🗑 <b><u>HAPUS GROUP (ADMIN)</u></b></blockquote>
<blockquote><b>Pilih cara hapus group:</b></blockquote>`;

  await bot.sendMessage(chatId, caption, {
    parse_mode: 'HTML',
    reply_markup: {
      keyboard: [
        ['📝 Hapus Manual', '🗑️ Hapus Semua'],
        ['🔙 Kembali']
      ],
      resize_keyboard: true
    }
  });
}

async function handleAdminHapusGroupManual(userId, chatId) {
  const data = global.adminSelectedUbot[userId];
  if (!data) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Pilih userbot dulu.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const groups = await db.all('SELECT * FROM groups WHERE owner_id = ? ORDER BY added_at DESC', data.ownerId);
  
  if (groups.length === 0) {
    await bot.sendMessage(chatId, `
<blockquote>📭 <b><u>KOSONG</u></b>
👥 <b>Belum ada grup tersimpan.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  if (!global.adminHapusGroupPage) global.adminHapusGroupPage = {};
  if (!global.adminHapusGroupPage[userId]) {
    global.adminHapusGroupPage[userId] = { page: 1, ownerId: data.ownerId };
  }
  
  global.adminHapusGroupPage[userId].groups = groups;
  global.adminHapusGroupPage[userId].ownerId = data.ownerId;
  
  const itemsPerPage = 10;
  const totalPages = Math.ceil(groups.length / itemsPerPage);
  let currentPage = global.adminHapusGroupPage[userId].page;
  
  if (currentPage > totalPages) currentPage = totalPages;
  if (currentPage < 1) currentPage = 1;
  
  const start = (currentPage - 1) * itemsPerPage;
  const end = start + itemsPerPage;
  const pageGroups = groups.slice(start, end);
  
  let response = `
<blockquote>🗑 <b><u>HAPUS GROUP MANUAL</u></b></blockquote>
<blockquote><b>Pilih grup yang mau dihapus:</b>
 <i>Halaman ${currentPage} / ${totalPages}</i></blockquote>`;

  for (let i = 0; i < pageGroups.length; i++) {
    const g = pageGroups[i];
    const nomor = start + i + 1;
    let title = g.group_title;
    if (title.length > 25) title = title.substring(0, 22) + '...';
    response += `

<blockquote><b>${nomor}.</b> ${title}
 <code>${g.group_id}</code></blockquote>`;
  }

  response += `

<i>📝 Kirim NOMOR grup yang mau dihapus. Atau klik tombol navigasi.</i>`;
  
  const buttons = [];
  const navButtons = [];
  
  if (currentPage > 1) {
    navButtons.push({ text: '◀️', callback_data: 'admin_hapus_group_prev' });
  }
  if (currentPage < totalPages) {
    navButtons.push({ text: '▶️', callback_data: 'admin_hapus_group_next' });
  }
  
  if (navButtons.length > 0) {
    buttons.push(navButtons);
  }
  
  buttons.push([{ text: '⬅️ Kembali', callback_data: 'admin_back_to_group_menu' }]);
  
  const sentMsg = await bot.sendMessage(chatId, response, {
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard: buttons }
  });
  
  if (global.adminHapusGroupMsgId && global.adminHapusGroupMsgId[userId]) {
    try {
      await safeDeleteMessage(chatId, global.adminHapusGroupMsgId[userId]);
    } catch (e) {}
  }
  
  if (!global.adminHapusGroupMsgId) global.adminHapusGroupMsgId = {};
  global.adminHapusGroupMsgId[userId] = sentMsg.message_id;
  
  global.waitingForAdminHapusGroupManual = global.waitingForAdminHapusGroupManual || {};
  global.waitingForAdminHapusGroupManual[userId] = { ownerId: data.ownerId, groups: groups };
}

async function handleAdminHapusGroupPrev(callbackQuery, userId, chatId, messageId) {
  await safeAnswerCallbackQuery(callbackQuery);
  
  if (global.adminHapusGroupPage && global.adminHapusGroupPage[userId]) {
    if (global.adminHapusGroupPage[userId].page > 1) {
      global.adminHapusGroupPage[userId].page--;
      await safeDeleteMessage(chatId, messageId);
      await handleAdminHapusGroupManual(userId, chatId);
    }
  }
}

async function handleAdminHapusGroupNext(callbackQuery, userId, chatId, messageId) {
  await safeAnswerCallbackQuery(callbackQuery);
  
  if (global.adminHapusGroupPage && global.adminHapusGroupPage[userId]) {
    const groups = await db.all('SELECT * FROM groups WHERE owner_id = ? ORDER BY added_at DESC', global.adminHapusGroupPage[userId].ownerId);
    const totalPages = Math.ceil(groups.length / 10);
    if (global.adminHapusGroupPage[userId].page < totalPages) {
      global.adminHapusGroupPage[userId].page++;
      await safeDeleteMessage(chatId, messageId);
      await handleAdminHapusGroupManual(userId, chatId);
    }
  }
}

async function handleAdminConfirmDeleteGroup(callbackQuery, userId, chatId, messageId, data) {
  const parts = data.replace('admin_delete_group_', '').split('_');
  const groupDbId = parts[0];
  const ownerId = parts[1];
  
  await safeAnswerCallbackQuery(callbackQuery, `<i>⏳ Menghapus grup...</i>`);
  
  const group = await db.get('SELECT * FROM groups WHERE id = ? AND owner_id = ?', groupDbId, ownerId);
  
  if (!group) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
👥 <b>Grup tidak ditemukan!</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const ubot = userbots.find(ub => ub.owner_id === ownerId);
  
  if (ubot && ubot.client) {
    try {
      let entity;
      const groupIdNum = parseInt(group.group_id);
      try {
        entity = await ubot.client.getEntity(groupIdNum);
      } catch (err) {
        entity = await ubot.client.getEntity(group.group_username || group.group_id);
      }
      
      if (entity) {
        await ubot.client.invoke(new Api.channels.LeaveChannel({ channel: entity }));
      }
    } catch (err) {
      logger.error(`Gagal keluar dari grup ${group.group_id}: ${err.message}`);
    }
  }
  
  await db.run('DELETE FROM groups WHERE id = ? AND owner_id = ?', groupDbId, ownerId);
  
  await safeDeleteMessage(chatId, messageId);
  
  const successMsg = await bot.sendMessage(chatId, `
<blockquote>✅ <b><u>BERHASIL DIHAPUS!</u></b>
🗑 <b>Grup:</b> ${group.group_title}
🆔 <b>ID:</b> <code>${group.group_id}</code>
🤖 <b>Status:</b> Userbot telah keluar dari grup</blockquote>`, {
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [
          { text: '⬅️ Kembali', callback_data: `admin_back_to_group_list_${ownerId}` }
        ]
      ]
    }
  });
  
  setTimeout(async () => {
    try {
      await safeDeleteMessage(chatId, successMsg.message_id);
    } catch (e) {}
    await handleAdminListGroup(userId, chatId);
  }, 3000);
}

async function handleAdminBackToGroupList(callbackQuery, userId, chatId, messageId, data) {
  const ownerId = data.replace('admin_back_to_group_list_', '');
  
  await safeDeleteMessage(chatId, messageId);
  
  global.adminSelectedUbot = global.adminSelectedUbot || {};
  global.adminSelectedUbot[userId] = { ubotId: null, ownerId: ownerId };
  
  await showAdminKelolaGroupMenu(userId, chatId);
}

async function handleAdminBackToGroupMenu(callbackQuery, userId, chatId, messageId) {
  await safeDeleteMessage(chatId, messageId);
  await showAdminKelolaGroupMenu(userId, chatId);
}

async function handleAdminHapusGroupSemua(userId, chatId) {
  const data = global.adminSelectedUbot[userId];
  if (!data) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Pilih userbot dulu.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const totalGroups = await db.get('SELECT COUNT(*) as count FROM groups WHERE owner_id = ?', data.ownerId);
  
  if (totalGroups.count === 0) {
    await bot.sendMessage(chatId, `
<blockquote>📭 <b><u>KOSONG</u></b>
👥 <b>Belum ada grup tersimpan.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  await bot.sendMessage(chatId, `
<blockquote>⚠️ <b><u>PERHATIAN!</u></b></blockquote>
<blockquote>Kamu akan menghapus <b>${totalGroups.count} grup</b> secara permanen.</blockquote>

<i>Yakin mau lanjut?</i>`, {
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [
          { text: '✅ Ya, Hapus Semua', callback_data: `admin_confirm_delete_all_groups_${data.ownerId}` },
          { text: '❌ Batal', callback_data: 'admin_cancel_delete_all_groups' }
        ]
      ]
    }
  });
}

async function handleAdminListGroup(userId, chatId) {
  const data = global.adminSelectedUbot[userId];
  if (!data) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Pilih userbot dulu.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const groups = await db.all('SELECT * FROM groups WHERE owner_id = ? ORDER BY added_at DESC', data.ownerId);
  
  if (groups.length === 0) {
    await bot.sendMessage(chatId, `
<blockquote>📭 <b><u>KOSONG</u></b>
👥 <b>Belum ada grup tersimpan.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  if (!global.adminGroupListPage) global.adminGroupListPage = {};
  if (!global.adminGroupListPage[userId]) {
    global.adminGroupListPage[userId] = { page: 1, ownerId: data.ownerId };
  }
  
  const itemsPerPage = 7;
  const totalPages = Math.ceil(groups.length / itemsPerPage);
  let currentPage = global.adminGroupListPage[userId].page;
  
  if (currentPage > totalPages) currentPage = totalPages;
  if (currentPage < 1) currentPage = 1;
  
  const start = (currentPage - 1) * itemsPerPage;
  const end = start + itemsPerPage;
  const pageGroups = groups.slice(start, end);
  
  let response = `
<blockquote>📖 <b><u>LIST GROUP</u></b></blockquote>
<blockquote><i>Halaman ${currentPage} / ${totalPages}</i></blockquote>`;

  for (let i = 0; i < pageGroups.length; i++) {
    const g = pageGroups[i];
    const nomor = start + i + 1;
    let title = g.group_title;
    if (title.length > 30) title = title.substring(0, 27) + '...';
    response += `

<blockquote><b>${nomor}.</b> <b>${title}</b>
 🆔 <b>ID</b>: <code>${g.group_id}</code>
 👤 <b>Username</b>: ${g.group_username || '-'}</blockquote>`;
  }

  response += `

<i>Gunakan tombol navigasi</i>`;
  
  const buttons = [];
  const navButtons = [];
  
  if (currentPage > 1) {
    navButtons.push({ text: '◀️', callback_data: 'admin_group_prev' });
  }
  if (currentPage < totalPages) {
    navButtons.push({ text: '▶️', callback_data: 'admin_group_next' });
  }
  
  if (navButtons.length > 0) {
    buttons.push(navButtons);
  }
  
  buttons.push([{ text: '⬅️ Kembali', callback_data: 'admin_back_to_group_menu' }]);
  
  const sentMsg = await bot.sendMessage(chatId, response, {
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard: buttons }
  });
  
  if (global.adminListGroupMsgId && global.adminListGroupMsgId[userId]) {
    try {
      await safeDeleteMessage(chatId, global.adminListGroupMsgId[userId]);
    } catch (e) {}
  }
  
  if (!global.adminListGroupMsgId) global.adminListGroupMsgId = {};
  global.adminListGroupMsgId[userId] = sentMsg.message_id;
}

async function handleAdminGroupPrev(callbackQuery, userId, chatId, messageId) {
  await safeAnswerCallbackQuery(callbackQuery);
  
  if (global.adminGroupListPage && global.adminGroupListPage[userId]) {
    global.adminGroupListPage[userId].page--;
    await safeDeleteMessage(chatId, messageId);
    await handleAdminListGroup(userId, chatId);
  }
}

async function handleAdminGroupNext(callbackQuery, userId, chatId, messageId) {
  await safeAnswerCallbackQuery(callbackQuery);
  
  if (global.adminGroupListPage && global.adminGroupListPage[userId]) {
    const groups = await db.all('SELECT * FROM groups WHERE owner_id = ? ORDER BY added_at DESC', global.adminGroupListPage[userId].ownerId);
    const totalPages = Math.ceil(groups.length / 7);
    if (global.adminGroupListPage[userId].page < totalPages) {
      global.adminGroupListPage[userId].page++;
      await safeDeleteMessage(chatId, messageId);
      await handleAdminListGroup(userId, chatId);
    }
  }
}

async function handleAdminSetDelay(userId, chatId) {
  const data = global.adminSelectedUbot[userId];
  if (!data) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Pilih userbot dulu.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  await bot.sendMessage(chatId, `
<blockquote>⏰ <b><u>SET DELAY (ADMIN)</u></b></blockquote>
<blockquote>📝 Masukin delay dalam MILIDETIK.</blockquote>
<blockquote><b>Rekomendasi:</b>
 • 300ms = Cepet
 • 500ms = Normal
 • 1000ms = Lambat</blockquote>

<i>⚠️ Minimal 100ms, Maksimal 5000ms</i>`, {
    parse_mode: 'HTML',
    reply_markup: { keyboard: [[`❌ Batalkan`]], resize_keyboard: true, one_time_keyboard: true }
  });
  
  global.waitingForAdminSetDelay = global.waitingForAdminSetDelay || {};
  global.waitingForAdminSetDelay[userId] = { ownerId: data.ownerId };
}

async function handleAdminSetJeda(userId, chatId) {
  const data = global.adminSelectedUbot[userId];
  if (!data) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Pilih userbot dulu.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  await bot.sendMessage(chatId, `
<blockquote>🕐 <b><u>SET JEDA (ADMIN)</u></b></blockquote>
<blockquote>📝 Masukin jeda antar round dalam MENIT.</blockquote>
<blockquote><b>Contoh:</b> 10, 20, 30, 720 (12 jam)</blockquote>

<i>⚠️ Minimal 1 menit</i>`, {
    parse_mode: 'HTML',
    reply_markup: { keyboard: [[`❌ Batalkan`]], resize_keyboard: true, one_time_keyboard: true }
  });
  
  global.waitingForAdminSetJeda = global.waitingForAdminSetJeda || {};
  global.waitingForAdminSetJeda[userId] = { ownerId: data.ownerId };
}

async function handleAdminAktifkanAutoBC(userId, chatId, messageId = null) {
  const data = global.adminSelectedUbot[userId];
  if (!data) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Pilih userbot dulu.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const userbotClient = userbots.find(ub => ub.owner_id === data.ownerId);
  
  if (!userbotClient || !userbotClient.client) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>GAGAL</u></b>
🤖 <b>Userbot offline! Tidak bisa mengaktifkan.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const groups = await db.all('SELECT * FROM groups WHERE owner_id = ?', data.ownerId);
  const messages = await db.all('SELECT * FROM messages WHERE owner_id = ?', data.ownerId);
  
  if (groups.length === 0 || messages.length === 0) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>GAGAL</u></b>
📝 <b>Tidak ada grup atau pesan! Setup dulu.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  let selectedMessage;
  const settingsData = await db.get('SELECT selected_message_id FROM settings WHERE owner_id = ?', data.ownerId);
  if (settingsData && settingsData.selected_message_id) {
    selectedMessage = messages.find(m => m.id === settingsData.selected_message_id);
  }
  if (!selectedMessage && messages.length > 0) {
    selectedMessage = messages[0];
  }
  
  if (!selectedMessage) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>GAGAL</u></b>
📝 <b>Tidak ada pesan tersimpan!</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  if (global.promoTimeouts && global.promoTimeouts[data.ownerId]) {
    clearTimeout(global.promoTimeouts[data.ownerId]);
    delete global.promoTimeouts[data.ownerId];
  }
  
  await db.run('UPDATE settings SET promosi_status = "ON" WHERE owner_id = ?', data.ownerId);
  
  const blacklistGroups = await db.all('SELECT group_id FROM blacklist_groups WHERE owner_id = ?', data.ownerId);
  const blacklistIds = blacklistGroups.map(b => b.group_id.toString());
  const validGroups = groups.filter(g => {
    return parseInt(g.group_id) < 0 && !blacklistIds.includes(g.group_id.toString());
  });
  
  const role = await getUserRole(data.ownerId);
  let watermarkToUse = '';
  
  if (role === 'PREMIUM_NO_WM' || role === 'RESELLER' || role === 'OWNER') {
    const freshSettings = await db.get('SELECT watermark, watermark_status FROM settings WHERE owner_id = ?', data.ownerId);
    if (freshSettings && freshSettings.watermark && freshSettings.watermark_status === 'ON') {
      watermarkToUse = freshSettings.watermark;
    }
  } else if (selectedMessage.type !== 'forward') {
    watermarkToUse = WM;
  }
  
  let messageContent = selectedMessage.content || '';
  if (selectedMessage.type !== 'forward' && watermarkToUse && messageContent) {
    messageContent = `${messageContent}\n\n${watermarkToUse}`;
  } else if (selectedMessage.type !== 'forward' && watermarkToUse && !messageContent) {
    messageContent = watermarkToUse;
  }
  
  const settings = await db.get('SELECT delay, jeda FROM settings WHERE owner_id = ?', data.ownerId) || {
    delay: 500, jeda: 15
  };
  
  if (promosiProgress[data.ownerId]) {
    delete promosiProgress[data.ownerId];
  }
  
  promosiProgress[data.ownerId] = {
    validGroups: validGroups,
    current: 0,
    success: 0,
    failed: 0,
    errors: [],
    running: true,
    startTime: Date.now(),
    settings: { delay: settings.delay || 500, jeda: settings.jeda || 15 },
    selectedMessage: selectedMessage,
    messageContent: messageContent,
    chatId: chatId,
    lastActivity: Date.now()
  };
  
  await savePromosiState(data.ownerId);
  await savePromosiStateToFile();
  
  if (messageId) {
    await safeEditMessageText(`
<blockquote>✅ <b><u>AUTOBC AKTIF</u></b>
📣 <b>AutoBC telah diaktifkan! Broadcast dimulai...</b></blockquote>`, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: 'HTML'
    });
  } else {
    await bot.sendMessage(chatId, `
<blockquote>✅ <b><u>AUTOBC AKTIF</u></b>
📣 <b>AutoBC telah diaktifkan! Broadcast dimulai...</b></blockquote>`, { parse_mode: 'HTML' });
  }
  
  executePromoRound(data.ownerId, chatId);
}

async function handleAdminNonaktifkanAutoBC(userId, chatId, messageId = null) {
  const data = global.adminSelectedUbot[userId];
  if (!data) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Pilih userbot dulu.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  if (promosiProgress[data.ownerId]) {
    promosiProgress[data.ownerId].running = false;
    delete promosiProgress[data.ownerId];
  }
  
  if (global.promoTimeouts && global.promoTimeouts[data.ownerId]) {
    clearTimeout(global.promoTimeouts[data.ownerId]);
    delete global.promoTimeouts[data.ownerId];
  }
  
  await db.run('UPDATE settings SET promosi_status = "OFF", promosi_active = 0, promosi_round_data = NULL WHERE owner_id = ?', data.ownerId);
  await savePromosiStateToFile();
  
  if (messageId) {
    await safeEditMessageText(`
<blockquote>⏹️ <b><u>AUTOBC NONAKTIF</u></b>
🛑 <b>AutoBC telah dinonaktifkan!</b></blockquote>`, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: 'HTML'
    });
  } else {
    await bot.sendMessage(chatId, `
<blockquote>⏹️ <b><u>AUTOBC NONAKTIF</u></b>
🛑 <b>AutoBC telah dinonaktifkan!</b></blockquote>`, { parse_mode: 'HTML' });
  }
}

async function handleAdminJedaAutoBC(userId, chatId, messageId = null) {
  const data = global.adminSelectedUbot[userId];
  if (!data) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Pilih userbot dulu.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  if (promosiProgress[data.ownerId]) {
    promosiProgress[data.ownerId].running = false;
    promosiProgress[data.ownerId].lastActivity = Date.now();
    await savePromosiState(data.ownerId);
    await savePromosiStateToFile();
  }
  
  if (global.promoTimeouts && global.promoTimeouts[data.ownerId]) {
    clearTimeout(global.promoTimeouts[data.ownerId]);
    delete global.promoTimeouts[data.ownerId];
  }
  
  await db.run('UPDATE settings SET promosi_status = "PAUSE" WHERE owner_id = ?', data.ownerId);
  
  if (messageId) {
    await safeEditMessageText(`
<blockquote>⏸️ <b><u>AUTOBC DIJEDA</u></b>
⏳ <b>AutoBC dijeda!</b></blockquote>`, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: 'HTML'
    });
  } else {
    await bot.sendMessage(chatId, `
<blockquote>⏸️ <b><u>AUTOBC DIJEDA</u></b>
⏳ <b>AutoBC dijeda!</b></blockquote>`, { parse_mode: 'HTML' });
  }
}

async function handleAdminStopAutoBC(userId, chatId, messageId = null) {
  const data = global.adminSelectedUbot[userId];
  if (!data) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Pilih userbot dulu.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  if (promosiProgress[data.ownerId]) {
    promosiProgress[data.ownerId].running = false;
    delete promosiProgress[data.ownerId];
  }
  
  if (global.promoTimeouts && global.promoTimeouts[data.ownerId]) {
    clearTimeout(global.promoTimeouts[data.ownerId]);
    delete global.promoTimeouts[data.ownerId];
  }
  
  await db.run('UPDATE settings SET promosi_status = "OFF", promosi_active = 0, promosi_round_data = NULL WHERE owner_id = ?', data.ownerId);
  await savePromosiStateToFile();
  
  if (messageId) {
    await safeEditMessageText(`
<blockquote>⏹️ <b><u>AUTOBC DIHENTIKAN</u></b>
🛑 <b>AutoBC dihentikan!</b></blockquote>`, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: 'HTML'
    });
  } else {
    await bot.sendMessage(chatId, `
<blockquote>⏹️ <b><u>AUTOBC DIHENTIKAN</u></b>
🛑 <b>AutoBC dihentikan!</b></blockquote>`, { parse_mode: 'HTML' });
  }
}

async function sendGroupListPage(chatId, messageId, userId) {
  const data = global.groupListPage[userId];
  if (!data) return;
  
  const start = (data.page - 1) * 5;
  const end = start + 5;
  const pageGroups = data.groups.slice(start, end);
  
  let response = `
<blockquote>📖 <b><u>DAFTAR GROUP</u></b></blockquote>
<blockquote><i>Halaman ${data.page} / ${data.totalPages}</i></blockquote>`;

  pageGroups.forEach((group, index) => {
    response += `

<blockquote><b>${start + index + 1}.</b> <b><u>${group.group_title}</u></b>
 🆔 <b>ID</b> : <code>${group.group_id}</code>
 👤 <b>Username</b> : ${group.group_username || '-'}
 🗓 <b>Ditambah</b> : ${moment(group.added_at * 1000).format('DD/MM/YYYY')}</blockquote>`;
  });

  response += `

<i>Gunakan tombol navigasi</i>`;
  
  const keyboard = {
    inline_keyboard: []
  };
  
  const navButtons = [];
  if (data.page > 1) {
    navButtons.push({ text: '◀️', callback_data: 'group_prev' });
  }
  if (data.page < data.totalPages) {
    navButtons.push({ text: '▶️', callback_data: 'group_next' });
  }
  
  if (navButtons.length > 0) {
    keyboard.inline_keyboard.push(navButtons);
  }
  
  keyboard.inline_keyboard.push([
    { text: '⬅️ Kembali', callback_data: 'back_main' }
  ]);
  
  if (messageId) {
    await safeEditMessageText(response, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: 'HTML',
      reply_markup: keyboard
    });
  } else {
    await bot.sendMessage(chatId, response, {
      parse_mode: 'HTML',
      reply_markup: keyboard
    });
  }
}

async function updatePaketDisplay(chatId, messageId, userId, type) {
  if (!userPayments[userId]) userPayments[userId] = { type, duration: 1, targetUserId: userId };
  
  const prices = await db.get(`SELECT * FROM prices WHERE type = ?`, type);
  // Defense-in-depth: kalau row harga somehow gak ketemu (row 'prices' belum
  // ke-seed / kehapus manual), jangan crash - kasih pesan jelas ke user.
  if (!prices) {
    logger.error(`updatePaketDisplay: row prices utk type="${type}" tidak ditemukan`);
    await safeEditMessageText(`<blockquote>❌ <b><u>ERROR</u></b>\n⚠️ Data harga belum siap, coba lagi sebentar.</blockquote>`, {
      chat_id: chatId, message_id: messageId, parse_mode: 'HTML'
    }).catch(() => {});
    return;
  }
  const duration = userPayments[userId].duration;
  const pricePerMonth = prices.price_1;
  const price = pricePerMonth * duration;
  const targetUserId = userPayments[userId].targetUserId || userId;
  
  let typeName = '';
  let emoji = '';
  let maxDuration = 5;
  if (type === 'wm') {
    typeName = 'BASIC';
    emoji = '🧩';
    maxDuration = 5;
  } else if (type === 'nowm') {
    typeName = 'PRO';
    emoji = '💎';
    maxDuration = 5;
  } else {
    typeName = 'RESELLER';
    emoji = '🎟';
    maxDuration = 5;
  }
  
  const isGift = targetUserId !== userId;
  
  const caption = `
<blockquote>${emoji} <b><u>PAKET ${typeName}</u></b></blockquote>
<blockquote>💰 <b>Harga perbulan</b> : <code><b>Rp ${pricePerMonth.toLocaleString()}</b></code>
💰 <b>Total</b> : <code><b>Rp ${price.toLocaleString()}</b></code>
🗓 <b>Durasi</b> : <code><b>${duration} bulan</b></code>
${isGift ? `🎁 <b>Untuk User</b> : <code>${targetUserId}</code>` : ''}</blockquote>

<i>🕐 Gunakan tombol di bawah untuk mengatur durasi (max ${maxDuration} bulan)</i>
`;

  await safeEditMessageText(caption, {
    chat_id: chatId,
    message_id: messageId,
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [
          { text: '➖', callback_data: `${type}_decr` },
          { text: `🗓 ${duration} Bulan`, callback_data: 'noop' },
          { text: '➕', callback_data: `${type}_incr` }
        ],
        [
          { text: '✅ Konfirmasi & Bayar', callback_data: `${type}_pay_now` }
        ],
        [
          { text: '❌ Batalkan', callback_data: 'back_to_toko' }
        ]
      ]
    }
  });
}

// Cache hasil cek join biar gak nembak Telegram API 3x di SETIAP pesan/klik dari SETIAP user.
// Ini penting banget buat stabilitas pas user rame - tanpa cache, getChatMember dipanggil
// bertubi-tubi dan gampang kena rate limit Telegram, yang bikin bot lemot/nge-block user asli.
const JOIN_CHECK_CACHE_TTL = 5 * 60 * 1000; // 5 menit
if (!global.joinCheckCache) global.joinCheckCache = new Map();

async function checkUserJoined(userId) {
  const cached = global.joinCheckCache.get(userId);
  if (cached && (Date.now() - cached.ts) < JOIN_CHECK_CACHE_TTL) {
    return cached.result;
  }

  try {
    // BUG FIX: sebelumnya cek pakai username (@LoggUserbot). Username bisa
    // berubah kapan aja dan gampang typo, jadi sekarang pakai ID numerik
    // chat (JOIN_CHECK_CHAT_ID) yang lebih stabil buat cek status join.
    const JOINED_STATUSES = ['member', 'administrator', 'creator', 'restricted'];

    const checkOne = async (chatIdOrUsername) => {
      if (!chatIdOrUsername) return { joined: true, errored: false };
      try {
        const member = await bot.getChatMember(chatIdOrUsername, userId);
        const joined = JOINED_STATUSES.includes(member.status);
        // LOG DEBUG: dicatat SETIAP kali dicek (bukan cuma pas error), biar
        // begitu ada laporan "udah join tapi kedeteksi belum", kita bisa
        // lihat persis status apa yang dibalikin Telegram - status yang
        // gak dikenal (left/kicked/beda chat ID/dst) langsung ketahuan dari log,
        // gak perlu tebak-tebakan lagi.
        logger.info(`checkUserJoined: chat=${chatIdOrUsername} user=${userId} status="${member.status}" -> joined=${joined}`);
        return { joined, errored: false };
      } catch (e) {
        logger.warn(`checkUserJoined: GAGAL cek chat=${chatIdOrUsername} user=${userId} - ${e.message}`);
        // BUG FIX: kalau API gagal (timeout/rate limit/dsb), JANGAN anggap user
        // belum join. Sebelumnya error selalu dibaca sebagai "belum join", dan
        // hasil negatif palsu itu ikut DI-CACHE 5 menit — jadi user yang
        // sebenarnya sudah join bisa ke-block gara-gara satu error sesaat.
        // Fail-open: anggap joined, tapi tandai errored supaya tidak di-cache.
        return { joined: true, errored: true };
      }
    };
    
    // Channel, Komunitas, dan Log Group dibagikan ke user lewat SATU folder
    // invite (folder link) - begitu user join folder itu, otomatis ke-join
    // ketiganya sekaligus. Karena itu cukup cek status join di JOIN_CHECK_CHAT_ID
    // aja sebagai wakil dari ketiganya (lebih ringan, gak perlu 3x panggilan API),
    // dan hasilnya dipakai buat channel & komunitas juga.
    const logGroupRes = await checkOne(JOIN_CHECK_CHAT_ID);
    
    const result = {
      logGroupJoined: logGroupRes.joined,
      channelJoined: logGroupRes.joined,
      requiredGroupJoined: logGroupRes.joined
    };

    // BUG FIX: sebelumnya hasil "BELUM join" ikut di-cache juga. Efeknya:
    // user baru join grup/channel, tapi karena pengecekan SEBELUM dia join
    // sempat ke-cache sebagai "belum join", /start berikutnya (dalam 5 menit
    // ke depan) tetap kebaca "belum join" walau di Telegram dia sudah join -
    // ini persis laporan "udah join tapi bot bilang belum, baru bener
    // setelah panel di-restart" (restart = cache global kehapus semua).
    // Sekarang HANYA hasil "SUDAH join" yang di-cache. Hasil "belum join"
    // TIDAK pernah di-cache, jadi tiap kali user /start atau klik "Cek
    // Ulang" saat status-nya belum join, bot SELALU nembak fresh ke
    // Telegram - begitu user beneran join, kecatat seketika tanpa nunggu
    // TTL/restart. Kasus sebaliknya (user keluar padahal statusnya sempat
    // ke-cache "sudah join") tetap dicover oleh listener 'chat_member'
    // real-time di atas (bot WAJIB jadi admin di JOIN_CHECK_CHAT_ID biar
    // event ini kekirim dari Telegram) + fallback TTL 5 menit di bawah.
    if (!logGroupRes.errored && logGroupRes.joined) {
      global.joinCheckCache.set(userId, { ts: Date.now(), result });
    }
    return result;
  } catch (error) {
    logger.error('checkUserJoined error:', error);
    return { logGroupJoined: true, channelJoined: true, requiredGroupJoined: true };
  }
}

async function sendJoinRequiredMessage(chatId, userId) {
  const { logGroupJoined, channelJoined, requiredGroupJoined } = await checkUserJoined(userId);
  const allJoined = logGroupJoined && channelJoined && requiredGroupJoined;

  // Channel Resmi, Komunitas, dan Log Group dibagikan lewat SATU folder
  // invite (JOIN_FOLDER_LINK) - user cukup pencet folder itu buat otomatis
  // join semuanya sekaligus, jadi cukup 1 tombol join di sini (bukan 3
  // tombol terpisah). Status join dicek lewat LOG_GROUP sebagai wakil.
  let caption = `
<blockquote>🔐 <b><u>Verifikasi Akses Diperlukan</u></b>
Gabung dulu ke channel &amp; grup resmi kami (1 folder aja, otomatis semua) sebelum lanjut menggunakan bot.</blockquote>
`;

  caption += allJoined ? `
<blockquote>✅ <b>Channel & Grup Resmi</b> — sudah join</blockquote>` : `
<blockquote>📣 <b>Channel & Grup Resmi</b> — <i>belum join</i></blockquote>`;

  caption += `

<blockquote>➡️ <i>Setelah join folder di bawah, tekan "Cek Ulang"</i></blockquote>`;

  const keyboard = {
    inline_keyboard: []
  };

  if (!allJoined && JOIN_FOLDER_LINK) {
    keyboard.inline_keyboard.push([{ text: `📂 Join Semua (1 Klik)`, url: JOIN_FOLDER_LINK }]);
  }

  keyboard.inline_keyboard.push([{ text: `🔄 Cek Ulang`, callback_data: 'check_join_status' }]);
  
  await bot.sendMessage(chatId, caption, {
    parse_mode: 'HTML',
    disable_web_page_preview: true,
    reply_markup: keyboard
  });
}

// BUG FIX: sebelumnya kalau user keluar dari grup/channel wajib-join, bot
// baru "sadar" itu paling cepat 5 menit kemudian (nunggu cache
// JOIN_CHECK_CACHE_TTL kadaluarsa) - user yang baru aja keluar masih bisa
// pakai bot beberapa menit ke depan. Sekarang pasang listener 'chat_member'
// (butuh bot jadi admin di JOIN_CHECK_CHAT_ID) yang dikirim Telegram REAL-TIME
// begitu ada yang keluar/di-kick/join lagi - cache user itu langsung dihapus
// seketika, jadi pengecekan berikutnya pasti fresh, gak perlu nunggu timeout.
bot.on('chat_member', (chatMemberUpdated) => {
  try {
    const updatedChatId = String(chatMemberUpdated.chat.id);
    if (updatedChatId !== String(JOIN_CHECK_CHAT_ID)) return;

    const userId = String(chatMemberUpdated.new_chat_member.user.id);
    const newStatus = chatMemberUpdated.new_chat_member.status;

    if (global.joinCheckCache) {
      global.joinCheckCache.delete(userId);
    }
    logger.info(`chat_member update: user ${userId} di ${updatedChatId} sekarang status="${newStatus}" -> cache join dihapus, cek berikutnya bakal fresh`);
  } catch (e) {
    logger.warn(`chat_member listener error: ${e.message}`);
  }
});

function formatDurationLong(totalSeconds) {
  const sec = Math.max(0, Math.floor(totalSeconds));
  const days = Math.floor(sec / 86400);
  const hours = Math.floor((sec % 86400) / 3600);
  const minutes = Math.floor((sec % 3600) / 60);
  const seconds = sec % 60;

  if (days > 0) {
    return `${days} hari ${hours} jam ${minutes} menit ${seconds} detik`;
  }
  return `${hours} jam ${minutes} menit ${seconds} detik`;
}

async function getSystemInfoBlock() {
  const runtimeStr = formatDurationLong(process.uptime());
  const serverUptimeStr = formatDurationLong(os.uptime());

  const totalMemBytes = os.totalmem();
  const freeMemBytes = os.freemem();
  const usedMemBytes = totalMemBytes - freeMemBytes;
  const totalMemGB = (totalMemBytes / (1024 ** 3));
  const usedMemGB = (usedMemBytes / (1024 ** 3));
  const memPercent = totalMemBytes > 0 ? ((usedMemBytes / totalMemBytes) * 100) : 0;

  const cpuCount = os.cpus() ? os.cpus().length : 1;
  const loadAvg1 = os.loadavg()[0] || 0;
  const cpuPercent = cpuCount > 0 ? Math.min((loadAvg1 / cpuCount) * 100, 100) : 0;

  let diskLine = '💽 DISK: N/A';
  try {
    const stat = fs.statfsSync('/');
    const totalDiskBytes = stat.blocks * stat.bsize;
    const freeDiskBytes = stat.bfree * stat.bsize;
    const usedDiskBytes = totalDiskBytes - freeDiskBytes;
    const totalDiskGB = totalDiskBytes / (1024 ** 3);
    const usedDiskGB = usedDiskBytes / (1024 ** 3);
    const diskPercent = totalDiskBytes > 0 ? ((usedDiskBytes / totalDiskBytes) * 100) : 0;
    diskLine = `💽 DISK: ${usedDiskGB.toFixed(1)}GB / ${totalDiskGB.toFixed(1)}GB (${diskPercent.toFixed(1)}%)`;
  } catch (e) {
    // fs.statfsSync tidak tersedia / gagal, biarkan fallback N/A
  }

  return `🤖 <b>INFO SISTEM BOT</b>
┣ Runtime: ${runtimeStr}
┗ Uptime: ${serverUptimeStr}

📊 <b>RESOURCES:</b>
┣ RAM: ${usedMemGB.toFixed(1)}GB / ${totalMemGB.toFixed(1)}GB (${memPercent.toFixed(1)}%)
┣ CPU: ${cpuPercent.toFixed(1)}% of ${cpuCount} Core
┗ ${diskLine.replace('💽 ', '')}
━━━━━━━━━━━━━━━━`;
}

safeOnText(/\/start/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  
  if (msg.chat.type !== 'private') {
    return;
  }
  
  const canProceed = await checkMaintenance(userId, chatId);
  if (!canProceed) return;
  
  const username = msg.from.username ? `@${escapeHtml(msg.from.username)}` : '';
  const firstName = escapeHtml(msg.from.first_name || '');
  const lastName = escapeHtml(msg.from.last_name || '');
  const fullName = `${firstName} ${lastName}`.trim() || 'Unknown';
  const botInfo = await getCachedBotInfo();
  const botFirstName = botInfo.first_name || 'Xavier-Jaseb Bot';
  const botUsername = botInfo.username || 'XavierJasebBot';
  
  // BUG FIX: /start adalah aksi yang sengaja ditekan user (bukan klik
  // menu yang bisa spam berkali-kali), jadi di sini cache "sudah join"
  // di-skip - PAKSA fresh-check ke Telegram tiap kali /start. Ini biar
  // kasus "user sudah join lalu KELUAR, terus /start lagi" langsung
  // kedeteksi keluar seketika, gak nunggu cache 5 menit habis dulu.
  // Cache tetap dipakai normal di tempat lain (klik menu/tombol) buat
  // proteksi rate limit, cuma /start ini yang selalu fresh.
  if (global.joinCheckCache) global.joinCheckCache.delete(userId);
  const { logGroupJoined, channelJoined, requiredGroupJoined } = await checkUserJoined(userId);
  
  if (!logGroupJoined || !channelJoined || !requiredGroupJoined) {
    await sendJoinRequiredMessage(chatId, userId);
    return;
  }
  
  const user = await db.get('SELECT * FROM users WHERE user_id = ?', userId);
  
  if (!user) {
    await db.run(
      'INSERT OR IGNORE INTO users (user_id, username, full_name, role, created_at, last_active) VALUES (?, ?, ?, ?, ?, ?)',
      userId, username, fullName, 'FREE', Math.floor(Date.now() / 1000), Math.floor(Date.now() / 1000)
    );
  
  } else {
    await db.run(
      'UPDATE users SET username = ?, full_name = ?, last_active = ? WHERE user_id = ?',
      username, fullName, Math.floor(Date.now() / 1000), userId
    );
  }
  
  const systemInfoBlock = await getSystemInfoBlock();

  const caption = `
<b><u>🚀 WELCOME TO USERBOT JASEB</u></b>

${systemInfoBlock}

<i>Ready to start? 👇</i>`;

  const keyboard = await getMainMenuKeyboard(userId);

  await bot.sendMessage(chatId, caption, { 
    parse_mode: 'HTML',
    reply_markup: keyboard
  });
});

// Owner ACC deposit manual
safeOnText(/\/accdeposit (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const role = await getUserRole(userId);
  
  if (!isOwnerId(userId) && role !== 'OWNER') {
    await bot.sendMessage(chatId, `<blockquote>❌ <b>No Permission</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const orderId = match[1].trim();
  
  const statusMsg = await bot.sendMessage(chatId, `<blockquote>⏳ <b>Memproses deposit...</b></blockquote>`, { parse_mode: 'HTML' });
  
  const result = await accDeposit(orderId, userId);
  
  await safeDeleteMessage(chatId, statusMsg.message_id);
  
  if (result.success) {
    await bot.sendMessage(chatId, `<blockquote>✅ <b>${result.message}</b></blockquote>`, { parse_mode: 'HTML' });
  } else {
    await bot.sendMessage(chatId, `<blockquote>❌ <b>${result.message}</b></blockquote>`, { parse_mode: 'HTML' });
  }
});

safeOnText(/\/addproduksaldo (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const role = await getUserRole(userId);
  
  if (!isOwnerId(userId) && role !== 'OWNER') {
    await bot.sendMessage(chatId, `<blockquote>❌ <b><u>No Permission</u></b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const args = match[1].trim().split(/\s+/);
  if (args.length < 2) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>FORMAT SALAH</u></b>
📝 Format: <code>/addproduksaldo user_id amount</code></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const targetId = args[0];
  const amount = parseInt(args[1]);
  
  if (isNaN(amount) || amount <= 0) {
    await bot.sendMessage(chatId, `<blockquote>❌ <b><u>NOMINAL TIDAK VALID</u></b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  await updateProdukBalance(targetId, amount, true, null, `admin_add`);
  
  await bot.sendMessage(chatId, `
<blockquote>✅ <b><u>BERHASIL TAMBAH SALDO PRODUK</u></b>
👤 User: <code>${targetId}</code>
💰 Saldo <b>+Rp ${amount.toLocaleString()}</b></blockquote>`, { parse_mode: 'HTML' });
});

safeOnText(/\/delproduksaldo (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const role = await getUserRole(userId);
  
  if (!isOwnerId(userId) && role !== 'OWNER') {
    await bot.sendMessage(chatId, `<blockquote>❌ <b><u>No Permission</u></b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const args = match[1].trim().split(/\s+/);
  if (args.length < 2) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>FORMAT SALAH</u></b>
📝 Format: <code>/delproduksaldo user_id amount</code></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const targetId = args[0];
  const amount = parseInt(args[1]);
  
  if (isNaN(amount) || amount <= 0) {
    await bot.sendMessage(chatId, `<blockquote>❌ <b><u>NOMINAL TIDAK VALID</u></b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const success = await updateProdukBalance(targetId, amount, false, null, `admin_remove`);
  
  if (success) {
    await bot.sendMessage(chatId, `
<blockquote>✅ <b><u>BERHASIL KURANGI SALDO PRODUK</u></b>
👤 User: <code>${targetId}</code>
💰 Saldo <b>-Rp ${amount.toLocaleString()}</b></blockquote>`, { parse_mode: 'HTML' });
  } else {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>GAGAL</u></b>
⚠️ Saldo tidak mencukupi</blockquote>`, { parse_mode: 'HTML' });
  }
});

safeOnText(/\/cekproduksaldo(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const role = await getUserRole(userId);
  
  if (!isOwnerId(userId) && role !== 'OWNER') {
    await bot.sendMessage(chatId, `<blockquote>❌ <b><u>No Permission</u></b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const targetId = match[1] ? match[1].trim() : null;
  
  if (targetId) {
    const balance = getProdukBalance(targetId);
    const transactions = await getProdukUserTransactions(targetId, 10);
    const totalSpent = transactions.filter(t => t.type === 'PURCHASE').reduce((sum, t) => sum + t.amount, 0);
    
    await bot.sendMessage(chatId, `
<blockquote>💰 <b><u>CEK SALDO PRODUK</u></b>
👤 User: <code>${targetId}</code>
💰 Saldo: <b>Rp ${balance.toLocaleString()}</b>
📊 Total Belanja: <b>Rp ${totalSpent.toLocaleString()}</b>
📝 Total Transaksi: ${transactions.length}</blockquote>`, { parse_mode: 'HTML' });
  } else {
    let allSaldo = '';
    const allUsers = await db.all('SELECT user_id FROM users');
    let totalSaldo = 0;
    let userCount = 0;
    
    for (const user of allUsers) {
      const balance = getProdukBalance(user.user_id);
      if (balance > 0) {
        allSaldo += `\n👤 <code>${user.user_id}</code> : <b>Rp ${balance.toLocaleString()}</b>`;
        totalSaldo += balance;
        userCount++;
      }
    }
    
    if (userCount === 0) {
      allSaldo = '\n<i>Tidak ada user dengan saldo</i>';
    }
    
    await bot.sendMessage(chatId, `
<blockquote>💰 <b><u>SEMUA SALDO PRODUK</u></b>
📊 <b>Total User</b> : ${userCount}
💰 <b>Total Saldo</b> : <b>Rp ${totalSaldo.toLocaleString()}</b>
📝 <b>Detail Saldo:</b>${allSaldo}</blockquote>`, { parse_mode: 'HTML' });
  }
});

safeOnText(/\/cekid/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  
  if (msg.chat.type !== 'private') {
    return;
  }
  
  try {
    const user = await db.get('SELECT user_id, username, full_name, role, expired, created_at FROM users WHERE user_id = ?', userId);
    const botInfo = await getCachedBotInfo();
    const botUsername = botInfo.username;
    
    let userPhotoFileId = null;
    let userFirstName = '';
    let userLastName = '';
    let userBio = '';
    
    try {
      const chat = await bot.getChat(userId);
      userFirstName = chat.first_name || '';
      userLastName = chat.last_name || '';
      
      const userPhotos = await bot.getUserProfilePhotos(userId, { limit: 1 });
      if (userPhotos && userPhotos.total_count > 0 && userPhotos.photos.length > 0) {
        const photo = userPhotos.photos[0][userPhotos.photos[0].length - 1];
        userPhotoFileId = photo.file_id;
      }
      
      try {
        const chatMember = await bot.getChatMember(chatId, userId);
        if (chatMember && chatMember.user && chatMember.user.bio) {
          userBio = chatMember.user.bio;
        }
      } catch (e) {}
      
    } catch (error) {
      console.log('Error getting user profile:', error.message);
    }
    
    const fullName = userFirstName || user?.full_name || 'Unknown';
    const username = user?.username || msg.from.username || '-';
    const role = user?.role || 'FREE';
    const expired = user?.expired ? moment(user.expired * 1000).format('DD/MM/YYYY HH:mm:ss') : '-';
    const registeredAt = user?.created_at ? moment(user.created_at * 1000).format('DD/MM/YYYY HH:mm:ss') : moment().format('DD/MM/YYYY HH:mm:ss');
    
    let roleIcon = '👤';
    let roleColor = '';
    if (role === 'OWNER') {
      roleIcon = '👑';
      roleColor = '🌟';
    } else if (role === 'RESELLER') {
      roleIcon = '🎟️';
    } else if (role === 'PREMIUM_WM') {
      roleIcon = '🧩';
    } else if (role === 'PREMIUM_NO_WM') {
      roleIcon = '💎';
    } else if (role === 'TRIAL') {
      roleIcon = '👤';
    }
    
    const caption = `
<blockquote>${roleIcon} <b><u>📋 INFO AKUN</u></b></blockquote>
<blockquote><b>Nama</b> : ${fullName}
<b>🆔 User ID</b> : <code>${userId}</code>
<b>📛 Username</b> : @${username.replace('@', '')}
<b>🎭 Role</b> : ${roleIcon} ${role}
<b>📅 Registrasi</b> : ${registeredAt}
<b>⏰ Expired</b> : ${expired}
${userBio ? `<b>📝 Bio</b> : ${userBio.substring(0, 100)}` : ''}</blockquote>
`;

    const keyboard = {
      inline_keyboard: [
        [
          { 
            text: 'Copy', 
            copy_text: { text: userId }
          }
        ]
      ]
    };
    
    if (userPhotoFileId) {
      await bot.sendPhoto(chatId, userPhotoFileId, {
        caption: caption,
        parse_mode: 'HTML',
        reply_markup: keyboard
      });
    } else {
      await bot.sendMessage(chatId, caption, {
        parse_mode: 'HTML',
        reply_markup: keyboard
      });
    }
    
  } catch (error) {
    console.error('Error in /cekid:', error);
    
    const caption = `
<blockquote>⚠️ <b><u>GAGAL MEMUAT DATA</u></b></blockquote>
<blockquote><b>🆔 User ID</b> : <code>${userId}</code>
<b>📛 Username</b> : @${msg.from.username || '-'}</blockquote>

<i>${error.message}</i>`;

    const keyboard = {
      inline_keyboard: [
        [
          { 
            text: 'Copy', 
            copy_text: { text: userId }
          }
        ]
      ]
    };
    
    await bot.sendMessage(chatId, caption, {
      parse_mode: 'HTML',
      reply_markup: keyboard
    });
  }
});

safeOnText(/\/ping/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const isOwner = isOwnerId(userId);
  
  if (!isOwner) return;
  
  const start = Date.now();
  
  try {
    await bot.sendChatAction(chatId, 'typing');
    const end = Date.now();
    const pingMs = end - start;
    
    const botInfo = await getCachedBotInfo();
    const botName = botInfo.first_name || 'Xavier Bot';
    const botUsername = botInfo.username || 'XavierJasebBot';
    
    const uptimeSeconds = process.uptime();
    const days = Math.floor(uptimeSeconds / 86400);
    const hours = Math.floor((uptimeSeconds % 86400) / 3600);
    const minutes = Math.floor((uptimeSeconds % 3600) / 60);
    const seconds = Math.floor(uptimeSeconds % 60);
    
    let uptimeString = '';
    if (days > 0) uptimeString += `${days}d `;
    if (hours > 0) uptimeString += `${hours}h `;
    if (minutes > 0) uptimeString += `${minutes}m `;
    uptimeString += `${seconds}s`;
    
    const memoryUsage = process.memoryUsage();
    const memoryMB = (memoryUsage.rss / 1024 / 1024).toFixed(2);
    
    const caption = `
<blockquote><b>🏓 PONG</b>

<b>Bot</b> : <code>${botName}</code>
<b>Ping</b> : <code>${pingMs} ms</code>
<b>Uptime</b> : <code>${uptimeString}</code>
<b>Memory</b> : <code>${memoryMB} MB</code>
<b>Server Time</b> : <code>${moment().format('DD/MM/YYYY HH:mm:ss')}</code></blockquote>
`;

    await bot.sendMessage(chatId, caption, { parse_mode: 'HTML' });
    
  } catch (error) {
    console.error('Ping error:', error);
  }
});

safeOnText(/\/maintenance(.+)?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const role = await getUserRole(userId);
  
  if (!isOwnerId(userId) && role !== 'OWNER') {
    await bot.sendMessage(chatId, `<blockquote>❌ <b><u>No Permission</u></b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const args = match[1] ? match[1].trim().split(/\s+/) : [];
  
  if (args.length === 0) {
    let statusText = maintenanceMode.enabled ? '✅ AKTIF' : '❌ NONAKTIF';
    let reasonText = maintenanceMode.enabled ? `\n📝 <b>Alasan:</b> ${maintenanceMode.reason}` : '';
    
    await bot.sendMessage(chatId, `
<blockquote>🔧 <b><u>MAINTENANCE MODE</u></b>
📊 <b>Status:</b> ${statusText}${reasonText}</blockquote>
<blockquote>📝 <b>Cara Penggunaan:</b>
<code>/maintenance on alasan disini</code> - Aktifkan maintenance
<code>/maintenance off</code> - Nonaktifkan maintenance
<code>/maintenance status</code> - Cek status</blockquote>
<blockquote>📌 <b>Contoh:</b>
<code>/maintenance on Bot sedang update fitur baru</code>
<code>/maintenance off</code></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const command = args[0].toLowerCase();
  
  if (command === 'on') {
    let reason = 'Bot sedang dalam perawatan. Mohon kembali lagi nanti.';
    if (args.length > 1) {
      reason = args.slice(1).join(' ');
    }
    
    maintenanceMode.enabled = true;
    maintenanceMode.reason = reason;
    
    await bot.sendMessage(chatId, `
<blockquote>✅ <b><u>MAINTENANCE MODE AKTIF</u></b>
📝 <b>Alasan:</b> ${reason}
⚠️ <b>Semua user tidak bisa menggunakan bot saat maintenance.</b></blockquote>`, { parse_mode: 'HTML' });
    
  } else if (command === 'off') {
    maintenanceMode.enabled = false;
    maintenanceMode.reason = 'Bot sedang dalam perawatan. Mohon kembali lagi nanti.';
    
    await bot.sendMessage(chatId, `
<blockquote>✅ <b><u>MAINTENANCE MODE NONAKTIF</u></b>
✅ <b>Bot sudah kembali normal. User bisa menggunakan bot kembali.</b></blockquote>`, { parse_mode: 'HTML' });
    
  } else if (command === 'status') {
    let statusText = maintenanceMode.enabled ? '✅ AKTIF' : '❌ NONAKTIF';
    let reasonText = maintenanceMode.enabled ? `\n📝 <b>Alasan:</b> ${maintenanceMode.reason}` : '';
    
    await bot.sendMessage(chatId, `
<blockquote>🔧 <b><u>MAINTENANCE MODE</u></b>
📊 <b>Status:</b> ${statusText}${reasonText}</blockquote>`, { parse_mode: 'HTML' });
  } else {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>COMMAND SALAH</u></b>
📝 <b>Gunakan:</b> <code>/maintenance on/off/status</code></blockquote>`, { parse_mode: 'HTML' });
  }
});

async function checkMaintenance(userId, chatId) {
  const role = await getUserRole(userId);
  const isOwner = (isOwnerId(userId) || role === 'OWNER');
  
  if (maintenanceMode.enabled && !isOwner) {
    await bot.sendMessage(chatId, `
<blockquote>🔧 <b><u>MAINTENANCE MODE</u></b>
${maintenanceMode.reason}</blockquote>
<i>Mohon tunggu hingga maintenance selesai.</i>`, { parse_mode: 'HTML' });
    return false;
  }
  return true;
}

safeOnText(/\/addprem(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const role = await getUserRole(userId);
  
  if (!isOwnerId(userId) && role !== 'OWNER') {
    await bot.sendMessage(chatId, `<blockquote>❌ <b><u>No Permission</u></b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const botInfo = await getCachedBotInfo();
  const botUsername = botInfo.username;
  
  if (!match[1]) {
    await bot.sendMessage(chatId, `
<blockquote><b><u>📝 FORMAT ADD PREMIUM</u></b></blockquote>
<blockquote><code>/addprem basic userid1,userid2,@username1,@username2 30d</code>
<code>/addprem pro userid1,userid2,@username1,@username2 12h</code></blockquote>
<blockquote><b>SATUAN WAKTU:</b>
 • <code>30m</code> = 30 menit
 • <code>12h</code> = 12 jam
 • <code>7d</code> = 7 hari
 • <code>2mo</code> = 2 bulan</blockquote>
<blockquote><b>CONTOH:</b>
<code>/addprem basic 123456789,@Reals_Unmeyz 30d</code>
<code>/addprem pro 987654321,@johndoe 2mo</code></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const args = match[1].trim().split(/\s+/);
  if (args.length < 3) {
    await bot.sendMessage(chatId, `<blockquote>❌ <b>Format salah! Minimal 3 parameter.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  let type = args[0].toLowerCase();
  let targetInput = args[1];
  let durationInput = args[2];
  
  if (type !== 'basic' && type !== 'pro') {
    await bot.sendMessage(chatId, `<blockquote>❌ <b>Type harus 'basic' atau 'pro'</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const isOwner = (isOwnerId(userId));
  let durationSeconds = parseDurationToSeconds(durationInput);
  
  if (!durationSeconds) {
    await bot.sendMessage(chatId, `<blockquote>❌ <b>Format durasi salah! Gunakan: 30m, 12h, 7d, 2mo</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  let durationDays = Math.floor(durationSeconds / 86400);
  let maxDays = 150;
  
  if (!isOwner && durationDays > maxDays) {
    await bot.sendMessage(chatId, `<blockquote>❌ <b>Reseller maksimal ${maxDays} hari (5 bulan).</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const expired = Math.floor(Date.now() / 1000) + durationSeconds;
  const durationText = formatDurationText(durationSeconds);
  
  const targetIds = targetInput.split(',').map(t => t.trim()).filter(t => t.length > 0);
  let successList = [];
  let failList = [];
  const adminName = escapeHtml(msg.from.first_name ? `${msg.from.first_name} ${msg.from.last_name || ''}`.trim() : msg.from.username || 'Owner');
  const statusMsg = await bot.sendMessage(chatId, `<blockquote>⏳ <b>Memproses ${targetIds.length} user...</b></blockquote>`, { parse_mode: 'HTML' });
  
  for (const target of targetIds) {
    let targetId = target;
    let targetName = '';
    
    if (target.startsWith('@')) {
      let username = target.replace('@', '');
      try {
        let found = false;
        const userData = await db.get('SELECT user_id, full_name FROM users WHERE username LIKE ?', `%${username}%`);
        if (userData) {
          targetId = userData.user_id;
          targetName = userData.full_name || username;
          found = true;
        }
        if (!found) {
          const chat = await bot.getChat(username).catch(() => null);
          if (chat) {
            targetId = chat.id.toString();
            targetName = chat.first_name || username;
            found = true;
          }
        }
        if (!found) {
          failList.push({ id: target, name: target, reason: 'username tidak ditemukan' });
          continue;
        }
      } catch (error) {
        failList.push({ id: target, name: target, reason: error.message });
        continue;
      }
    } else if (/^\d+$/.test(targetId)) {
      const userData = await db.get('SELECT full_name FROM users WHERE user_id = ?', targetId);
      targetName = userData?.full_name || targetId;
      try {
        const chat = await bot.getChat(targetId).catch(() => null);
        if (chat && chat.first_name) {
          targetName = chat.first_name;
        }
      } catch(e) {}
    } else {
      failList.push({ id: target, name: target, reason: 'format ID salah' });
      continue;
    }
    
    const isWm = (type === 'basic');
    try {
      if (isWm) {
        const exists = await db.get('SELECT * FROM premium_wm WHERE user_id = ?', targetId);
        if (exists) {
          await db.run('UPDATE premium_wm SET expired = ?, added_by = ? WHERE user_id = ?', expired, userId, targetId);
        } else {
          await db.run('INSERT INTO premium_wm (user_id, expired, added_by, created_at) VALUES (?, ?, ?, ?)', targetId, expired, userId, Math.floor(Date.now() / 1000));
        }
        const userExists = await db.get('SELECT * FROM users WHERE user_id = ?', targetId);
        if (!userExists) {
          await db.run('INSERT OR IGNORE INTO users (user_id, full_name, role, created_at, expired) VALUES (?, ?, ?, ?, ?)', targetId, targetName, 'PREMIUM_WM', Math.floor(Date.now() / 1000), expired);
        } else {
          await db.run('UPDATE users SET role = ?, full_name = ?, expired = ? WHERE user_id = ?', 'PREMIUM_WM', targetName, expired, targetId);
        }
        
        const paketEmoji = '🧩';
        const paketName = 'Basic';
        
        const notification = `
<blockquote>✅ <b><u>AKSES PREMIUM DITAMBAHKAN</u></b></blockquote>
<blockquote><b>NAME</b> : ${escapeHtml(targetName)}
<b>ID</b> : <code>${targetId}</code>
<b>PAKET</b> : ${paketEmoji} ${paketName}
<b>DURASI</b> : ${durationText}
<b>EXPIRED</b> : ${new Date(expired * 1000).toLocaleString()}
<b>DITAMBAH OLEH</b> : ${escapeHtml(adminName)}</blockquote>
<blockquote><b>SILAHKAN BUKA @${botUsername} UNTUK MEMBUAT USERBOT</b></blockquote>`;
        
        await bot.sendMessage(targetId, notification, { parse_mode: 'HTML' }).catch(() => {});
        await sendAddSuccessToAdmin(userId, targetId, 'wm', durationSeconds, adminName);
        successList.push({ id: targetId, name: targetName, duration: durationText, paket: 'Basic' });
        
      } else {
        const exists = await db.get('SELECT * FROM premium_no_wm WHERE user_id = ?', targetId);
        if (exists) {
          await db.run('UPDATE premium_no_wm SET expired = ?, added_by = ? WHERE user_id = ?', expired, userId, targetId);
        } else {
          await db.run('INSERT INTO premium_no_wm (user_id, expired, added_by, created_at) VALUES (?, ?, ?, ?)', targetId, expired, userId, Math.floor(Date.now() / 1000));
        }
        const userExists = await db.get('SELECT * FROM users WHERE user_id = ?', targetId);
        if (!userExists) {
          await db.run('INSERT OR IGNORE INTO users (user_id, full_name, role, created_at, expired) VALUES (?, ?, ?, ?, ?)', targetId, targetName, 'PREMIUM_NO_WM', Math.floor(Date.now() / 1000), expired);
        } else {
          await db.run('UPDATE users SET role = ?, full_name = ?, expired = ? WHERE user_id = ?', 'PREMIUM_NO_WM', targetName, expired, targetId);
        }
        
        const paketEmoji = '💎';
        const paketName = 'Pro';
        
        const notification = `
<blockquote>✅ <b><u>AKSES PREMIUM DITAMBAHKAN</u></b></blockquote>
<blockquote><b>NAME</b> : ${escapeHtml(targetName)}
<b>ID</b> : <code>${targetId}</code>
<b>PAKET</b> : ${paketEmoji} ${paketName}
<b>DURASI</b> : ${durationText}
<b>EXPIRED</b> : ${new Date(expired * 1000).toLocaleString()}
<b>DITAMBAH OLEH</b> : ${escapeHtml(adminName)}</blockquote>
<blockquote><b>SILAHKAN BUKA @${botUsername} UNTUK MEMBUAT USERBOT</b></blockquote>`;
        
        await bot.sendMessage(targetId, notification, { parse_mode: 'HTML' }).catch(() => {});
        await sendAddSuccessToAdmin(userId, targetId, 'nowm', durationSeconds, adminName);
        successList.push({ id: targetId, name: targetName, duration: durationText, paket: 'Pro' });
      }
      
      await db.run('INSERT INTO activity_logs (user_id, action, details, timestamp) VALUES (?, ?, ?, ?)', 
        userId, `ADD_${isWm ? 'BASIC' : 'PRO'}`, `Tambah ${targetId} selama ${durationText}`, Math.floor(Date.now() / 1000));
        
    } catch (error) {
      failList.push({ id: targetId, name: targetName, reason: error.message });
    }
  }
  
  await safeDeleteMessage(chatId, statusMsg.message_id);
  
  let resultMsg = `<blockquote>✅ <b><u>HASIL TAMBAH PREMIUM</u></b></blockquote>\n\n`;
  resultMsg += `<blockquote><b>✅ BERHASIL (${successList.length}):</b></blockquote>\n`;
  for (const s of successList) {
    resultMsg += `<blockquote> • ${escapeHtml(s.name)} (${s.id}) - ${s.paket} / ${s.duration}</blockquote>\n`;
  }
  resultMsg += `\n<blockquote><b>❌ GAGAL (${failList.length}):</b></blockquote>\n`;
  for (const f of failList) {
    resultMsg += `<blockquote> • ${f.name} (${f.id}) - ${f.reason}</blockquote>\n`;
  }
  
  await bot.sendMessage(chatId, resultMsg, { parse_mode: 'HTML' });
});

safeOnText(/\/delprem(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const role = await getUserRole(userId);
  if (!isOwnerId(userId) && role !== 'OWNER') {
    await bot.sendMessage(chatId, `<blockquote>❌ <b><u>No Permission</u></b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  if (!match[1]) {
    await bot.sendMessage(chatId, `
<blockquote><b>📝 FORMAT DEL PREMIUM</b></blockquote>
<blockquote><code>/delprem userid1,userid2,@username1,@username2</code></blockquote>
<blockquote><b>CONTOH:</b>
<code>/delprem 123456789,@Reals_Unmeyz</code></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  let targetInput = match[1].trim();
  const targetIds = targetInput.split(',').map(t => t.trim()).filter(t => t.length > 0);
  let successList = [];
  let failList = [];
  const statusMsg = await bot.sendMessage(chatId, `<blockquote>⏳ <b>Memproses ${targetIds.length} user...</b></blockquote>`, { parse_mode: 'HTML' });
  for (const target of targetIds) {
    let targetId = target;
    if (target.startsWith('@')) {
      let username = target.replace('@', '');
      try {
        let found = false;
        const userData = await db.get('SELECT user_id FROM users WHERE LOWER(username) = LOWER(?)', username);
        if (userData) {
          targetId = userData.user_id;
          found = true;
        }
        if (!found) {
          const chat = await bot.getChat(username).catch(() => null);
          if (chat) {
            targetId = chat.id.toString();
            found = true;
          }
        }
        if (!found) {
          failList.push(`${target} (username tidak ditemukan)`);
          continue;
        }
      } catch (error) {
        failList.push(`${target} (error: ${error.message})`);
        continue;
      }
    }
    if (!/^\d+$/.test(targetId)) {
      failList.push(`${target} (format ID salah)`);
      continue;
    }
    const isWm = await db.get('SELECT * FROM premium_wm WHERE user_id = ?', targetId);
    const isNowm = await db.get('SELECT * FROM premium_no_wm WHERE user_id = ?', targetId);
    if (!isWm && !isNowm) {
      failList.push(`${targetId} (tidak punya akses premium)`);
      continue;
    }
    let deletedTypes = [];
    try {
      if (isWm) {
        await db.run('DELETE FROM premium_wm WHERE user_id = ?', targetId);
        deletedTypes.push('Basic');
      }
      if (isNowm) {
        await db.run('DELETE FROM premium_no_wm WHERE user_id = ?', targetId);
        deletedTypes.push('Pro');
      }
      await db.run('DELETE FROM reseller_added WHERE user_id = ?', targetId);
      const hasOtherPremium = await db.get('SELECT * FROM premium_wm WHERE user_id = ? UNION SELECT * FROM premium_no_wm WHERE user_id = ?', targetId, targetId);
      const isReseller = await db.get('SELECT * FROM reseller_list WHERE user_id = ?', targetId);
      if (!hasOtherPremium && !isReseller) {
        await db.run('UPDATE users SET role = "FREE" WHERE user_id = ?', targetId);
      }
      await cleanupUserData(targetId, 'removed_premium');
      successList.push(`${targetId} (${deletedTypes.join(' & ')})`);
      try {
        await bot.sendMessage(targetId, `<blockquote>⚠️ <b>Akses premium (${deletedTypes.join(' & ')}) telah dihapus.</b></blockquote>`, { parse_mode: 'HTML' });
      } catch (e) {}
      await db.run('INSERT INTO activity_logs (user_id, action, details, timestamp) VALUES (?, ?, ?, ?)', userId, 'REMOVE_PREMIUM', `Hapus ${targetId}`, Math.floor(Date.now() / 1000));
    } catch (error) {
      failList.push(`${targetId} (error: ${error.message})`);
    }
  }
  await safeDeleteMessage(chatId, statusMsg.message_id);
  let resultMsg = `<blockquote>✅ <b>HASIL HAPUS PREMIUM</b></blockquote>\n\n<blockquote><b>✅ BERHASIL (${successList.length}):</b></blockquote>\n`;
  for (const s of successList) resultMsg += `<blockquote> • ${s}</blockquote>\n`;
  resultMsg += `\n<blockquote><b>❌ GAGAL (${failList.length}):</b></blockquote>\n`;
  for (const f of failList) resultMsg += `<blockquote> • ${f}</blockquote>\n`;
  await bot.sendMessage(chatId, resultMsg, { parse_mode: 'HTML' });
});

safeOnText(/\/addreseller(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const role = await getUserRole(userId);
  
  if (!isOwnerId(userId) && role !== 'OWNER') {
    await bot.sendMessage(chatId, `<blockquote>❌ <b><u>No Permission</u></b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const botInfo = await getCachedBotInfo();
  const botUsername = botInfo.username;
  
  if (!match[1]) {
    await bot.sendMessage(chatId, `
<blockquote><b><u>📝 FORMAT ADD RESELLER</u></b></blockquote>
<blockquote><code>/addreseller userid1,userid2,@username1,@username2 30d</code>
<code>/addreseller userid1,userid2,@username1,@username2 12h</code>
<code>/addreseller userid1,userid2,@username1,@username2 60m</code></blockquote>
<blockquote><b>SATUAN WAKTU:</b>
 • <code>30m</code> = 30 menit
 • <code>12h</code> = 12 jam
 • <code>7d</code> = 7 hari
 • <code>2mo</code> = 2 bulan
 • <code>1y</code> = 1 tahun</blockquote>
<blockquote><b>CONTOH:</b>
<code>/addreseller 123456789,@Reals_Unmeyz 30d</code></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const args = match[1].trim().split(/\s+/);
  if (args.length < 2) {
    await bot.sendMessage(chatId, `<blockquote>❌ <b>Format salah! Minimal 2 parameter.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const targetInput = args[0];
  const durationInput = args[1];
  
  const isOwner = (isOwnerId(userId));
  let durationSeconds = parseDurationToSeconds(durationInput);
  
  if (!durationSeconds) {
    await bot.sendMessage(chatId, `<blockquote>❌ <b>Format durasi salah! Gunakan: 30m, 12h, 7d, 2mo, 1y</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  let durationDays = Math.floor(durationSeconds / 86400);
  let maxDays = 365; // Owner bisa kasih 1 tahun
  
  if (!isOwner && durationDays > maxDays) {
    await bot.sendMessage(chatId, `<blockquote>❌ <b>Reseller maksimal ${maxDays} hari (1 tahun).</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const expired = Math.floor(Date.now() / 1000) + durationSeconds;
  const durationText = formatDurationText(durationSeconds);
  
  const targetIds = targetInput.split(',').map(t => t.trim()).filter(t => t.length > 0);
  let successList = [];
  let failList = [];
  const adminName = escapeHtml(msg.from.first_name ? `${msg.from.first_name} ${msg.from.last_name || ''}`.trim() : msg.from.username || 'Owner');
  const statusMsg = await bot.sendMessage(chatId, `<blockquote>⏳ <b>Memproses ${targetIds.length} user...</b></blockquote>`, { parse_mode: 'HTML' });
  
  for (const target of targetIds) {
    let targetId = target;
    let targetName = '';
    
    if (target.startsWith('@')) {
      let username = target.replace('@', '');
      try {
        let found = false;
        const userData = await db.get('SELECT user_id, full_name FROM users WHERE username LIKE ?', `%${username}%`);
        if (userData) {
          targetId = userData.user_id;
          targetName = userData.full_name || username;
          found = true;
        }
        if (!found) {
          const chat = await bot.getChat(username).catch(() => null);
          if (chat) {
            targetId = chat.id.toString();
            targetName = chat.first_name || username;
            found = true;
          }
        }
        if (!found) {
          failList.push({ id: target, name: target, reason: 'username tidak ditemukan' });
          continue;
        }
      } catch (error) {
        failList.push({ id: target, name: target, reason: error.message });
        continue;
      }
    } else if (/^\d+$/.test(targetId)) {
      const userData = await db.get('SELECT full_name FROM users WHERE user_id = ?', targetId);
      targetName = userData?.full_name || targetId;
      try {
        const chat = await bot.getChat(targetId).catch(() => null);
        if (chat && chat.first_name) {
          targetName = chat.first_name;
        }
      } catch(e) {}
    } else {
      failList.push({ id: target, name: target, reason: 'format ID salah' });
      continue;
    }
    
    // HAPUS AKSES LAIN DULU
    try {
      // Hapus premium lain
      await db.run('DELETE FROM premium_wm WHERE user_id = ?', targetId);
      await db.run('DELETE FROM premium_no_wm WHERE user_id = ?', targetId);
      await db.run('DELETE FROM reseller_added WHERE user_id = ?', targetId);
      
      // Hapus dari file list_access
      removeAccess(targetId);
      
      // Tambah reseller dengan expired
      const exists = await db.get('SELECT * FROM reseller_list WHERE user_id = ?', targetId);
      if (exists) {
        await db.run('UPDATE reseller_list SET added_by = ?, added_at = ?, expired = ? WHERE user_id = ?', 
          userId, Math.floor(Date.now() / 1000), expired, targetId);
      } else {
        await db.run('INSERT INTO reseller_list (user_id, added_by, added_at, expired) VALUES (?, ?, ?, ?)', 
          targetId, userId, Math.floor(Date.now() / 1000), expired);
      }
      
      const userExists = await db.get('SELECT * FROM users WHERE user_id = ?', targetId);
      if (!userExists) {
        await db.run('INSERT OR IGNORE INTO users (user_id, full_name, role, created_at, expired) VALUES (?, ?, ?, ?, ?)', 
          targetId, targetName, 'RESELLER', Math.floor(Date.now() / 1000), expired);
      } else {
        await db.run('UPDATE users SET role = ?, full_name = ?, expired = ? WHERE user_id = ?', 
          'RESELLER', targetName, expired, targetId);
      }
      
      // Update file list_access
      addAccess(targetId, `${durationDays}d`, 'reseller');
      
      // Bersihin akses user biar ga double
      cleanupUserAccess(targetId);
      
      const paketEmoji = '🎟';
      const paketName = 'Reseller';
      
      const notification = `
<blockquote>✅ <b><u>AKSES RESELLER DITAMBAHKAN</u></b></blockquote>
<blockquote><b>NAME</b> : ${escapeHtml(targetName)}
<b>ID</b> : <code>${targetId}</code>
<b>PAKET</b> : ${paketEmoji} ${paketName}
<b>DURASI</b> : ${durationText}
<b>EXPIRED</b> : ${new Date(expired * 1000).toLocaleString()}
<b>DITAMBAH OLEH</b> : ${escapeHtml(adminName)}</blockquote>
<blockquote><b>SILAHKAN BUKA @${botUsername} UNTUK MEMBUAT USERBOT</b></blockquote>`;
      
      await bot.sendMessage(targetId, notification, { parse_mode: 'HTML' }).catch(() => {});
      await sendAddSuccessToAdmin(userId, targetId, 'reseller', durationSeconds, adminName);
      successList.push({ id: targetId, name: targetName, duration: durationText, paket: 'Reseller' });
      
      await db.run('INSERT INTO activity_logs (user_id, action, details, timestamp) VALUES (?, ?, ?, ?)', 
        userId, 'ADD_RESELLER', `Tambah reseller ${targetId} selama ${durationText}`, Math.floor(Date.now() / 1000));
        
    } catch (error) {
      failList.push({ id: targetId, name: targetName, reason: error.message });
    }
  }
  
  await safeDeleteMessage(chatId, statusMsg.message_id);
  
  let resultMsg = `<blockquote>✅ <b><u>HASIL TAMBAH RESELLER</u></b></blockquote>\n\n`;
  resultMsg += `<blockquote><b>✅ BERHASIL (${successList.length}):</b></blockquote>\n`;
  for (const s of successList) {
    resultMsg += `<blockquote> • ${escapeHtml(s.name)} (${s.id}) - ${s.paket} / ${s.duration}</blockquote>\n`;
  }
  resultMsg += `\n<blockquote><b>❌ GAGAL (${failList.length}):</b></blockquote>\n`;
  for (const f of failList) {
    resultMsg += `<blockquote> • ${f.name} (${f.id}) - ${f.reason}</blockquote>\n`;
  }
  
  await bot.sendMessage(chatId, resultMsg, { parse_mode: 'HTML' });
});

safeOnText(/\/listprem/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const role = await getUserRole(userId);
  
  if (!isOwnerId(userId) && role !== 'OWNER') {
    await bot.sendMessage(chatId, `<blockquote>❌ <b><u>No Permission</u></b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const wmUsers = await db.all('SELECT * FROM premium_wm ORDER BY expired ASC');
  const nowmUsers = await db.all('SELECT * FROM premium_no_wm ORDER BY expired ASC');
  
  if (wmUsers.length === 0 && nowmUsers.length === 0) {
    await bot.sendMessage(chatId, `<blockquote>📭 <b><u>KOSONG</u></b>\n👤 <i>Belum ada user premium.</i></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  let response = `<blockquote>📖 <b><u>DAFTAR PREMIUM USER</u></b></blockquote>\n\n`;
  
  if (wmUsers.length > 0) {
    response += `<blockquote>🧩 <b>PREMIUM BASIC (WM)</b></blockquote>\n`;
    for (let i = 0; i < wmUsers.length; i++) {
      const u = wmUsers[i];
      const sisaHari = Math.max(0, Math.floor((u.expired - Math.floor(Date.now() / 1000)) / 86400));
      const expiredDate = new Date(u.expired * 1000).toLocaleDateString('id-ID');
      response += `<blockquote>${i + 1}. <code>${u.user_id}</code>  📅 ${expiredDate} (${sisaHari} hari)</blockquote>\n`;
    }
    response += `\n`;
  }
  
  if (nowmUsers.length > 0) {
    response += `<blockquote>💎 <b>PREMIUM PRO (NO WM)</b></blockquote>\n`;
    for (let i = 0; i < nowmUsers.length; i++) {
      const u = nowmUsers[i];
      const sisaHari = Math.max(0, Math.floor((u.expired - Math.floor(Date.now() / 1000)) / 86400));
      const expiredDate = new Date(u.expired * 1000).toLocaleDateString('id-ID');
      response += `<blockquote>${i + 1}. <code>${u.user_id}</code>  📅 ${expiredDate} (${sisaHari} hari)</blockquote>\n`;
    }
    response += `\n`;
  }
  
  response += `<blockquote><i>Total: ${wmUsers.length + nowmUsers.length} user premium</i></blockquote>`;
  
  const messages = [];
  let currentMsg = '';
  const lines = response.split('\n');
  
  for (const line of lines) {
    if ((currentMsg + line + '\n').length > 4000) {
      messages.push(currentMsg);
      currentMsg = line + '\n';
    } else {
      currentMsg += line + '\n';
    }
  }
  if (currentMsg) messages.push(currentMsg);
  
  for (const msg of messages) {
    await bot.sendMessage(chatId, msg, { parse_mode: 'HTML' });
  }
});

safeOnText(/\/listreseller/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const role = await getUserRole(userId);
  
  if (!isOwnerId(userId) && role !== 'OWNER') {
    await bot.sendMessage(chatId, `<blockquote>❌ <b><u>No Permission</u></b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const resellers = await db.all('SELECT * FROM reseller_list ORDER BY added_at DESC');
  
  if (resellers.length === 0) {
    await bot.sendMessage(chatId, `<blockquote>📭 <b><u>KOSONG</u></b>\n👑 <i>Belum ada reseller.</i></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  let response = `<blockquote>📖 <b><u>DAFTAR RESELLER</u></b></blockquote>`;
  
  for (let i = 0; i < resellers.length; i++) {
    const r = resellers[i];
    const addedDate = new Date(r.added_at * 1000).toLocaleDateString('id-ID');
    const addedBy = r.added_by === userId ? 'Owner' : r.added_by;
    
    const totalAdded = await db.get('SELECT COUNT(*) as count FROM reseller_added WHERE reseller_id = ?', r.user_id);
    
    response += `
<blockquote>${i + 1}. <code>${r.user_id}</code>
   📅 Ditambah: ${addedDate}
   👥 Total user: ${totalAdded.count || 0}</blockquote>`;
  }
  
  response += `
<blockquote><i>Total: ${resellers.length} reseller</i></blockquote>`;
  
  await bot.sendMessage(chatId, response, { parse_mode: 'HTML' });
});

async function handlePaketWm(callbackQuery, userId, chatId, messageId) {
  userPayments[userId] = { type: 'wm', duration: 1, targetUserId: userId };
  await updatePaketDisplay(chatId, messageId, userId, 'wm');
}

async function handlePaketNowm(callbackQuery, userId, chatId, messageId) {
  userPayments[userId] = { type: 'nowm', duration: 1, targetUserId: userId };
  await updatePaketDisplay(chatId, messageId, userId, 'nowm');
}

async function handlePaketReseller(callbackQuery, userId, chatId, messageId) {
  userPayments[userId] = { type: 'reseller', duration: 1, targetUserId: userId };
  await updatePaketDisplay(chatId, messageId, userId, 'reseller');
}

async function handlePaketWmSelf(callbackQuery, userId, chatId, messageId) {
  userPayments[userId] = { type: 'wm', duration: 1, targetUserId: userId };
  await updatePaketDisplay(chatId, messageId, userId, 'wm');
}

async function handlePaketNowmSelf(callbackQuery, userId, chatId, messageId) {
  userPayments[userId] = { type: 'nowm', duration: 1, targetUserId: userId };
  await updatePaketDisplay(chatId, messageId, userId, 'nowm');
}

async function handlePaketResellerSelf(callbackQuery, userId, chatId, messageId) {
  userPayments[userId] = { type: 'reseller', duration: 1, targetUserId: userId };
  await updatePaketDisplay(chatId, messageId, userId, 'reseller');
}

async function handleBackToOwnerMenu(callbackQuery, userId, chatId, messageId) {
  await safeDeleteMessage(chatId, messageId);
  const keyboard = await getOwnerMenuKeyboard();
  const caption = `
⚙️ <b><u>Pilih menu di bawah:</u></b>`;
  await bot.sendMessage(chatId, caption, {
    parse_mode: 'HTML',
    reply_markup: keyboard
  });
}

async function handlePaketWmGift(callbackQuery, userId, chatId, messageId) {
  if (!waitingForGiveUserId[userId]) {
    await safeAnswerCallbackQuery(callbackQuery, `❌ ID user tujuan tidak ditemukan`, true);
    return;
  }
  
  const targetUserId = waitingForGiveUserId[userId];
  const now = Math.floor(Date.now() / 1000);
  
  // Cek apakah user tujuan punya akses lebih tinggi (Pro atau Reseller)
  const hasPro = await db.get('SELECT * FROM premium_no_wm WHERE user_id = ? AND expired > ?', targetUserId, now);
  const hasReseller = await db.get('SELECT * FROM reseller_list WHERE user_id = ?', targetUserId);
  
  if (hasPro) {
    await safeAnswerCallbackQuery(callbackQuery, `❌ User ${targetUserId} sudah punya Plan Pro, tidak bisa digift Basic`, true);
    return;
  }
  if (hasReseller) {
    await safeAnswerCallbackQuery(callbackQuery, `❌ User ${targetUserId} sudah jadi Reseller, tidak bisa digift Basic`, true);
    return;
  }
  
  userPayments[userId] = { type: 'wm', duration: 1, targetUserId: targetUserId };
  await updatePaketDisplay(chatId, messageId, userId, 'wm');
}

async function handlePaketNowmGift(callbackQuery, userId, chatId, messageId) {
  if (!waitingForGiveUserId[userId]) {
    await safeAnswerCallbackQuery(callbackQuery, `❌ ID user tujuan tidak ditemukan`, true);
    return;
  }
  
  const targetUserId = waitingForGiveUserId[userId];
  const now = Math.floor(Date.now() / 1000);
  
  // Cek apakah user tujuan punya akses lebih tinggi (Reseller)
  const hasReseller = await db.get('SELECT * FROM reseller_list WHERE user_id = ?', targetUserId);
  
  if (hasReseller) {
    await safeAnswerCallbackQuery(callbackQuery, `❌ User ${targetUserId} sudah jadi Reseller, tidak bisa digift Pro`, true);
    return;
  }
  
  userPayments[userId] = { type: 'nowm', duration: 1, targetUserId: targetUserId };
  await updatePaketDisplay(chatId, messageId, userId, 'nowm');
}

async function handlePaketResellerGift(callbackQuery, userId, chatId, messageId) {
  if (!waitingForGiveUserId[userId]) {
    await safeAnswerCallbackQuery(callbackQuery, `❌ ID user tujuan tidak ditemukan`, true);
    return;
  }
  userPayments[userId] = { type: 'reseller', duration: 1, targetUserId: waitingForGiveUserId[userId] };
  await updatePaketDisplay(chatId, messageId, userId, 'reseller');
}

async function handleCancelDeleteAll(callbackQuery, userId, chatId, messageId) {
  await safeAnswerCallbackQuery(callbackQuery, `❌ Penghapusan dibatalkan`);
  await safeDeleteMessage(chatId, messageId);
  await bot.sendMessage(chatId, `
❌ <b><u>Dibatalkan</u></b>`);
}

async function handleGroupNext(callbackQuery, userId, chatId, messageId) {
  if (global.groupListPage[userId]) {
    global.groupListPage[userId].page++;
    await sendGroupListPage(chatId, messageId, userId);
  }
}

async function handleGroupPrev(callbackQuery, userId, chatId, messageId) {
  if (global.groupListPage[userId]) {
    global.groupListPage[userId].page--;
    await sendGroupListPage(chatId, messageId, userId);
  }
}

async function handleWmIncr(callbackQuery, userId, chatId, messageId) {
  if (!userPayments[userId]) userPayments[userId] = { type: 'wm', duration: 1, targetUserId: userId };
  if (userPayments[userId].duration < 5) {
    userPayments[userId].duration++;
    await updatePaketDisplay(chatId, messageId, userId, 'wm');
  }
}

async function handleWmDecr(callbackQuery, userId, chatId, messageId) {
  if (!userPayments[userId]) userPayments[userId] = { type: 'wm', duration: 1, targetUserId: userId };
  if (userPayments[userId].duration > 1) {
    userPayments[userId].duration--;
    await updatePaketDisplay(chatId, messageId, userId, 'wm');
  }
}

async function handleNowmIncr(callbackQuery, userId, chatId, messageId) {
  if (!userPayments[userId]) userPayments[userId] = { type: 'nowm', duration: 1, targetUserId: userId };
  if (userPayments[userId].duration < 5) {
    userPayments[userId].duration++;
    await updatePaketDisplay(chatId, messageId, userId, 'nowm');
  }
}

async function handleNowmDecr(callbackQuery, userId, chatId, messageId) {
  if (!userPayments[userId]) userPayments[userId] = { type: 'nowm', duration: 1, targetUserId: userId };
  if (userPayments[userId].duration > 1) {
    userPayments[userId].duration--;
    await updatePaketDisplay(chatId, messageId, userId, 'nowm');
  }
}

async function handleManualBackup(callbackQuery, userId, chatId) {
  await safeAnswerCallbackQuery(callbackQuery);
  await manualBackupCommand(userId, chatId);
}

async function handleResellerIncr(callbackQuery, userId, chatId, messageId) {
  if (!userPayments[userId]) userPayments[userId] = { type: 'reseller', duration: 1, targetUserId: userId };
  if (userPayments[userId].duration < 5) {
    userPayments[userId].duration++;
    await updatePaketDisplay(chatId, messageId, userId, 'reseller');
  }
}

async function handleResellerDecr(callbackQuery, userId, chatId, messageId) {
  if (!userPayments[userId]) userPayments[userId] = { type: 'reseller', duration: 1, targetUserId: userId };
  if (userPayments[userId].duration > 1) {
    userPayments[userId].duration--;
    await updatePaketDisplay(chatId, messageId, userId, 'reseller');
  }
}

async function handleBackToToko(callbackQuery, userId, chatId, messageId) {
  await safeDeleteMessage(chatId, messageId).catch(() => {});
  
  const caption = `
<blockquote>🛒 <b><u>USERBOT STORE</u></b></blockquote>
<i>Pilih tombol di bawah</i>`;

  await bot.sendMessage(chatId, caption, {
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [
          { text: '🛒 Beli Userbot', callback_data: 'beli_userbot' }
        ],
        [
          { text: '🛍️ Beli Produk', callback_data: 'beli_produk' }
        ],
        [
          { text: '🎁 Berikan Userbot', callback_data: 'give_userbot' }
        ],
        [
          { text: '⬅️ Kembali', callback_data: 'back_main' }
        ]
      ]
    }
  });
}

async function handleUseToken(callbackQuery, userId, chatId, messageId) {
  const hasUbot = await userHasUserbot(userId);
  
  if (hasUbot) {
    await safeAnswerCallbackQuery(callbackQuery, `<i>❌ Kamu udah punya userbot, ga perlu pake token</i>`, true);
    return;
  }
  
  await safeEditMessageText(`
<blockquote>🔑 <b><u>TOKEN GARANSI</u></b></blockquote>
<blockquote>📨 Silahkan kirimkan token yang kamu miliki, untuk dicek terlebih dahulu!!</blockquote>
<blockquote>⚠️ Token hanya bisa dipakai 1 kali!</blockquote>`, {
    chat_id: chatId,
    message_id: messageId,
    parse_mode: 'HTML'
  });
  
  global.waitingForToken = global.waitingForToken || {};
  global.waitingForToken[userId] = true;
}

async function handleRevokeToken(callbackQuery, userId, chatId, messageId) {
  console.log('revoke_token clicked by user:', userId);
  
  try {
    const hasUbot = await userHasUserbot(userId);
    console.log('hasUbot:', hasUbot);
    
    if (!hasUbot) {
      await safeEditMessageText(`
<blockquote>❌ <b><u>ERROR</u></b>
🔑 <b>Maaf, lu bukan user userbot ini dan lu gak punya token.</b></blockquote>`, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '⬅️ Kembali', callback_data: 'back_to_token_menu' }
            ]
          ]
        }
      });
      return;
    }
    
    const ubotData = await db.get('SELECT * FROM userbots WHERE owner_id = ?', userId);
    console.log('ubotData:', ubotData);
    
    if (!ubotData) {
      await safeEditMessageText(`
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Data userbot ga ketemu.</b></blockquote>`, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '⬅️ Kembali', callback_data: 'back_to_token_menu' }
            ]
          ]
        }
      });
      return;
    }
    
    await db.run('DELETE FROM tokens WHERE owner_id = ?', userId);
    
    const newToken = generateSecureToken();
    
    await db.run(
      'INSERT INTO tokens (token, owner_id, ubot_id, role, created_at, expired_at) VALUES (?, ?, ?, ?, ?, ?)',
      newToken, userId, ubotData.ubot_id, await getUserRole(userId), Math.floor(Date.now() / 1000), ubotData.expired
    );
    
    await safeEditMessageText(`
<blockquote>🔑 <b><u>TOKEN DIGANTI</u></b></blockquote>
<blockquote><b>Token barumu</b> :
 <code>${newToken}</code></blockquote>

<i>Simpan baik-baik ya!</i>`, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [
            { text: '⬅️ Kembali', callback_data: 'back_to_token_menu' }
          ]
        ]
      }
    });
    
  } catch (error) {
    console.error('Error in revoke_token:', error);
    await safeEditMessageText(`
<blockquote>❌ <b><u>ERROR</u></b>
⚠️ <b>Ada masalah: ${error.message}</b></blockquote>`, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [
            { text: '⬅️ Kembali', callback_data: 'back_to_token_menu' }
          ]
        ]
      }
    });
  }
}

async function handleSelectUbot(callbackQuery, userId, chatId, messageId, data) {
  const index = parseInt(data.replace('select_ubot_', ''));
  const ubotsData = global.listUbotData?.[userId]?.ubots;
  
  if (!ubotsData || index >= ubotsData.length) {
    await safeAnswerCallbackQuery(callbackQuery, '<i>❌ Data userbot tidak ditemukan</i>', true);
    return;
  }
  
  const ubot = ubotsData[index];
  const user = await db.get('SELECT * FROM users WHERE user_id = ?', ubot.owner_id);
  
  const totalGroup = await db.get('SELECT COUNT(*) as count FROM groups WHERE owner_id = ?', ubot.owner_id);
  const totalPesan = await db.get('SELECT COUNT(*) as count FROM messages WHERE owner_id = ?', ubot.owner_id);
  const role = await getUserRole(ubot.owner_id);
  
  const userbotClient = userbots.find(ub => ub.owner_id === ubot.owner_id);
  let statusPromosi = 'NONAKTIF';
  
  if (userbotClient && userbotClient.client) {
    try {
      const me = await userbotClient.client.getMe();
      if (me) {
        const promoSetting = await db.get('SELECT promosi_status FROM settings WHERE owner_id = ?', ubot.owner_id);
        if (promoSetting && promoSetting.promosi_status === 'ON') {
          statusPromosi = promosiProgress[ubot.owner_id]?.running ? `✅ AKTIF` : `⏸️ PAUSE`;
        }
      }
    } catch (err) {
      statusPromosi = `⚠️ OFFLINE`;
    }
  } else {
    statusPromosi = `❌ OFFLINE`;
  }
  
  const response = `
<blockquote>⚙️ <b><u>KONTROL USERBOT: ${ubot.ubot_id}</u></b></blockquote>
<blockquote>👤 <b>Pemilik</b> : <a href="tg://user?id=${ubot.owner_id}">${user?.full_name || 'Unknown'}</a>
👥 <b>Username</b> : ${user?.username || '-'}
🆔 <b>ID</b> : <code>${ubot.owner_id}</code>
🛒 <b>Paket</b> : ${role}
🗓 <b>Habis</b> : ${new Date(ubot.expired * 1000).toLocaleDateString()}
📊 <b>Grup</b> : ${totalGroup.count} grup
📖 <b>Pesan</b> : ${totalPesan.count} pesan
📤 <b>Terkirim</b> : ${promosiProgress[ubot.owner_id]?.success || 0}
📣 <b>Status Promosi</b> : ${statusPromosi}</blockquote>
<i>Pilih tombol kontrol di bawah</i>`;

  await safeEditMessageText(response, {
    chat_id: chatId,
    message_id: messageId,
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [
          { text: '▶️ Aktifkan', callback_data: `ubot_promo_on_${ubot.owner_id}` },
          { text: '⏸️ Pause', callback_data: `ubot_promo_pause_${ubot.owner_id}` },
          { text: '⏹️ Hentikan', callback_data: `ubot_promo_stop_${ubot.owner_id}` }
        ],
        [
          { text: '🔄 Restart', callback_data: `ubot_restart_${ubot.owner_id}` },
          { text: '🔄 Refresh', callback_data: `ubot_refresh_${ubot.owner_id}` }
        ],
        [
          { text: '📊 Detail', callback_data: `ubot_detail_${ubot.owner_id}` },
          { text: '🗑️ Hapus', callback_data: `ubot_delete_${ubot.owner_id}` }
        ],
        [
          { text: '⬅️ Kembali', callback_data: 'back_to_ubot_list' }
        ]
      ]
    }
  });
  
  global.selectedUbot = global.selectedUbot || {};
  global.selectedUbot[userId] = ubot;
  
  await safeAnswerCallbackQuery(callbackQuery);
}

async function handleBackToUbotList(callbackQuery, userId, chatId, messageId) {
  await safeDeleteMessage(chatId, messageId);
  
  const ubots = await db.all('SELECT * FROM userbots ORDER BY created_at DESC');
  
  if (ubots.length === 0) {
    await bot.sendMessage(chatId, `
<blockquote>📭 <b><u>KOSONG</u></b>
🤖 <i>Belum ada userbot terdaftar.</i></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const itemsPerPage = 5;
  const totalPages = Math.ceil(ubots.length / itemsPerPage);
  let currentPage = global.ubotListPage?.[userId] || 1;
  
  if (currentPage > totalPages) currentPage = totalPages;
  if (currentPage < 1) currentPage = 1;
  
  const start = (currentPage - 1) * itemsPerPage;
  const end = start + itemsPerPage;
  const pageUbots = ubots.slice(start, end);
  
  let response = `
<blockquote>🤖 <b><u>DAFTAR USERBOT</u></b></blockquote>`;
  
  for (let i = 0; i < pageUbots.length; i++) {
    const ubot = pageUbots[i];
    const user = await db.get('SELECT * FROM users WHERE user_id = ?', ubot.owner_id);
    const statusEmoji = ubot.status === 'AKTIF' ? `✅` : `❌`;
    const nomor = start + i + 1;
    
    response += `

<blockquote><b>${nomor}.</b> ${statusEmoji} <code>${ubot.ubot_id}</code>
 👤 ${user?.full_name || 'Unknown'} ${user?.username ? `| @${user.username.replace('@', '')}` : ''}
 🆔 <code>${ubot.owner_id}</code></blockquote>`;
  }
  
  response += `

<blockquote><i>Halaman ${currentPage} / ${totalPages}</i></blockquote>`;
  
  const buttons = [];
  const navButtons = [];
  
  if (currentPage > 1) {
    navButtons.push({ text: '◀️', callback_data: 'ubot_prev_page' });
  }
  if (currentPage < totalPages) {
    navButtons.push({ text: '▶️', callback_data: 'ubot_next_page' });
  }
  
  if (navButtons.length > 0) {
    buttons.push(navButtons);
  }
  
  const row = [];
  for (let i = 0; i < pageUbots.length; i++) {
    const idx = start + i;
    row.push({ text: `${idx + 1}`, callback_data: `select_ubot_${idx}` });
    if (row.length === 4 || i === pageUbots.length - 1) {
      buttons.push([...row]);
      row.length = 0;
    }
  }
  
  buttons.push([{ text: '⬅️ Kembali', callback_data: 'back_to_owner_menu' }]);
  
  await bot.sendMessage(chatId, response, {
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard: buttons }
  });
  
  global.listUbotData = global.listUbotData || {};
  global.listUbotData[userId] = { ubots: ubots, page: currentPage, totalPages: totalPages };
  global.ubotListPage = global.ubotListPage || {};
  global.ubotListPage[userId] = currentPage;
}

async function handleUbotPromoOn(callbackQuery, userId, chatId, messageId, data) {
  const targetUserId = data.replace('ubot_promo_on_', '');
  
  await safeAnswerCallbackQuery(callbackQuery, `<i>⏳ Mengaktifkan promosi...</i>`);
  
  const userbotClient = userbots.find(ub => ub.owner_id === targetUserId);
  
  if (!userbotClient || !userbotClient.client) {
    await safeEditMessageText(`
<blockquote>❌ <b><u>GAGAL</u></b>
🤖 <b>Userbot offline! Tidak bisa mengaktifkan.</b></blockquote>`, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: 'HTML'
    });
    return;
  }
  
  const groups = await db.all('SELECT * FROM groups WHERE owner_id = ?', targetUserId);
  const messages = await db.all('SELECT * FROM messages WHERE owner_id = ?', targetUserId);
  
  if (groups.length === 0 || messages.length === 0) {
    await safeEditMessageText(`
<blockquote>❌ <b><u>GAGAL</u></b>
📝 <b>Tidak ada grup atau pesan! Setup dulu.</b></blockquote>`, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: 'HTML'
    });
    return;
  }
  
  if (global.promoTimeouts && global.promoTimeouts[targetUserId]) {
    clearTimeout(global.promoTimeouts[targetUserId]);
    delete global.promoTimeouts[targetUserId];
  }
  
  await db.run('UPDATE settings SET promosi_status = "ON" WHERE owner_id = ?', targetUserId);
  
  const blacklistGroups = await db.all('SELECT group_id FROM blacklist_groups WHERE owner_id = ?', targetUserId);
  const blacklistIds = blacklistGroups.map(b => b.group_id.toString());
  const validGroups = groups.filter(g => {
    return parseInt(g.group_id) < 0 && !blacklistIds.includes(g.group_id.toString());
  });
  
  const settingsData = await db.get('SELECT selected_message_id FROM settings WHERE owner_id = ?', targetUserId);
  let selectedMessage = messages.find(m => m.id === settingsData?.selected_message_id);
  if (!selectedMessage) selectedMessage = messages[0];
  
  const role = await getUserRole(targetUserId);
  let watermarkToUse = '';
  
  if (role === 'PREMIUM_NO_WM' || role === 'RESELLER' || role === 'OWNER') {
    const freshSettings = await db.get('SELECT watermark, watermark_status FROM settings WHERE owner_id = ?', targetUserId);
    if (freshSettings && freshSettings.watermark && freshSettings.watermark_status === 'ON') {
      watermarkToUse = freshSettings.watermark;
    }
  } else if (selectedMessage.type !== 'forward') {
    watermarkToUse = WM;
  }
  
  let messageContent = selectedMessage.content || '';
  if (selectedMessage.type !== 'forward' && watermarkToUse && messageContent) {
    messageContent = `${messageContent}\n\n${watermarkToUse}`;
  } else if (selectedMessage.type !== 'forward' && watermarkToUse && !messageContent) {
    messageContent = watermarkToUse;
  }
  
  const settings = await db.get('SELECT delay, jeda FROM settings WHERE owner_id = ?', targetUserId) || {
    delay: 500, jeda: 15
  };
  
  if (promosiProgress[targetUserId]) {
    delete promosiProgress[targetUserId];
  }
  
  promosiProgress[targetUserId] = {
    validGroups: validGroups,
    current: 0,
    success: 0,
    failed: 0,
    errors: [],
    running: true,
    startTime: Date.now(),
    settings: { delay: settings.delay || 500, jeda: settings.jeda || 15 },
    selectedMessage: selectedMessage,
    messageContent: messageContent,
    chatId: null,
    lastActivity: Date.now()
  };
  
  await savePromosiState(targetUserId);
  await savePromosiStateToFile();
  
  await safeEditMessageText(`
<blockquote>✅ <b><u>PROMOSI AKTIF</u></b>
📣 <b>Promosi userbot telah diaktifkan! Broadcast dimulai...</b></blockquote>`, {
    chat_id: chatId,
    message_id: messageId,
    parse_mode: 'HTML'
  });
  
  executePromoRound(targetUserId, null);
}

async function handleUbotPromoPause(callbackQuery, userId, chatId, messageId, data) {
  const targetUserId = data.replace('ubot_promo_pause_', '');
  
  await safeAnswerCallbackQuery(callbackQuery, `<i>⏸️ Menjeda promosi...</i>`);
  
  if (promosiProgress[targetUserId]) {
    promosiProgress[targetUserId].running = false;
    promosiProgress[targetUserId].lastActivity = Date.now();
    await savePromosiState(targetUserId);
    await savePromosiStateToFile();
  }
  
  if (global.promoTimeouts && global.promoTimeouts[targetUserId]) {
    clearTimeout(global.promoTimeouts[targetUserId]);
    delete global.promoTimeouts[targetUserId];
  }
  
  await db.run('UPDATE settings SET promosi_status = "PAUSE" WHERE owner_id = ?', targetUserId);
  
  await safeEditMessageText(`
<blockquote>⏸️ <b><u>PROMOSI DIJEDA</u></b>
⏳ <b>Promosi userbot telah dijeda!</b></blockquote>`, {
    chat_id: chatId,
    message_id: messageId,
    parse_mode: 'HTML'
  });
}

async function handleUbotPromoStop(callbackQuery, userId, chatId, messageId, data) {
  const targetUserId = data.replace('ubot_promo_stop_', '');
  
  await safeAnswerCallbackQuery(callbackQuery, `<i>⏹️ Menghentikan promosi...</i>`);
  
  if (promosiProgress[targetUserId]) {
    promosiProgress[targetUserId].running = false;
    delete promosiProgress[targetUserId];
  }
  
  if (global.promoTimeouts && global.promoTimeouts[targetUserId]) {
    clearTimeout(global.promoTimeouts[targetUserId]);
    delete global.promoTimeouts[targetUserId];
  }
  
  await db.run('UPDATE settings SET promosi_status = "OFF", promosi_active = 0, promosi_round_data = NULL WHERE owner_id = ?', targetUserId);
  
  await savePromosiStateToFile();
  
  await safeEditMessageText(`
<blockquote>⏹️ <b><u>PROMOSI DIHENTIKAN</u></b>
🛑 <b>Promosi userbot telah dihentikan total!</b></blockquote>`, {
    chat_id: chatId,
    message_id: messageId,
    parse_mode: 'HTML'
  });
}

async function handleUbotRestart(callbackQuery, userId, chatId, messageId, data) {
  const targetUserId = data.replace('ubot_restart_', '');
  
  await safeAnswerCallbackQuery(callbackQuery, `<i>🔄 Merestart round...</i>`);
  
  const userbotClient = userbots.find(ub => ub.owner_id === targetUserId);
  
  if (!userbotClient || !userbotClient.client) {
    await safeEditMessageText(`
<blockquote>❌ <b><u>GAGAL</u></b>
🤖 <b>Userbot offline! Tidak bisa restart.</b></blockquote>`, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: 'HTML'
    });
    return;
  }
  
  const groups = await db.all('SELECT * FROM groups WHERE owner_id = ?', targetUserId);
  const messages = await db.all('SELECT * FROM messages WHERE owner_id = ?', targetUserId);
  
  if (groups.length === 0 || messages.length === 0) {
    await safeEditMessageText(`
<blockquote>❌ <b><u>GAGAL</u></b>
📝 <b>Tidak ada grup atau pesan! Setup dulu.</b></blockquote>`, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: 'HTML'
    });
    return;
  }
  
  if (promosiProgress[targetUserId]) {
    promosiProgress[targetUserId].running = false;
    
    setTimeout(async () => {
      const blacklistGroups = await db.all('SELECT group_id FROM blacklist_groups WHERE owner_id = ?', targetUserId);
      const blacklistIds = blacklistGroups.map(b => b.group_id.toString());
      const validGroups = groups.filter(g => {
        return parseInt(g.group_id) < 0 && !blacklistIds.includes(g.group_id.toString());
      });
      
      if (validGroups.length > 0 && promosiProgress[targetUserId]) {
        promosiProgress[targetUserId].validGroups = validGroups;
        promosiProgress[targetUserId].current = 0;
        promosiProgress[targetUserId].success = 0;
        promosiProgress[targetUserId].failed = 0;
        promosiProgress[targetUserId].errors = [];
        promosiProgress[targetUserId].running = true;
        promosiProgress[targetUserId].startTime = Date.now();
        
        await savePromosiState(targetUserId);
        await savePromosiStateToFile();
        
        executePromoRound(targetUserId, null);
      }
    }, 1000);
  } else {
    await startautoBroadcast(targetUserId, null);
  }
  
  await safeEditMessageText(`
<blockquote>🔄 <b><u>RESTART ROUND</u></b>
✅ <b>Round broadcast telah direstart!</b></blockquote>`, {
    chat_id: chatId,
    message_id: messageId,
    parse_mode: 'HTML'
  });
}

async function handleUbotRefresh(callbackQuery, userId, chatId, messageId, data) {
  const targetUserId = data.replace('ubot_refresh_', '');
  
  await safeAnswerCallbackQuery(callbackQuery, `<i>🔄 Refreshing...</i>`);
  
  const userbotClient = userbots.find(ub => ub.owner_id === targetUserId);
  const user = await db.get('SELECT * FROM users WHERE user_id = ?', targetUserId);
  const ubotData = await db.get('SELECT * FROM userbots WHERE owner_id = ?', targetUserId);
  const totalGroup = await db.get('SELECT COUNT(*) as count FROM groups WHERE owner_id = ?', targetUserId);
  const totalPesan = await db.get('SELECT COUNT(*) as count FROM messages WHERE owner_id = ?', targetUserId);
  const role = await getUserRole(targetUserId);
  
  let statusPromosi = 'NONAKTIF';
  let realTimeConnected = false;
  
  if (userbotClient && userbotClient.client) {
    try {
      const me = await userbotClient.client.getMe();
      if (me) {
        realTimeConnected = true;
        const promoSetting = await db.get('SELECT promosi_status FROM settings WHERE owner_id = ?', targetUserId);
        if (promoSetting && promoSetting.promosi_status === 'ON') {
          statusPromosi = promosiProgress[targetUserId]?.running ? `✅ AKTIF` : `⏸️ PAUSE`;
        }
      }
    } catch (err) {
      statusPromosi = `⚠️ OFFLINE`;
    }
  } else {
    statusPromosi = `❌ OFFLINE`;
  }
  
  const response = `
<blockquote>⚙️ <b><u>KONTROL USERBOT: ${ubotData?.ubot_id || '-'}</u></b></blockquote>
<blockquote>👤 <b>Pemilik</b> : <a href="tg://user?id=${targetUserId}">${user?.full_name || 'Unknown'}</a>
👥 <b>Username</b> : ${user?.username || '-'}
🆔 <b>ID</b> : <code>${targetUserId}</code>
🛒 <b>Paket</b> : ${role}
🗓 <b>Habis</b> : ${ubotData?.expired ? new Date(ubotData.expired * 1000).toLocaleDateString() : '-'}
📊 <b>Grup</b> : ${totalGroup.count} grup
📖 <b>Pesan</b> : ${totalPesan.count} pesan
📤 <b>Terkirim</b> : ${promosiProgress[targetUserId]?.success || 0}
📣 <b>Status Promosi</b> : ${statusPromosi}
🖥️ <b>Koneksi</b> : ${realTimeConnected ? `✅ ONLINE` : `❌ OFFLINE`}</blockquote>

<i>Pilih tombol kontrol di bawah</i>`;

  await safeEditMessageText(response, {
    chat_id: chatId,
    message_id: messageId,
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [
          { text: '▶️ Aktifkan', callback_data: `ubot_promo_on_${targetUserId}` },
          { text: '⏸️ Pause', callback_data: `ubot_promo_pause_${targetUserId}` },
          { text: '⏹️ Hentikan', callback_data: `ubot_promo_stop_${targetUserId}` }
        ],
        [
          { text: '🔄 Restart', callback_data: `ubot_restart_${targetUserId}` },
          { text: '🔄 Refresh', callback_data: `ubot_refresh_${targetUserId}` }
        ],
        [
          { text: '📊 Detail', callback_data: `ubot_detail_${targetUserId}` },
          { text: '🗑️ Hapus', callback_data: `ubot_delete_${targetUserId}` }
        ],
        [
          { text: '⬅️ Kembali', callback_data: 'back_to_ubot_list' }
        ]
      ]
    }
  });
}

async function handleUbotDetail(callbackQuery, userId, chatId, messageId, data) {
  const targetUserId = data.replace('ubot_detail_', '');
  
  await safeAnswerCallbackQuery(callbackQuery, `<i>📊 Mengambil data detail...</i>`);
  
  const userbotClient = userbots.find(ub => ub.owner_id === targetUserId);
  const ubotData = await db.get('SELECT * FROM userbots WHERE owner_id = ?', targetUserId);
  
  let realTimeStatus = `❌ OFFLINE`;
  let realTimePhone = '-';
  let realTimeUsername = '-';
  let realTimeFirstName = '-';
  let realTimeLastName = '-';
  let realTimeGroups = 0;
  let realTimeTotalChats = 0;
  let realTimeUptime = '0 menit';
  
  if (userbotClient && userbotClient.client) {
    try {
      const me = await userbotClient.client.getMe();
      if (me) {
        realTimeStatus = `✅ ONLINE`;
        realTimePhone = me.phone || '-';
        realTimeUsername = me.username ? `@${me.username}` : '-';
        realTimeFirstName = me.firstName || '-';
        realTimeLastName = me.lastName || '-';
        
        const dialogs = await userbotClient.client.getDialogs();
        realTimeTotalChats = dialogs.length;
        realTimeGroups = dialogs.filter(d => d.isGroup).length;
        
        const startTime = userbotClient.startTime || Date.now();
        const uptimeSeconds = Math.floor((Date.now() - startTime) / 1000);
        const hours = Math.floor(uptimeSeconds / 3600);
        const minutes = Math.floor((uptimeSeconds % 3600) / 60);
        realTimeUptime = `${hours > 0 ? hours + ' jam ' : ''}${minutes} menit`;
      }
    } catch (err) {
      realTimeStatus = `⚠️ ERROR`;
    }
  }
  
  const totalGroupDb = await db.get('SELECT COUNT(*) as count FROM groups WHERE owner_id = ?', targetUserId);
  const totalBlacklistDb = await db.get('SELECT COUNT(*) as count FROM blacklist_groups WHERE owner_id = ?', targetUserId);
  const totalPesanDb = await db.get('SELECT COUNT(*) as count FROM messages WHERE owner_id = ?', targetUserId);
  const settings = await db.get('SELECT * FROM settings WHERE owner_id = ?', targetUserId) || {};
  
  const response = `
<blockquote>📊 <b><u>DETAIL USERBOT</u></b></blockquote>
<blockquote>🖥️ <b>STATUS USERBOT</b>
 • Koneksi: ${realTimeStatus}
 • Uptime: ${realTimeUptime}
 • Total Chat: ${realTimeTotalChats} (${realTimeGroups} grup)</blockquote>
<blockquote>👤 <b>AKUN USERBOT</b>
 • Nama: ${realTimeFirstName} ${realTimeLastName}
 • Username: ${realTimeUsername}
 • ID: <code>${ubotData?.ubot_id || '-'}</code>
 • Nomor: <code>${realTimePhone}</code></blockquote>
<blockquote>📖 <b>DATA DATABASE</b>
 • Grup Target: ${totalGroupDb.count || 0}
 • Blacklist: ${totalBlacklistDb.count || 0}
 • Pesan: ${totalPesanDb.count || 0}
 • Delay: ${settings.delay || 300} ms
 • Jeda: ${settings.jeda || 20} menit</blockquote>

<i>Klik refresh untuk update</i>`;

  await safeEditMessageText(response, {
    chat_id: chatId,
    message_id: messageId,
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [
          { text: '🔄 Refresh', callback_data: `ubot_refresh_${targetUserId}` }
        ],
        [
          { text: '⬅️ Kembali', callback_data: `back_to_ubot_list` }
        ]
      ]
    }
  });
}

async function handleUbotDelete(callbackQuery, userId, chatId, messageId, data) {
  const targetUserId = data.replace('ubot_delete_', '');
  const ubotData = await db.get('SELECT * FROM userbots WHERE owner_id = ?', targetUserId);
  
  await safeEditMessageText(`
<blockquote>⚠️ <b><u>PERINGATAN!</u></b></blockquote>
<blockquote>Yakin mau hapus userbot permanen?</blockquote>
<blockquote>📌 <b>ID Userbot:</b> <code>${ubotData?.ubot_id || '-'}</code>
👤 <b>Pemilik:</b> <code>${targetUserId}</code></blockquote>

<i>Semua data grup, pesan, dan pengaturan akan hilang!</i>

<i>Konfirmasi pilihan Anda</i>`, {
    chat_id: chatId,
    message_id: messageId,
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [
          { text: '✅ Ya, Hapus', callback_data: `confirm_delete_ubot_${targetUserId}_${ubotData?.ubot_id}` },
          { text: '❌ Batal', callback_data: `back_to_ubot_list` }
        ]
      ]
    }
  });
}

async function handleBackToTokenMenu(callbackQuery, userId, chatId, messageId) {
  const tokens = await db.all('SELECT * FROM tokens WHERE used_by = ? AND used = 1', userId);
  
  let tokenMessage = `
<blockquote>🔑 <b><u>SISTEM TOKEN</u></b></blockquote>
<blockquote>Token itu buat claim akses premium kalo:
 • Akun Telegram lu kena banned
 • Lu mau pindah ke akun baru
 • Lu kehilangan akses ke userbot</blockquote>
<blockquote>⚠️ <b>PERHATIAN</b>
 • 1 token cuma bisa dipake 1 kali
 • Token cuma bisa dipake 1 user
 • Token ga bisa dipindah ke orang lain
 • Simpan token lu baik-baik!</blockquote>
<blockquote>📌 <b>CARA PAKE</b>
 Kalo akun lu kena banned, tinggal buat userbot baru pake akun baru, trus pake token ini.
 Lu bakal dapet akses premium sesuai paket awal.</blockquote>

<i>Simpan token dengan baik!</i>`;

  if (tokens.length > 0) {
    tokenMessage += `\n\n<blockquote><b>Token yang udah lu claim sebelumnya:</b></blockquote>\n`;
    for (let i = 0; i < tokens.length; i++) {
      const t = tokens[i];
      const claimDate = new Date(t.used_at * 1000).toLocaleString();
      tokenMessage += `<blockquote><code>${t.token}</code> (Claim: ${claimDate})</blockquote>\n`;
    }
  }

  await safeEditMessageText(tokenMessage, {
    chat_id: chatId,
    message_id: messageId,
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [
          { text: '🔑 Pake Token', callback_data: 'use_token' }
        ],
        [
          { text: '⬅️ Kembali', callback_data: 'back_main' }
        ]
      ]
    }
  });
}

async function handleWmPayNow(callbackQuery, userId, chatId, messageId) {
  if (!userPayments[userId] || userPayments[userId].type !== 'wm') return;
  
  const duration = userPayments[userId].duration;
  const targetUserId = userPayments[userId].targetUserId || userId;
  const prices = await db.get(`SELECT * FROM prices WHERE type = 'wm'`);
  const pricePerMonth = prices?.price_1 || 3000;
  const amount = pricePerMonth * duration;
  const isGift = targetUserId !== userId;
  
  await safeDeleteMessage(chatId, messageId);
  
  const infoText = `<blockquote>🧩 Paket: Plan Basic | 📅 ${duration} bulan | 💰 Rp ${pricePerMonth.toLocaleString()}/bulan</blockquote>`;

  const result = await createPayment(userId, chatId, amount, 'BASIC', infoText, async (userId, orderId) => {
    const expired = Math.floor(Date.now() / 1000) + duration * 30 * 24 * 3600;
    const days = duration * 30;
    
    // HAPUS SEMUA AKSES LAIN - biar Basic yang aktif
    await db.run('DELETE FROM premium_no_wm WHERE user_id = ?', targetUserId);
    await db.run('DELETE FROM reseller_list WHERE user_id = ?', targetUserId);
    await db.run('DELETE FROM reseller_added WHERE user_id = ?', targetUserId);
    await db.run('DELETE FROM premium_wm WHERE user_id = ?', targetUserId);
    
    // Hapus dari file list_access
    removeAccess(targetUserId);
    // Bersihin akses user biar ga double
cleanupUserAccess(targetUserId);
    
    // Tambah akses Basic
    await db.run(`INSERT OR REPLACE INTO premium_wm (user_id, expired, added_by, created_at) VALUES (?, ?, ?, ?)`,
      targetUserId, expired, isGift ? `GIFT_FROM_${userId}` : 'AUTO', Math.floor(Date.now() / 1000));
    await db.run(`UPDATE users SET role = ? WHERE user_id = ?`, 'PREMIUM_WM', targetUserId);
    await db.run(`UPDATE users SET expired = ? WHERE user_id = ?`, expired, targetUserId);
    
    // Update file list_access
    addAccess(targetUserId, `${duration * 30}d`, 'basic');

    // PENTING: akses premium di atas sudah SUKSES tersimpan di database.
    // Kegagalan kirim notifikasi (mis. target user memblokir bot / belum
    // pernah start chat) TIDAK BOLEH dianggap sebagai kegagalan pembelian
    // -- kalau exception ini lolos ke luar onSuccess, createPayment() akan
    // mengembalikan saldo padahal premiumnya sudah aktif (jadi premium
    // gratis + saldo balik). Makanya bagian notifikasi dibungkus sendiri.
    try {
      await bot.sendMessage(targetUserId, `
<blockquote>✅ <b>PEMBELIAN BERHASIL</b></blockquote>
<blockquote>🧩 <b>Paket</b> : Plan Basic
📅 <b>Durasi</b> : ${duration} bulan
💰 <b>Total</b> : <code><b>Rp ${amount.toLocaleString()}</b></code>
🆔 <b>Order ID</b> : <code>${orderId}</code></blockquote>
🚀 <b>Akses premium sudah aktif! Tekan ➕ Deploy Userbot untuk mulai.</b>`, { parse_mode: 'HTML' });
    } catch (notifErr) {
      logger.warn(`Gagal kirim notifikasi pembelian Basic ke ${targetUserId} (akses tetap aktif): ${notifErr.message}`);
    }

    try {
      await sendLogNotification(targetUserId, { type: 'wm', duration: duration }, 'payment_success');
    } catch (logErr) {
      logger.warn(`Gagal kirim log notifikasi pembelian Basic: ${logErr.message}`);
    }
  });
  
  if (!result.ok) {
    await bot.sendMessage(chatId, `<blockquote>❌ ${result.error}</blockquote>`, { parse_mode: 'HTML' });
  }
}

async function handleNowmPayNow(callbackQuery, userId, chatId, messageId) {
  if (!userPayments[userId] || userPayments[userId].type !== 'nowm') return;
  
  const duration = userPayments[userId].duration;
  const targetUserId = userPayments[userId].targetUserId || userId;
  const prices = await db.get(`SELECT * FROM prices WHERE type = 'nowm'`);
  const pricePerMonth = prices?.price_1 || 5000;
  const amount = pricePerMonth * duration;
  const isGift = targetUserId !== userId;
  
  await safeDeleteMessage(chatId, messageId);
  
  const infoText = `<blockquote>💎 Paket: Plan Pro | 📅 ${duration} bulan | 💰 Rp ${pricePerMonth.toLocaleString()}/bulan</blockquote>`;

  const result = await createPayment(userId, chatId, amount, 'PRO', infoText, async (userId, orderId) => {
    const expired = Math.floor(Date.now() / 1000) + duration * 30 * 24 * 3600;
    const days = duration * 30;
    
    // HAPUS SEMUA AKSES LAIN - biar Pro yang aktif
    await db.run('DELETE FROM premium_wm WHERE user_id = ?', targetUserId);
    await db.run('DELETE FROM reseller_list WHERE user_id = ?', targetUserId);
    await db.run('DELETE FROM reseller_added WHERE user_id = ?', targetUserId);
    await db.run('DELETE FROM premium_no_wm WHERE user_id = ?', targetUserId);
    
    // Hapus dari file list_access
    removeAccess(targetUserId);
    // Bersihin akses user biar ga double
cleanupUserAccess(targetUserId);
    
    // Tambah akses Pro
    await db.run(`INSERT OR REPLACE INTO premium_no_wm (user_id, expired, added_by, created_at) VALUES (?, ?, ?, ?)`,
      targetUserId, expired, isGift ? `GIFT_FROM_${userId}` : 'AUTO', Math.floor(Date.now() / 1000));
    await db.run(`UPDATE users SET role = ? WHERE user_id = ?`, 'PREMIUM_NO_WM', targetUserId);
    await db.run(`UPDATE users SET expired = ? WHERE user_id = ?`, expired, targetUserId);
    
    // Update file list_access
    addAccess(targetUserId, `${duration * 30}d`, 'pro');

    // Sama seperti Plan Basic: akses sudah aktif, jadi kegagalan notifikasi
    // tidak boleh memicu rollback saldo.
    try {
      await bot.sendMessage(targetUserId, `
<blockquote>✅ <b>PEMBELIAN BERHASIL</b></blockquote>
<blockquote>💎 <b>Paket</b> : Plan Pro
📅 <b>Durasi</b> : ${duration} bulan
💰 <b>Total</b> : <code><b>Rp ${amount.toLocaleString()}</b></code>
🆔 <b>Order ID</b> : <code>${orderId}</code></blockquote>
🚀 <b>Akses premium sudah aktif! Tekan ➕ Deploy Userbot untuk mulai.</b>`, { parse_mode: 'HTML' });
    } catch (notifErr) {
      logger.warn(`Gagal kirim notifikasi pembelian Pro ke ${targetUserId} (akses tetap aktif): ${notifErr.message}`);
    }

    try {
      await sendLogNotification(targetUserId, { type: 'nowm', duration: duration }, 'payment_success');
    } catch (logErr) {
      logger.warn(`Gagal kirim log notifikasi pembelian Pro: ${logErr.message}`);
    }
  });
  
  if (!result.ok) {
    await bot.sendMessage(chatId, `<blockquote>❌ ${result.error}</blockquote>`, { parse_mode: 'HTML' });
  }
}

async function handleResellerPayNow(callbackQuery, userId, chatId, messageId) {
  if (!userPayments[userId] || userPayments[userId].type !== 'reseller') return;
  
  const duration = userPayments[userId].duration;
  const targetUserId = userPayments[userId].targetUserId || userId;
  const prices = await db.get(`SELECT * FROM prices WHERE type = 'reseller'`);
  const pricePerMonth = prices?.price_1 || 10000;
  const amount = pricePerMonth * duration;
  const isGift = targetUserId !== userId;
  
  await safeDeleteMessage(chatId, messageId);
  
  const infoText = `<blockquote>🎟 Paket: Reseller | 📅 ${duration} bulan | 💰 Rp ${pricePerMonth.toLocaleString()}/bulan</blockquote>`;

  const result = await createPayment(userId, chatId, amount, 'RESELLER', infoText, async (userId, orderId) => {
    // HAPUS SEMUA AKSES LAIN - biar Reseller yang aktif
    await db.run('DELETE FROM premium_wm WHERE user_id = ?', targetUserId);
    await db.run('DELETE FROM premium_no_wm WHERE user_id = ?', targetUserId);
    await db.run('DELETE FROM reseller_added WHERE user_id = ?', targetUserId);
    await db.run('DELETE FROM reseller_list WHERE user_id = ?', targetUserId);
    
    // Hapus dari file list_access
    removeAccess(targetUserId);
    // Bersihin akses user biar ga double
    cleanupUserAccess(targetUserId);
    
    // Hitung expired berdasarkan durasi (bulan)
    const expired = Math.floor(Date.now() / 1000) + (duration * 30 * 24 * 3600);
    
    // Tambah akses Reseller dengan expired
    await db.run(`INSERT OR REPLACE INTO reseller_list (user_id, added_by, added_at) VALUES (?, ?, ?)`,
      targetUserId, isGift ? `GIFT_FROM_${userId}` : 'AUTO', Math.floor(Date.now() / 1000));
    await db.run(`UPDATE users SET role = ? WHERE user_id = ?`, 'RESELLER', targetUserId);
    await db.run(`UPDATE users SET expired = ? WHERE user_id = ?`, expired, targetUserId);
    
    // Update file list_access dengan durasi yang bener
    addAccess(targetUserId, `${duration * 30}d`, 'reseller');

    // Sama seperti Basic/Pro: akses sudah aktif, notifikasi gagal tidak
    // boleh memicu rollback saldo.
    try {
      await bot.sendMessage(targetUserId, `
<blockquote>✅ <b>PEMBELIAN BERHASIL</b></blockquote>
<blockquote>🎟 <b>Paket</b> : Akses Reseller
📅 <b>Durasi</b> : ${duration} bulan
💰 <b>Total</b> : <code><b>Rp ${amount.toLocaleString()}</b></code>
🆔 <b>Order ID</b> : <code>${orderId}</code></blockquote>
🚀 <b>Akses reseller sudah aktif! Tekan ➕ Deploy Userbot untuk mulai.</b>`, { parse_mode: 'HTML' });
    } catch (notifErr) {
      logger.warn(`Gagal kirim notifikasi pembelian Reseller ke ${targetUserId} (akses tetap aktif): ${notifErr.message}`);
    }

    try {
      await sendLogNotification(targetUserId, { type: 'reseller', duration: duration }, 'payment_success');
    } catch (logErr) {
      logger.warn(`Gagal kirim log notifikasi pembelian Reseller: ${logErr.message}`);
    }
  });
  
  if (!result.ok) {
    await bot.sendMessage(chatId, `<blockquote>❌ ${result.error}</blockquote>`, { parse_mode: 'HTML' });
  }
}

async function handleExtend(callbackQuery, userId, chatId, messageId, data) {
  const bulan = parseInt(data.replace('extend_', ''));
  const ubot = userbots.find(ub => ub.owner_id === userId);
  if (!ubot) return;
  
  const role = await getUserRole(userId);
  let pricePerMonth = 0, paketNama = '', emoji = '';
  
  if (role === 'PREMIUM_WM') {
    const prices = await db.get(`SELECT * FROM prices WHERE type = 'wm'`);
    pricePerMonth = prices?.price_1 || 3000;
    paketNama = 'Basic';
    emoji = '🧩';
  } else if (role === 'PREMIUM_NO_WM') {
    const prices = await db.get(`SELECT * FROM prices WHERE type = 'nowm'`);
    pricePerMonth = prices?.price_1 || 5000;
    paketNama = 'Pro';
    emoji = '💎';
  } else {
    return;
  }
  
  const totalPrice = pricePerMonth * bulan;
  
  await safeDeleteMessage(chatId, messageId);
  
  const infoText = `<blockquote>${emoji} Perpanjang Plan ${paketNama} | 📅 ${bulan} bulan | 💰 Rp ${pricePerMonth.toLocaleString()}/bulan</blockquote>`;

  const result = await createPayment(userId, chatId, totalPrice, 'EXTEND', infoText, async (userId, orderId) => {
    const ubotData = await db.get('SELECT * FROM userbots WHERE owner_id = ?', userId);
    if (ubotData) {
      let expiredBaru = ubotData.expired;
      const sekarang = Math.floor(Date.now() / 1000);
      const tambahDetik = bulan * 30 * 24 * 3600;
      
      expiredBaru = expiredBaru > sekarang ? expiredBaru + tambahDetik : sekarang + tambahDetik;
      
      await db.run('UPDATE userbots SET expired = ? WHERE owner_id = ?', expiredBaru, userId);
      await db.run('UPDATE users SET expired = ? WHERE user_id = ?', expiredBaru, userId);
      
      const sisaHari = Math.floor((expiredBaru - sekarang) / 86400);

      // Masa aktif sudah diperpanjang di database; notifikasi gagal tidak
      // boleh memicu rollback saldo.
      try {
        await bot.sendMessage(userId, `
<blockquote>✅ <b>PERPANJANG BERHASIL</b></blockquote>
<blockquote>${emoji} <b>Paket</b> : Plan ${paketNama}
📅 <b>Perpanjang</b> : ${bulan} bulan
💰 <b>Total</b> : <code><b>Rp ${totalPrice.toLocaleString()}</b></code>
🆔 <b>Order ID</b> : <code>${orderId}</code>
🗓 <b>Sisa Aktif</b> : ${sisaHari} hari</blockquote>`, { parse_mode: 'HTML' });
      } catch (notifErr) {
        logger.warn(`Gagal kirim notifikasi perpanjang ke ${userId} (masa aktif tetap terperpanjang): ${notifErr.message}`);
      }

      try {
        await sendLogNotification(userId, { type: 'extend', duration: bulan }, 'payment_success');
      } catch (logErr) {
        logger.warn(`Gagal kirim log notifikasi perpanjang: ${logErr.message}`);
      }
    }
  });
  
  if (!result.ok) {
    await bot.sendMessage(chatId, `<blockquote>❌ ${result.error}</blockquote>`, { parse_mode: 'HTML' });
  }
}

async function handleConfirmDeleteUbot(callbackQuery, userId, chatId, messageId, data) {
  const parts = data.replace('confirm_delete_ubot_', '').split('_');
  const targetUserId = parts[0];
  const ubotId = parts[1];
  
  await safeAnswerCallbackQuery(callbackQuery);
  
  const confirmMsg = await bot.sendMessage(chatId, `
<blockquote>⏳ <b><u>MENGHAPUS USERBOT</u></b>
🤖 Menghapus userbot <code>${ubotId}</code>...</blockquote>`, { parse_mode: 'HTML' });
  
  const result = await cleanupUserData(targetUserId, 'manual_delete_by_owner');
  
  await safeDeleteMessage(chatId, confirmMsg.message_id).catch(() => {});
  
  if (result) {
    await safeEditMessageText(`
<blockquote>✅ <b><u>BERHASIL DIHAPUS</u></b></blockquote>
<blockquote>🤖 <b>Userbot <code>${ubotId}</code> berhasil dihapus!</b>
📁 Semua data telah dibersihkan dari sistem.</blockquote>`, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: 'HTML'
    });
  } else {
    await safeEditMessageText(`
<blockquote>❌ <b><u>GAGAL</u></b></blockquote>
<blockquote>🤖 <b>Gagal menghapus userbot <code>${ubotId}</code>.</b>
⚠️ Coba lagi nanti atau hubungi owner.</blockquote>`, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: 'HTML'
    });
  }
  
  delete global.selectedUbot[userId];
}

async function handleCancelDeleteUbot(callbackQuery, userId, chatId, messageId) {
  await safeAnswerCallbackQuery(callbackQuery);
  await safeDeleteMessage(chatId, messageId);
  await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>BATAL</u></b>
🗑️ Penghapusan userbot dibatalkan.</blockquote>`, {
    parse_mode: 'HTML',
    reply_markup: await getOwnerMenuKeyboard()
  });
}

async function handleConfirmDeleteAll(callbackQuery, userId, chatId, messageId, data) {
  const targetUserId = data.replace('confirm_delete_all_', '');
  
  if (targetUserId !== userId) {
    await safeAnswerCallbackQuery(callbackQuery, `<i>❌ Anda tidak bisa menghapus pesan user lain!</i>`, true);
    return;
  }
  
  await safeDeleteMessage(chatId, messageId);
  
  await db.run('DELETE FROM messages WHERE owner_id = ?', targetUserId);
  await db.run('UPDATE settings SET selected_message_id = NULL WHERE owner_id = ?', targetUserId);
  
  await bot.sendMessage(chatId, `
<blockquote>✅ <b><u>BERHASIL</u></b>
🗑️ Semua pesan udah dihapus.</blockquote>`, { parse_mode: 'HTML' });
}

async function handleBackToPaket(callbackQuery, userId, chatId, messageId) {
    const caption = `
<blockquote>🛒 <b><u>PILIH PAKET USERBOT</u></b></blockquote>
<blockquote>🧩 <b>Plan Basic</b>
• Bisa mengakses fitur AutoBC (Berwatermark Bot)
• Tidak bisa menggunakan AutoFW
• Nikmati akses userbot yang cukup untuk kebutuhan standar
• Fitur bisa bertambah atau berkurang sesuai dari pengembangan atau developer</blockquote>
<blockquote>💎 <b>Plan Pro</b>
• Unlock semua kemampuan fitur pro yang super lengkap tanpa watermark AutoBC
• Fitur akan terus dikembangkan dan bisa berubah sesuai keputusan developer</blockquote>
<blockquote>🎟 <b>Akses Reseller</b>
• Unlock semua kemampuan fitur pro yang super lengkap tanpa watermark AutoBC
• Bisa open akses sewa userbot menggunakan userbot kami (Tanpa batas user)
• Fitur akan terus dikembangkan dan bisa berubah sesuai keputusan developer</blockquote>
`;

    await safeEditMessageText(caption, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
            inline_keyboard: [
                [
                    { text: '🧩 Plan Basic', callback_data: 'paket_wm' },
                    { text: '💎 Plan Pro', callback_data: 'paket_nowm' }
                ],
                [
                    { text: '🎟 Akses Reseller', callback_data: 'paket_reseller' },
                    { text: '🤖 Clone Bot', callback_data: 'paket_clone' }
                ],
                [
                    { text: '⬅️ Kembali', callback_data: 'back_main' }
                ]
            ]
        }
    });
}

async function handleRefreshDetail(callbackQuery, userId, chatId, messageId, data) {
  const targetUserId = data.replace('refresh_detail_', '');
  
  await safeAnswerCallbackQuery(callbackQuery, `<i>🔄 Refreshing data...</i>`);
  
  try {
    const ubotData = await db.get('SELECT * FROM userbots WHERE owner_id = ?', targetUserId);
    if (!ubotData) {
      await safeEditMessageText(`
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Userbot tidak ditemukan.</b></blockquote>`, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML'
      });
      return;
    }
    
    const userbotClient = userbots.find(ub => ub.owner_id === targetUserId);
    
    let realTimeStatus = `❌ OFFLINE`;
    let realTimePhone = '-';
    let realTimeUsername = '-';
    let realTimeFirstName = '-';
    let realTimeLastName = '-';
    let realTimeGroups = 0;
    let realTimeTotalChats = 0;
    let realTimeUptime = '0 menit';
    let realTimeLastSeen = '-';
    let realTimePing = '-';
    let realTimeOnline = `❌`;
    
    if (userbotClient && userbotClient.client) {
      const startPing = Date.now();
      
      try {
        const me = await userbotClient.client.getMe();
        const ping = Date.now() - startPing;
        realTimePing = `${ping} ms`;
        
        if (me) {
          realTimeStatus = `✅ ONLINE`;
          realTimePhone = me.phone || '-';
          realTimeUsername = me.username ? `@${me.username}` : '-';
          realTimeFirstName = me.firstName || '-';
          realTimeLastName = me.lastName || '-';
          
          const dialogs = await userbotClient.client.getDialogs();
          realTimeTotalChats = dialogs.length;
          realTimeGroups = dialogs.filter(d => d.isGroup).length;
          
          const startTime = userbotClient.startTime || Date.now();
          const uptimeSeconds = Math.floor((Date.now() - startTime) / 1000);
          const hours = Math.floor(uptimeSeconds / 3600);
          const minutes = Math.floor((uptimeSeconds % 3600) / 60);
          realTimeUptime = `${hours > 0 ? hours + ' jam ' : ''}${minutes} menit`;
          
          try {
            const fullUser = await userbotClient.client.invoke(new Api.users.GetFullUser({
              id: me.id
            }));
            if (fullUser && fullUser.fullUser && fullUser.fullUser.status) {
              if (fullUser.fullUser.status instanceof Api.UserStatusOnline) {
                realTimeOnline = `✅ ONLINE`;
                realTimeLastSeen = 'Sekarang';
              } else if (fullUser.fullUser.status instanceof Api.UserStatusOffline) {
                realTimeOnline = `❌ OFFLINE`;
                realTimeLastSeen = moment.unix(fullUser.fullUser.status.wasOnline).format('DD/MM/YYYY HH:mm:ss');
              }
            }
          } catch (e) {}
        }
      } catch (err) {
        realTimeStatus = `⚠️ ERROR`;
      }
    }
    
    const user = await db.get('SELECT * FROM users WHERE user_id = ?', targetUserId);
    const totalGroupDb = await db.get('SELECT COUNT(*) as count FROM groups WHERE owner_id = ?', targetUserId);
    const totalBlacklistDb = await db.get('SELECT COUNT(*) as count FROM blacklist_groups WHERE owner_id = ?', targetUserId);
    const totalPesanDb = await db.get('SELECT COUNT(*) as count FROM messages WHERE owner_id = ?', targetUserId);
    const settings = await db.get('SELECT * FROM settings WHERE owner_id = ?', targetUserId) || {};
    const broadcastStatusDb = await db.get('SELECT promosi_status FROM settings WHERE owner_id = ?', targetUserId);
    const isRunning = promosiProgress[targetUserId]?.running || false;
    const statusText = broadcastStatusDb?.promosi_status === 'ON' && isRunning ? `✅ AKTIF` : (broadcastStatusDb?.promosi_status === 'ON' ? `⏸️ PAUSE` : `❌ NONAKTIF`);
    
    const response = `
<blockquote>⚙️ <b><u>KONTROL USERBOT: ${ubotData.ubot_id}</u></b></blockquote>
<blockquote>🖥️ <b>STATUS USERBOT</b>
 • Koneksi: ${realTimeStatus}
 • Ping: ${realTimePing}
 • Uptime: ${realTimeUptime}
 • Online: ${realTimeOnline}
 • Last Seen: ${realTimeLastSeen}</blockquote>
<blockquote>👤 <b>AKUN USERBOT</b>
 • Nama: ${realTimeFirstName} ${realTimeLastName}
 • Username: ${realTimeUsername}
 • HP: ${realTimePhone}
 • ID: <code>${ubotData.ubot_id}</code></blockquote>
<blockquote>💬 <b>CHAT USERBOT</b>
 • Total Chat: ${realTimeTotalChats}
 • Grup: ${realTimeGroups}</blockquote>
<blockquote>📖 <b>DATA DATABASE</b>
 • Grup Target: ${totalGroupDb.count || 0}
 • Blacklist: ${totalBlacklistDb.count || 0}
 • Pesan: ${totalPesanDb.count || 0}</blockquote>
<blockquote>⚙️ <b>PENGATURAN</b>
 • Delay: ${settings.delay || 300} ms
 • Jeda: ${settings.jeda || 20} menit
 • Watermark: ${settings.watermark_status || 'OFF'}</blockquote>
<blockquote>📣 <b>STATUS PROMOSI</b>
 • Status: ${statusText}
 • Terkirim: ${promosiProgress[targetUserId]?.success || 0}
 • Gagal: ${promosiProgress[targetUserId]?.failed || 0}
 • Progress: ${promosiProgress[targetUserId]?.current || 0}/${promosiProgress[targetUserId]?.validGroups?.length || 0}</blockquote>

<i>Klik refresh untuk update</i>`;

    await safeEditMessageText(response, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [
            { text: '🔄 Refresh Data', callback_data: `refresh_detail_${targetUserId}` }
          ],
          [
            { text: '⬅️ Kembali', callback_data: 'back_main' }
          ]
        ]
      }
    });
    
  } catch (error) {
    await safeEditMessageText(`
<blockquote>❌ <b><u>GAGAL REFRESH</u></b>
⚠️ <b>${error.message}</b></blockquote>`, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: 'HTML'
    });
  }
}

async function handleBackMain(callbackQuery, userId, chatId, messageId) {
  await safeDeleteMessage(chatId, messageId);
  
  const firstName = callbackQuery.from.first_name || 'User';
  const botInfo = await getCachedBotInfo();
  const botFirstName = botInfo.first_name || 'Xavier-Jaseb Bot';
  const botUsername = botInfo.username || 'XavierJasebBot';
  const systemInfoBlock = await getSystemInfoBlock();
  
  const caption = `
<b><u>🚀 WELCOME TO USERBOT JASEB</u></b>

${systemInfoBlock}

<i>Ready to start? 👇</i>`;
  
  const keyboard = await getMainMenuKeyboard(userId);
  
  await bot.sendMessage(chatId, caption, { 
    parse_mode: 'HTML',
    reply_markup: keyboard
  });
}

bot.on('callback_query', async (callbackQuery) => {
  const msg = callbackQuery.message;
  const chatId = msg.chat.id;
  const messageId = msg.message_id;
  const data = callbackQuery.data;
  const userId = callbackQuery.from.id.toString();
  
  try {
  if (msg.chat.type !== 'private') {
    await safeAnswerCallbackQuery(callbackQuery, '<i>❌ Bot hanya bisa digunakan di Private Chat!</i>', true);
    return;
  }
  
  const canProceed = await checkMaintenance(userId, chatId);
  if (!canProceed) return;
  
  const { logGroupJoined, channelJoined, requiredGroupJoined } = await checkUserJoined(userId);
  if (!logGroupJoined || !channelJoined || !requiredGroupJoined) {
    await safeAnswerCallbackQuery(callbackQuery, '<i>⚠️ Anda harus join grup/channel terlebih dahulu!</i>', true);
    await sendJoinRequiredMessage(chatId, userId);
    return;
  }
  
  await safeAnswerCallbackQuery(callbackQuery);
 
  
  if (data.startsWith('reseller_add_durasi_')) {
  const parts = data.replace('reseller_add_durasi_', '').split('_');
  const days = parseInt(parts[0]);
  const type = parts[1];
  const targetUserId = parts[2];
  
  const isOwner = (isOwnerId(userId));
  const maxDays = 150;
  
  if (!isOwner && days > maxDays) {
    await safeAnswerCallbackQuery(callbackQuery, `❌ Maksimal ${maxDays} hari (5 bulan)`, true);
    return;
  }
  
  const role = type === 'wm' ? 'PREMIUM_WM' : 'PREMIUM_NO_WM';
  const expired = Math.floor(Date.now() / 1000) + (days * 86400);
  const durationText = `${days} hari (${Math.floor(days / 30)} bulan)`;
  
  const userExists = await db.get('SELECT * FROM users WHERE user_id = ?', targetUserId);
  const targetName = userExists?.full_name || targetUserId;
  
  const botInfo = await getCachedBotInfo();
  const botUsername = botInfo.username;
  
  const adminName = callbackQuery.from.first_name || 'Reseller';
  
  try {
    if (type === 'wm') {
      await db.run('INSERT OR REPLACE INTO premium_wm (user_id, expired, added_by, created_at) VALUES (?, ?, ?, ?)',
        targetUserId, expired, `RESELLER_${userId}`, Math.floor(Date.now() / 1000));
    } else {
      await db.run('INSERT OR REPLACE INTO premium_no_wm (user_id, expired, added_by, created_at) VALUES (?, ?, ?, ?)',
        targetUserId, expired, `RESELLER_${userId}`, Math.floor(Date.now() / 1000));
    }
    
    await db.run('INSERT OR REPLACE INTO reseller_added (reseller_id, user_id, type, expired, added_at) VALUES (?, ?, ?, ?, ?)',
      userId, targetUserId, type, expired, Math.floor(Date.now() / 1000));
    
    if (!userExists) {
      await db.run('INSERT OR IGNORE INTO users (user_id, full_name, role, created_at, expired) VALUES (?, ?, ?, ?, ?)',
        targetUserId, targetName, role, Math.floor(Date.now() / 1000), expired);
    } else {
      await db.run('UPDATE users SET role = ?, expired = ? WHERE user_id = ?', role, expired, targetUserId);
    }
    
    const paketEmoji = type === 'wm' ? '🧩' : '💎';
    const paketName = type === 'wm' ? 'Basic (WM)' : 'Pro (NO WM)';
    
    const notification = `
<blockquote>✅ <b><u>AKSES PREMIUM DITAMBAHKAN</u></b></blockquote>
<blockquote>
<b>NAME</b> : ${targetName}
<b>ID</b> : <code>${targetUserId}</code>
<b>PAKET</b> : ${paketEmoji} ${paketName}
<b>DURASI</b> : ${durationText}
<b>EXPIRED</b> : ${new Date(expired * 1000).toLocaleString()}
<b>DITAMBAH OLEH</b> : ${adminName}</blockquote>
<blockquote><b>SILAHKAN BUKA @${botUsername} UNTUK MEMBUAT USERBOT</b></blockquote>`;
    
    await bot.sendMessage(targetUserId, notification, { parse_mode: 'HTML' }).catch(() => {});
    
    await safeEditMessageText(`
<blockquote>✅ <b><u>BERHASIL!</u></b></blockquote>
<blockquote>✅ User <code>${targetUserId}</code> berhasil ditambahkan sebagai ${paketName} selama ${durationText}.</blockquote>`, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: 'HTML'
    });
    
    setTimeout(async () => {
      try {
        await safeDeleteMessage(chatId, messageId);
      } catch(e) {}
      await handleMenuReseller(userId, chatId);
    }, 2000);
    
  } catch (error) {
    await safeEditMessageText(`
<blockquote>❌ <b><u>GAGAL</u></b>
⚠️ ${error.message}</blockquote>`, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: 'HTML'
    });
  }
  
  return;
  }

  if (data === 'produk_deposit_minus') {
  if (!produkBaruDepositAmount[userId]) produkBaruDepositAmount[userId] = 5000;
  if (produkBaruDepositAmount[userId] > 5000) {
    produkBaruDepositAmount[userId] -= 5000;
  } else {
    await safeAnswerCallbackQuery(callbackQuery, { text: '⚠️ Minimal Rp 2.000', show_alert: true });
    return;
  }
  await produkBaruShowDepositMenu(userId, chatId, messageId);
  return;
}

if (data === 'produk_deposit_plus') {
  if (!produkBaruDepositAmount[userId]) produkBaruDepositAmount[userId] = 5000;
  if (produkBaruDepositAmount[userId] < 20000) {
    produkBaruDepositAmount[userId] += 5000;
  } else {
    await safeAnswerCallbackQuery(callbackQuery, { text: '⚠️ Maksimal Rp 20.000', show_alert: true });
    return;
  }
  await produkBaruShowDepositMenu(userId, chatId, messageId);
  return;
}

if (data === 'produk_baru_cek_saldo') {
  const user = await db.get('SELECT user_id, username, full_name FROM users WHERE user_id = ?', userId);
  const balance = getProdukBalance(userId);
  const transactions = await getProdukUserTransactions(userId, 10);
  
  const totalTransaksi = transactions.filter(t => t.type === 'PURCHASE').length;
  const jumlahBeli = transactions.filter(t => t.type === 'PURCHASE').reduce((sum, t) => sum + (t.details.match(/quantity:(\d+)/)?.[1] || 0), 0);
  const pemakaianSaldo = transactions.filter(t => t.type === 'PURCHASE').reduce((sum, t) => sum + t.amount, 0);
  
  const caption = `
<blockquote>💰 <b><u>SALDO PRODUK</u></b></blockquote>
<blockquote><b>👤 User</b> : <i>${user?.full_name || 'Unknown'}</i>
<b>🆔 ID</b> : <code>${userId}</code>
<b>💰 Saldo</b> : <code><b>Rp ${balance.toLocaleString()}</b></code>
<b>📊 Pemakaian Saldo</b> : <code><b>Rp ${pemakaianSaldo.toLocaleString()}</b></code>
<b>📦 Jumlah Beli</b> : <code><b>${jumlahBeli}</b> produk</code>
<b>📝 Total Transaksi</b> : <code><b>${totalTransaksi}</b></code></blockquote>

<i>Klik tombol di bawah untuk deposit</i>`;

  await safeEditMessageText(caption, {
    chat_id: chatId,
    message_id: messageId,
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [
          { text: '💰 Deposit', callback_data: 'produk_baru_deposit_menu' },
          { text: '🛍️ Beli Produk', callback_data: 'beli_produk' }
        ],
        [
          { text: '⬅️ Kembali ke Produk', callback_data: 'produk_baru_back_to_list' }
        ]
      ]
    }
  });
  
  await safeAnswerCallbackQuery(callbackQuery);
  return;
}

if (data.startsWith('batal_deposit_')) {
  const orderId = data.replace('batal_deposit_', '');
  const order = await db.get('SELECT * FROM deposit_orders WHERE order_id = ? AND user_id = ?', orderId, userId);
  
  if (!order) {
    await safeAnswerCallbackQuery(callbackQuery, '❌ Order tidak ditemukan', true);
    return;
  }
  
  if (order.status !== 'pending') {
    await safeAnswerCallbackQuery(callbackQuery, `⚠️ Order sudah ${order.status}`, true);
    return;
  }
  
  await db.run('UPDATE deposit_orders SET status = "cancelled" WHERE order_id = ?', orderId);
  delete global.waitingForDepositProof[userId];
  
  await safeDeleteMessage(chatId, messageId);
  await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>DEPOSIT DIBATALKAN</u></b>
🆔 <b>Order ID</b> : <code>${orderId}</code>
💰 <b>Nominal</b> : <b>Rp ${order.amount.toLocaleString()}</b></blockquote>

<i>Deposit berhasil dibatalkan.</i>`, { parse_mode: 'HTML' });
  
  await safeAnswerCallbackQuery(callbackQuery, '✅ Deposit dibatalkan');
  return;
}

if (data === 'produk_deposit_custom') {
  await safeAnswerCallbackQuery(callbackQuery);
  await safeEditMessageText('<i>📝 Kirim nominal deposit (2000-20000):</i>', {
    chat_id: chatId, message_id: messageId, parse_mode: 'HTML'
  });
  global.waitingForProdukDepositCustom = userId;
  return;
}

if (data.startsWith('deposit_accept_')) {
  await handleDepositAccept(callbackQuery, userId, chatId, messageId, data);
  return;
}

if (data.startsWith('check_join_status')) {
  await safeAnswerCallbackQuery(callbackQuery, '🔄 Mengecek ulang...');
  
  global.joinCheckCache.delete(userId); // paksa cek fresh ke Telegram, jangan pake cache lama
  const { logGroupJoined, channelJoined, requiredGroupJoined } = await checkUserJoined(userId);
  
  if (!logGroupJoined || !channelJoined || !requiredGroupJoined) {
    try { await safeDeleteMessage(chatId, messageId); } catch (e) {}
    await sendJoinRequiredMessage(chatId, userId);
    return;
  }
  
  try { await safeDeleteMessage(chatId, messageId); } catch (e) {}
  
  const user = await db.get('SELECT * FROM users WHERE user_id = ?', userId);
  const displayFirstName = escapeHtml(callbackQuery.from.first_name || 'User');
  if (!user) {
    const username = callbackQuery.from.username ? `@${escapeHtml(callbackQuery.from.username)}` : '';
    const lastName = escapeHtml(callbackQuery.from.last_name || '');
    const fullName = `${displayFirstName} ${lastName}`.trim() || 'Unknown';
    await db.run(
      'INSERT OR IGNORE INTO users (user_id, username, full_name, role, created_at, last_active) VALUES (?, ?, ?, ?, ?, ?)',
      userId, username, fullName, 'FREE', Math.floor(Date.now() / 1000), Math.floor(Date.now() / 1000)
    );
  }
  
  const joinBotInfo = await getCachedBotInfo();
  const joinBotFirstName = joinBotInfo.first_name || 'Xavier-Jaseb Bot';
  const joinBotUsername = joinBotInfo.username || 'XavierJasebBot';
  
  const caption = `
<blockquote>✨ <b><u>${joinBotFirstName}</u></b>
Selamat datang, <b>${displayFirstName}</b> 👋</blockquote>

<blockquote>Kelola userbot kamu dengan mudah lewat menu di bawah — mulai dari deploy, pengaturan, sampai status akun, semua dalam satu tempat.</blockquote>

<blockquote>🆔 <b>User ID</b> : <code>${userId}</code>
🤖 <b>Bot</b> : @${joinBotUsername}</blockquote>

<i>Pilih menu di bawah untuk mulai 👇</i>`;

  const keyboard = await getMainMenuKeyboard(userId);
  await bot.sendMessage(chatId, caption, {
    parse_mode: 'HTML',
    reply_markup: keyboard
  });
  return;
}

if (data.startsWith('deposit_reject_')) {
  await handleDepositReject(callbackQuery, userId, chatId, messageId, data);
  return;
}

if (data.startsWith('produk_deposit_now_')) {
  const nominal = parseInt(data.replace('produk_deposit_now_', ''));
  if (isNaN(nominal) || nominal < 2000 || nominal > 20000) {
    await safeAnswerCallbackQuery(callbackQuery, '❌ Nominal tidak valid', true);
    return;
  }
  await produkBaruDeposit(callbackQuery, userId, chatId, messageId, nominal);
  return;
}

if (data.startsWith('produk_deposit_manual_')) {
  const nominal = parseInt(data.replace('produk_deposit_manual_', ''));
  if (isNaN(nominal) || nominal < 2000 || nominal > 20000) {
    await safeAnswerCallbackQuery(callbackQuery, '❌ Nominal tidak valid', true);
    return;
  }
  await produkBaruDepositManual(callbackQuery, userId, chatId, messageId, nominal);
  return;
}

// Cek status deposit otomatis (Pakasir) secara manual lewat tombol
if (data.startsWith('felix_check_')) {
  const orderId = data.replace('felix_check_', '');
  const payment = global.activePayments?.[orderId];

  if (!payment) {
    await safeAnswerCallbackQuery(callbackQuery, '⚠️ Order tidak ditemukan / sudah selesai', true);
    return;
  }

  await safeAnswerCallbackQuery(callbackQuery, '🔄 Mengecek status...');

  const result = await checkFelixStatus(orderId);
  if (!result) {
    await bot.sendMessage(chatId, '<i>⚠️ Gagal mengecek status, coba lagi sebentar.</i>', { parse_mode: 'HTML' });
    return;
  }

  if (result.status === 'SETTLED') {
    await handleFelixPaymentSettled(orderId, payment);
    try { await safeDeleteMessage(chatId, messageId); } catch (e) {}
  } else if (result.status === 'EXPIRED' || result.status === 'CANCELED') {
    payment.status = result.status;
    delete global.activePayments[orderId];
    await bot.sendMessage(chatId, `<blockquote>⚠️ Order ${result.status === 'EXPIRED' ? 'sudah kedaluarsa' : 'dibatalkan'}.</blockquote>`, { parse_mode: 'HTML' });
    try { await safeDeleteMessage(chatId, messageId); } catch (e) {}
  } else {
    await bot.sendMessage(chatId, '<i>⏳ Pembayaran belum terdeteksi. Silakan cek lagi beberapa saat.</i>', { parse_mode: 'HTML' });
  }
  return;
}

// Batalkan order deposit otomatis (Pakasir)
if (data.startsWith('felix_cancel_')) {
  const orderId = data.replace('felix_cancel_', '');
  const payment = global.activePayments?.[orderId];

  if (!payment) {
    await safeAnswerCallbackQuery(callbackQuery, '⚠️ Order tidak ditemukan / sudah selesai', true);
    return;
  }

  const result = await cancelFelixOrder(orderId);
  delete global.activePayments[orderId];

  try { await safeDeleteMessage(chatId, messageId); } catch (e) {}
  await bot.sendMessage(chatId, `<blockquote>${result.success ? '❌ <b>Deposit dibatalkan</b>' : '⚠️ ' + result.message}</blockquote>`, { parse_mode: 'HTML' });
  await safeAnswerCallbackQuery(callbackQuery, result.success ? '✅ Dibatalkan' : '⚠️ Gagal membatalkan');
  return;
}
  
  if (data === 'produk_baru_prev') {
    if (produkBaruCurrentPage[userId] && produkBaruCurrentPage[userId].page > 1) {
      produkBaruCurrentPage[userId].page--;
      await produkBaruShowList(userId, chatId, messageId);
    }
    return;
  }
  
  if (data === 'produk_baru_next') {
    const totalPages = Math.ceil(produkBaruCurrentPage[userId]?.products.length / 10) || 1;
    if (produkBaruCurrentPage[userId] && produkBaruCurrentPage[userId].page < totalPages) {
      produkBaruCurrentPage[userId].page++;
      await produkBaruShowList(userId, chatId, messageId);
    }
    return;
  }
  
  if (data === 'produk_baru_back_to_list') {
    await produkBaruShowList(userId, chatId, messageId);
    return;
  }
  
  if (data === 'produk_baru_deposit_menu') {
    await produkBaruShowDepositMenu(userId, chatId, messageId);
    return;
  }
  
  if (data === 'deposit_minus') {
    if (!produkBaruDepositAmount[userId]) produkBaruDepositAmount[userId] = 5000;
    if (produkBaruDepositAmount[userId] > 5000) produkBaruDepositAmount[userId] -= 5000;
    await produkBaruShowDepositMenu(userId, chatId, messageId);
    return;
  }
  
  if (data === 'deposit_plus') {
    if (!produkBaruDepositAmount[userId]) produkBaruDepositAmount[userId] = 5000;
    produkBaruDepositAmount[userId] += 5000;
    await produkBaruShowDepositMenu(userId, chatId, messageId);
    return;
  }
  
  if (data === 'deposit_custom') {
    await safeAnswerCallbackQuery(callbackQuery);
    await safeEditMessageText('<i>📝 Kirim nominal deposit (minimal 10000):</i>', {
      chat_id: chatId, message_id: messageId, parse_mode: 'HTML'
    });
    global.waitingForDepositCustom = userId;
    return;
  }
  
  if (data.startsWith('deposit_now_')) {
    const nominal = parseInt(data.replace('deposit_now_', ''));
    if (isNaN(nominal) || nominal < 2000 || nominal > 20000) {
      await safeAnswerCallbackQuery(callbackQuery, '❌ Nominal tidak valid', true);
      return;
    }
    await produkBaruDeposit(callbackQuery, userId, chatId, messageId, nominal);
    return;
  }
  
  if (data === 'produk_baru_qty_inc') {
    await produkBaruQtyInc(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data === 'produk_baru_qty_dec') {
    await produkBaruQtyDec(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data === 'produk_baru_confirm') {
    await produkBaruConfirm(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data.startsWith('produk_baru_payment_')) {
    await produkBaruProcessPayment(callbackQuery, userId, chatId, messageId, data);
    return;
  }
  
  if (data.startsWith('produk_baru_detail_')) {
    await produkBaruShowDetail(callbackQuery, userId, chatId, messageId, data);
    return;
  }
  
  if (data.startsWith('produk_baru_buy_saldo_')) {
    await produkBaruBuyWithSaldo(callbackQuery, userId, chatId, messageId, data);
    return;
  }
  
  if (data.startsWith('produk_baru_buy_now_')) {
    await produkBaruBuyWithNow(callbackQuery, userId, chatId, messageId, data);
    return;
  }
  
  if (data.startsWith('produk_baru_edit_')) {
    const productId = parseInt(data.replace('produk_baru_edit_', ''));
    await produkBaruEditForm(callbackQuery, userId, chatId, messageId, productId);
    return;
  }
  
  if (data.startsWith('produk_baru_hapus_')) {
    const productId = parseInt(data.replace('produk_baru_hapus_', ''));
    await produkBaruHapus(callbackQuery, userId, chatId, messageId, productId);
    return;
  }
  
  if (data === 'produk_baru_laporan_stok') {
    await handleProdukBaruLaporanStok(userId, chatId, messageId);
    return;
  }
  
  if (data === 'produk_baru_stok_prev') {
    if (produkBaruCurrentPage[userId] && produkBaruCurrentPage[userId].stokPage > 1) {
      produkBaruCurrentPage[userId].stokPage--;
      await handleProdukBaruLaporanStok(userId, chatId, messageId);
    }
    return;
  }
  
  if (data === 'produk_baru_stok_next') {
    const products = produkBaruData.filter(p => p.is_active === 1);
    const totalPages = Math.ceil(products.length / 10);
    if (produkBaruCurrentPage[userId] && produkBaruCurrentPage[userId].stokPage < totalPages) {
      produkBaruCurrentPage[userId].stokPage++;
      await handleProdukBaruLaporanStok(userId, chatId, messageId);
    }
    return;
  }
  
  if (data === 'produk_baru_edit_nama') {
    await safeAnswerCallbackQuery(callbackQuery);
    await safeEditMessageText(`
<blockquote><b><u>✏️ Edit Nama Produk</u></b></blockquote>
<i>Kirim nama baru untuk produk ini:</i>`, {
      chat_id: chatId, message_id: messageId, parse_mode: 'HTML'
    });
    global.waitingEditProdukBaru = { userId, field: 'nama', productId: produkBaruEditId };
    return;
  }
  
  if (data === 'produk_baru_edit_kode') {
    await safeAnswerCallbackQuery(callbackQuery);
    await safeEditMessageText(`
<blockquote><b><u>✏️ Edit Kode Produk</u></b></blockquote>
<i>Kirim kode baru untuk produk ini:</i>`, {
      chat_id: chatId, message_id: messageId, parse_mode: 'HTML'
    });
    global.waitingEditProdukBaru = { userId, field: 'kode', productId: produkBaruEditId };
    return;
  }
  
  if (data === 'produk_baru_edit_deskripsi') {
    await safeAnswerCallbackQuery(callbackQuery);
    await safeEditMessageText(`
<blockquote><b><u>✏️ Edit Deskripsi</u></b></blockquote>
<i>Kirim deskripsi baru untuk produk ini:</i>`, {
      chat_id: chatId, message_id: messageId, parse_mode: 'HTML'
    });
    global.waitingEditProdukBaru = { userId, field: 'deskripsi', productId: produkBaruEditId };
    return;
  }
  
  if (data === 'produk_baru_edit_harga') {
    await safeAnswerCallbackQuery(callbackQuery);
    await safeEditMessageText(`
<blockquote><b><u>✏️ Edit Harga</u></b></blockquote>
<i>Kirim harga baru (angka):</i>`, {
      chat_id: chatId, message_id: messageId, parse_mode: 'HTML'
    });
    global.waitingEditProdukBaru = { userId, field: 'harga', productId: produkBaruEditId };
    return;
  }
  
  if (data === 'produk_baru_edit_stok') {
    await safeAnswerCallbackQuery(callbackQuery);
    await safeEditMessageText(`
<blockquote><b><u>✏️ Edit Stok</u></b></blockquote>
<i>Kirim stok baru (angka):</i>`, {
      chat_id: chatId, message_id: messageId, parse_mode: 'HTML'
    });
    global.waitingEditProdukBaru = { userId, field: 'stok', productId: produkBaruEditId };
    return;
  }
  
  if (data === 'produk_baru_edit_note') {
    await safeAnswerCallbackQuery(callbackQuery);
    await safeEditMessageText(`
<blockquote><b><u>✏️ Edit Catatan</u></b></blockquote>
<i>Kirim catatan baru untuk produk ini:</i>`, {
      chat_id: chatId, message_id: messageId, parse_mode: 'HTML'
    });
    global.waitingEditProdukBaru = { userId, field: 'note', productId: produkBaruEditId };
    return;
  }
  
  if (data === 'produk_baru_edit_file') {
    await safeAnswerCallbackQuery(callbackQuery);
    await safeEditMessageText(`
<blockquote><b><u>📎 Ganti File</u></b></blockquote>
<i>Kirim file baru (foto, video, dokumen):</i>`, {
      chat_id: chatId, message_id: messageId, parse_mode: 'HTML'
    });
    global.waitingEditProdukBaruFile = { userId, productId: produkBaruEditId };
    return;
  }
  
  if (data === 'produk_baru_edit_file_hapus') {
    await safeAnswerCallbackQuery(callbackQuery);
    const product = produkBaruData.find(p => p.id === produkBaruEditId);
    if (product) {
      produkBaruUpdate(produkBaruEditId, { file_id: null, file_name: null, file_mime: null, file_size: null });
      await safeEditMessageText(`<blockquote>✅ <b>File produk berhasil dihapus!</b></blockquote>`, {
        chat_id: chatId, message_id: messageId, parse_mode: 'HTML'
      });
      setTimeout(async () => {
        await produkBaruEditForm(callbackQuery, userId, chatId, messageId, produkBaruEditId);
      }, 1500);
    }
    return;
  }

  if (data === 'paket_wm' || data === 'paket_wm_self') {
    await handlePaketWm(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data === 'paket_nowm' || data === 'paket_nowm_self') {
    await handlePaketNowm(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data === 'paket_reseller' || data === 'paket_reseller_self') {
    await handlePaketReseller(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data === 'paket_wm_gift') {
    await handlePaketWmGift(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data === 'paket_clone') {
    await handleSewaBot(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data === 'paket_nowm_gift') {
    await handlePaketNowmGift(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data === 'paket_reseller_gift') {
    await handlePaketResellerGift(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data.startsWith('paket_wm_gift_')) {
    await handlePaketWmGiftInput(callbackQuery, userId, chatId, messageId, data.replace('paket_wm_gift_', ''));
    return;
  }
  
  if (data.startsWith('paket_nowm_gift_')) {
    await handlePaketNowmGiftInput(callbackQuery, userId, chatId, messageId, data.replace('paket_nowm_gift_', ''));
    return;
  }
  
  if (data.startsWith('paket_reseller_gift_')) {
    await handlePaketResellerGiftInput(callbackQuery, userId, chatId, messageId, data.replace('paket_reseller_gift_', ''));
    return;
  }
  
  if (data === 'wm_pay_now') {
    await handleWmPayNow(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data === 'nowm_pay_now') {
    await handleNowmPayNow(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data === 'reseller_pay_now') {
    await handleResellerPayNow(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data.startsWith('extend_')) {
    await handleExtend(callbackQuery, userId, chatId, messageId, data);
    return;
  }
  
  if (data === 'wm_incr' || data === 'nowm_incr' || data === 'reseller_incr') {
    if (data === 'wm_incr') await handleWmIncr(callbackQuery, userId, chatId, messageId);
    else if (data === 'nowm_incr') await handleNowmIncr(callbackQuery, userId, chatId, messageId);
    else await handleResellerIncr(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data === 'wm_decr' || data === 'nowm_decr' || data === 'reseller_decr') {
    if (data === 'wm_decr') await handleWmDecr(callbackQuery, userId, chatId, messageId);
    else if (data === 'nowm_decr') await handleNowmDecr(callbackQuery, userId, chatId, messageId);
    else await handleResellerDecr(callbackQuery, userId, chatId, messageId);
    return;
  }

  if (data === 'back_to_toko' || data === 'back_to_paket') {
    await handleBackToToko(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data === 'back_to_owner_menu') {
    await handleBackToOwnerMenu(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data === 'back_main') {
    await handleBackMain(callbackQuery, userId, chatId, messageId);
    return;
  }

  // Fitur /update (v10.6): tombol restart setelah database/kode diperbarui.
  if (data === 'confirm_update_restart') {
    if (!isOwnerId(userId)) {
      await safeAnswerCallbackQuery(callbackQuery, '❌ Hanya owner', true);
      return;
    }
    await safeEditMessageText(`<blockquote>🔄 <b>Merestart proses...</b></blockquote>\n<i>Kalau bot tidak balas dalam 1-2 menit, cek manual lewat SSH.</i>`, {
      chat_id: chatId, message_id: messageId, parse_mode: 'HTML'
    });
    logger.info(`Restart dipicu manual oleh owner via /update (userId=${userId})`);
    try { await saveAutoRestartState(); } catch (e) {}
    setTimeout(() => process.exit(0), 800);
    return;
  }

  if (data === 'group_next' || data === 'group_prev') {
    if (data === 'group_next') await handleGroupNext(callbackQuery, userId, chatId, messageId);
    else await handleGroupPrev(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data === 'use_token') {
    await handleUseToken(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data === 'revoke_token') {
    await handleRevokeToken(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data === 'back_to_token_menu') {
    await handleBackToTokenMenu(callbackQuery, userId, chatId, messageId);
    return;
  }

if (data.startsWith('confirm_logout_')) {
    await handleConfirmLogout(callbackQuery, userId, chatId, messageId, data);
    return;
  }

if (data === 'cancel_logout') {
    await handleCancelLogout(callbackQuery, userId, chatId, messageId);
    return;
  }

  if (data === 'admin_back_to_kelola_pesan') {
    await showAdminKelolaPesanMenu(userId, chatId);
    return;
  }

  if (data === 'admin_cancel_delete_all_pesan' || data === 'admin_cancel_delete_all_groups' || data === 'cancel_reset_all_groups') {
    try {
      await safeEditMessageText(`<blockquote>❌ <b>Dibatalkan.</b></blockquote>`, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML'
      });
    } catch (e) {}
    return;
  }
  
  if (data === 'admin_owner_prev_page') {
    await handleAdminOwnerPrevPage(callbackQuery, userId, chatId);
    return;
  }
  
  if (data === 'admin_owner_next_page') {
    await handleAdminOwnerNextPage(callbackQuery, userId, chatId);
    return;
  }
  
  if (data === 'admin_group_prev') {
    await handleAdminGroupPrev(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data === 'admin_group_next') {
    await handleAdminGroupNext(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data === 'admin_back_to_group_menu') {
    await handleAdminBackToGroupMenu(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data === 'admin_hapus_group_prev') {
    await handleAdminHapusGroupPrev(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data === 'admin_hapus_group_next') {
    await handleAdminHapusGroupNext(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data === 'admin_list_pesan_prev') {
    await handleAdminListPesanPrev(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data === 'admin_list_pesan_next') {
    await handleAdminListPesanNext(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data === 'user_pesan_prev') {
    await handleUserPesanPrev(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data === 'user_pesan_next') {
    await handleUserPesanNext(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data === 'admin_back_to_del_pesan') {
    await handleAdminBackToDelPesan(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data === 'admin_del_pesan_prev') {
    await handleAdminDelPesanPrev(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data === 'admin_del_pesan_next') {
    await handleAdminDelPesanNext(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data.startsWith('admin_delete_group_')) {
    await handleAdminConfirmDeleteGroup(callbackQuery, userId, chatId, messageId, data);
    return;
  }
  
  if (data.startsWith('admin_back_to_group_list_')) {
    await handleAdminBackToGroupList(callbackQuery, userId, chatId, messageId, data);
    return;
  }
  
  if (data.startsWith('admin_select_owner_')) {
    await handleAdminSelectOwner(callbackQuery, userId, chatId, messageId, data);
    return;
  }
  
  if (data.startsWith('admin_select_ubot_')) {
    await handleAdminSelectUbot(callbackQuery, userId, chatId, messageId, data);
    return;
  }
  
  if (data.startsWith('admin_select_message_')) {
    await handleAdminSelectMessage(callbackQuery, userId, chatId, messageId, data);
    return;
  }
  
  if (data === 'set_harga_wm') {
    await handleSetHargaWm(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data === 'set_harga_nowm') {
    await handleSetHargaNowm(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data === 'set_harga_reseller') {
    await handleSetHargaReseller(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data === 'back_to_harga_menu') {
    await handleBackToHargaMenu(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data.startsWith('edit_harga_wm_')) {
    await handleEditHargaWm(callbackQuery, userId, chatId, messageId, data);
    return;
  }
  
  if (data.startsWith('edit_harga_nowm_')) {
    await handleEditHargaNowm(callbackQuery, userId, chatId, messageId, data);
    return;
  }
  
  if (data.startsWith('edit_harga_reseller_')) {
    await handleEditHargaReseller(callbackQuery, userId, chatId, messageId, data);
    return;
  }
  
  if (data.startsWith('harga_prev_')) {
    await handleHargaPrev(callbackQuery, userId, chatId, messageId, data.replace('harga_prev_', ''));
    return;
  }
  
  if (data.startsWith('harga_next_')) {
    await handleHargaNext(callbackQuery, userId, chatId, messageId, data.replace('harga_next_', ''));
    return;
  }

  if (data === 'back_to_ubot_list') {
    await handleBackToUbotList(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data === 'ubot_prev_page') {
    await handleUbotPrevPage(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data === 'ubot_next_page') {
    await handleUbotNextPage(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data.startsWith('select_ubot_')) {
    await handleSelectUbot(callbackQuery, userId, chatId, messageId, data);
    return;
  }
  
  if (data.startsWith('ubot_promo_on_')) {
    await handleUbotPromoOn(callbackQuery, userId, chatId, messageId, data);
    return;
  }
  
  if (data.startsWith('ubot_promo_pause_')) {
    await handleUbotPromoPause(callbackQuery, userId, chatId, messageId, data);
    return;
  }
  
  if (data.startsWith('ubot_promo_stop_')) {
    await handleUbotPromoStop(callbackQuery, userId, chatId, messageId, data);
    return;
  }
  
  if (data.startsWith('ubot_restart_')) {
    await handleUbotRestart(callbackQuery, userId, chatId, messageId, data);
    return;
  }
  
  if (data.startsWith('ubot_refresh_')) {
    await handleUbotRefresh(callbackQuery, userId, chatId, messageId, data);
    return;
  }
  
  if (data.startsWith('ubot_detail_')) {
    await handleUbotDetail(callbackQuery, userId, chatId, messageId, data);
    return;
  }
  
  if (data.startsWith('ubot_delete_')) {
    await handleUbotDelete(callbackQuery, userId, chatId, messageId, data);
    return;
  }
  
  if (data.startsWith('confirm_delete_ubot_')) {
    await handleConfirmDeleteUbot(callbackQuery, userId, chatId, messageId, data);
    return;
  }
  
  if (data === 'cancel_delete_ubot') {
    await handleCancelDeleteUbot(callbackQuery, userId, chatId, messageId);
    return;
  }

  if (data === 'cancel_delete_all') {
    await handleCancelDeleteAll(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data === 'manual_backup') {
    await handleManualBackup(callbackQuery, userId, chatId);
    return;
  }
  
  if (data === 'confirm_broadcast') {
    await handleConfirmBroadcast(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data === 'cancel_broadcast') {
    await handleCancelBroadcast(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data === 'agree_trial') {
    await handleAgreeTrial(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data === 'agree_userbot') {
    await handleAgreeUserbot(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data === 'beli_userbot') {
    await handleBeliUserbot(userId, chatId);
    await safeDeleteMessage(chatId, messageId);
    return;
  }
  
  if (data === 'give_userbot') {
    await handleGiveUserbot(userId, chatId);
    await safeDeleteMessage(chatId, messageId);
    return;
  }
  
  if (data === 'back_to_owner_list') {
    await handleBackToOwnerList(callbackQuery, userId, chatId, messageId);
    return;
  }
  
  if (data.startsWith('confirm_reset_all_groups_')) {
    const ownerId = data.replace('confirm_reset_all_groups_', '');
    await safeAnswerCallbackQuery(callbackQuery, '<i>⏳ Menghapus semua grup...</i>');
    await db.run('DELETE FROM groups WHERE owner_id = ?', ownerId);
    await safeEditMessageText(`<blockquote>✅ <b><u>SEMUA GRUP DIHAPUS</u></b>\n🗑️ <b>Semua grup berhasil dihapus!</b></blockquote>`, {
      chat_id: chatId, message_id: messageId, parse_mode: 'HTML'
    });
    setTimeout(async () => { await safeDeleteMessage(chatId, messageId); }, 2000);
    return;
  }
  
  if (data.startsWith('confirm_delete_all_')) {
    await handleConfirmDeleteAll(callbackQuery, userId, chatId, messageId, data);
    return;
  }
  
  if (data.startsWith('refresh_detail_')) {
    await handleRefreshDetail(callbackQuery, userId, chatId, messageId, data);
    return;
  }
  
  if (data.startsWith('user_select_message_')) {
    await handleUserSelectMessage(callbackQuery, userId, chatId, messageId, data);
    return;
  }

  if (data === 'produk_baru_populer') {
    await handleProdukBaruPopuler(userId, chatId, messageId);
    return;
  }
  } catch (error) {
    logger.error(`callback_query handler error (userId=${userId}, data=${data}):`, error && error.stack ? error.stack : error);
    try {
      await safeAnswerCallbackQuery(callbackQuery, '<i>⚠️ Terjadi error, coba lagi.</i>', true).catch(() => {});
    } catch (e) {}
  }
});

async function handleCancelResetAllGroups(callbackQuery, userId, chatId, messageId) {
  await safeAnswerCallbackQuery(callbackQuery, '❌ Penghapusan dibatalkan');
  await safeDeleteMessage(chatId, messageId);
  await bot.sendMessage(chatId, `❌ <b>Penghapusan grup dibatalkan</b>`, { parse_mode: 'HTML' });
}

async function handleAdminOwnerPrevPage(callbackQuery, userId, chatId) {
  if (global.adminOwnerListPage && global.adminOwnerListPage[userId] > 1) {
    global.adminOwnerListPage[userId]--;
    await handleAdminControlAccount(userId, chatId);
  }
  await safeAnswerCallbackQuery(callbackQuery);
}

async function handleAdminOwnerNextPage(callbackQuery, userId, chatId) {
  const owners = global.adminOwnersData?.[userId]?.owners || [];
  const totalPages = global.adminOwnersData?.[userId]?.totalPages || 1;
  if (global.adminOwnerListPage && global.adminOwnerListPage[userId] < totalPages) {
    global.adminOwnerListPage[userId]++;
    await handleAdminControlAccount(userId, chatId);
  }
  await safeAnswerCallbackQuery(callbackQuery);
}

async function handleUbotPrevPage(callbackQuery, userId, chatId, messageId) {
  if (global.ubotListPage && global.ubotListPage[userId] > 1) {
    global.ubotListPage[userId]--;
    await handleSettingUserbot(userId, chatId, messageId);
  }
  await safeAnswerCallbackQuery(callbackQuery);
}

async function handleUbotNextPage(callbackQuery, userId, chatId, messageId) {
  const ubots = await db.all('SELECT * FROM userbots ORDER BY created_at DESC');
  const totalPages = Math.ceil(ubots.length / 5);
  if (global.ubotListPage && global.ubotListPage[userId] < totalPages) {
    global.ubotListPage[userId]++;
    await handleSettingUserbot(userId, chatId, messageId);
  }
  await safeAnswerCallbackQuery(callbackQuery);
}

async function handleConfirmBroadcast(callbackQuery, userId, chatId, messageId) {
  if (!global.waitingForBroadcast || global.waitingForBroadcast.userId !== userId) {
    await safeAnswerCallbackQuery(callbackQuery, '<i>❌ Tidak ada broadcast yang tertunda.</i>', true);
    return;
  }
  
  await safeAnswerCallbackQuery(callbackQuery, '<i>⏳ Memulai broadcast...</i>');
  
  const broadcastData = global.waitingForBroadcast;
  delete global.waitingForBroadcast;
  
  await safeDeleteMessage(chatId, messageId);
  
  const statusMsg = await bot.sendMessage(chatId, `
<blockquote>⏳ <b><u>BROADCAST DIMULAI</u></b>
📡 <i>Lagi ngirim broadcast...</i></blockquote>`, { parse_mode: 'HTML' });
  
  const users = await db.all('SELECT user_id FROM users');
  let sukses = 0;
  let gagal = 0;
  const effectId = getRandomEffect();
  
  for (let i = 0; i < users.length; i++) {
    try {
      if (broadcastData.msgType === 'photo' && broadcastData.fileId) {
        await bot.sendPhoto(users[i].user_id, broadcastData.fileId, { caption: broadcastData.message, parse_mode: 'HTML', message_effect_id: effectId });
      } else if (broadcastData.msgType === 'video' && broadcastData.fileId) {
        await bot.sendVideo(users[i].user_id, broadcastData.fileId, { caption: broadcastData.message, parse_mode: 'HTML', message_effect_id: effectId });
      } else if (broadcastData.msgType === 'document' && broadcastData.fileId) {
        await bot.sendDocument(users[i].user_id, broadcastData.fileId, { caption: broadcastData.message, parse_mode: 'HTML', message_effect_id: effectId });
      } else if (broadcastData.msgType === 'audio' && broadcastData.fileId) {
        await bot.sendAudio(users[i].user_id, broadcastData.fileId, { caption: broadcastData.message, parse_mode: 'HTML', message_effect_id: effectId });
      } else if (broadcastData.msgType === 'voice' && broadcastData.fileId) {
        await bot.sendVoice(users[i].user_id, broadcastData.fileId, { caption: broadcastData.message, parse_mode: 'HTML', message_effect_id: effectId });
      } else {
        await bot.sendMessage(users[i].user_id, broadcastData.message, { parse_mode: 'HTML', message_effect_id: effectId });
      }
      sukses++;
    } catch (err) {
      gagal++;
    }
    
    if ((i + 1) % 50 === 0) {
      try {
        await safeEditMessageText(`
<blockquote>⏳ <b><u>BROADCAST PROGRESS</u></b>
✅ Sukses: ${sukses}
❌ Gagal: ${gagal}
📊 Progress: ${i + 1}/${users.length} user</blockquote>`, {
          chat_id: chatId,
          message_id: statusMsg.message_id,
          parse_mode: 'HTML'
        });
      } catch (e) {}
    }
    
    await new Promise(r => setTimeout(r, 100));
  }
  
  await safeDeleteMessage(chatId, statusMsg.message_id).catch(() => {});
  
  const finalEffectId = getRandomEffect();
  
  await bot.sendMessage(chatId, `
<blockquote>✅ <b><u>BROADCAST SELESAI!</u></b>
👥 <b>Total user</b> : ${users.length}
✅ <b>Sukses</b> : ${sukses}
❌ <b>Gagal</b> : ${gagal}</blockquote>`, {
    parse_mode: 'HTML',
    message_effect_id: finalEffectId
  });
}

async function handleCancelBroadcast(callbackQuery, userId, chatId, messageId) {
  delete global.waitingForBroadcast;
  await safeAnswerCallbackQuery(callbackQuery, '<i>❌ Broadcast dibatalkan.</i>');
  await safeDeleteMessage(chatId, messageId);
  await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>BROADCAST DIBATALKAN</u></b>
🛑 Broadcast dibatalkan.</blockquote>`, {
    parse_mode: 'HTML',
    reply_markup: await getOwnerMenuKeyboard()
  });
}

async function handlePaketWmGiftInput(callbackQuery, userId, chatId, messageId, targetUserId) {
  userPayments[userId] = { type: 'wm', duration: 1, targetUserId: targetUserId };
  await updatePaketDisplay(chatId, messageId, userId, 'wm');
}

async function handlePaketNowmGiftInput(callbackQuery, userId, chatId, messageId, targetUserId) {
  userPayments[userId] = { type: 'nowm', duration: 1, targetUserId: targetUserId };
  await updatePaketDisplay(chatId, messageId, userId, 'nowm');
}

async function handlePaketResellerGiftInput(callbackQuery, userId, chatId, messageId, targetUserId) {
  userPayments[userId] = { type: 'reseller', duration: 1, targetUserId: targetUserId };
  await updatePaketDisplay(chatId, messageId, userId, 'reseller');
}

async function handleAdminSelectOwner(callbackQuery, userId, chatId, messageId, data) {
  const ownerId = data.replace('admin_select_owner_', '');
  const userbots = await getAllUserbotsByOwner(ownerId);
  
  if (userbots.length === 0) {
    await safeAnswerCallbackQuery(callbackQuery, '<i>❌ Tidak ada userbot yang bisa dikontrol</i>', true);
    return;
  }
  
  if (userbots.length === 1) {
    await showAdminControlMenu(userId, chatId, userbots[0].ubot_id, ownerId);
    await safeDeleteMessage(chatId, messageId);
  } else {
    let response = `
<blockquote>🤖 <b><u>PILIH USERBOT</u></b></blockquote>`;
    const buttons = [];
    const row = [];
    
    for (let i = 0; i < userbots.length; i++) {
      const ubot = userbots[i];
      response += `

<blockquote><b>${i + 1}.</b> <code>${ubot.ubot_id}</code></blockquote>`;
      row.push({ text: `${i + 1}`, callback_data: `admin_select_ubot_${ubot.ubot_id}_${ownerId}` });
      if (row.length === 3 || i === userbots.length - 1) {
        buttons.push([...row]);
        row.length = 0;
      }
    }
    
    response += `

<i>Pilih nomor userbot yang mau dikontrol</i>`;
    
    buttons.push([{ text: '⬅️ Kembali', callback_data: 'back_to_owner_list' }]);
    
    await safeEditMessageText(response, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: 'HTML',
      reply_markup: { inline_keyboard: buttons }
    });
  }
  await safeAnswerCallbackQuery(callbackQuery);
}

async function handleAdminSelectUbot(callbackQuery, userId, chatId, messageId, data) {
  const parts = data.replace('admin_select_ubot_', '').split('_');
  const ubotId = parts[0];
  const ownerId = parts[1];
  await showAdminControlMenu(userId, chatId, ubotId, ownerId);
  await safeDeleteMessage(chatId, messageId);
  await safeAnswerCallbackQuery(callbackQuery);
}

async function handleBackToOwnerList(callbackQuery, userId, chatId, messageId) {
  await safeDeleteMessage(chatId, messageId);
  await handleAdminControlAccount(userId, chatId);
  await safeAnswerCallbackQuery(callbackQuery);
}

async function handleAdminSelectMessage(callbackQuery, userId, chatId, messageId, data) {
  const parts = data.replace('admin_select_message_', '').split('_');
  const messageIdDb = parts[0];
  const ownerId = parts[1];
  
  const selectedMsg = await db.get('SELECT local_id FROM messages WHERE id = ?', messageIdDb);
  
  await db.run('UPDATE settings SET selected_message_id = ? WHERE owner_id = ?', messageIdDb, ownerId);
  
  await safeAnswerCallbackQuery(callbackQuery, `<i>✅ Pesan #${selectedMsg?.local_id} dipilih jadi pesan aktif</i>`);
  
  try {
    await safeEditMessageText(`
<blockquote>✅ <b><u>PESAN AKTIF DIPILIH</u></b>
📝 <b>Pesan #${selectedMsg?.local_id} berhasil dipilih jadi pesan aktif!</b></blockquote>`, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: 'HTML'
    });
  } catch (e) {}
  
  setTimeout(async () => {
    try {
      await safeDeleteMessage(chatId, messageId);
    } catch (e) {}
    await showAdminKelolaPesanMenu(userId, chatId);
  }, 2000);
}

async function handleAdminConfirmDeleteAllGroups(callbackQuery, userId, chatId, messageId, data) {
  const ownerId = data.replace('admin_confirm_delete_all_groups_', '');
  await db.run('DELETE FROM groups WHERE owner_id = ?', ownerId);
  await safeEditMessageText(`
<blockquote>✅ <b><u>SEMUA GRUP DIHAPUS</u></b>
🗑️ <b>Semua grup berhasil dihapus!</b></blockquote>`, {
    chat_id: chatId,
    message_id: messageId,
    parse_mode: 'HTML'
  });
  await safeAnswerCallbackQuery(callbackQuery);
}

async function handleAdminBackToKelolaPesan(callbackQuery, userId, chatId, messageId) {
  await safeDeleteMessage(chatId, messageId);
  await showAdminKelolaPesanMenu(userId, chatId);
  await safeAnswerCallbackQuery(callbackQuery);
}

async function handleAdminCancelDeleteAllGroups(callbackQuery, userId, chatId, messageId) {
  await safeDeleteMessage(chatId, messageId);
  await safeAnswerCallbackQuery(callbackQuery, '<i>Penghapusan dibatalkan</i>');
}

async function handleCancelAction(userId, chatId) {
  const sessions = [
    'waitingForPhone', 'waitingForPhoneTrial', 'waitingForOTP', 'waitingForOTPTrial',
    'waitingForSession', 'waitingForSessionTrial',
    'waitingFor2FA', 'waitingForWatermark', 'waitingForAddGroup', 'waitingForAddBlacklist',
    'waitingForDeleteBlacklist', 'waitingForDeleteMessage', 'waitingForAddTrigger',
    'waitingForTriggerResponse', 'waitingForAddChannel', 'waitingForDelay', 'waitingForJeda', 
 'waitingForToken', 'waitingForEditName', 'waitingForEditBio', 
    'waitingForEditUsername', 'waitingForEditPhoto', 'waitingForMessage', 'waitingForSelectMessage', 
    'waitingForDeleteAll', 'waitingForJoinGroup', 'waitingForLeaveGroup', 
    'waitingForDelResellerAdded', 'waitingForAddWM', 'waitingForAddWMOwner',
    'waitingForGiveUserId', 'waitingForBroadcast', 'waitingForBroadcastPM',
    'waitingForCreateToken', 'waitingForDeleteToken',
    'waitingForDelPremium', 'waitingForAddReseller', 'waitingForDelReseller',
    'waitingForAddAdminInput', 'waitingForRemoveAdminInput',
    'waitingForAdminSetPesan', 'waitingForAdminDelPesan', 'waitingForAdminTambahGroupManual',
    'waitingForAdminHapusGroupManual', 'waitingForAdminSetDelay', 'waitingForAdminSetJeda',
    'waitingForAdminBroadcastPM'
  ];
  
  sessions.forEach(session => {
    if (global[session]) {
      if (global[session][userId]) delete global[session][userId];
    }
  });
  
  if (waitingForGiveUserId && waitingForGiveUserId[userId]) delete waitingForGiveUserId[userId];
  if (chatSessions && chatSessions[userId]) delete chatSessions[userId];
  if (global.loginSessions && global.loginSessions[userId]) delete global.loginSessions[userId];
  if (global.otpAttempts && global.otpAttempts[userId]) delete global.otpAttempts[userId];
  if (global.twoFAAttempts && global.twoFAAttempts[userId]) delete global.twoFAAttempts[userId];
  if (global.waitingForAddTrigger && global.waitingForAddTrigger[userId]) delete global.waitingForAddTrigger[userId];
  if (global.waitingForTriggerResponse && global.waitingForTriggerResponse[userId]) delete global.waitingForTriggerResponse[userId];
  if (global.waitingForAddChannel && global.waitingForAddChannel[userId]) delete global.waitingForAddChannel[userId];
  if (global.waitingForForwardLink) delete global.waitingForForwardLink;
  if (global.waitingForSelectMessage && global.waitingForSelectMessage[userId]) delete global.waitingForSelectMessage[userId];
  
  await bot.sendMessage(chatId, `
<blockquote>➡️ <b><u>Kembali ke menu utama</u></b></blockquote>`, { 
    parse_mode: 'HTML',
    reply_markup: await getMainMenuKeyboard(userId)
  });
}

async function handleUbahNotif(userId, chatId) {
  const settings = await db.get('SELECT notif_target, notif_to_saved FROM settings WHERE owner_id = ?', userId);
  
  let targetDisplay = '<b>Default (Pemilik Userbot)</b>';
  let savedDisplay = '❌ <b>Tidak</b>';
  
  if (settings && settings.notif_target && settings.notif_target !== userId) {
    targetDisplay = `<code>${settings.notif_target}</code>`;
  }
  if (settings && settings.notif_to_saved === 1) {
    savedDisplay = '✅ <b>Ya (Saved Messages)</b>';
  }
  
  const caption = `
<blockquote>📨 <b><u>UBAH NOTIFIKASI BROADCAST</u></b></blockquote>
<blockquote><b>🎯 Target</b> : ${targetDisplay}
<b>📝 Kirim ke Saved Messages</b> : ${savedDisplay}</blockquote>

<i>Notifikasi akan dikirim saat broadcast selesai</i>
<i>Pengirim: USERBOT (bukan BOT)</i>

<b>Pilih menu di bawah:</b>`;

  await bot.sendMessage(chatId, caption, {
    parse_mode: 'HTML',
    reply_markup: {
      keyboard: [
        ['👤 Daftar Pengguna', '📝 Pesan Tersimpan'],
        ['🔄 Reset Notifikasi', '🔙 Kembali']
      ],
      resize_keyboard: true
    }
  });
}

async function handleNotifUserLain(userId, chatId) {
  const ubot = userbots.find(ub => ub.owner_id === userId);
  if (!ubot) {
    await bot.sendMessage(chatId, `<blockquote>❌ Userbot tidak ditemukan.</blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  await bot.sendMessage(chatId, `
<blockquote>👤 <b><u>SET TARGET USERS</u></b></blockquote>
<blockquote><b>Contoh:</b>
<code>123456789</code> (User ID)
<code>@username</code> (Username)</blockquote>

<i>Ketik <b>❌ Batalkan</b> untuk batal.</i>`, {
    parse_mode: 'HTML',
    reply_markup: { keyboard: [['❌ Batalkan']], resize_keyboard: true, one_time_keyboard: true }
  });
  
  global.waitingForNotifTarget = true;
  global.notifTargetUserId = userId;
}

async function handleSetNotifTargetInput(userId, chatId, text) {
  if (!global.waitingForNotifTarget) return;
  delete global.waitingForNotifTarget;
  
  const ownerId = global.notifTargetUserId;
  delete global.notifTargetUserId;
  
  const ubot = userbots.find(ub => ub.owner_id === ownerId);
  if (!ubot) {
    await bot.sendMessage(chatId, `<blockquote>❌ Userbot tidak ditemukan.</blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  let targetId = text.trim();
  let targetDisplay = '';
  
  try {
    if (targetId.startsWith('@')) {
      const username = targetId.replace('@', '');
      const entity = await ubot.client.getEntity(username);
      targetId = entity.id.toString();
      targetDisplay = `@${username} (${targetId})`;
    } else if (/^\d+$/.test(targetId)) {
      const entity = await ubot.client.getEntity(parseInt(targetId));
      targetDisplay = `${entity.firstName || ''} ${entity.lastName || ''}`.trim() || entity.username || targetId;
      if (entity.username) targetDisplay += ` (@${entity.username})`;
      targetDisplay += ` (${targetId})`;
    } else {
      await bot.sendMessage(chatId, `<blockquote>❌ Format salah!</blockquote>`, { parse_mode: 'HTML' });
      await handleUbahNotif(ownerId, chatId);
      return;
    }
  } catch (error) {
    await bot.sendMessage(chatId, `<blockquote>❌ Target tidak valid</blockquote>`, { parse_mode: 'HTML' });
    await handleUbahNotif(ownerId, chatId);
    return;
  }
  
  await db.run('UPDATE settings SET notif_target = ? WHERE owner_id = ?', targetId, ownerId);
  
  const cek = await db.get('SELECT notif_target FROM settings WHERE owner_id = ?', ownerId);
  console.log(`Notif target saved for ${ownerId}:`, cek);
  
  await bot.sendMessage(chatId, `<blockquote>✅ Target berhasil diatur ke: ${targetDisplay}</blockquote>`, { parse_mode: 'HTML' });
  await handleUbahNotif(ownerId, chatId);
}

async function handleNotifSaved(userId, chatId) {
  const ubot = userbots.find(ub => ub.owner_id === userId);
  if (!ubot) {
    await bot.sendMessage(chatId, `<blockquote>❌ Userbot tidak ditemukan.</blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const current = await db.get('SELECT notif_to_saved FROM settings WHERE owner_id = ?', userId);
  const newValue = current?.notif_to_saved === 1 ? 0 : 1;
  
  await db.run('UPDATE settings SET notif_to_saved = ? WHERE owner_id = ?', newValue, userId);
  
  const cek = await db.get('SELECT notif_to_saved FROM settings WHERE owner_id = ?', userId);
  console.log(`Notif to saved for ${userId}:`, cek);
  
  const status = newValue === 1 ? '✅ AKTIF' : '❌ NONAKTIF';
  
  await bot.sendMessage(chatId, `
<blockquote>📝 SAVED MESSAGES</blockquote>
<blockquote>Status kirim ke Saved Messages: ${status}</blockquote>
<blockquote>${newValue === 1 ? 'Notifikasi akan dikirim ke Saved Messages Telegram via USERBOT' : 'Notifikasi akan dikirim ke chat biasa'}</blockquote>`, {
    parse_mode: 'HTML'
  });
  
  await handleUbahNotif(userId, chatId);
}

async function handleResetNotif(userId, chatId) {
  await db.run('UPDATE settings SET notif_target = NULL, notif_to_saved = 0 WHERE owner_id = ?', userId);
  
  await bot.sendMessage(chatId, `
<blockquote>✅ <b>NOTIFIKASI RESET</b>
📨 <b>Notifikasi broadcast kembali ke default!</b></blockquote>

<i>Notifikasi akan dikirim ke pemilik userbot</i>`, {
    parse_mode: 'HTML'
  });
  
  await handleUbahNotif(userId, chatId);
}

async function handleBackOrBeranda(msg, userId, chatId) {
  const hasUbot = await userHasUserbot(userId);
  
  if (hasUbot) {
    const ubot = userbots.find(ub => ub.owner_id === userId);
    const settings = await db.get('SELECT promosi_status FROM settings WHERE owner_id = ?', userId) || { promosi_status: 'OFF' };
    const role = await getUserRole(userId);
    const user = await db.get('SELECT expired FROM users WHERE user_id = ?', userId);
    const expired = user?.expired ? moment(user.expired * 1000).format('DD-MM-YYYY HH:mm') : '-';
    
    let paketName = '';
    if (role === 'PREMIUM_WM') paketName = '🧩 Plan Basic';
    else if (role === 'PREMIUM_NO_WM') paketName = '💎 Plan Pro';
    else if (role === 'RESELLER') paketName = '🎟 Akses Reseller';
    else if (role === 'TRIAL') paketName = `✨ Free Lifetime (20 Grup)`;
    else paketName = '✨ Free Deploy';
    
    const statusPromosi = settings.promosi_status === 'ON' ? `✅ Aktif` : `❌ Nonaktif`;
    
    const caption = `
<blockquote>📖 <b><u>INFO USERBOT</u></b></blockquote>
<blockquote>📣 Auto Promosi : ${statusPromosi}
🤖 ID Userbot : <code>${ubot?.id || '-'}</code>
🛒 Paket : ${paketName}
🗓 Habis : ${expired}</blockquote>

👇 <i>Pilih tombol di bawah sesuai kebutuhan!</i>`;
    
    const keyboard = await getMainMenuKeyboard(userId);
    
    await bot.sendMessage(chatId, caption, { 
      parse_mode: 'HTML',
      reply_markup: keyboard 
    });
    
  } else {
    const firstName = msg.from.first_name || 'User';
    const botInfo = await getCachedBotInfo();
    const botFirstName = botInfo.first_name || 'Xavier-Jaseb Bot';
    const botUsername = botInfo.username || 'XavierJasebBot';
    const systemInfoBlock = await getSystemInfoBlock();
    
    const caption = `
<b><u>🚀 WELCOME TO USERBOT JASEB</u></b>

${systemInfoBlock}

<i>Ready to start? 👇</i>`;
    
    const keyboard = await getMainMenuKeyboard(userId);
    
    await bot.sendMessage(chatId, caption, { 
      parse_mode: 'HTML',
      reply_markup: keyboard 
    });
  }
}

async function handleTrialUserbot(userId, chatId) {
  if (!config.ENABLED) {
    return;
  }
  
  const user = await db.get('SELECT * FROM users WHERE user_id = ?', userId);
  const hasUbot = await userHasUserbot(userId);
  
  if (hasUbot) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>GAGAL</u></b>
🤖 Kamu udah punya userbot.</blockquote>`, { 
      parse_mode: 'HTML',
      reply_markup: await getBackKeyboard() 
    });
    return;
  }
  
  // Catatan: deploy gratis SENGAJA bisa dipakai berkali-kali (sesuai T&C di bawah),
  // jadi gak ada pengecekan trial_used di sini. Satu-satunya batasan adalah
  // "gak boleh deploy baru kalau masih ada userbot aktif" (dicek di atas).
  
  const caption = `
<blockquote>✨ <b>FREE PREMIUM ACCESS</b></blockquote>

<blockquote><b>🎯 LIFETIME PREMIUM FEATURES</b>
✅ Full akses semua fitur premium
✅ Auto broadcast tanpa batasan waktu
✅ Bisa deploy userbot kapan aja
✅ Watermark bisa diatur sendiri
✅ Support forward message</blockquote>

<blockquote><b>📊 BATASAN GRUP</b>
⚠️ Maksimal <b>20 grup target</b>
💡 Kenapa dibatasi?
 • Menjaga kualitas server
 • Mencegah penyalahgunaan
 • Bagi yang butuh lebih, upgrade ke paket berbayar
 • Supaya semua user bisa menikmati layanan gratis dengan stabil</blockquote>

<blockquote><b>🔹 Syarat & Ketentuan</b>
• Bisa deploy berkali-kali
• 1 userbot aktif per user
• Grup otomatis dibatasi 20
• Resiko pemakaian: <a href="https://telegra.ph/RESIKO-USERBOT-AUTO-05-12">Baca Disini</a></blockquote>

<blockquote><b>✅ Next Step</b>
Tekan <b>✅ Setuju Free</b> untuk mulai deploy</blockquote>

<i>Pilih opsi di bawah</i>`;

  await bot.sendMessage(chatId, caption, { 
    parse_mode: 'HTML', 
    disable_web_page_preview: true,
    reply_markup: {
      keyboard: [[{ text: '✅ Klaim Userbot Gratis' }], [{ text: '🏠 Beranda' }]],
      resize_keyboard: true
    }
  });
}

async function handleSayaSetujuTrial(userId, chatId) {
  const hasUbot = await userHasUserbot(userId);
  
  if (hasUbot) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>GAGAL</u></b>
🤖 <b>Kamu udah punya userbot.</b></blockquote>`, { 
      parse_mode: 'HTML',
      reply_markup: await getBackKeyboard() 
    });
    return;
  }
  
  const caption = `
<blockquote><b><u>Silahkan pilih cara login userbot kamu.</u></b></blockquote>
<blockquote>📱 <b>Kirim Kontak</b> — login via nomor telepon + OTP
🔑 <b>Login dengan Session</b> — login langsung pakai String Session Pyrogram/Telethon/GramJS</blockquote>`;

  await bot.sendMessage(chatId, caption, { 
    parse_mode: 'HTML', 
    reply_markup: { 
      keyboard: [
        [{ text: '📱 Kirim Kontak', request_contact: true }, { text: '🔑 Login dengan Session' }],
        [{ text: `❌ Batalkan` }]
      ], 
      resize_keyboard: true, 
      one_time_keyboard: true 
    }
  });
  
  global.waitingForPhoneTrial = global.waitingForPhoneTrial || {};
  global.waitingForPhoneTrial[userId] = true;
}

async function handleStatusAkun(userId, chatId) {
  const ubot = userbots.find(ub => ub.owner_id === userId);
  const botInfo = await getCachedBotInfo();
  const botName = botInfo.first_name || 'RN Jaseb V2';
  
  const getUptime = () => {
    const uptimeSeconds = process.uptime();
    const days = Math.floor(uptimeSeconds / 86400);
    const hours = Math.floor((uptimeSeconds % 86400) / 3600);
    const minutes = Math.floor((uptimeSeconds % 3600) / 60);
    const seconds = Math.floor(uptimeSeconds % 60);
    return `${days}d : ${hours}h : ${minutes}m : ${seconds}s`;
  };
  
  let statusText = '❌ Tidak Aktif';
  let userType = 'Costumer';
  let planText = 'Basic';
  let expiredText = 'None';
  let uptimeText = getUptime();
  let tokenText = '-';
  let promosiStatus = 'Off';
  
  if (ubot) {
    const role = await getUserRole(userId);
    const settings = await db.get('SELECT promosi_status FROM settings WHERE owner_id = ?', userId) || { promosi_status: 'OFF' };
    const user = await db.get('SELECT expired FROM users WHERE user_id = ?', userId);
    
    statusText = '✅ Aktif';
    
    if (role === 'PREMIUM_WM') {
      userType = 'Premium';
      planText = '🧩 Plan Basic';
    } else if (role === 'PREMIUM_NO_WM') {
      userType = 'Premium';
      planText = '💎 Plan Pro';
    } else if (role === 'RESELLER') {
      userType = 'Reseller';
      planText = '🎟 Akses Reseller';
    } else if (role === 'TRIAL') {
      userType = 'Free';
      planText = `✨ Free Lifetime (20 Grup)`;
    } else {
      userType = 'Free';
      planText = '✨ Free Deploy';
    }
    
    if (settings.promosi_status === 'ON') {
      promosiStatus = 'On';
    }
    
    if (user?.expired) {
      const expiredDate = new Date(user.expired * 1000);
      const now = new Date();
      const daysLeft = Math.ceil((expiredDate - now) / (1000 * 60 * 60 * 24));
      
      if (daysLeft > 0) {
        expiredText = `${expiredDate.toLocaleDateString('id-ID')} (${daysLeft} hari)`;
      } else {
        expiredText = `${expiredDate.toLocaleDateString('id-ID')} (Expired)`;
        statusText = '⚠️ Expired';
      }
    }
    
    const tokens = await db.get('SELECT token FROM tokens WHERE owner_id = ? AND used = 0 AND expired_at > ?', userId, Math.floor(Date.now() / 1000));
    if (tokens) {
      tokenText = tokens.token.substring(0, 10) + '...';
    }
    
    const startTime = ubot.startTime || Date.now();
    const uptimeSeconds = Math.floor((Date.now() - startTime) / 1000);
    const days = Math.floor(uptimeSeconds / 86400);
    const hours = Math.floor((uptimeSeconds % 86400) / 3600);
    const minutes = Math.floor((uptimeSeconds % 3600) / 60);
    const seconds = uptimeSeconds % 60;
    uptimeText = `${days}d : ${hours}h : ${minutes}m : ${seconds}s`;
  }
  
  const caption = `
<blockquote>📊 <b><u>Status Akun</u></b></blockquote>

<blockquote>🔸 <b>Status</b>       : ${statusText}
🔸 <b>Tipe User</b>   : ${userType}
🔸 <b>Paket</b>       : ${planText}
🔸 <b>Auto Promosi</b> : ${promosiStatus}
🔸 <b>Masa Aktif</b>  : ${expiredText}</blockquote>

<blockquote>⏱ <b>Uptime Bot</b> : ${uptimeText}
🎫 <b>Token</b>      : <code>${tokenText}</code></blockquote>

<blockquote><i>Ketik "🔙 Kembali" untuk balik ke menu utama</i></blockquote>`;

  await bot.sendMessage(chatId, caption, {
    parse_mode: 'HTML',
    reply_markup: {
      keyboard: [[`🔙 Kembali`]],
      resize_keyboard: true
    }
  });
}

async function handleMulaiTrial(userId, chatId) {
  const hasUbot = await userHasUserbot(userId);
  
  if (hasUbot) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>GAGAL</u></b>
🤖 <b>Kamu udah punya userbot.</b></blockquote>`, { 
      parse_mode: 'HTML',
      reply_markup: await getBackKeyboard() 
    });
    return;
  }
  
  const caption = `
<blockquote><b>⭐ RULES & TERMS</b>

<b>🔹 Refund Policy</b>
• Refund available within 48 hours after purchase
• Only valid if features haven't been used
• Once used, refund is not applicable

<b>⚠️ Disclaimer</b>
• Complete guide available in this bot
• Userbot risks: <a href="https://telegra.ph/RESIKO-USERBOT-AUTO-05-12">Read Here</a>
• Purchase means you accept all risks

<b>✅ Next Step</b>
• Click button below to continue

<i>Select your option below</i></blockquote>`;

  await bot.sendMessage(chatId, caption, { 
    parse_mode: 'HTML',
    disable_web_page_preview: true,
    reply_markup: {
      inline_keyboard: [
        [
          { text: '❌ Batal', callback_data: 'back_main' },
          { text: '✅ Saya Setuju', callback_data: 'agree_trial' }
        ]
      ]
    }
  });
}

async function handleBuatUserbot(userId, chatId) {
  const role = await getUserRole(userId);
  const hasAccess = ['PREMIUM_WM', 'PREMIUM_NO_WM', 'RESELLER', 'OWNER'].includes(role);
  
  if (hasAccess) {
    const caption = `
<blockquote><b>🤖 RULES & TERMS</b>

<b>⭐ Refund Policy</b>
• Refund available within 48 hours after purchase
• Only valid if features haven't been used
• Once used, refund is not applicable

<b>⚠️ Disclaimer</b>
• Complete guide available in this bot
• Userbot risks: <a href="https://telegra.ph/RESIKO-USERBOT-AUTO-05-12">Read Here</a>
• Purchase means you accept all risks

<b>✅ Next Step</b>
• Click button below to continue

<i>Select your option below</i></blockquote>
`;

    await bot.sendMessage(chatId, caption, { 
      parse_mode: 'HTML',
      disable_web_page_preview: true,
      reply_markup: {
        inline_keyboard: [
          [
            { text: '✅ Saya Setuju', callback_data: 'agree_userbot' },
            { text: '❌ Batal', callback_data: 'back_main' }
          ]
        ]
      }
    });
  } else {
    const caption = `
<blockquote>⚠️ <b><u>HARUS BERLANGGANAN DULU</u></b></blockquote>
<blockquote>Pilih salah satu:</blockquote>`;

    await bot.sendMessage(chatId, caption, {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [
            { text: '🛒 Beli Userbot', callback_data: 'beli_userbot' },
            { text: '🎁 Berikan Userbot', callback_data: 'give_userbot' }
          ],
          [
            { text: '⬅️ Kembali', callback_data: 'back_main' }
          ]
        ]
      }
    });
  }
}

async function handleAgreeTrial(callbackQuery, userId, chatId, messageId) {
  await safeAnswerCallbackQuery(callbackQuery);
  await safeDeleteMessage(chatId, messageId);
  await handleSayaSetujuTrial(userId, chatId);
}

async function handleAgreeUserbot(callbackQuery, userId, chatId, messageId) {
  await safeAnswerCallbackQuery(callbackQuery);
  await safeDeleteMessage(chatId, messageId);
  
  // CEK ULANG ROLE & DATA PREMIUM SEBELUM DEPLOY
  const role = await getUserRole(userId);
  const hasAccess = ['PREMIUM_WM', 'PREMIUM_NO_WM', 'RESELLER', 'OWNER'].includes(role);
  
  let hasPremiumData = false;
  const now = Math.floor(Date.now() / 1000);
  
  if (role === 'PREMIUM_WM') {
    const data = await db.get('SELECT * FROM premium_wm WHERE user_id = ? AND expired > ?', userId, now);
    if (data) hasPremiumData = true;
  } else if (role === 'PREMIUM_NO_WM') {
    const data = await db.get('SELECT * FROM premium_no_wm WHERE user_id = ? AND expired > ?', userId, now);
    if (data) hasPremiumData = true;
  } else if (role === 'RESELLER') {
    const data = await db.get('SELECT * FROM reseller_list WHERE user_id = ?', userId);
    if (data) hasPremiumData = true;
  } else if (role === 'OWNER') {
    hasPremiumData = true;
  }
  
  // CEK GIFT DARI RESELLER
  if (!hasPremiumData) {
    const giftData = await db.get('SELECT * FROM reseller_added WHERE user_id = ? AND expired > ?', userId, now);
    if (giftData) hasPremiumData = true;
  }
  
  if (!hasAccess || !hasPremiumData) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>GA BISA DEPLOY</u></b>
⚠️ Kamu belum punya akses premium yang valid.
🎁 Kalau dapat gift, pastikan sudah dikonfirmasi owner.</blockquote>
<i>Hubungi pengirim gift atau ${OWNER_USERNAME}.</i>`, { parse_mode: 'HTML' });
    return;
  }
  
  await handleSayaSetuju(userId, chatId);
}

async function handleSayaSetuju(userId, chatId) {
  const role = await getUserRole(userId);
  const hasUbot = await userHasUserbot(userId);
  const hasAccess = ['PREMIUM_WM', 'PREMIUM_NO_WM', 'RESELLER', 'OWNER'].includes(role);
  
  // CEK DATA PREMIUM DI TABEL - PASTIKAN VALID
  let hasPremiumData = false;
  const now = Math.floor(Date.now() / 1000);
  
  if (role === 'PREMIUM_WM') {
    const data = await db.get('SELECT * FROM premium_wm WHERE user_id = ? AND expired > ?', userId, now);
    if (data) hasPremiumData = true;
  } else if (role === 'PREMIUM_NO_WM') {
    const data = await db.get('SELECT * FROM premium_no_wm WHERE user_id = ? AND expired > ?', userId, now);
    if (data) hasPremiumData = true;
  } else if (role === 'RESELLER') {
    const data = await db.get('SELECT * FROM reseller_list WHERE user_id = ?', userId);
    if (data) hasPremiumData = true;
  } else if (role === 'OWNER') {
    hasPremiumData = true; // Owner selalu punya akses
  }
  
  // CEK JUGA APAKAH USER DAPAT GIFT DARI RESELLER
  if (!hasPremiumData) {
    const giftData = await db.get('SELECT * FROM reseller_added WHERE user_id = ? AND expired > ?', userId, now);
    if (giftData) hasPremiumData = true;
  }
  
  if (!hasAccess || !hasPremiumData) {
    const caption = `
<blockquote>❌ <b><u>GA BISA DEPLOY</u></b></blockquote>
<blockquote>⚠️ Kamu belum punya akses premium yang valid.</blockquote>
<blockquote>🎁 Kalau dapat gift dari reseller/owner, pastikan sudah dikonfirmasi.</blockquote>

<i>Silakan hubungi ${OWNER_USERNAME} untuk bantuan.</i>`;

    await bot.sendMessage(chatId, caption, { 
      parse_mode: 'HTML', 
      reply_markup: { keyboard: [[{ text: '🔙 Kembali' }]], resize_keyboard: true } 
    });
    return;
  }
  
  if (hasUbot) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>GAGAL</u></b>
🤖 <b>Kamu udah punya userbot, ga bisa bikin lagi.</b></blockquote>`, { 
      parse_mode: 'HTML',
      reply_markup: await getBackKeyboard() 
    });
    return;
  }
  
  const caption = `
<blockquote><b><u>Silahkan pilih cara login userbot kamu.</u></b></blockquote>
<blockquote>📱 <b>Kirim Kontak</b> — login via nomor telepon + OTP
🔑 <b>Login dengan Session</b> — login langsung pakai String Session Pyrogram/Telethon/GramJS</blockquote>`;

  await bot.sendMessage(chatId, caption, { 
    parse_mode: 'HTML', 
    reply_markup: { 
      keyboard: [
        [{ text: '📱 Kirim Kontak', request_contact: true }, { text: '🔑 Login dengan Session' }],
        [{ text: `❌ Batalkan` }]
      ], 
      resize_keyboard: true, 
      one_time_keyboard: true 
    }
  });
  
  global.waitingForPhone = global.waitingForPhone || {};
  global.waitingForPhone[userId] = true;
}

async function handleBeliProduk(userId, chatId) {
  await produkBaruShowList(userId, chatId);
}

async function handleBeliUserbot(userId, chatId) {
    const caption = `
<blockquote>🛍️ <b><u>PILIH PAKET USERBOT</u></b>
Bandingkan dulu manfaat tiap paket sebelum lanjut 👇</blockquote>
<blockquote>🧩 <b>BASIC</b>
✅ Fitur AutoBC (auto broadcast)
✅ Kirim pesan teks, gambar, video, dokumen
✅ Delay custom (atur jeda kirim)
✅ Support multiple sesi (banyak group sekaligus)
✅ Manual broadcast (kirim manual)
✅ Cocok untuk kebutuhan standar/harian
✅ Unlimited group
✅ Lebih stabil & performa optimal
❌ Tanpa AutoForward
❌ Tanpa Share Forward
❌ Pesan terkirim masih ada watermark</blockquote>
<blockquote>💎 <b>PRO</b>
✅ Semua fitur Basic
✅ Tanpa watermark (pesan bersih profesional)
✅ AutoForward aktif (otomatis forward ke group lain)
✅ Share Forward (share pesan dari group lain)
✅ Unlimited group
✅ Prioritas support (respon lebih cepat)
✅ Tampilan pesan lebih bersih & premium
✅ Cocok kalau butuh tampilan pesan yang lebih bersih
✅ Ideal untuk bisnis & branding</blockquote>
<blockquote>🎟️ <b>RESELLER</b>
✅ Semua fitur Pro
✅ Bisa buka layanan sewa userbot pakai kuota kami sendiri (tanpa batas jumlah user)
✅ Kelola pelanggan sendiri
✅ Profit 100% milik kamu
✅ Bebas atur harga jual
✅ Dapat database terpisah
✅ Akses owner penuh
✅ Free rename bot
✅ Support prioritas utama
✅ Cocok buat yang mau jualan ulang ke pelanggan sendiri
✅ Wajib join group/channel sendiri</blockquote>
<blockquote><i>Fitur di tiap paket bisa berubah sewaktu-waktu mengikuti pengembangan bot.</i></blockquote>`;

    await bot.sendMessage(chatId, caption, {
        parse_mode: 'HTML',
        reply_markup: {
            inline_keyboard: [
                [
                    { text: '🧩 Pilih Basic', callback_data: 'paket_wm_self' },
                    { text: '💎 Pilih Pro', callback_data: 'paket_nowm_self' }
                ],
                [
                    { text: '🎟️ Pilih Reseller', callback_data: 'paket_reseller_self' }
                ],
                [
                    { text: '⬅️ Kembali', callback_data: 'back_main' }
                ]
            ]
        }
    });
}

async function handlePerpanjangUserbot(userId, chatId) {
  const ubot = userbots.find(ub => ub.owner_id === userId);
  
  if (!ubot) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Userbot tidak ditemukan.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const role = await getUserRole(userId);
  const sisaHari = ubot.expired ? Math.max(0, Math.floor((ubot.expired - Math.floor(Date.now() / 1000)) / 86400)) : 0;
  
  let pricePerMonth = 0;
  let paketEmoji = '';
  let paketNama = '';
  
  if (role === 'PREMIUM_WM') {
    const prices = await db.get(`SELECT * FROM prices WHERE type = 'wm'`);
    pricePerMonth = prices?.price_1 || 2000;
    paketEmoji = '🧩';
    paketNama = 'Plan Basic (WM)';
  } else if (role === 'PREMIUM_NO_WM') {
    const prices = await db.get(`SELECT * FROM prices WHERE type = 'nowm'`);
    pricePerMonth = prices?.price_1 || 4000;
    paketEmoji = '💎';
    paketNama = 'Plan Pro (NO WM)';
  } else if (role === 'RESELLER') {
    const prices = await db.get(`SELECT * FROM prices WHERE type = 'reseller'`);
    pricePerMonth = prices?.price_1 || 7000;
    paketEmoji = '🎟';
    paketNama = 'Akses Reseller';
  } else {
    pricePerMonth = 0;
    paketEmoji = '❓';
    paketNama = 'Unknown';
  }
  
  // Kalo pricePerMonth 0, kasih tau user
  if (pricePerMonth === 0) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
⚠️ <b>Paket tidak dikenali atau tidak memiliki harga.</b>
📝 <i>Hubungi owner untuk info lebih lanjut.</i></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const caption = `
<blockquote>⚙️ <b><u>PERPANJANG USERBOT</u></b></blockquote>
<blockquote>🆔 <b>ID Userbot</b> : <code>${ubot.id}</code>
🛒 <b>Paket Saat Ini</b> : ${paketEmoji} ${paketNama}
🗓 <b>Sisa Masa Aktif</b> : ${sisaHari} hari</blockquote>
<blockquote>📖 <b>Pilih durasi perpanjang</b>
 • 1 bulan = <b>Rp ${pricePerMonth.toLocaleString()}</b>
 • 2 bulan = <b>Rp ${(pricePerMonth * 2).toLocaleString()}</b>
 • 3 bulan = <b>Rp ${(pricePerMonth * 3).toLocaleString()}</b>
 • 6 bulan = <b>Rp ${(pricePerMonth * 6).toLocaleString()}</b>
 • 12 bulan = <b>Rp ${(pricePerMonth * 12).toLocaleString()}</b></blockquote>

<i>Pilih durasi di bawah</i>`;

  await bot.sendMessage(chatId, caption, {
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [
          { text: '1 Bulan', callback_data: 'extend_1' },
          { text: '2 Bulan', callback_data: 'extend_2' },
          { text: '3 Bulan', callback_data: 'extend_3' }
        ],
        [
          { text: '6 Bulan', callback_data: 'extend_6' },
          { text: '12 Bulan', callback_data: 'extend_12' }
        ],
        [
          { text: '⬅️ Kembali', callback_data: 'back_to_toko' }
        ]
      ]
    }
  });
}

async function handleGiveUserbot(userId, chatId) {
  waitingForGiveUserId[userId] = true;
  
  await bot.sendMessage(chatId, `
<blockquote>🎁 <b><u>GIVE USERBOT (GIFT)</u></b></blockquote>
<blockquote>📩 <b>Masukkan UserID</b>
🆔 Format: <code>123456789</code>
📝 <b>Note:</b> Pastikan UserID tujuan benar</blockquote>
<blockquote>⚠️ UserID wajib berupa angka</blockquote>

<i>Ketik <b>❌ Batalkan</b> untuk membatalkan.</i>`, {
    parse_mode: 'HTML',
    reply_markup: {
      keyboard: [[{ text: `❌ Batalkan` }]],
      resize_keyboard: true
    }
  });
}

async function handleBackupRestore(userId, chatId) {
  await getBackupInfo(userId, chatId);
}

async function handlePesanGroup(userId, chatId) {
  let targetUserId = userId;
  const ubot = userbots.find(ub => ub.owner_id === targetUserId);
  
  if (!ubot) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Userbot ga ketemu atau lagi mati.</b></blockquote>`, { 
      parse_mode: 'HTML',
      reply_markup: await getBackKeyboard() 
    });
    return;
  }
  
  const totalPesan = await db.get('SELECT COUNT(*) as count FROM messages WHERE owner_id = ?', targetUserId);
  const totalGrup = await db.get('SELECT COUNT(*) as count FROM groups WHERE owner_id = ?', targetUserId);
  const settings = await db.get('SELECT selected_message_id FROM settings WHERE owner_id = ?', targetUserId);
  
  let pesanAktif = '-';
  if (settings && settings.selected_message_id) {
    const selectedMsg = await db.get('SELECT local_id FROM messages WHERE id = ? AND owner_id = ?', settings.selected_message_id, targetUserId);
    if (selectedMsg) {
      pesanAktif = `<code>#${selectedMsg.local_id}</code>`;
    }
  }
  
  const caption = `
<blockquote>📂 <b><u>PESAN & GROUP</u></b></blockquote>
<blockquote>📊 <b>STATISTIK</b>
 • <b>Total Pesan</b> : ${totalPesan.count || 0}
 • <b>Total Grup</b> : ${totalGrup.count || 0}
 • <b>Pesan Aktif</b> : ${pesanAktif}</blockquote>

<i>Pilih menu di bawah</i>`;
  
  await bot.sendMessage(chatId, caption, { 
    parse_mode: 'HTML', 
    reply_markup: await getPesanGroupKeyboard() 
  });
}

async function handleKelolaPesan(userId, chatId) {
  const totalPesan = await db.get('SELECT COUNT(*) as count FROM messages WHERE owner_id = ?', userId);
  const settings = await db.get('SELECT selected_message_id FROM settings WHERE owner_id = ?', userId);
  let selectedInfo = '-';
  
  if (settings && settings.selected_message_id) {
    const selectedMsg = await db.get('SELECT local_id FROM messages WHERE id = ? AND owner_id = ?', settings.selected_message_id, userId);
    if (selectedMsg) {
      selectedInfo = `<code>#${selectedMsg.local_id}</code>`;
    }
  }
  
  const caption = `
<blockquote>📝 <b><u>KELOLA PESAN</u></b></blockquote>
<blockquote>📊 <b>Total Pesan</b> : ${totalPesan.count || 0}
✅ <b>Pesan Aktif</b> : ${selectedInfo}</blockquote>

<i>Pilih opsi di bawah</i>`;
  
  await bot.sendMessage(chatId, caption, { 
    parse_mode: 'HTML', 
    reply_markup: await getKelolaPesanKeyboard(userId) 
  });
}

async function handleAdminchat(userId, chatId) {
  const caption = `
📞 <b><u>CONTACT ADMIN</u></b>`;
  await bot.sendMessage(chatId, caption, {
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [{ text: '🇮🇩 Owner', url: `tg://user?id=${OWNER_ID}` }],
        [{ text: 'all our team', url: `https://t.me/umeyXD/4` }],
        [{ text: '🔙 Kembali', callback_data: 'back_main' }]
      ]
    }
  });
}

async function handletqcredit(userId, chatId) {
  const caption = `
<blockquote>💌 <b><u>ABOUT THIS BOT</u></b></blockquote>

<blockquote><b>🤖 BOT NAME</b>
<b>Xavier-Jaseb Userbot</b>
Auto Broadcast Telegram Userbot</blockquote>

<blockquote><b>👨‍💻 DEVELOPER</b>
<b>Owner</b> : <a href="tg://user?id=${OWNER_ID}">${OWNER_USERNAME || 'Owner'}</a>
<b>Channel</b> : <a href="https://t.me/InformasiUserbot">@InformasiUserbot</a>
<b>Support</b> : <a href="https://t.me/umeyXD/4">@umeyXD/4</a></blockquote>

<blockquote><b>📌 FEATURES</b>
✅ Multi-group broadcasting
✅ Manual & forward message
✅ Customizable delay & jeda
✅ Free & Premium packages
✅ Reseller system
✅ Admin control
✅ Token system
✅ Product store</blockquote>

<blockquote><b>⚙️ TECH STACK</b>
• Node.js
• Telegram Bot API
• Telethon (Userbot)
• SQLite Database</blockquote>

<blockquote><b>📢 SUPPORT & DONATION</b>
💬 <a href="https://t.me/InformasiUserbot">Channel</a>
👤 <a href="tg://user?id=${OWNER_ID}">Contact Owner</a>
📦 <a href="https://t.me/umeyXD/4">Group Support</a></blockquote>

<blockquote><b>© 2025 - ${new Date().getFullYear()} Bot-Jaseb</b>
<i>All rights reserved</i></blockquote>`;

  await bot.sendMessage(chatId, caption, {
    parse_mode: 'HTML',
    disable_web_page_preview: true,
    reply_markup: {
      inline_keyboard: [
        [
          { text: '💬 Channel', url: 'https://t.me/InformasiUserbot' },
          { text: '👤 Owner', url: `tg://user?id=${OWNER_ID}` }
        ],
        [
          { text: '📦 Support Group', url: 'https://t.me/umeyXD/4' }
        ],
        [
          { text: '⬅️ Kembali', callback_data: 'back_main' }
        ]
      ]
    }
  });
}

async function handleModeForward(userId, chatId) {
  const role = await getUserRole(userId);
  const hasAccess = ['PREMIUM_NO_WM', 'RESELLER', 'OWNER'].includes(role);
  
  if (!hasAccess) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>No Permission</u></b>
↗️ <b>Fitur ini cuma buat Pro & Reseller.</b></blockquote>`, {
      parse_mode: 'HTML',
      reply_markup: await getKelolaPesanKeyboard(userId)
    });
    return;
  }
  
  await bot.sendMessage(chatId, `
<blockquote>↗️ <b><u>Kirim link pesan Telegram yang mau di-forward.</u></b></blockquote>
<blockquote>📌 Contoh: <code>https://t.me/username/1234</code></blockquote>`, {
    parse_mode: 'HTML',
    reply_markup: { keyboard: [[{ text: `❌ Batalkan` }]], resize_keyboard: true }
  });
  
  global.waitingForForwardLink = true;
}

async function handleModeBiasa(userId, chatId) {
  await bot.sendMessage(chatId, `
<blockquote><b><u>📩 Pesan Basic</u></b></blockquote>
<blockquote>Kirim pesan apa saja untuk disimpan sebagai pesan broadcast.
<b>Support:</b> Teks · Foto · Video · Dokumen · Audio · Voice · Sticker · GIF</blockquote>`, {
    parse_mode: 'HTML',
    reply_markup: {
      keyboard: [[{ text: '❌ Batalkan' }]],
      resize_keyboard: true,
      one_time_keyboard: true
    }
  });
  
  global.waitingForMessage = global.waitingForMessage || {};
  global.waitingForMessage[userId] = { type: 'copy_message' };
}

async function handleAdminListPesanPrev(callbackQuery, userId, chatId, messageId) {
  await safeAnswerCallbackQuery(callbackQuery);
  
  if (global.adminListPesanPage && global.adminListPesanPage[userId]) {
    if (global.adminListPesanPage[userId].page > 1) {
      global.adminListPesanPage[userId].page--;
      await safeDeleteMessage(chatId, messageId);
      await handleAdminListPesan(userId, chatId);
    }
  }
}

async function handleAdminListPesanNext(callbackQuery, userId, chatId, messageId) {
  await safeAnswerCallbackQuery(callbackQuery);
  
  if (global.adminListPesanPage && global.adminListPesanPage[userId]) {
    const messages = await db.all('SELECT * FROM messages WHERE owner_id = ? ORDER BY local_id DESC', global.adminListPesanPage[userId].ownerId);
    const totalPages = Math.ceil(messages.length / 5);
    if (global.adminListPesanPage[userId].page < totalPages) {
      global.adminListPesanPage[userId].page++;
      await safeDeleteMessage(chatId, messageId);
      await handleAdminListPesan(userId, chatId);
    }
  }
}

async function handleLihatSemuaPesan(userId, chatId) {
  const messages = await db.all('SELECT * FROM messages WHERE owner_id = ? ORDER BY local_id DESC', userId);
  
  if (messages.length === 0) {
    await bot.sendMessage(chatId, `
<blockquote>📭 <b><u>KOSONG</u></b>
📝 Belum ada pesan tersimpan.</blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  if (!global.userListPesanPage) global.userListPesanPage = {};
  if (!global.userListPesanPage[userId]) {
    global.userListPesanPage[userId] = { page: 1 };
  }
  
  const itemsPerPage = 5;
  const totalPages = Math.ceil(messages.length / itemsPerPage);
  let currentPage = global.userListPesanPage[userId].page;
  
  if (currentPage > totalPages) currentPage = totalPages;
  if (currentPage < 1) currentPage = 1;
  
  const start = (currentPage - 1) * itemsPerPage;
  const end = start + itemsPerPage;
  const pageMessages = messages.slice(start, end);
  
  let response = `
<blockquote>📖 <b><u>DAFTAR PESAN KAMU</u></b></blockquote>
<blockquote><i>Halaman ${currentPage} / ${totalPages}</i></blockquote>`;

  for (let i = 0; i < pageMessages.length; i++) {
    const msg = pageMessages[i];
    const nomor = start + i + 1;
    let preview = '';
    
    if (msg.type === 'text') {
      preview = msg.content ? msg.content.substring(0, 50) + (msg.content.length > 50 ? '...' : '') : '(kosong)';
    } else if (msg.type === 'photo') {
      preview = '📸 [FOTO]';
    } else if (msg.type === 'video') {
      preview = '🎥 [VIDEO]';
    } else if (msg.type === 'document') {
      preview = '📄 [DOKUMEN]';
    } else if (msg.type === 'forward') {
      preview = '↗️ [FORWARD]';
    } else {
      preview = `[${msg.type.toUpperCase()}]`;
    }
    
    response += `

<blockquote><b>${nomor}.</b> <b>ID</b>: <code>#${msg.local_id}</code> | <b>Tipe</b>: ${msg.type}
 <i>Isi:</i> ${preview}</blockquote>`;
  }
  
  response += `

<blockquote><i>Total: ${messages.length} pesan</i></blockquote>`;
  
  const buttons = [];
  const navButtons = [];
  
  if (currentPage > 1) {
    navButtons.push({ text: '◀️', callback_data: 'user_pesan_prev' });
  }
  if (currentPage < totalPages) {
    navButtons.push({ text: '▶️', callback_data: 'user_pesan_next' });
  }
  
  const row = [];
  for (let i = 0; i < pageMessages.length; i++) {
    const msg = pageMessages[i];
    row.push({ text: `${start + i + 1}`, callback_data: `user_select_message_${msg.id}` });
    if (row.length === 3 || i === pageMessages.length - 1) {
      buttons.push([...row]);
      row.length = 0;
    }
  }
  
  if (navButtons.length > 0) {
    buttons.unshift(navButtons);
  }
  
  buttons.push([{ text: '⬅️ Kembali', callback_data: 'admin_back_to_kelola_pesan' }]);
  
  const sentMsg = await bot.sendMessage(chatId, response, {
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard: buttons }
  });
  
  if (global.userListPesanMsgId && global.userListPesanMsgId[userId]) {
    try {
      await safeDeleteMessage(chatId, global.userListPesanMsgId[userId]);
    } catch (e) {}
  }
  
  if (!global.userListPesanMsgId) global.userListPesanMsgId = {};
  global.userListPesanMsgId[userId] = sentMsg.message_id;
  
  global.waitingForSelectMessage = global.waitingForSelectMessage || {};
  global.waitingForSelectMessage[userId] = true;
}

async function handleUserPesanPrev(callbackQuery, userId, chatId, messageId) {
  await safeAnswerCallbackQuery(callbackQuery);
  
  if (global.userListPesanPage && global.userListPesanPage[userId]) {
    if (global.userListPesanPage[userId].page > 1) {
      global.userListPesanPage[userId].page--;
      await safeDeleteMessage(chatId, messageId);
      await handleLihatSemuaPesan(userId, chatId);
    }
  }
}

async function handleUserPesanNext(callbackQuery, userId, chatId, messageId) {
  await safeAnswerCallbackQuery(callbackQuery);
  
  if (global.userListPesanPage && global.userListPesanPage[userId]) {
    const messages = await db.all('SELECT * FROM messages WHERE owner_id = ? ORDER BY local_id DESC', userId);
    const totalPages = Math.ceil(messages.length / 5);
    if (global.userListPesanPage[userId].page < totalPages) {
      global.userListPesanPage[userId].page++;
      await safeDeleteMessage(chatId, messageId);
      await handleLihatSemuaPesan(userId, chatId);
    }
  }
}

async function handleUserSelectMessage(callbackQuery, userId, chatId, messageId, data) {
  const messageIdDb = data.replace('user_select_message_', '');
  
  const selectedMsg = await db.get('SELECT local_id, id FROM messages WHERE id = ? AND owner_id = ?', messageIdDb, userId);
  
  if (!selectedMsg) {
    await safeAnswerCallbackQuery(callbackQuery, `<i>❌ Pesan tidak ditemukan</i>`, true);
    return;
  }
  
  await db.run('UPDATE settings SET selected_message_id = ? WHERE owner_id = ?', selectedMsg.id, userId);
  
  await safeAnswerCallbackQuery(callbackQuery, `<i>✅ Pesan #${selectedMsg.local_id} dipilih jadi pesan aktif</i>`);
  
  await safeDeleteMessage(chatId, messageId);
  
  await bot.sendMessage(chatId, `
<blockquote>✅ <b><u>PESAN AKTIF DIPILIH</u></b>
📝 <b>Pesan #${selectedMsg.local_id} dipilih jadi pesan aktif!</b></blockquote>`, {
    parse_mode: 'HTML',
    reply_markup: await getKelolaPesanKeyboard(userId)
  });
}

async function handleResetText(userId, chatId) {
  await bot.sendMessage(chatId, `
<blockquote>🗑 <b><u>RESET TEXT</u></b>
📝 <b>Kirim ID pesan yang mau dihapus</b></blockquote>`, {
    parse_mode: 'HTML',
    reply_markup: { keyboard: [[{ text: `❌ Batalkan` }]], resize_keyboard: true, one_time_keyboard: true }
  });
  
  global.waitingForDeleteMessage = global.waitingForDeleteMessage || {};
  global.waitingForDeleteMessage[userId] = true;
}

async function handleResetSemuaText(userId, chatId) {
  const totalPesan = await db.get('SELECT COUNT(*) as count FROM messages WHERE owner_id = ?', userId);
  
  if (totalPesan.count === 0) {
    await bot.sendMessage(chatId, `
<blockquote>📭 <b><u>KOSONG</u></b>
📝 Belum ada pesan tersimpan.</blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  await bot.sendMessage(chatId, `
<blockquote>⚠️ <b><u>PERHATIAN!</u></b></blockquote>
<blockquote>Kamu bakal hapus <b>${totalPesan.count} pesan</b> permanen.</blockquote>

<i>Yakin mau lanjut?</i>`, {
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [
          { text: '✅ Ya, Hapus Semua', callback_data: `confirm_delete_all_${userId}` },
          { text: '❌ Batalkan', callback_data: 'cancel_delete_all' }
        ]
      ]
    }
  });
}

async function handleKelolaGroup(userId, chatId) {
  let targetUserId = userId;
  const ubot = userbots.find(ub => ub.owner_id === targetUserId);
  
  if (!ubot) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Userbot ga ketemu atau lagi mati.</b></blockquote>`, { 
      parse_mode: 'HTML',
      reply_markup: await getBackKeyboard() 
    });
    return;
  }
  
  const totalGroups = await db.get('SELECT COUNT(*) as count FROM groups WHERE owner_id = ?', targetUserId);
  
  const caption = `
<blockquote>👥 <b><u>KELOLA GROUP</u></b></blockquote>
<blockquote>📊 <b>Total Group</b> : ${totalGroups.count || 0}</blockquote>

<i>Pilih opsi di bawah</i>`;
  
  await bot.sendMessage(chatId, caption, { 
    parse_mode: 'HTML', 
    reply_markup: await getKelolaGroupKeyboard() 
  });
}

async function handleTambahManualGroup(userId, chatId) {
  let targetUserId = userId;
  
  // Cek role user, kalo trial kasih batasan
  const role = await getUserRole(targetUserId);
  const isTrial = (role === 'TRIAL');
  
  let batasanMsg = '';
  if (isTrial) {
    const existingGroups = await db.all('SELECT COUNT(*) as count FROM groups WHERE owner_id = ?', targetUserId);
    const currentCount = existingGroups[0]?.count || 0;
    if (currentCount >= 20) {
      await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>BATAS GRUP TERPENUHI</u></b>
📊 Kamu udah punya <b>20 grup</b>, batas maksimal free!
🗑️ Hapus dulu beberapa grup atau upgrade ke premium.</blockquote>`, { parse_mode: 'HTML' });
      return;
    }
    const sisaSlot = 20 - currentCount;
    batasanMsg = `\n⚠️ <i>Free: maksimal 20 grup (sisa ${sisaSlot} slot)</i>`;
  }
  
  await bot.sendMessage(chatId, `
<blockquote>➕ <b><u>TAMBAH MANUAL</u></b></blockquote>
<blockquote>📝 Kirim username atau ID grup <i>(pisahin pake koma)</i>.</blockquote>
<blockquote>📌 Contoh: <code>@grup1, @grup2, -100123456789</code></blockquote>
${batasanMsg}`, { 
    parse_mode: 'HTML', 
    reply_markup: { keyboard: [[{ text: `❌ Batalkan` }]], resize_keyboard: true, one_time_keyboard: true } 
  });
  
  global.waitingForAddGroup = global.waitingForAddGroup || {};
  global.waitingForAddGroup[userId] = { targetUserId: targetUserId };
}

async function handleTambahSemuaGroup(userId, chatId) {
  let targetUserId = userId;
  const ubot = userbots.find(ub => ub.owner_id === targetUserId);
  
  if (!ubot) {
    await bot.sendMessage(chatId, `<blockquote>❌ <b><u>ERROR</u></b> 🤖 <b>Userbot ga ketemu atau lagi mati.</b></blockquote>`);
    return;
  }
  
  // Cek role user, kalo trial kasih batasan
  const role = await getUserRole(targetUserId);
  const isTrial = (role === 'TRIAL');
  
  const existingGroups = await db.all('SELECT COUNT(*) as count FROM groups WHERE owner_id = ?', targetUserId);
  const currentCount = existingGroups[0]?.count || 0;
  
  let maxAdd = 9999;
  let batasanMsg = '';
  if (isTrial) {
    if (currentCount >= 20) {
      await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>BATAS GRUP TERPENUHI</u></b>
📊 Kamu udah punya <b>20 grup</b>, batas maksimal free!
🗑️ Hapus dulu beberapa grup atau upgrade ke premium.</blockquote>`, { parse_mode: 'HTML' });
      return;
    }
    maxAdd = 20 - currentCount;
    batasanMsg = `\n⚠️ <i>Free: maksimal ${maxAdd} grup lagi (total 20)</i>`;
  }
  
  await bot.sendMessage(chatId, `
<blockquote>⚙️ <b><u>MENGAMBIL DAFTAR GRUP</u></b>
⏳ <i>Lagi nambahin grup... Tunggu bentar.</i>${batasanMsg}</blockquote>`, { parse_mode: 'HTML' });
  
  try {
    const dialogs = await ubot.client.getDialogs();
    let added = 0;
    let skipped = 0;
    
    for (const dialog of dialogs) {
      if (isTrial && added >= maxAdd) {
        skipped++;
        continue;
      }
      
      if (dialog.isGroup) {
        const exists = await db.get('SELECT * FROM groups WHERE owner_id = ? AND group_id = ?', targetUserId, dialog.id.toString());
        
        if (!exists) {
          await db.run(
            'INSERT INTO groups (owner_id, group_id, group_title, group_username, added_at) VALUES (?, ?, ?, ?, ?)',
            targetUserId, dialog.id.toString(), dialog.title, dialog.username || '', Math.floor(Date.now() / 1000)
          );
          added++;
        }
      }
    }
    
    let resultMsg = `<blockquote>✅ <b><u>BERHASIL</u></b>\n📊 <b>Berhasil nambah ${added} grup baru.</b>`;
    if (isTrial && skipped > 0) {
      resultMsg += `\n⚠️ <b>${skipped} grup dilewati</b> (batas 20 grup free)`;
    }
    resultMsg += `</blockquote>`;
    
    await bot.sendMessage(chatId, resultMsg, { parse_mode: 'HTML' });
  } catch (error) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>GAGAL</u></b>
⚠️ <b>Gagal sync grup:</b> ${error.message}</blockquote>`, { parse_mode: 'HTML' });
  }
}

async function handleLihatGrup(userId, chatId) {
  let targetUserId = userId;
  const groups = await db.all('SELECT * FROM groups WHERE owner_id = ? ORDER BY added_at DESC', targetUserId);
  
  if (groups.length === 0) {
    await bot.sendMessage(chatId, `
<blockquote>📭 <b><u>KOSONG</u></b>
👥 <i>Belum ada group tersimpan.</i></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  global.groupListPage = global.groupListPage || {};
  global.groupListPage[userId] = {
    groups: groups,
    page: 1,
    totalPages: Math.ceil(groups.length / 5)
  };

  await sendGroupListPage(chatId, null, userId);
}

async function handleResetSemuaGroup(userId, chatId) {
  let targetUserId = userId;
  
  const totalGroups = await db.get('SELECT COUNT(*) as count FROM groups WHERE owner_id = ?', targetUserId);
  
  if (totalGroups.count === 0) {
    await bot.sendMessage(chatId, `
<blockquote>📭 <b><u>KOSONG</u></b>
👥 <i>Belum ada grup tersimpan.</i></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  await bot.sendMessage(chatId, `
<blockquote>⚠️ <b><u>PERHATIAN!</u></b></blockquote>
<blockquote>Kamu akan menghapus <b>${totalGroups.count} grup</b> secara permanen.</blockquote>

<i>Yakin mau lanjut?</i>`, {
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [
          { text: '✅ Ya, Hapus Semua', callback_data: `confirm_reset_all_groups_${targetUserId}` },
          { text: '❌ Batal', callback_data: 'cancel_reset_all_groups' }
        ]
      ]
    }
  });
}

async function handleBlacklistGrup(userId, chatId) {
  let targetUserId = userId;
  const totalBlacklist = await db.get('SELECT COUNT(*) as count FROM blacklist_groups WHERE owner_id = ?', targetUserId);
  
  const caption = `
<blockquote>❌ <b><u>BLACKLIST GRUP</u></b></blockquote>
<blockquote>📊 <b>Total Blacklist</b> : ${totalBlacklist.count || 0}</blockquote>

<i>Pilih opsi di bawah</i>`;
  
  await bot.sendMessage(chatId, caption, { 
    parse_mode: 'HTML', 
    reply_markup: await getBlacklistGroupKeyboard() 
  });
}

async function handleTambahBlacklist(userId, chatId) {
  await bot.sendMessage(chatId, `
<blockquote>➕ <b><u>TAMBAH BLACKLIST</u></b></blockquote>
<blockquote>📝 Kirim username atau ID grup yang mau di-blacklist.</blockquote>
<blockquote>📌 Contoh: <code>@groupsampah, -100123456789</code></blockquote>`, { 
    parse_mode: 'HTML', 
    reply_markup: { keyboard: [[{ text: `❌ Batalkan` }]], resize_keyboard: true, one_time_keyboard: true } 
  });
  
  global.waitingForAddBlacklist = global.waitingForAddBlacklist || {};
  global.waitingForAddBlacklist[userId] = true;
}

async function handleLihatBlacklist(userId, chatId) {
  const blacklists = await db.all('SELECT * FROM blacklist_groups WHERE owner_id = ? ORDER BY added_at DESC LIMIT 10', userId);
  
  if (blacklists.length === 0) {
    await bot.sendMessage(chatId, `
<blockquote>📭 <b><u>KOSONG</u></b>
🚫 <i>Belum ada group yang di-blacklist.</i></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  let response = `
<blockquote>📖 <b><u>DAFTAR BLACKLIST</u></b></blockquote>`;
  
  blacklists.forEach((bl, index) => {
    response += `

<blockquote><b>${index + 1}.</b> <b>${bl.group_title}</b>
 🆔 <b>ID</b> : ${bl.group_id}
 📝 <b>Alasan</b> : ${bl.reason || '-'}</blockquote>`;
  });
  
  response += `

<blockquote><i>Total: ${blacklists.length} blacklist</i></blockquote>`;
  
  await bot.sendMessage(chatId, response, { 
    parse_mode: 'HTML', 
    reply_markup: await getBlacklistGroupKeyboard() 
  });
}

async function handleHapusBlacklist(userId, chatId) {
  await bot.sendMessage(chatId, `
<blockquote>🗑 <b><u>HAPUS BLACKLIST</u></b>
📝 <b>Kirim ID group yang mau dihapus dari blacklist</b></blockquote>`, {
    parse_mode: 'HTML',
    reply_markup: { keyboard: [[{ text: `❌ Batalkan` }]], resize_keyboard: true, one_time_keyboard: true }
  });
  
  global.waitingForDeleteBlacklist = global.waitingForDeleteBlacklist || {};
  global.waitingForDeleteBlacklist[userId] = true;
}

async function handleMenuBroadcast(userId, chatId) {
  let targetUserId = userId;
  const ubot = userbots.find(ub => ub.owner_id === targetUserId);
  
  if (!ubot) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Userbot ga ketemu atau lagi mati.</b></blockquote>`, { 
      parse_mode: 'HTML',
      reply_markup: await getBackKeyboard() 
    });
    return;
  }
  
  const settings = await db.get('SELECT * FROM settings WHERE owner_id = ?', targetUserId) || {
    delay: 300, jeda: 20, promosi_status: 'OFF'
  };
  
  const totalGroups = await db.get('SELECT COUNT(*) as count FROM groups WHERE owner_id = ?', targetUserId);
  const lastRun = promosiProgress[targetUserId]?.lastRun || 'Belum pernah';
  
  const caption = `
<blockquote>📣 <b><u>MENU BROADCAST</u></b></blockquote>
<blockquote>✅ <b>Status</b> : ${settings.promosi_status}
🎯 <b>Target</b> : ${totalGroups.count || 0} Grup
⏰ <b>Delay</b> : ${settings.delay} ms | <b>Jeda</b> : ${settings.jeda} Menit</blockquote>
<blockquote>📖 <b>ROUND TERAKHIR</b>
 • <b>Waktu</b> : ${lastRun}
 • <b>Sukses</b> : ${promosiProgress[targetUserId]?.success || 0} Grup
 • <b>Gagal</b> : ${promosiProgress[targetUserId]?.failed || 0} Grup</blockquote>

<i>Pilih menu di bawah</i>`;
  
  await bot.sendMessage(chatId, caption, { 
    parse_mode: 'HTML', 
    reply_markup: await getMenuPromosiKeyboard() 
  });
}

async function handleMulaiBroadcast(userId, chatId) {
  let targetUserId = userId;
  const statusMsg = await bot.sendMessage(chatId, `
<blockquote>⏳ <b><u>MEMULAI BROADCAST</u></b>
📡 <i>Memulai broadcast...</i></blockquote>`, { parse_mode: 'HTML' });
  await startautoBroadcast(targetUserId, chatId, statusMsg.message_id);
}

async function handleJedaBroadcast(userId, chatId) {
  let targetUserId = userId;
  
  if (promosiProgress[targetUserId]) {
    promosiProgress[targetUserId].running = false;
    await db.run('UPDATE settings SET promosi_status = ? WHERE owner_id = ?', 'PAUSE', targetUserId);
    await bot.sendMessage(chatId, `
<blockquote>⏸️ <b><u>BROADCAST DIJEDA</u></b>
⏳ <b>Promosi dijeda.</b></blockquote>`, { parse_mode: 'HTML' });
  }
}

async function handleStopBroadcast(userId, chatId) {
  let targetUserId = userId;
  
  if (promosiProgress[targetUserId]) {
    promosiProgress[targetUserId].running = false;
    delete promosiProgress[targetUserId];
    await db.run('UPDATE settings SET promosi_status = ? WHERE owner_id = ?', 'OFF', targetUserId);
    await bot.sendMessage(chatId, `
<blockquote>⏹️ <b><u>BROADCAST DIHENTIKAN</u></b>
🛑 <b>Promosi dihentikan.</b></blockquote>`, { parse_mode: 'HTML' });
  }
}

async function handleRestartRound(userId, chatId) {
  let targetUserId = userId;
  
  if (promosiProgress[targetUserId]) {
    promosiProgress[targetUserId].running = false;
    setTimeout(() => {
      promosiProgress[targetUserId].running = true;
      executePromoRound(targetUserId, chatId);
    }, 1000);
    await bot.sendMessage(chatId, `
<blockquote>🔄 <b><u>RESTART ROUND</u></b>
🔄 <i>Lagi restart round...</i></blockquote>`, { parse_mode: 'HTML' });
  }
}

async function handleBroadcastGlobal(userId, chatId) {
  const role = await getUserRole(userId);
  
  if (!isOwnerId(userId) && role !== 'OWNER') {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>No Permission</u></b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  global.waitingForBroadcast = { userId, step: 'waiting_for_message' };
  
  await bot.sendMessage(chatId, `
<blockquote>📣 <b><u>BROADCAST BOT</u></b></blockquote>
<blockquote>📩 Kirim pesan yang mau disebar ke semua user.</blockquote>
<blockquote>⚠️ Setelah kirim pesan, akan ada konfirmasi sebelum broadcast dimulai.</blockquote>`, { parse_mode: 'HTML' });
}

async function handleBroadcastPM(userId, chatId) {
  const ubot = userbots.find(ub => ub.owner_id === userId);
  
  if (!ubot) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Userbot lagi mati atau ga ketemu.</b></blockquote>`, {
      parse_mode: 'HTML',
      reply_markup: await getBackKeyboard()
    });
    return;
  }
  
  await bot.sendMessage(chatId, `
<blockquote>📣 <b><u>BROADCAST PM</u></b>
📩 <i>Kirim pesan yang mau lu sebar ke semua user yang pernah chat sama userbot lu.</i></blockquote>`, {
    parse_mode: 'HTML',
    reply_markup: { keyboard: [[`❌ Batalkan`]], resize_keyboard: true, one_time_keyboard: true }
  });
  
  global.waitingForBroadcastPM = true;
}

async function handleGrupList(userId, chatId) {
  let targetUserId = userId;
  const ubot = userbots.find(ub => ub.owner_id === targetUserId);
  
  if (!ubot) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Userbot ga ketemu atau lagi mati.</b></blockquote>`, { 
      parse_mode: 'HTML',
      reply_markup: await getBackKeyboard() 
    });
    return;
  }
  
  const totalGroups = await db.get('SELECT COUNT(*) as count FROM groups WHERE owner_id = ?', targetUserId);
  const totalMessages = await db.get('SELECT COUNT(*) as count FROM messages WHERE owner_id = ?', targetUserId);
  const blacklist = await db.get('SELECT COUNT(*) as count FROM blacklist_groups WHERE owner_id = ?', targetUserId);
  const aktif = totalGroups.count - blacklist.count;
  
  const caption = `
<blockquote>👥 <b><u>GRUP & LIST</u></b></blockquote>

<i>Pake tombol di bawah buat ngatur grup & list kamu!</i>

<blockquote>📊 <b>STATISTIK</b>
 • <b>Total Grup</b> : ${totalGroups.count || 0}
 • <b>Total List/Pesan</b> : ${totalMessages.count || 0}
 • <b>Grup Aktif</b> : ${aktif < 0 ? 0 : aktif} <i>(ga termasuk blacklist)</i></blockquote>

<i>Pilih menu di bawah</i>`;
  
  await bot.sendMessage(chatId, caption, { 
    parse_mode: 'HTML', 
    reply_markup: await getKelolaGroupKeyboard() 
  });
}

async function handleKelolaListPesan(userId, chatId) {
  let targetUserId = userId;
  const totalPesan = await db.get('SELECT COUNT(*) as count FROM messages WHERE owner_id = ?', targetUserId);
  
  const caption = `
<blockquote>📝 <b><u>KELOLA PESAN</u></b></blockquote>
<blockquote>📊 <b>Total Pesan</b> : ${totalPesan.count || 0}
✅ <b>Pesan Aktif</b> : ID ${(await db.get('SELECT selected_message_id FROM settings WHERE owner_id = ?', targetUserId))?.selected_message_id || '-'}</blockquote>

<i>Pilih opsi di bawah</i>`;
  
  await bot.sendMessage(chatId, caption, { 
    parse_mode: 'HTML', 
    reply_markup: await getKelolaPesanKeyboard(targetUserId) 
  });
}

async function handleDelayJeda(userId, chatId) {
  let targetUserId = userId;
  
  const settings = await db.get('SELECT * FROM settings WHERE owner_id = ?', targetUserId) || {
    delay: 300, jeda: 20
  };
  
  const caption = `
<blockquote>⏳ <b><u>DELAY & JEDA</u></b></blockquote>
<blockquote>⏰ <b>Delay Antar Grup</b> : ${settings.delay} ms
🕐 <b>Jeda Antar Round</b> : ${settings.jeda} menit
📊 <b>Estimasi per Round</b> : ${Math.ceil((await db.get('SELECT COUNT(*) as count FROM groups WHERE owner_id = ?', targetUserId)).count * settings.delay / 1000)} detik</blockquote>

<i>Pilih menu di bawah</i>`;
  
  await bot.sendMessage(chatId, caption, { 
    parse_mode: 'HTML', 
    reply_markup: await getDelayJedaKeyboard() 
  });
}

async function handleAturDelay(userId, chatId) {
  let targetUserId = userId;
  
  await bot.sendMessage(chatId, `
<blockquote>⏰ <b><u>ATUR DELAY</u></b></blockquote>
<blockquote>📝 Masukin delay dalam MILIDETIK.</blockquote>
<blockquote><b>Rekomendasi:</b>
 • 300ms = Cepet <i>(resiko sedang)</i>
 • 500ms = Normal <i>(aman)</i>
 • 1000ms = Lambat <i>(sangat aman)</i></blockquote>
<blockquote>⚠️ Minimal 100ms, Maksimal 5000ms</blockquote>`, { 
    parse_mode: 'HTML', 
    reply_markup: { keyboard: [[{ text: `❌ Batalkan` }]], resize_keyboard: true, one_time_keyboard: true } 
  });
  
  global.waitingForDelay = global.waitingForDelay || {};
  global.waitingForDelay[userId] = { targetUserId: targetUserId };
}

async function handleAturJeda(userId, chatId) {
  let targetUserId = userId;
  
  await bot.sendMessage(chatId, `
<blockquote>🕐 <b><u>ATUR JEDA</u></b></blockquote>
<blockquote>📝 Masukin jeda antar round dalam MENIT.</blockquote>
<blockquote>📌 Contoh: 10, 20, 30, 720 (12 jam), 1440 (24 jam)</blockquote>
<blockquote>⚠️ Minimal 1 menit, tidak ada batasan maksimal</blockquote>`, { 
    parse_mode: 'HTML', 
    reply_markup: { keyboard: [[{ text: `❌ Batalkan` }]], resize_keyboard: true, one_time_keyboard: true } 
  });
  
  global.waitingForJeda = global.waitingForJeda || {};
  global.waitingForJeda[userId] = { targetUserId: targetUserId };
}

async function handleExpertExtra(userId, chatId) {
  let targetUserId = userId;
  const ubot = userbots.find(ub => ub.owner_id === targetUserId);
  
  if (!ubot) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Userbot ga ketemu atau lagi mati.</b></blockquote>`, { 
      parse_mode: 'HTML',
      reply_markup: await getBackKeyboard() 
    });
    return;
  }
  
  const caption = `
<blockquote>⚡️ <b><u>EXPERT EXTRA</u></b></blockquote>

<i>Pilih fitur yang mau dipake</i>`;
  
  await bot.sendMessage(chatId, caption, { 
    parse_mode: 'HTML', 
    reply_markup: await getFiturSpesialKeyboard(targetUserId) 
  });
}

async function handleLihatToken(userId, chatId) {
  const tokens = await db.all('SELECT * FROM tokens WHERE owner_id = ? AND used = 0 AND expired_at > ?', userId, Math.floor(Date.now() / 1000));
  
  if (tokens.length === 0) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>KOSONG</u></b>
🔑 <b>Kamu ga punya token cadangan yang aktif.</b></blockquote>`, { 
      parse_mode: 'HTML',
      reply_markup: await getBackKeyboard() 
    });
    return;
  }
  
  let tokenList = `
<blockquote>🔑 <b><u>TOKEN CADANGAN KAMU</u></b></blockquote>`;
  
  for (let i = 0; i < tokens.length; i++) {
    const t = tokens[i];
    const expiredDate = new Date(t.expired_at * 1000).toLocaleString();
    const sisaHari = Math.floor((t.expired_at - Math.floor(Date.now() / 1000)) / 86400);
    
    let paketName = '';
    if (t.role === 'PREMIUM_WM') paketName = '🧩 Plan Basic';
    else if (t.role === 'PREMIUM_NO_WM') paketName = '💎 Plan Pro';
    else paketName = t.role;
    
    tokenList += `

<blockquote><b>${i + 1}.</b> <code>${t.token}</code>
 📦 <b>Paket</b> : ${paketName}
 ⏰ <b>Sisa</b> : ${sisaHari} hari
 📅 <b>Habis</b> : ${expiredDate}</blockquote>`;
  }
  
  tokenList += `

<blockquote><i>Simpan token ini baik-baik! Pake kalo userbot bermasalah.</i></blockquote>`;
  
  await bot.sendMessage(chatId, tokenList, { 
    parse_mode: 'HTML', 
    reply_markup: await getBackKeyboard() 
  });
}

async function handleMasukGroup(userId, chatId) {
  let targetUserId = userId;
  const ubot = userbots.find(ub => ub.owner_id === targetUserId);
  
  if (!ubot) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Userbot ga ketemu atau lagi mati.</b></blockquote>`, { 
      parse_mode: 'HTML',
      reply_markup: await getBackKeyboard() 
    });
    return;
  }
  
  const caption = `
<blockquote>➕ <b><u>MASUK GROUP</u></b></blockquote>
<blockquote>📝 Kirim username atau invite link group.</blockquote>
<blockquote>🔗 Pisahin pake koma kalo mau banyak.</blockquote>
<blockquote>📌 Contoh: <code>@grup1, @grup2, https://t.me/+abcdefg</code></blockquote>`;

  await bot.sendMessage(chatId, caption, { 
    parse_mode: 'HTML', 
    reply_markup: {
      keyboard: [[{ text: `❌ Batalkan` }]], 
      resize_keyboard: true, 
      one_time_keyboard: true
    } 
  });
  
  global.waitingForJoinGroup = global.waitingForJoinGroup || {};
  global.waitingForJoinGroup[userId] = { targetUserId: targetUserId };
}

async function handleKeluarGroup(userId, chatId) {
  let targetUserId = userId;
  const ubot = userbots.find(ub => ub.owner_id === targetUserId);
  
  if (!ubot) {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Userbot ga ketemu atau lagi mati.</b></blockquote>`, { 
      parse_mode: 'HTML',
      reply_markup: await getBackKeyboard() 
    });
    return;
  }
  
  await bot.sendMessage(chatId, `
<blockquote>➖ <b><u>KELUAR GROUP</u></b></blockquote>
<blockquote>📝 Masukin username buat keluar group!</blockquote>
<blockquote>📌 Contoh: <code>@group1, @group2</code></blockquote>`, {
    parse_mode: 'HTML',
    reply_markup: { keyboard: [[{ text: `❌ Batalkan` }]], resize_keyboard: true, one_time_keyboard: true }
  });
  
  global.waitingForLeaveGroup = global.waitingForLeaveGroup || {};
  global.waitingForLeaveGroup[userId] = { targetUserId };
}

async function handleMenuReseller(userId, chatId) {
  const role = await getUserRole(userId);
  
  if (role !== 'RESELLER' && role !== 'OWNER') {
    await bot.sendMessage(chatId, `<blockquote>❌ <b><u>No Permission</u></b> 👑 <b>Cuma reseller & owner yang bisa akses menu ini.</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const added = await db.get('SELECT COUNT(*) as count FROM reseller_added WHERE reseller_id = ?', userId);
  const wm = await db.get('SELECT COUNT(*) as count FROM reseller_added WHERE reseller_id = ? AND type = "wm"', userId);
  const nowm = await db.get('SELECT COUNT(*) as count FROM reseller_added WHERE reseller_id = ? AND type = "nowm"', userId);
  const latest = await db.all('SELECT * FROM reseller_added WHERE reseller_id = ? ORDER BY added_at DESC LIMIT 5', userId);
  
  const latestList = latest.map(l => `• ${l.user_id} <i>(${l.type})</i>`).join('\n') || '• -';
  
  const caption = `
<blockquote>🎟 <b><u>MENU RESELLER</u></b></blockquote>
<blockquote>📊 <b>STATISTIK KAMU</b>
 • <b>Total User Ditambah</b> : ${added.count || 0}
 • <b>Premium WM</b> : ${wm.count || 0}
 • <b>Premium NO WM</b> : ${nowm.count || 0}</blockquote>
<blockquote>📖 <b>USER TERAKHIR</b>
 ${latestList}</blockquote>

<i>Pilih menu di bawah</i>`;
  
  await bot.sendMessage(chatId, caption, { 
    parse_mode: 'HTML', 
    reply_markup: {
      keyboard: [
        ['➕ Tambah Basic', '➕ Tambah Pro'],
        ['➖ Hapus Basic/Pro', '📋 Daftar Member Premium'],
        ['🔙 Kembali']
      ],
      resize_keyboard: true
    }
  });
}

async function handleResellerAddBasic(userId, chatId) {
  const role = await getUserRole(userId);
  if (role !== 'RESELLER' && role !== 'OWNER') {
    await bot.sendMessage(chatId, `<blockquote>❌ <b>Only Reseller</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }

  await bot.sendMessage(chatId, `
<blockquote>➕ <b><u>TAMBAH USER BASIC (WM) - MULTIPLE</u></b></blockquote>
<blockquote>📝 Kirim User ID atau Username, pisahkan dengan koma.</blockquote>
<blockquote><b>Contoh:</b>
<code>123456789,987654321,7654321</code>
<code>@johndoe,@janedoe,@user3</code>
<code>123456789,@johndoe,987654321</code></blockquote>

<i>Ketik <b>❌ Batalkan</b> untuk batal.</i>`, {
    parse_mode: 'HTML',
    reply_markup: { keyboard: [['❌ Batalkan']], resize_keyboard: true, one_time_keyboard: true }
  });

  global.waitingResellerAddBasic = global.waitingResellerAddBasic || {};
  waitingResellerAddBasic[userId] = true;
}

async function handleResellerAddPro(userId, chatId) {
  const role = await getUserRole(userId);
  if (role !== 'RESELLER' && role !== 'OWNER') {
    await bot.sendMessage(chatId, `<blockquote>❌ <b>Only Reseller</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }

  await bot.sendMessage(chatId, `
<blockquote>➕ <b><u>TAMBAH USER PRO (NO WM) - MULTIPLE</u></b></blockquote>
<blockquote>📝 Kirim User ID atau Username, pisahkan dengan koma.</blockquote>
<blockquote><b>Contoh:</b>
<code>123456789,987654321,7654321</code>
<code>@johndoe,@janedoe,@user3</code>
<code>123456789,@johndoe,987654321</code></blockquote>

<i>Ketik <b>❌ Batalkan</b> untuk batal.</i>`, {
    parse_mode: 'HTML',
    reply_markup: { keyboard: [['❌ Batalkan']], resize_keyboard: true, one_time_keyboard: true }
  });

  global.waitingResellerAddPro = global.waitingResellerAddPro || {};
  waitingResellerAddPro[userId] = true;
}

async function handleResellerDelete(userId, chatId) {
  const role = await getUserRole(userId);
  if (role !== 'RESELLER' && role !== 'OWNER') {
    await bot.sendMessage(chatId, `<blockquote>❌ <b>Only Reseller</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }

  await bot.sendMessage(chatId, `
<blockquote>🗑️ <b><u>HAPUS AKSES PREMIUM - MULTIPLE</u></b></blockquote>
<blockquote>📝 Kirim User ID atau Username, pisahkan dengan koma.</blockquote>
<blockquote><b>Contoh:</b>
<code>123456789,987654321,7654321</code>
<code>@johndoe,@janedoe,@user3</code>
<code>123456789,@johndoe,987654321</code></blockquote>
<blockquote>⚠️ Sistem akan otomatis mendeteksi paket user (Basic/Pro) dan menghapusnya.</blockquote>

<i>Ketik <b>❌ Batalkan</b> untuk batal.</i>`, {
    parse_mode: 'HTML',
    reply_markup: { keyboard: [['❌ Batalkan']], resize_keyboard: true, one_time_keyboard: true }
  });

  global.waitingResellerDelete = global.waitingResellerDelete || {};
  waitingResellerDelete[userId] = true;
}

async function handleResellerListPrem(userId, chatId) {
  const role = await getUserRole(userId);
  if (role !== 'RESELLER' && role !== 'OWNER') {
    await bot.sendMessage(chatId, `<blockquote>❌ <b>Only Reseller</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }

  const addedUsers = await db.all('SELECT * FROM reseller_added WHERE reseller_id = ? ORDER BY added_at DESC', userId);
  
  if (addedUsers.length === 0) {
    await bot.sendMessage(chatId, `
<blockquote>📭 <b><u>KOSONG</u></b>
👥 <i>Belum ada user yang ditambahkan.</i></blockquote>`, { parse_mode: 'HTML' });
    return;
  }

  let response = `<blockquote>📖 <b><u>DAFTAR USER PREMIUM TAMBAHAN ANDA</u></b></blockquote>`;
  
  for (let i = 0; i < addedUsers.length; i++) {
    const u = addedUsers[i];
    const expiredDate = new Date(u.expired * 1000).toLocaleString('id-ID');
    const typeIcon = u.type === 'wm' ? '🧩' : '💎';
    const typeName = u.type === 'wm' ? 'Basic' : 'Pro';
    const sisaHari = Math.max(0, Math.floor((u.expired - Math.floor(Date.now() / 1000)) / 86400));
    
    response += `

<blockquote><b>${i + 1}.</b> ${typeIcon} <code>${u.user_id}</code> - ${typeName}
   📅 Ditambah: ${expiredDate}
   ⏰ Sisa: ${sisaHari} hari</blockquote>`;
  }
  
  response += `

<blockquote><i>Total: ${addedUsers.length} user premium</i></blockquote>`;
  
  await bot.sendMessage(chatId, response, { parse_mode: 'HTML' });
}

async function handleHelpMenu(userId, chatId) {
  const role = await getUserRole(userId);
  
  if (!isOwnerId(userId) && role !== 'OWNER') {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>No Permission</u></b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const caption = `
<blockquote>🛒 <b><u>HELP MENU</u></b></blockquote>

<i>Pilih menu di bawah</i>`;

  await bot.sendMessage(chatId, caption, {
    parse_mode: 'HTML',
    reply_markup: await getOwnerMenuKeyboard()
  });
}

async function handleSettingPremium(userId, chatId) {
  const role = await getUserRole(userId);
  
  if (!isOwnerId(userId) && role !== 'OWNER') {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>No Permission</u></b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const caption = `
<blockquote>🛒 <b><u>SETTING PREMIUM</u></b></blockquote>
<blockquote>📝 <b>Gunakan command berikut:</b>
<code>/addprem basic userid 30</code> - Tambah BASIC
<code>/addprem pro userid 30</code> - Tambah PRO
<code>/delprem basic userid</code> - Hapus BASIC
<code>/delprem pro userid</code> - Hapus PRO
<code>/listprem</code> - Lihat semua premium</blockquote>
`;

  await bot.sendMessage(chatId, caption, {
    parse_mode: 'HTML',
    reply_markup: {
      keyboard: [['🔙 Kembali']],
      resize_keyboard: true
    }
  });
}

async function handleSettingReseller(userId, chatId) {
  const role = await getUserRole(userId);
  
  if (!isOwnerId(userId) && role !== 'OWNER') {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>No Permission</u></b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const caption = `
<blockquote>🎟 <b><u>SETTING RESELLER</u></b></blockquote>
<blockquote>📝 <b>Gunakan command berikut:</b>
<code>/addreseller userid</code> - Tambah Reseller
<code>/delreseller userid</code> - Hapus Reseller
<code>/listreseller</code> - Lihat semua reseller</blockquote>
`;

  await bot.sendMessage(chatId, caption, {
    parse_mode: 'HTML',
    reply_markup: {
      keyboard: [['🔙 Kembali']],
      resize_keyboard: true
    }
  });
}

async function handleSettingToken(userId, chatId) {
  const role = await getUserRole(userId);
  
  if (!isOwnerId(userId) && role !== 'OWNER') {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>No Permission</u></b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const caption = `
<blockquote>🔑 <b><u>SETTING TOKEN</u></b></blockquote>
<blockquote>Kelola token userbot:</blockquote>

<i>Pilih menu di bawah</i>`;

  await bot.sendMessage(chatId, caption, {
    parse_mode: 'HTML',
    reply_markup: {
      keyboard: [
        ['🎫 Buat Token', '🗑️ Hapus Token'],
        ['📋 Daftar Token'],
        ['🔙 Kembali']
      ],
      resize_keyboard: true
    }
  });
}

async function handleSettingUserbot(userId, chatId, messageId = null) {
  const role = await getUserRole(userId);
  
  if (!isOwnerId(userId) && role !== 'OWNER') {
    await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>No Permission</u></b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const ubots = await db.all('SELECT * FROM userbots ORDER BY created_at DESC');
  
  if (ubots.length === 0) {
    if (messageId) {
      await safeEditMessageText(`
<blockquote>📭 <b><u>KOSONG</u></b>
🤖 <i>Belum ada userbot terdaftar.</i></blockquote>`, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML'
      });
    } else {
      await bot.sendMessage(chatId, `
<blockquote>📭 <b><u>KOSONG</u></b>
🤖 <i>Belum ada userbot terdaftar.</i></blockquote>`, { parse_mode: 'HTML' });
    }
    return;
  }
  
  const itemsPerPage = 5;
  const totalPages = Math.ceil(ubots.length / itemsPerPage);
  let currentPage = global.ubotListPage?.[userId] || 1;
  
  if (currentPage > totalPages) currentPage = totalPages;
  if (currentPage < 1) currentPage = 1;
  
  const start = (currentPage - 1) * itemsPerPage;
  const end = start + itemsPerPage;
  const pageUbots = ubots.slice(start, end);
  
  let response = `
<blockquote>🤖 <b><u>DAFTAR USERBOT</u></b></blockquote>`;
  
  for (let i = 0; i < pageUbots.length; i++) {
    const ubot = pageUbots[i];
    const user = await db.get('SELECT * FROM users WHERE user_id = ?', ubot.owner_id);
    const statusEmoji = ubot.status === 'AKTIF' ? `✅` : `❌`;
    const nomor = start + i + 1;
    
    response += `

<blockquote><b>${nomor}.</b> ${statusEmoji} <code>${ubot.ubot_id}</code>
 👤 ${user?.full_name || 'Unknown'} ${user?.username ? `| @${user.username.replace('@', '')}` : ''}
 🆔 <code>${ubot.owner_id}</code></blockquote>`;
  }
  
  response += `

<blockquote><i>Halaman ${currentPage} / ${totalPages}</i></blockquote>`;
  
  const buttons = [];
  const navButtons = [];
  
  if (currentPage > 1) {
    navButtons.push({ text: '◀️', callback_data: 'ubot_prev_page' });
  }
  if (currentPage < totalPages) {
    navButtons.push({ text: '▶️', callback_data: 'ubot_next_page' });
  }
  
  if (navButtons.length > 0) {
    buttons.push(navButtons);
  }
  
  const row = [];
  for (let i = 0; i < pageUbots.length; i++) {
    const idx = start + i;
    row.push({ text: `${idx + 1}`, callback_data: `select_ubot_${idx}` });
    if (row.length === 4 || i === pageUbots.length - 1) {
      buttons.push([...row]);
      row.length = 0;
    }
  }
  
  buttons.push([{ text: '⬅️ Kembali', callback_data: 'back_to_owner_menu' }]);
  
  if (messageId) {
    await safeEditMessageText(response, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: 'HTML',
      reply_markup: { inline_keyboard: buttons }
    });
  } else {
    await bot.sendMessage(chatId, response, {
      parse_mode: 'HTML',
      reply_markup: { inline_keyboard: buttons }
    });
  }
  
  global.listUbotData = global.listUbotData || {};
  global.listUbotData[userId] = { ubots: ubots, page: currentPage, totalPages: totalPages };
  global.ubotListPage = global.ubotListPage || {};
  global.ubotListPage[userId] = currentPage;
}

async function handleStatistikGlobal(userId, chatId) {
  const role = await getUserRole(userId);
  const isOwner = (isOwnerId(userId) || role === 'OWNER');

  let caption;

  if (isOwner) {
    // Owner: statistik sistem secara keseluruhan
    const totalUser = await db.get('SELECT COUNT(*) as count FROM users');
    const totalUbot = await db.get('SELECT COUNT(*) as count FROM userbots WHERE status = "AKTIF"');
    const totalTrial = await db.get('SELECT COUNT(*) as count FROM users WHERE role = "TRIAL"');
    const totalWM = await db.get('SELECT COUNT(*) as count FROM premium_wm');
    const totalNoWM = await db.get('SELECT COUNT(*) as count FROM premium_no_wm');
    const totalReseller = await db.get('SELECT COUNT(*) as count FROM reseller_list');
    const totalGroupsAll = await db.get('SELECT COUNT(*) as count FROM groups');
    const totalSentAll = await db.get('SELECT COALESCE(SUM(total_sent), 0) as total FROM userbots');

    caption = `
<blockquote>📊 <b>System Statistics</b></blockquote>
<blockquote><b>📁 Database Overview:</b>
├ 👥 Total Users: ${totalUser.count || 0}
└ 🤖 Active Userbots: ${totalUbot.count || 0}</blockquote>
<blockquote><b>🎫 License Distribution:</b>
├ ⭐ Trial: ${totalTrial.count || 0}
├ 🧩 Basic (WM): ${totalWM.count || 0}
├ 💎 Pro (No WM): ${totalNoWM.count || 0}
└ 🎟️ Reseller: ${totalReseller.count || 0}</blockquote>
<blockquote><b>📡 Broadcast Overview (semua user):</b>
├ 👥 Total Grup Tersimpan: ${totalGroupsAll.count || 0}
└ 📨 Total Pesan Terkirim: ${totalSentAll.total || 0}</blockquote>`;
  } else {
    // User biasa: statistik userbot miliknya sendiri
    const totalGroups = await db.get('SELECT COUNT(*) as count FROM groups WHERE owner_id = ?', userId);
    const myUbot = await db.get('SELECT COALESCE(SUM(total_sent), 0) as total FROM userbots WHERE owner_id = ?', userId);
    const lastRound = await db.get('SELECT * FROM promo_logs WHERE owner_id = ? ORDER BY started_at DESC LIMIT 1', userId);
    const totalRounds = await db.get('SELECT COUNT(*) as count FROM promo_logs WHERE owner_id = ?', userId);
    const settings = await db.get('SELECT promosi_status FROM settings WHERE owner_id = ?', userId) || { promosi_status: 'OFF' };

    const statusText = settings.promosi_status === 'ON' ? '✅ Aktif'
      : settings.promosi_status === 'PAUSE' ? '⏸️ Pause'
      : '❌ Nonaktif';

    caption = `
<blockquote>📊 <b>Statistik Userbot Kamu</b></blockquote>
<blockquote><b>📡 Status Broadcast:</b> ${statusText}</blockquote>
<blockquote><b>👥 Grup:</b>
└ Total Grup Tersimpan: ${totalGroups.count || 0}</blockquote>
<blockquote><b>📨 Pengiriman:</b>
├ Total Pesan Terkirim (sepanjang waktu): ${myUbot.total || 0}
└ Total Ronde Broadcast: ${totalRounds.count || 0}</blockquote>${lastRound ? `
<blockquote><b>🕐 Ronde Terakhir (#${lastRound.round_number || '-'}):</b>
├ Target Grup: ${lastRound.total_groups || 0}
├ ✅ Berhasil: ${lastRound.success || 0}
└ ❌ Gagal: ${lastRound.failed || 0}</blockquote>` : ''}`;
  }

  await bot.sendMessage(chatId, caption, {
    parse_mode: 'HTML',
    reply_markup: {
      keyboard: [
        ['🔙 Kembali']
      ],
      resize_keyboard: true
    }
  });
}

async function handleTokoUserbot(userId, chatId) {
  const hasUbot = await userHasUserbot(userId);
  
  if (hasUbot) {
    const caption = `
<blockquote>🛒 <b><u>STORE MENU</u></b></blockquote>

<i>Pilih tombol di bawah</i>`;

    await bot.sendMessage(chatId, caption, {
      parse_mode: 'HTML',
      reply_markup: {
        keyboard: [
          ['🔄 Perpanjang Userbot', '🛍️ Beli Produk'],
          ['🎁 Berikan Userbot', '🤖 Clone Bot'],
          ['🔙 Kembali']
        ],
        resize_keyboard: true
      }
    });
  } else {
    const caption = `
<blockquote>🛒 <b><u>STORE MENU</u></b></blockquote>

<i>Pilih tombol di bawah</i>`;

    await bot.sendMessage(chatId, caption, {
      parse_mode: 'HTML',
      reply_markup: {
        keyboard: [
          ['🛒 Beli Userbot', '🛍️ Beli Produk'],
          ['🎁 Berikan Userbot', '🤖 Clone Bot'],
          ['🔙 Kembali']
        ],
        resize_keyboard: true
      }
    });
  }
}

async function handleTokenUserbot(userId, chatId) {
  await bot.sendMessage(chatId, `
<blockquote><b>🔑 SISTEM TOKEN</b>

<b>Apa itu token?</b>
• Token berguna untuk klaim garansi userbot jika:
• Kamu mau pindah akun Telegram
• Akunmu kena banned Telegram
• Kamu perlu install ulang userbot

<b>⚠️ Perhatian</b>
• 1 token hanya bisa dipakai 1 kali
• Token hanya bisa dipakai oleh pemiliknya
• Simpan tokenmu, jangan disebar

<b>Bagaimana cara kerjanya?</b>
• Token jadi kunci untuk memindahkan userbot dari satu akun ke akun lain tanpa bayar lagi.

<b>🔴 PENTING</b> Simpan token kamu baik-baik!</blockquote>`, {
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [
          { text: '🔑 Pake Token', callback_data: 'use_token' },
          { text: '🔄 Ganti Token', callback_data: 'revoke_token' }
        ],
        [
          { text: '⬅️ Kembali', callback_data: 'back_main' }
        ]
      ]
    }
  });
}

function generateSecureToken() {
  const timestamp = Date.now().toString();
  const randomPart = crypto.randomBytes(32).toString('base64');
  const randomPart2 = crypto.randomBytes(24).toString('base64');
  const randomPart3 = crypto.randomBytes(16).toString('base64');
  
  const rawToken = `${timestamp}|${randomPart}|${randomPart2}|${randomPart3}`;
  
  return Buffer.from(rawToken).toString('base64');
}

async function handleCreateToken(userId, chatId) {
  if (!isOwnerId(userId)) return;
  
  await bot.sendMessage(chatId, `
<blockquote>🔑 <b><u>CREATE TOKEN</u></b></blockquote>
<blockquote>Pilih jenis akses token:
 • <b>wm</b> - Akses Premium WM
 • <b>nowm</b> - Akses Premium NO WM
 • <b>reseller</b> - Akses Reseller</blockquote>
<blockquote>Format: <code>jenis durasi_hari</code></blockquote>
<blockquote>Contoh: <code>wm 30</code> (WM 30 hari)
 Contoh: <code>reseller 365</code> (Reseller 1 tahun)</blockquote>
<blockquote>Durasi: 1-365 hari</blockquote>`, {
    parse_mode: 'HTML',
    reply_markup: { keyboard: [[`❌ Batalkan`]], resize_keyboard: true, one_time_keyboard: true }
  });
  
  global.waitingForCreateToken = true;
}

async function handleHapusToken(userId, chatId) {
  if (!isOwnerId(userId)) return;
  
  const tokens = await db.all('SELECT * FROM tokens WHERE used = 0 AND expired_at > ? ORDER BY created_at DESC', Math.floor(Date.now() / 1000));
  
  if (tokens.length === 0) {
    await bot.sendMessage(chatId, `
<blockquote>📭 <b><u>KOSONG</u></b>
🔑 Belum ada token aktif.</blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  let response = `
<blockquote>🗑 <b><u>HAPUS TOKEN</u></b></blockquote>
<blockquote><b>Pilih nomor token yang mau dihapus:</b></blockquote>`;
  
  for (let i = 0; i < tokens.length; i++) {
    const t = tokens[i];
    let paketName = '';
    if (t.role === 'PREMIUM_WM') paketName = '🧩 Basic';
    else if (t.role === 'PREMIUM_NO_WM') paketName = '💎 Pro';
    else if (t.role === 'RESELLER') paketName = '🎟 Reseller';
    
    response += `

<blockquote><b>${i + 1}.</b> <code>${t.token.substring(0, 15)}...</code> | ${paketName}</blockquote>`;
  }
  
  response += `

<blockquote>📝 Kirim nomor token yang mau dihapus.</blockquote>`;
  
  await bot.sendMessage(chatId, response, { parse_mode: 'HTML' });
  
  global.waitingForDeleteToken = true;
  global.tokenListForDelete = tokens;
}

async function handleListToken(userId, chatId) {
  if (!isOwnerId(userId)) return;
  
  const tokens = await db.all('SELECT * FROM tokens WHERE used = 0 AND expired_at > ? ORDER BY created_at DESC', Math.floor(Date.now() / 1000));
  
  if (tokens.length === 0) {
    await bot.sendMessage(chatId, `
<blockquote>📭 <b><u>KOSONG</u></b>
🔑 Belum ada token aktif.</blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  let response = `
<blockquote>📖 <b><u>DAFTAR TOKEN AKTIF</u></b></blockquote>`;
  
  for (let i = 0; i < tokens.length; i++) {
    const t = tokens[i];
    const expiredDate = new Date(t.expired_at * 1000).toLocaleString();
    const sisaHari = Math.floor((t.expired_at - Math.floor(Date.now() / 1000)) / 86400);
    
    let paketName = '';
    if (t.role === 'PREMIUM_WM') paketName = '🧩 Plan Basic';
    else if (t.role === 'PREMIUM_NO_WM') paketName = '💎 Plan Pro';
    else if (t.role === 'RESELLER') paketName = '🎟 Akses Reseller';
    
    response += `

<blockquote><b>${i + 1}.</b> <code>${t.token}</code>
 🛒 Paket: ${paketName}
 👤 Owner: <code>${t.owner_id || '-'}</code>
 🕐 Sisa: ${sisaHari} hari
 📅 Habis: ${expiredDate}</blockquote>`;
  }
  
  response += `

<blockquote><i>Total: ${tokens.length} token aktif</i></blockquote>`;
  
  await bot.sendMessage(chatId, response, { parse_mode: 'HTML' });
}

async function handleBeranda(userId, chatId, msg) {
  const firstName = msg.from.first_name || 'User';
  
  const botInfo = await getCachedBotInfo();
  const botFirstName = botInfo.first_name || 'Xavier-Jaseb Bot';
  const botUsername = botInfo.username || 'XavierJasebBot';
  
  const systemInfoBlock = await getSystemInfoBlock();

  const caption = `
<b><u>🚀 WELCOME TO USERBOT JASEB</u></b>

${systemInfoBlock}

<i>Ready to start? 👇</i>`;
  
  const keyboard = await getMainMenuKeyboard(userId);
  await bot.sendMessage(chatId, caption, { 
    parse_mode: 'HTML', 
    disable_web_page_preview: true,
    reply_markup: keyboard 
  });
}

bot.on('message', async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const text = msg.text || '';

  if (msg.chat.type !== 'private') {
    return;
  }
  
  try {

  // BUG FIX: handler ini (semua pesan/reply-keyboard) sebelumnya SAMA SEKALI
  // gak pernah cek wajib-join / maintenance, beda dari bot.on('callback_query')
  // yang sudah cek. Akibatnya user yang gak lewat /start (mis. masih ada
  // history chat lama, atau langsung pencet tombol reply-keyboard) bisa
  // tembus ke semua fitur tanpa pernah diminta join folder sama sekali.
  // /start dikecualikan di sini karena udah punya gate sendiri di
  // bot.onText(/\/start/...) - biar gak double proses.
  if (!text.startsWith('/start')) {
    const canProceed = await checkMaintenance(userId, chatId);
    if (!canProceed) return;

    const { logGroupJoined, channelJoined, requiredGroupJoined } = await checkUserJoined(userId);
    if (!logGroupJoined || !channelJoined || !requiredGroupJoined) {
      await sendJoinRequiredMessage(chatId, userId);
      return;
    }
  }

  if (text === '❌ Batalkan') {
    await handleCancelAction(userId, chatId);
    return;
  }
  
  if (text === '🔙 Kembali' || text === '🏠 Beranda') {
    await handleBackOrBeranda(msg, userId, chatId);
    return;
  }
  
  if (text === '🎁 Coba Gratis') {
    await handleTrialUserbot(userId, chatId);
    return;
  }
  
  if (text === '🛍️ Beli Produk') {
    await produkBaruShowList(userId, chatId);
    return;
  }
  
  if (text === '📦 Pengaturan Produk' && isOwnerId(userId)) {
    await produkBaruOwnerMenu(userId, chatId);
    return;
  }
  
  if (text === '➕ Tambah Produk' && isOwnerId(userId)) {
    await produkBaruTambah(userId, chatId);
    return;
  }
  
  if (text === '📋 Daftar Produk' && isOwnerId(userId)) {
    await produkBaruLihat(userId, chatId);
    return;
  }
  
  if (text === '📝 Edit Produk' && isOwnerId(userId)) {
    await produkBaruEdit(userId, chatId);
    return;
  }
  
  if (text === '💰 Saldo Saya') {
  const user = await db.get('SELECT user_id, username, full_name FROM users WHERE user_id = ?', userId);
  const balance = getProdukBalance(userId);
  const transactions = await getProdukUserTransactions(userId, 10);
  
  const totalTransaksi = transactions.filter(t => t.type === 'PURCHASE').length;
  const jumlahBeli = transactions.filter(t => t.type === 'PURCHASE').reduce((sum, t) => sum + (t.details.match(/quantity:(\d+)/)?.[1] || 0), 0);
  const pemakaianSaldo = transactions.filter(t => t.type === 'PURCHASE').reduce((sum, t) => sum + t.amount, 0);
  
  const caption = `
<blockquote>💰 <b><u>SALDO PRODUK</u></b></blockquote>
<blockquote><b>👤 User</b> : <i>${user?.full_name || 'Unknown'}</i>
<b>🆔 ID</b> : <code>${userId}</code>
<b>💰 Saldo</b> : <code><b>Rp ${balance.toLocaleString()}</b></code>
<b>📊 Pemakaian Saldo</b> : <code><b>Rp ${pemakaianSaldo.toLocaleString()}</b></code>
<b>📦 Jumlah Beli</b> : <code><b>${jumlahBeli}</b> produk</code>
<b>📝 Total Transaksi</b> : <code><b>${totalTransaksi}</b></code></blockquote>

<i>Klik tombol di bawah untuk deposit</i>`;

  await bot.sendMessage(chatId, caption, {
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [
          { text: '💰 Deposit', callback_data: 'produk_baru_deposit_menu' },
          { text: '🛍️ Beli Produk', callback_data: 'beli_produk' }
        ],
        [
          { text: '⬅️ Kembali', callback_data: 'back_main' }
        ]
      ]
    }
  });
  return;
}
  
  if (produkBaruWaitingAdd && isOwnerId(userId)) {
    await produkBaruTambahInput(userId, chatId, text);
    return;
  }
  
  if (produkBaruWaitingFile && isOwnerId(userId)) {
    await produkBaruUploadFile(userId, chatId, msg);
    return;
  }

  // Fitur /update (v10.6): owner sedang diminta upload file .zip.
  if (global.waitingForUpdateFile && isOwnerId(userId) && msg.document) {
    await handleUpdateFileUpload(userId, chatId, msg);
    return;
  }
  
  if (text === '➕ Tambah Basic') {
    await handleResellerAddBasic(userId, chatId);
    return;
  }
  
  if (text === '➕ Tambah Pro') {
    await handleResellerAddPro(userId, chatId);
    return;
  }
  
  if (global.waitingResellerAddBasic && global.waitingResellerAddBasic[userId]) {
  delete global.waitingResellerAddBasic[userId];
  
  const inputs = text.split(',').map(i => i.trim()).filter(i => i.length > 0);
  let successList = [];
  let failList = [];
  
  const statusMsg = await bot.sendMessage(chatId, `<blockquote>⏳ Memproses ${inputs.length} user...</blockquote>`, { parse_mode: 'HTML' });
  
  for (const input of inputs) {
    let targetUserId = input;
    
    if (input.startsWith('@')) {
      const username = input.replace('@', '');
      try {
        const userData = await db.get('SELECT user_id FROM users WHERE username LIKE ?', `%${username}%`);
        if (userData) {
          targetUserId = userData.user_id;
        } else {
          const chat = await bot.getChat(username).catch(() => null);
          if (chat) {
            targetUserId = chat.id.toString();
          } else {
            failList.push(`${input} (username tidak ditemukan)`);
            continue;
          }
        }
      } catch (error) {
        failList.push(`${input} (error: ${error.message})`);
        continue;
      }
    }
    
    if (!/^\d+$/.test(targetUserId)) {
      failList.push(`${input} (format ID salah)`);
      continue;
    }
    
    try {
      const isAlreadyReseller = await db.get('SELECT * FROM reseller_list WHERE user_id = ?', targetUserId);
      if (isAlreadyReseller) {
        failList.push(`${targetUserId} (sudah jadi reseller, tidak perlu ditambah)`);
        continue;
      }
      
      global.resellerAddData = global.resellerAddData || {};
      global.resellerAddData[userId] = { 
        targetUserId, 
        type: 'wm', 
        inputs: inputs, 
        successList: successList, 
        failList: failList, 
        statusMsgId: statusMsg.message_id,
        currentIndex: 0
      };
      
      await safeDeleteMessage(chatId, statusMsg.message_id);
      
      await bot.sendMessage(chatId, `
<blockquote>📅 <b>Pilih Durasi untuk User ${targetUserId}</b></blockquote>
<blockquote>👤 Target User: <code>${targetUserId}</code>
📦 Paket: <b>Basic (WM)</b></blockquote>
<blockquote>Pilih durasi (maksimal 5 bulan / 150 hari):</blockquote>`, {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '1 Bulan (30 Hari)', callback_data: `reseller_add_durasi_30_wm_${targetUserId}` },
              { text: '2 Bulan (60 Hari)', callback_data: `reseller_add_durasi_60_wm_${targetUserId}` }
            ],
            [
              { text: '3 Bulan (90 Hari)', callback_data: `reseller_add_durasi_90_wm_${targetUserId}` },
              { text: '4 Bulan (120 Hari)', callback_data: `reseller_add_durasi_120_wm_${targetUserId}` }
            ],
            [
              { text: '5 Bulan (150 Hari)', callback_data: `reseller_add_durasi_150_wm_${targetUserId}` }
            ],
            [
              { text: '❌ Batal', callback_data: 'back_main' }
            ]
          ]
        }
      });
      
      return;
      
    } catch (error) {
      failList.push(`${targetUserId} (error: ${error.message})`);
    }
  }
  
  await safeDeleteMessage(chatId, statusMsg.message_id);
  
  let resultMsg = `<blockquote>✅ <b><u>HASIL TAMBAH BASIC (WM)</u></b></blockquote>\n\n`;
  resultMsg += `<blockquote><b>✅ BERHASIL (${successList.length}):</b></blockquote>\n`;
  for (const s of successList) {
    resultMsg += `<blockquote> • ${s}</blockquote>\n`;
  }
  resultMsg += `\n<blockquote><b>❌ GAGAL (${failList.length}):</b></blockquote>\n`;
  for (const f of failList) {
    resultMsg += `<blockquote> • ${f}</blockquote>\n`;
  }
  
  await bot.sendMessage(chatId, resultMsg, { parse_mode: 'HTML' });
  return;
  }

  if (global.waitingResellerAddPro && global.waitingResellerAddPro[userId]) {
  delete global.waitingResellerAddPro[userId];
  
  const inputs = text.split(',').map(i => i.trim()).filter(i => i.length > 0);
  let successList = [];
  let failList = [];
  
  const statusMsg = await bot.sendMessage(chatId, `<blockquote>⏳ Memproses ${inputs.length} user...</blockquote>`, { parse_mode: 'HTML' });
  
  for (const input of inputs) {
    let targetUserId = input;
    
    if (input.startsWith('@')) {
      const username = input.replace('@', '');
      try {
        const userData = await db.get('SELECT user_id FROM users WHERE username LIKE ?', `%${username}%`);
        if (userData) {
          targetUserId = userData.user_id;
        } else {
          const chat = await bot.getChat(username).catch(() => null);
          if (chat) {
            targetUserId = chat.id.toString();
          } else {
            failList.push(`${input} (username tidak ditemukan)`);
            continue;
          }
        }
      } catch (error) {
        failList.push(`${input} (error: ${error.message})`);
        continue;
      }
    }
    
    if (!/^\d+$/.test(targetUserId)) {
      failList.push(`${input} (format ID salah)`);
      continue;
    }
    
    try {
      const isAlreadyReseller = await db.get('SELECT * FROM reseller_list WHERE user_id = ?', targetUserId);
      if (isAlreadyReseller) {
        failList.push(`${targetUserId} (sudah jadi reseller, tidak perlu ditambah)`);
        continue;
      }
      
      global.resellerAddData = global.resellerAddData || {};
      global.resellerAddData[userId] = { 
        targetUserId, 
        type: 'nowm', 
        inputs: inputs, 
        successList: successList, 
        failList: failList, 
        statusMsgId: statusMsg.message_id,
        currentIndex: 0
      };
      
      await safeDeleteMessage(chatId, statusMsg.message_id);
      
      await bot.sendMessage(chatId, `
<blockquote>📅 <b>Pilih Durasi untuk User ${targetUserId}</b></blockquote>
<blockquote>👤 Target User: <code>${targetUserId}</code>
📦 Paket: <b>Pro (NO WM)</b></blockquote>
<blockquote>Pilih durasi (maksimal 5 bulan / 150 hari):</blockquote>`, {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '1 Bulan (30 Hari)', callback_data: `reseller_add_durasi_30_nowm_${targetUserId}` },
              { text: '2 Bulan (60 Hari)', callback_data: `reseller_add_durasi_60_nowm_${targetUserId}` }
            ],
            [
              { text: '3 Bulan (90 Hari)', callback_data: `reseller_add_durasi_90_nowm_${targetUserId}` },
              { text: '4 Bulan (120 Hari)', callback_data: `reseller_add_durasi_120_nowm_${targetUserId}` }
            ],
            [
              { text: '5 Bulan (150 Hari)', callback_data: `reseller_add_durasi_150_nowm_${targetUserId}` }
            ],
            [
              { text: '❌ Batal', callback_data: 'back_main' }
            ]
          ]
        }
      });
      
      return;
      
    } catch (error) {
      failList.push(`${targetUserId} (error: ${error.message})`);
    }
  }
  
  await safeDeleteMessage(chatId, statusMsg.message_id);
  
  let resultMsg = `<blockquote>✅ <b><u>HASIL TAMBAH PRO (NO WM)</u></b></blockquote>\n\n`;
  resultMsg += `<blockquote><b>✅ BERHASIL (${successList.length}):</b></blockquote>\n`;
  for (const s of successList) {
    resultMsg += `<blockquote> • ${s}</blockquote>\n`;
  }
  resultMsg += `\n<blockquote><b>❌ GAGAL (${failList.length}):</b></blockquote>\n`;
  for (const f of failList) {
    resultMsg += `<blockquote> • ${f}</blockquote>\n`;
  }
  
  await bot.sendMessage(chatId, resultMsg, { parse_mode: 'HTML' });
  return;
  }
  
  if (global.waitingResellerDelete && global.waitingResellerDelete[userId]) {
  delete global.waitingResellerDelete[userId];
  
  const inputs = text.split(',').map(i => i.trim()).filter(i => i.length > 0);
  let successList = [];
  let failList = [];
  
  const statusMsg = await bot.sendMessage(chatId, `<blockquote>⏳ Memproses ${inputs.length} user...</blockquote>`, { parse_mode: 'HTML' });
  
  for (const input of inputs) {
    let targetUserId = input;
    
    if (input.startsWith('@')) {
      const username = input.replace('@', '');
      try {
        const userData = await db.get('SELECT user_id FROM users WHERE username LIKE ?', `%${username}%`);
        if (userData) {
          targetUserId = userData.user_id;
        } else {
          const chat = await bot.getChat(username).catch(() => null);
          if (chat) {
            targetUserId = chat.id.toString();
          } else {
            failList.push(`${input} (username tidak ditemukan)`);
            continue;
          }
        }
      } catch (error) {
        failList.push(`${input} (error: ${error.message})`);
        continue;
      }
    }
    
    if (!/^\d+$/.test(targetUserId)) {
      failList.push(`${input} (format ID salah)`);
      continue;
    }
    
    const addedByReseller = await db.get('SELECT * FROM reseller_added WHERE reseller_id = ? AND user_id = ?', userId, targetUserId);
    
    if (!addedByReseller) {
      failList.push(`${targetUserId} (tidak ditambahkan oleh Anda atau tidak memiliki akses premium dari Anda)`);
      continue;
    }
    
    const isWm = await db.get('SELECT * FROM premium_wm WHERE user_id = ?', targetUserId);
    const isNowm = await db.get('SELECT * FROM premium_no_wm WHERE user_id = ?', targetUserId);
    
    let deletedType = '';
    
    try {
      if (isWm) {
        await db.run('DELETE FROM premium_wm WHERE user_id = ?', targetUserId);
        deletedType = 'Basic (WM)';
      }
      
      if (isNowm) {
        await db.run('DELETE FROM premium_no_wm WHERE user_id = ?', targetUserId);
        deletedType = deletedType ? `${deletedType} & Pro (NO WM)` : 'Pro (NO WM)';
      }
      
      await db.run('DELETE FROM reseller_added WHERE reseller_id = ? AND user_id = ?', userId, targetUserId);
      
      const stillHasWm = await db.get('SELECT * FROM premium_wm WHERE user_id = ?', targetUserId);
      const stillHasNowm = await db.get('SELECT * FROM premium_no_wm WHERE user_id = ?', targetUserId);
      const isResellerUser = await db.get('SELECT * FROM reseller_list WHERE user_id = ?', targetUserId);
      
      if (!stillHasWm && !stillHasNowm && !isResellerUser) {
        await db.run('UPDATE users SET role = "FREE" WHERE user_id = ?', targetUserId);
      }
      
      await cleanupUserData(targetUserId, `deleted_by_reseller_${userId}`);
      
      successList.push(`${targetUserId} (${deletedType})`);
      
      try {
        await bot.sendMessage(targetUserId, `
<blockquote>⚠️ <b>Akses Premium Dicabut</b></blockquote>
<blockquote>Akses premium Anda (${deletedType}) telah dihapus oleh reseller.
Userbot Anda juga sudah otomatis dihapus dari sistem.</blockquote>
<blockquote>Hubungi reseller atau owner untuk info lebih lanjut.</blockquote>`, { parse_mode: 'HTML' });
      } catch (e) {}
      
    } catch (error) {
      failList.push(`${targetUserId} (error: ${error.message})`);
    }
  }
  
  await safeDeleteMessage(chatId, statusMsg.message_id);
  
  let resultMsg = `<blockquote>✅ <b><u>HASIL HAPUS AKSES PREMIUM</u></b></blockquote>\n\n`;
  resultMsg += `<blockquote><b>✅ BERHASIL (${successList.length}):</b></blockquote>\n`;
  for (const s of successList) {
    resultMsg += `<blockquote> • ${s}</blockquote>\n`;
  }
  resultMsg += `\n<blockquote><b>❌ GAGAL (${failList.length}):</b></blockquote>\n`;
  for (const f of failList) {
    resultMsg += `<blockquote> • ${f}</blockquote>\n`;
  }
  
  await bot.sendMessage(chatId, resultMsg, { parse_mode: 'HTML' });
  return;
  }
  
  if (text === '➖ Hapus Basic/Pro') {
    await handleResellerDelete(userId, chatId);
    return;
  }
  
  if (text === '📋 Daftar Member Premium') {
    await handleResellerListPrem(userId, chatId);
    return;
  }
  
  if (text === '📋 Daftar Produk') {
    await produkBaruShowList(userId, chatId);
    return;
  }

  if (text === '🗂 Laporan Stok') {
    await handleProdukBaruLaporanStok(userId, chatId, null);
    return;
  }

  if (text === '❔ Cara Pemesanan') {
    await handleCaraOrder(userId, chatId);
    return;
  }

  if (text === 'ℹ️ Informasi') {
    await handleInformation(userId, chatId);
    return;
  }

  if (global.waitingForProdukDepositCustom === userId) {
  delete global.waitingForProdukDepositCustom;
  const nominal = parseInt(text);
  
  if (isNaN(nominal) || nominal < 2000) {
    await bot.sendMessage(chatId, '<blockquote>❌ Minimal deposit Rp 2.000</blockquote>', { parse_mode: 'HTML' });
    await produkBaruShowDepositMenu(userId, chatId, null);
    return;
  }
  if (nominal > 20000) {
    await bot.sendMessage(chatId, '<blockquote>❌ Maksimal deposit Rp 20.000</blockquote>', { parse_mode: 'HTML' });
    await produkBaruShowDepositMenu(userId, chatId, null);
    return;
  }
  
  produkBaruDepositAmount[userId] = nominal;
  await produkBaruShowDepositMenu(userId, chatId, null);
  return;
}
  
  if (global.waitingForDepositCustom === userId) {
  delete global.waitingForDepositCustom;
  const nominal = parseInt(text);
  
  if (isNaN(nominal) || nominal < 2000) {
    await bot.sendMessage(chatId, '<blockquote>❌ Minimal deposit Rp 2.000</blockquote>', { parse_mode: 'HTML' });
    await produkBaruShowDepositMenu(userId, chatId, null);
    return;
  }
  if (nominal > 20000) {
    await bot.sendMessage(chatId, '<blockquote>❌ Maksimal deposit Rp 20.000</blockquote>', { parse_mode: 'HTML' });
    await produkBaruShowDepositMenu(userId, chatId, null);
    return;
  }
  
  produkBaruDepositAmount[userId] = nominal;
  await produkBaruShowDepositMenu(userId, chatId, null);
  return;
  }
  
  if (global.waitingEditProdukBaru && global.waitingEditProdukBaru.userId === userId) {
    const data = global.waitingEditProdukBaru;
    delete global.waitingEditProdukBaru;
    
    const product = produkBaruData.find(p => p.id === data.productId);
    if (!product) {
      await bot.sendMessage(chatId, `<blockquote><b>❌ Produk tidak ditemukan!</b></blockquote>`, { parse_mode: 'HTML' });
      return;
    }
    
    let newValue = text.trim();
    let updateField = '';
    let updateValue = null;
    
    switch (data.field) {
      case 'nama':
        updateField = 'name';
        updateValue = newValue;
        break;
      case 'kode':
        updateField = 'code';
        updateValue = newValue;
        break;
      case 'deskripsi':
        updateField = 'description';
        updateValue = newValue;
        break;
      case 'harga':
        updateValue = parseInt(newValue);
        if (isNaN(updateValue) || updateValue <= 0) {
          await bot.sendMessage(chatId, `<blockquote><b>❌ Harga harus angka positif!</b></blockquote>`, { parse_mode: 'HTML' });
          return;
        }
        updateField = 'price';
        break;
      case 'stok':
        updateValue = parseInt(newValue);
        if (isNaN(updateValue) || updateValue < 0) {
          await bot.sendMessage(chatId, `<blockquote><b>❌ Stok harus angka!</b></blockquote>`, { parse_mode: 'HTML' });
          return;
        }
        updateField = 'stock';
        break;
      case 'note':
        updateField = 'note';
        updateValue = newValue;
        break;
      default:
        return;
    }
    
    produkBaruUpdate(data.productId, { [updateField]: updateValue });
    
    await bot.sendMessage(chatId, `<blockquote><b>✅ ${data.field} berhasil diupdate!</b></blockquote>`, { parse_mode: 'HTML' });
    await produkBaruEditForm(null, userId, chatId, null, data.productId);
    return;
  }

  if (global.waitingEditProdukBaruFile && global.waitingEditProdukBaruFile.userId === userId) {
    const data = global.waitingEditProdukBaruFile;
    delete global.waitingEditProdukBaruFile;
    
    let fileId = null;
    let fileName = null;
    let mimeType = null;
    let fileSize = null;
    
    if (msg.document) {
      fileId = msg.document.file_id;
      fileName = msg.document.file_name;
      mimeType = msg.document.mime_type;
      fileSize = msg.document.file_size;
    } else if (msg.photo) {
      fileId = msg.photo[msg.photo.length - 1].file_id;
      fileName = `photo_${Date.now()}.jpg`;
      mimeType = 'image/jpeg';
      fileSize = msg.photo[msg.photo.length - 1].file_size;
    } else if (msg.video) {
      fileId = msg.video.file_id;
      fileName = msg.video.file_name || `video_${Date.now()}.mp4`;
      mimeType = msg.video.mime_type;
      fileSize = msg.video.file_size;
    } else {
      await bot.sendMessage(chatId, `<blockquote><b>❌ Kirim file yang valid (dokumen, foto, atau video).</b></blockquote>`, { parse_mode: 'HTML' });
      return;
    }
    
    produkBaruUpdate(data.productId, {
      file_id: fileId,
      file_name: fileName,
      file_mime: mimeType,
      file_size: fileSize
    });
    
    await bot.sendMessage(chatId, `
<blockquote>✅ <b>File berhasil diupload!</b>
📎 Nama file: ${fileName}
📦 Ukuran: ${(fileSize / 1024).toFixed(2)} KB</blockquote>`, { parse_mode: 'HTML' });
    await produkBaruEditForm(null, userId, chatId, null, data.productId);
    return;
  }

  if (produkBaruCurrentPage[userId] && text.match(/^\d+$/)) {
    const selectedNumber = parseInt(text);
    const start = (produkBaruCurrentPage[userId].page - 1) * 10;
    const productIndex = selectedNumber - 1;
    const absoluteIndex = start + productIndex;
    const products = produkBaruCurrentPage[userId].products;
    
    if (absoluteIndex >= 0 && absoluteIndex < products.length) {
      const product = products[absoluteIndex];
      
      produkBaruUserCart[userId] = {
        productId: product.id,
        qty: 1,
        product: product,
        productIndex: absoluteIndex
      };
      
      const saldo = await produkBaruCekSaldo(userId);
      const totalHarga = product.price;
      const cukupSaldo = saldo >= totalHarga;
      
      const caption = `
<blockquote><b><u>📝 Tambahkan jumlah pembelian</u></b></blockquote>
<blockquote><b>📦 Produk</b> : <b>${product.name}</b>
<b>🔑 Kode</b> : <code>${product.code || '-'}</code>
<b>📊 Sisa Stok</b> : <code>${product.stock}</code>
<b>📈 Stok Terjual</b> : <code>${product.sold || 0}</code>
<b>📝 Deskripsi</b> : <i>${product.description}</i></blockquote>
<blockquote><b>🔢 Jumlah</b> : <code><b>1</b></code>
<b>💰 Harga</b> : <code><b>Rp ${product.price.toLocaleString()}</b></code>
<b>💵 Total Harga</b> : <code><b>Rp ${totalHarga.toLocaleString()}</b></code>
<b>💳 Saldo Anda</b> : <code><b>Rp ${saldo.toLocaleString()}</b></code>
${!cukupSaldo ? `\n⚠️ <i>Saldo tidak mencukupi, silakan deposit atau bayar via QRIS</i>` : ''}</blockquote>

<i>Gunakan tombol di bawah</i>`;

      const keyboard = {
        inline_keyboard: [
          [
            { text: '➖', callback_data: 'produk_baru_qty_dec' },
            { text: '1', callback_data: 'produk_baru_qty_show' },
            { text: '➕', callback_data: 'produk_baru_qty_inc' }
          ],
          [
            { text: '💳 Buy (Saldo)', callback_data: `produk_baru_buy_saldo_${product.id}_1` },
            { text: '⚡ Buy (Now)', callback_data: `produk_baru_buy_now_${product.id}_1` }
          ],
          [
            { text: '💰 Cek Saldo', callback_data: 'produk_baru_cek_saldo' },
            { text: '❌ Batal', callback_data: 'produk_baru_back_to_list' }
          ]
        ]
      };
      
      await bot.sendMessage(chatId, caption, {
        parse_mode: 'HTML',
        reply_markup: keyboard
      });
      
    } else {
      await bot.sendMessage(chatId, `<blockquote><b>❌ Nomor produk tidak valid!</b></blockquote>`, { parse_mode: 'HTML' });
    }
    return;
  }
  
  if (text === '🛠️ Perangkat') {
    await handleToolsMenu(userId, chatId);
    return;
  }
  
  if (text === '📊 Status Akun') {
    await handleStatusAkun(userId, chatId);
    return;
  }
  
  if (text === '✅ Klaim Userbot Gratis') {
    await handleMulaiTrial(userId, chatId);
    return;
  }
  
  if (text === '🤖 Deploy Userbot') {
    await handleBuatUserbot(userId, chatId);
    return;
  }
  
  if (text === '🛒 Beli Userbot') {
    await handleBeliUserbot(userId, chatId);
    return;
  }
  
  if (text === '🔄 Perpanjang Userbot') {
    await handlePerpanjangUserbot(userId, chatId);
    return;
  }
  
  if (text === '🎁 Berikan Userbot') {
    await handleGiveUserbot(userId, chatId);
    return;
  }
  
  if (text === '🔃 Pulihkan Database') {
    await handleBackupRestore(userId, chatId);
    return;
  }
  
  if (text === '💰 Pengaturan Harga') {
    await handleSettingHarga(userId, chatId);
    return;
  }
  
  if (text === '👑 Kontrol Admin') {
    await handleExpertExtraAdmin(userId, chatId);
    return;
  }
  
  if (text === '📨 Pengaturan Notifikasi') {
    await handleUbahNotif(userId, chatId);
    return;
  }

  if (text === '👤 Daftar Pengguna') {
    await handleNotifUserLain(userId, chatId);
    return;
  }
  
  if (text === '📝 Pesan Tersimpan') {
    await handleNotifSaved(userId, chatId);
    return;
  }

  if (text === '🔄 Reset Notifikasi') {
    await handleResetNotif(userId, chatId);
    return;
  }
  
  if (global.waitingForNotifTarget && global.notifTargetUserId === userId) {
    await handleSetNotifTargetInput(userId, chatId, text);
    return;
  }

  if (text === '👑 Tambah Admin') {
    await handleAddAdmin(userId, chatId);
    return;
  }
  
  if (text === '🗑️ Hapus Admin') {
    await handleRemoveAdmin(userId, chatId);
    return;
  }
  
  if (text === '📋 Daftar Admin') {
    await handleListAdmin(userId, chatId);
    return;
  }
  
  if (text === '🕹️ Kontrol Akun') {
    await handleAdminControlAccount(userId, chatId);
    return;
  }
  
  if (text === '📄 Kelola Teks') {
    await showAdminKelolaPesanMenu(userId, chatId);
    return;
  }
  
  if (text === '💬 Kelola Grup') {
    await showAdminKelolaGroupMenu(userId, chatId);
    return;
  }
  
  if (text === '⏱️ Delay & Jeda') {
    await showAdminDelayJedaMenu(userId, chatId);
    return;
  }
  
  if (text === '📢 Menu Broadcast') {
    await showAdminBroadcastMenu(userId, chatId);
    return;
  }
  
  if (text === '📢 Broadcast Pesan Pribadi') {
    await handleBroadcastPM(userId, chatId);
    return;
  }
  
  if (text === '➕ Tambah Pesan') {
    await handleAdminSetPesan(userId, chatId);
    return;
  }
  
  if (text === '↗️ Atur Forward') {
    await handleAdminModeForward(userId, chatId);
    return;
  }

  if (global.waitingForAdminForwardLink && global.waitingForAdminForwardLink[userId]) {
    await handleAdminForwardLinkInput(userId, chatId, text);
    return;
  }

  if (text === '🗑️ Hapus Pesan') {
    await handleAdminDelPesan(userId, chatId);
    return;
  }
  
  if (text === '📋 Daftar Pesan') {
    await handleAdminListPesan(userId, chatId);
    return;
  }
  
  if (text === '➕ Tambah Grup') {
    await handleAdminTambahGroup(userId, chatId);
    return;
  }
  
  if (text === '📝 Tambah Manual') {
    await handleAdminTambahGroupManual(userId, chatId);
    return;
  }
  
  if (text === '🔄 Tambah Otomatis') {
    await handleAdminTambahGroupOtomatis(userId, chatId);
    return;
  }
  
  if (text === '🗑️ Hapus Grup') {
    await handleAdminHapusGroup(userId, chatId);
    return;
  }
  
  if (text === '📝 Hapus Manual') {
    await handleAdminHapusGroupManual(userId, chatId);
    return;
  }
  
  if (text === '🗑️ Hapus Semua') {
    await handleAdminHapusGroupSemua(userId, chatId);
    return;
  }
  
  if (text === '📋 Daftar Grup') {
    await handleAdminListGroup(userId, chatId);
    return;
  }
  
  if (text === '⏱️ Atur Delay (Admin)') {
    await handleAdminSetDelay(userId, chatId);
    return;
  }
  
  if (text === '⏸️ Atur Jeda (Admin)') {
    await handleAdminSetJeda(userId, chatId);
    return;
  }
  
  if (text === '▶️ Aktifkan Auto Share') {
    await handleAdminAktifkanAutoBC(userId, chatId);
    return;
  }
  
  if (text === '🔄 Nonaktifkan Auto Share') {
    await handleAdminNonaktifkanAutoBC(userId, chatId);
    return;
  }
  
  if (text === '⏸️ Jeda Auto Share') {
    await handleAdminJedaAutoBC(userId, chatId);
    return;
  }
  
  if (text === '⏹️ Hentikan Auto Share') {
    await handleAdminStopAutoBC(userId, chatId);
    return;
  }
  
  if (text === '🗑️ Hapus Manual' && global.waitingForAdminDelPesanChoice && global.waitingForAdminDelPesanChoice[userId]) {
    await handleAdminDelPesanManual(userId, chatId);
    return;
  }

  if (text === '🗑️ Hapus Semua' && global.waitingForAdminDelPesanChoice && global.waitingForAdminDelPesanChoice[userId]) {
    await handleAdminDelPesanSemua(userId, chatId);
    return;
  }

  if (global.waitingForAddAdminInput && global.waitingForAddAdminInput[userId]) {
    await handleAddAdminInput(userId, chatId, text);
    return;
  }

  if (global.waitingForRemoveAdminInput && global.waitingForRemoveAdminInput[userId]) {
    await handleRemoveAdminInput(userId, chatId, text);
    return;
  }

  if (global.waitingForAdminSetPesan && global.waitingForAdminSetPesan[userId]) {
    delete global.waitingForAdminSetPesan[userId];
    
    const data = global.adminSelectedUbot[userId];
    if (!data) {
      await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Sesi admin habis. Pilih userbot dulu.</b></blockquote>`, { parse_mode: 'HTML' });
      return;
    }
    
    let type = 'text';
    let content = msg.text || '';
    let fileId = null;
    let caption = msg.caption || '';
    
    if (msg.photo) {
      type = 'photo';
      fileId = msg.photo[msg.photo.length - 1].file_id;
      content = caption;
    } else if (msg.video) {
      type = 'video';
      fileId = msg.video.file_id;
      content = caption;
    } else if (msg.document) {
      type = 'document';
      fileId = msg.document.file_id;
      content = caption;
    } else if (msg.audio) {
      type = 'audio';
      fileId = msg.audio.file_id;
      content = caption;
    } else if (msg.voice) {
      type = 'voice';
      fileId = msg.voice.file_id;
      content = caption;
    } else if (msg.sticker) {
      type = 'sticker';
      fileId = msg.sticker.file_id;
      content = '';
    } else if (msg.animation) {
      type = 'animation';
      fileId = msg.animation.file_id;
      content = caption;
    }
    
    if (type === 'text' && !content) {
      await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
📝 <b>Pesan tidak boleh kosong.</b></blockquote>`, { parse_mode: 'HTML' });
      await showAdminKelolaPesanMenu(userId, chatId);
      return;
    }
    
    const lastMessage = await db.get('SELECT MAX(local_id) as max FROM messages WHERE owner_id = ?', data.ownerId);
    const nextLocalId = (lastMessage?.max || 0) + 1;
    
    await db.run(
      'INSERT INTO messages (owner_id, local_id, type, content, file_id, caption, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
      data.ownerId, nextLocalId, type, content, fileId, caption, Math.floor(Date.now() / 1000)
    );
    
    const newMessage = await db.get('SELECT id FROM messages WHERE owner_id = ? AND local_id = ?', data.ownerId, nextLocalId);
    
    if (newMessage) {
      await db.run('UPDATE settings SET selected_message_id = ? WHERE owner_id = ?', newMessage.id, data.ownerId);
    }
    
    await bot.sendMessage(chatId, `
<blockquote>✅ <b><u>BERHASIL</u></b>
📝 <b>Pesan #${nextLocalId} berhasil disimpan dan dipilih sebagai pesan aktif!</b></blockquote>`, { parse_mode: 'HTML' });
    await showAdminKelolaPesanMenu(userId, chatId);
    return;
  }

  if (global.waitingForAdminDelPesan && global.waitingForAdminDelPesan[userId]) {
    const data = global.waitingForAdminDelPesan[userId];
    delete global.waitingForAdminDelPesan[userId];
    
    const index = parseInt(text) - 1;
    if (isNaN(index) || index < 0 || index >= data.messages.length) {
      await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🔢 <b>Nomor pesan tidak valid.</b></blockquote>`, { parse_mode: 'HTML' });
      await showAdminKelolaPesanMenu(userId, chatId);
      return;
    }
    
    const messageToDelete = data.messages[index];
    const settings = await db.get('SELECT selected_message_id FROM settings WHERE owner_id = ?', data.ownerId);
    
    await db.run('DELETE FROM messages WHERE id = ? AND owner_id = ?', messageToDelete.id, data.ownerId);
    
    if (settings && settings.selected_message_id === messageToDelete.id) {
      await db.run('UPDATE settings SET selected_message_id = NULL WHERE owner_id = ?', data.ownerId);
    }
    
    await bot.sendMessage(chatId, `
<blockquote>✅ <b><u>BERHASIL DIHAPUS</u></b>
🗑️ <b>Pesan #${messageToDelete.local_id} berhasil dihapus!</b></blockquote>`, { parse_mode: 'HTML' });
    await showAdminKelolaPesanMenu(userId, chatId);
    return;
  }

  if (global.waitingForAdminTambahGroupManual && global.waitingForAdminTambahGroupManual[userId]) {
    const data = global.waitingForAdminTambahGroupManual[userId];
    delete global.waitingForAdminTambahGroupManual[userId];
    
    const ubot = userbots.find(ub => ub.owner_id === data.ownerId);
    if (!ubot) {
      await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Userbot tidak ditemukan.</b></blockquote>`, { parse_mode: 'HTML' });
      return;
    }
    
    const inputs = text.split(',').map(i => i.trim()).filter(i => i.length > 0);
    let added = 0;
    let failed = 0;
    let alreadyExist = 0;
    const failedDetails = [];
    const newGroups = [];
    
    const statusMsg = await bot.sendMessage(chatId, `
<blockquote>⏳ <b><u>MEMPROSES</u></b>
🔄 <i>Memproses ${inputs.length} grup...</i></blockquote>`, { parse_mode: 'HTML' });
    
    for (const input of inputs) {
      if (!input) continue;
      
      try {
        let groupId = null;
        let groupTitle = input;
        let groupUsername = '';
        
        if (input.startsWith('@')) {
          let username = input.replace('@', '');
          let entity = await ubot.client.getEntity(username);
          groupId = getMarkedGroupId(entity);
          groupTitle = entity.title;
          groupUsername = username;
          
          try {
            await ubot.client.invoke(new Api.channels.JoinChannel({ channel: entity }));
          } catch (joinErr) {
            if (!joinErr.message.includes('USER_ALREADY_PARTICIPANT')) {
              throw joinErr;
            }
          }
        }
        else if (input.match(/^-?\d+$/)) {
          groupId = input;
          let entity = await ubot.client.getEntity(parseInt(groupId));
          groupTitle = entity.title;
          groupUsername = entity.username || '';
          
          try {
            await ubot.client.invoke(new Api.channels.JoinChannel({ channel: entity }));
          } catch (joinErr) {
            if (!joinErr.message.includes('USER_ALREADY_PARTICIPANT')) {
              throw joinErr;
            }
          }
        }
        else if (input.includes('t.me/')) {
          let inviteHash = '';
          if (input.includes('t.me/+')) {
            inviteHash = input.split('t.me/+')[1].split('/')[0].split('?')[0];
          } else if (input.includes('t.me/joinchat/')) {
            inviteHash = input.split('t.me/joinchat/')[1].split('/')[0].split('?')[0];
          } else {
            let username = input.split('t.me/')[1].split('/')[0];
            let entity = await ubot.client.getEntity(username);
            groupId = getMarkedGroupId(entity);
            groupTitle = entity.title;
            groupUsername = username;
            
            try {
              await ubot.client.invoke(new Api.channels.JoinChannel({ channel: entity }));
            } catch (joinErr) {
              if (!joinErr.message.includes('USER_ALREADY_PARTICIPANT')) {
                throw joinErr;
              }
            }
          }
          
          if (inviteHash) {
            try {
              const result = await ubot.client.invoke(new Api.messages.ImportChatInvite({ hash: inviteHash }));
              if (result && result.chats && result.chats.length > 0) {
                groupId = getMarkedGroupId(result.chats[0]);
                groupTitle = result.chats[0].title;
              }
            } catch (err) {
              if (err.message.includes('USER_ALREADY_PARTICIPANT')) {
                const dialogs = await ubot.client.getDialogs();
                for (const dialog of dialogs) {
                  if (dialog.isGroup && dialog.inviteLink && dialog.inviteLink.includes(inviteHash)) {
                    groupId = dialog.id.toString();
                    groupTitle = dialog.title;
                    groupUsername = dialog.username || '';
                    break;
                  }
                }
                if (!groupId) {
                  throw new Error('Userbot sudah join tapi grup tidak ditemukan di dialog');
                }
              } else {
                throw err;
              }
            }
          }
        }
        else {
          throw new Error('Format tidak dikenali');
        }
        
        if (!groupId) {
          throw new Error('Gagal mendapatkan ID grup');
        }
        
        const exists = await db.get('SELECT * FROM groups WHERE owner_id = ? AND group_id = ?', data.ownerId, groupId);
        
        if (!exists) {
          await db.run(
            'INSERT INTO groups (owner_id, group_id, group_title, group_username, added_at) VALUES (?, ?, ?, ?, ?)',
            data.ownerId, groupId, groupTitle, groupUsername, Math.floor(Date.now() / 1000)
          );
          added++;
          newGroups.push({ group_id: groupId, group_title: groupTitle });
        } else {
          alreadyExist++;
        }
        
      } catch (error) {
        failed++;
        let errorMsg = error.message;
        if (errorMsg.includes('USER_ALREADY_PARTICIPANT')) {
          errorMsg = 'Sudah join';
        } else if (errorMsg.includes('CHANNEL_PRIVATE')) {
          errorMsg = 'Grup private, undang userbot dulu';
        } else if (errorMsg.includes('FLOOD')) {
          errorMsg = 'Flood wait';
        } else if (errorMsg.includes('Invite') || errorMsg.includes('invite')) {
          errorMsg = 'Link invite tidak valid';
        }
        failedDetails.push(`${input.substring(0, 40)} (${errorMsg.substring(0, 50)})`);
      }
      
      await new Promise(r => setTimeout(r, 1000));
    }
    
    await safeDeleteMessage(chatId, statusMsg.message_id);
    
    let resultMsg = `
<blockquote>✅ <b><u>HASIL TAMBAH GRUP</u></b></blockquote>
<blockquote>✅ Berhasil: ${added} grup
📋 Sudah ada: ${alreadyExist} grup
❌ Gagal: ${failed} grup</blockquote>`;
    
    if (failedDetails.length > 0 && failedDetails.length <= 10) {
      resultMsg += `

<blockquote><b>Detail Gagal:</b>
${failedDetails.map(d => ` • ${d}`).join('\n')}</blockquote>`;
    } else if (failedDetails.length > 10) {
      resultMsg += `

<blockquote><b>${failedDetails.length} grup gagal ditambahkan</b></blockquote>`;
    }
    
    await bot.sendMessage(chatId, resultMsg, { parse_mode: 'HTML' });
    
    if (added > 0 && promosiProgress[data.ownerId] && promosiProgress[data.ownerId].running) {
      try {
        const currentGroups = await db.all('SELECT * FROM groups WHERE owner_id = ?', data.ownerId);
        const blacklistGroups = await db.all('SELECT group_id FROM blacklist_groups WHERE owner_id = ?', data.ownerId);
        const blacklistIds = blacklistGroups.map(b => b.group_id.toString());
        const validGroups = currentGroups.filter(g => {
          return parseInt(g.group_id) < 0 && !blacklistIds.includes(g.group_id.toString());
        });
        
        promosiProgress[data.ownerId].validGroups = validGroups;
        
        await savePromosiState(data.ownerId);
        await savePromosiStateToFile();
        
        await bot.sendMessage(chatId, `
<blockquote>🔄 <b><u>GRUP BERHASIL DIUPDATE</u></b>
✅ <b>${added} grup baru telah ditambahkan ke daftar broadcast!</b>
📊 <b>Total grup sekarang:</b> ${validGroups.length} grup</blockquote>

<i>Grup baru akan otomatis dipakai di Putaran berikutnya</i>`, { parse_mode: 'HTML' });
      } catch (refreshErr) {
        logger.error(`Gagal refresh grup: ${refreshErr.message}`);
      }
    }
    
    await showAdminKelolaGroupMenu(userId, chatId);
    return;
  }

  if (global.waitingForAdminHapusGroupManual && global.waitingForAdminHapusGroupManual[userId]) {
    const data = global.waitingForAdminHapusGroupManual[userId];
    delete global.waitingForAdminHapusGroupManual[userId];
    
    const nomor = parseInt(text);
    if (isNaN(nomor) || nomor < 1 || nomor > data.groups.length) {
      await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🔢 <b>Nomor tidak valid. Kirim nomor antara 1 - ${data.groups.length}.</b></blockquote>`, { parse_mode: 'HTML' });
      await handleAdminHapusGroupManual(userId, chatId);
      return;
    }
    
    const groupToDelete = data.groups[nomor - 1];
    const ubot = userbots.find(ub => ub.owner_id === data.ownerId);
    
    const statusMsg = await bot.sendMessage(chatId, `
<blockquote>⏳ <b><u>MENGHAPUS GRUP</u></b>
🗑️ <i>Menghapus grup ${groupToDelete.group_title}...</i></blockquote>`, { parse_mode: 'HTML' });
    
    if (ubot && ubot.client) {
      try {
        let entity;
        const groupIdNum = parseInt(groupToDelete.group_id);
        try {
          entity = await ubot.client.getEntity(groupIdNum);
        } catch (err) {
          if (groupToDelete.group_username) {
            entity = await ubot.client.getEntity(groupToDelete.group_username);
          } else {
            throw new Error('Tidak bisa mendapatkan entity grup');
          }
        }
        
        if (entity) {
          await ubot.client.invoke(new Api.channels.LeaveChannel({ channel: entity }));
        }
      } catch (err) {
        logger.error(`Gagal keluar dari grup: ${err.message}`);
      }
    }
    
    await db.run('DELETE FROM groups WHERE id = ? AND owner_id = ?', groupToDelete.id, data.ownerId);
    
    await safeDeleteMessage(chatId, statusMsg.message_id);
    
    const successMsg = await bot.sendMessage(chatId, `
<blockquote>✅ <b><u>BERHASIL DIHAPUS!</u></b></blockquote>
<blockquote>🗑️ <b>Grup:</b> ${groupToDelete.group_title}
🆔 <b>ID:</b> <code>${groupToDelete.group_id}</code>
🤖 <b>Status:</b> Userbot telah keluar dari grup</blockquote>`, {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [
            { text: '🏠 Kembali', callback_data: 'admin_back_to_group_menu' }
          ]
        ]
      }
    });
    
    setTimeout(async () => {
      try {
        await safeDeleteMessage(chatId, successMsg.message_id);
      } catch (e) {}
      await handleAdminHapusGroupManual(userId, chatId);
    }, 2000);
    
    return;
  }

if (global.waitingForAdminSetDelay && global.waitingForAdminSetDelay[userId]) {
    const data = global.waitingForAdminSetDelay[userId];
    delete global.waitingForAdminSetDelay[userId];
    
    const delay = parseInt(text);
    if (isNaN(delay) || delay < 100 || delay > 5000) {
      await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🔢 <b>Masukkan angka antara 100-5000 milidetik.</b></blockquote>`, { parse_mode: 'HTML' });
      await showAdminDelayJedaMenu(userId, chatId);
      return;
    }
    
    await db.run('UPDATE settings SET delay = ? WHERE owner_id = ?', delay, data.ownerId);
    await bot.sendMessage(chatId, `
<blockquote>✅ <b><u>DELAY DIUPDATE</u></b>
⏰ <b>Delay diatur menjadi ${delay} ms (${delay/1000} detik).</b></blockquote>`, { parse_mode: 'HTML' });
    await showAdminDelayJedaMenu(userId, chatId);
    return;
  }

if (global.waitingForAdminSetJeda && global.waitingForAdminSetJeda[userId]) {
    const data = global.waitingForAdminSetJeda[userId];
    delete global.waitingForAdminSetJeda[userId];
    
    const jeda = parseInt(text);
    if (isNaN(jeda) || jeda < 1) {
      await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🔢 <b>Masukkan angka minimal 1 menit.</b></blockquote>`, { parse_mode: 'HTML' });
      await showAdminDelayJedaMenu(userId, chatId);
      return;
    }
    
    await db.run('UPDATE settings SET jeda = ? WHERE owner_id = ?', jeda, data.ownerId);
    
    let jedaText = '';
    if (jeda >= 1440) {
      const hari = jeda / 1440;
      jedaText = `${jeda} menit (${hari} hari)`;
    } else if (jeda >= 60) {
      const jam = jeda / 60;
      jedaText = `${jeda} menit (${jam} jam)`;
    } else {
      jedaText = `${jeda} menit`;
    }
    
    await bot.sendMessage(chatId, `
<blockquote>✅ <b><u>JEDA DIUPDATE</u></b>
🕐 <b>Jeda diatur menjadi ${jedaText}.</b></blockquote>`, { parse_mode: 'HTML' });
    await showAdminDelayJedaMenu(userId, chatId);
    return;
  }

if (text === '🔃 Pulihkan Database') {
    await handleBackupRestore(userId, chatId);
    return;
  }
  
if (global.waitingForEditHarga) {
    await processEditHargaInput(userId, chatId, text);
    return;
  }
  
if (text === '📂 Pesan & Grup' || text === '⬅️ Menu Pesan') {
    await handlePesanGroup(userId, chatId);
    return;
  }
  
if (text === '📝 Atur Pesan') {
    await handleKelolaPesan(userId, chatId);
    return;
  }
  
if (text === '📢 Pesan Forward') {
    await handleModeForward(userId, chatId);
    return;
  }
  
if (global.waitingForForwardLink && userId) {
    delete global.waitingForForwardLink;
    
    try {
      const ubot = userbots.find(ub => ub.owner_id === userId);
      if (!ubot) {
        await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Userbot ga ketemu.</b></blockquote>`);
        return;
      }
      
      let entity;
      let messageId;
      
      const urlPattern = /https?:\/\/t\.me\/(?:c\/)?([^\/]+)\/(\d+)/;
      const match = text.match(urlPattern);
      
      if (!match) {
        await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🔗 <b>Link ga valid. Pake format: https://t.me/username/1234</b></blockquote>`);
        return;
      }
      
      const chatPart = match[1];
      messageId = parseInt(match[2]);
      
      try {
        entity = await ubot.client.getEntity(chatPart);
      } catch {
        entity = await ubot.client.getEntity(`https://t.me/${chatPart}`);
      }
      
      const messages = await ubot.client.getMessages(entity, { ids: messageId });
      const msgForward = messages[0];
      
      if (!msgForward) {
        await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
📝 <b>Pesan ga ketemu.</b></blockquote>`);
        return;
      }
      
      const lastMessage = await db.get('SELECT MAX(local_id) as max FROM messages WHERE owner_id = ?', userId);
      const nextLocalId = (lastMessage?.max || 0) + 1;
      
      await db.run(
        'INSERT INTO messages (owner_id, local_id, type, content, file_id, caption, from_chat, forward_message_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
        userId, nextLocalId, 'forward', msgForward.message || '', null, msgForward.message || '', entity.id.toString(), messageId, Math.floor(Date.now() / 1000)
      );
      
      await bot.sendMessage(chatId, `
<blockquote>✅ <b><u>BERHASIL</u></b></blockquote>
<blockquote>📝 <b>Pesan #${nextLocalId} berhasil disimpan!</b></blockquote>

<i>Nanti bakal di-forward ke grup target (tanpa watermark).</i>`, {
        parse_mode: 'HTML',
        reply_markup: await getKelolaPesanKeyboard(userId)
      });
      
    } catch (error) {
      await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>GAGAL</u></b>
⚠️ <b>${error.message}</b></blockquote>`, {
        parse_mode: 'HTML'
      });
    }
    return;
  }
  
if (text === '📨 Pesan Salin') {
    await handleModeBiasa(userId, chatId);
    return;
  }
  
if (text === '📋 Lihat Pesan') {
    await handleLihatSemuaPesan(userId, chatId);
    return;
  }
  
if (text && text.startsWith('✅ Pilih Pesan #') && global.waitingForSelectMessage && global.waitingForSelectMessage[userId]) {
    const localId = parseInt(text.replace('✅ Pilih Pesan #', ''));
    
    const message = await db.get('SELECT id, local_id FROM messages WHERE owner_id = ? AND local_id = ?', userId, localId);
    
    if (message) {
      await db.run('UPDATE settings SET selected_message_id = ? WHERE owner_id = ?', message.id, userId);
      await bot.sendMessage(chatId, `
<blockquote>✅ <b><u>PESAN AKTIF DIPILIH</u></b>
📝 <b>Pesan #${message.local_id} dipilih jadi pesan aktif!</b></blockquote>`, { 
        parse_mode: 'HTML',
        reply_markup: await getKelolaPesanKeyboard(userId) 
      });
    } else {
      await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
📝 <b>Pesan ga ketemu.</b></blockquote>`, { parse_mode: 'HTML' });
    }
    
    delete global.waitingForSelectMessage[userId];
    return;
  }
  
if (text === '🗑️ Reset Teks') {
    await handleResetText(userId, chatId);
    return;
  }
  
if (global.waitingForDeleteMessage && global.waitingForDeleteMessage[userId]) {
    delete global.waitingForDeleteMessage[userId];
    
    const localId = parseInt(text);
    
    const message = await db.get('SELECT id FROM messages WHERE owner_id = ? AND local_id = ?', userId, localId);
    
    if (!message) {
      await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
📝 <b>Pesan ga ketemu.</b></blockquote>`, { parse_mode: 'HTML' });
      return;
    }
    
    const settings = await db.get('SELECT selected_message_id FROM settings WHERE owner_id = ?', userId);
    
    const result = await db.run('DELETE FROM messages WHERE id = ? AND owner_id = ?', message.id, userId);
    
    if (result.changes > 0) {
      if (settings && settings.selected_message_id === message.id) {
        await db.run('UPDATE settings SET selected_message_id = NULL WHERE owner_id = ?', userId);
      }
      await bot.sendMessage(chatId, `
<blockquote>✅ <b><u>BERHASIL DIHAPUS</u></b>
🗑️ <b>Pesan #${localId} berhasil dihapus!</b></blockquote>`, {
        parse_mode: 'HTML',
        reply_markup: await getKelolaPesanKeyboard(userId)
      });
    } else {
      await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
📝 <b>Pesan ga ketemu.</b></blockquote>`, { parse_mode: 'HTML' });
    }
    return;
  }
  
if (text === '🗑️ Reset Semua') {
    await handleResetSemuaText(userId, chatId);
    return;
  }
  
if (text === '👥 Atur Grup') {
    await handleKelolaGroup(userId, chatId);
    return;
  }
  
if (text === '➕ Tambah Manual') {
    await handleTambahManualGroup(userId, chatId);
    return;
  }
  
if (text === '🔄 Tambah Semua') {
    await handleTambahSemuaGroup(userId, chatId);
    return;
  }
  
if (text === '📋 Lihat Grup') {
    await handleLihatGrup(userId, chatId);
    return;
  }
  
if (text === '🗑️ Reset Semua Grup') {
    await handleResetSemuaGroup(userId, chatId);
    return;
  }
  
if (text === '🚫 Blacklist Grup') {
    await handleBlacklistGrup(userId, chatId);
    return;
  }
  
if (text === '➕ Tambah Blacklist') {
    await handleTambahBlacklist(userId, chatId);
    return;
  }
  
if (text === '📋 Lihat Blacklist') {
    await handleLihatBlacklist(userId, chatId);
    return;
  }
  
if (text === '➖ Hapus Blacklist') {
    await handleHapusBlacklist(userId, chatId);
    return;
  }
  
if (global.waitingForDeleteBlacklist && global.waitingForDeleteBlacklist[userId]) {
    delete global.waitingForDeleteBlacklist[userId];
    
    const groupId = text;
    const result = await db.run('DELETE FROM blacklist_groups WHERE group_id = ? AND owner_id = ?', groupId, userId);
    
    if (result && result.changes && result.changes > 0) {
      await bot.sendMessage(chatId, `
<blockquote>✅ <b><u>BERHASIL</u></b>
🚫 <b>Group berhasil dihapus dari blacklist!</b></blockquote>`, {
        parse_mode: 'HTML',
        reply_markup: await getBlacklistGroupKeyboard()
      });
    } else {
      await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🚫 <b>Group ga ketemu di blacklist.</b></blockquote>`, { parse_mode: 'HTML' });
    }
    return;
  }
  
if (text === '🚀 Jalankan Promosi') {
    await handleMenuBroadcast(userId, chatId);
    return;
  }
  
if (text === '▶️ Mulai' || text === '▶️Mulai' || text === '🚀 Mulai Broadcast') {
    await handleMulaiBroadcast(userId, chatId);
    return;
  }
  
if (text === '⏸️ Jeda') {
    await handleJedaBroadcast(userId, chatId);
    return;
  }
  
if (text === '⏹️ Hentikan') {
    await handleStopBroadcast(userId, chatId);
    return;
  }
  
if (text === '🔄 Ulangi Putaran') {
    await handleRestartRound(userId, chatId);
    return;
  }
  
if (text === '📢 Broadcast') {
    await handleBroadcastGlobal(userId, chatId);
    return;
  }
  
if (global.waitingForBroadcast && global.waitingForBroadcast.userId === userId && global.waitingForBroadcast.step === 'waiting_for_message') {
    let pesan = text;
    let fileId = null;
    let caption = '';
    let msgType = 'text';
    
    if (msg.photo) {
      msgType = 'photo';
      fileId = msg.photo[msg.photo.length - 1].file_id;
      caption = msg.caption || '';
      pesan = caption;
    } else if (msg.video) {
      msgType = 'video';
      fileId = msg.video.file_id;
      caption = msg.caption || '';
      pesan = caption;
    } else if (msg.document) {
      msgType = 'document';
      fileId = msg.document.file_id;
      caption = msg.caption || '';
      pesan = caption;
    } else if (msg.audio) {
      msgType = 'audio';
      fileId = msg.audio.file_id;
      caption = msg.caption || '';
      pesan = caption;
    } else if (msg.voice) {
      msgType = 'voice';
      fileId = msg.voice.file_id;
      caption = msg.caption || '';
      pesan = caption;
    }
    
    if (!pesan && !fileId && msgType === 'text') {
      await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
📝 Pesan ga boleh kosong.</blockquote>`, { parse_mode: 'HTML' });
      delete global.waitingForBroadcast;
      return;
    }
    
    global.waitingForBroadcast = {
      userId,
      step: 'waiting_for_confirmation',
      message: pesan,
      fileId: fileId,
      caption: caption,
      msgType: msgType
    };
    
    let preview = pesan ? pesan.substring(0, 200) : '[Media/file]';
    if (pesan && pesan.length > 200) preview += '...';
    
    await bot.sendMessage(chatId, `
<blockquote>⚠️ <b><u>KONFIRMASI BROADCAST</u></b></blockquote>
<blockquote>📩 Berikut pesan yang akan dikirim ke SEMUA user:</blockquote>
<blockquote>📝 <b>PREVIEW PESAN</b>
 ${preview}</blockquote>
<blockquote>👥 <b>Total penerima</b> : ${(await db.all('SELECT user_id FROM users')).length} user</blockquote>
<blockquote>⚠️ Yakin ingin mengirim broadcast ini?</blockquote>`, {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [
            { text: '✅ Kirim Broadcast', callback_data: 'confirm_broadcast' },
            { text: '❌ Batalkan', callback_data: 'cancel_broadcast' }
          ]
        ]
      }
    });
    return;
  }
  
  if (global.waitingForBroadcastPM) {
    delete global.waitingForBroadcastPM;
    
    const ubot = userbots.find(ub => ub.owner_id === userId);
    
    if (!ubot) {
      await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Userbot ga ketemu.</b></blockquote>`, {
        parse_mode: 'HTML',
        reply_markup: await getMainMenuKeyboard(userId)
      });
      return;
    }
    
    let pesan = text;
    let fileId = null;
    let caption = '';
    let type = 'text';
    
    if (msg.photo) {
      type = 'photo';
      fileId = msg.photo[msg.photo.length - 1].file_id;
      caption = msg.caption || '';
      pesan = caption;
    } else if (msg.video) {
      type = 'video';
      fileId = msg.video.file_id;
      caption = msg.caption || '';
      pesan = caption;
    } else if (msg.document) {
      type = 'document';
      fileId = msg.document.file_id;
      caption = msg.caption || '';
      pesan = caption;
    } else if (msg.audio) {
      type = 'audio';
      fileId = msg.audio.file_id;
      caption = msg.caption || '';
      pesan = caption;
    } else if (msg.voice) {
      type = 'voice';
      fileId = msg.voice.file_id;
      caption = msg.caption || '';
      pesan = caption;
    }
    
    if (!pesan && !fileId) {
      await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
📝 <b>Pesan ga boleh kosong cuy.</b></blockquote>`, { parse_mode: 'HTML' });
      return;
    }
    
    const statusMsg = await bot.sendMessage(chatId, `
<blockquote>⏳ <b><u>MENGAMBIL DAFTAR USER</u></b>
👥 <i>Lagi ngambil daftar user yang pernah chat...</i></blockquote>`, { parse_mode: 'HTML' });
    
    // STABILITAS (v10.3): broadcast PM ini bisa lama (loop 1 user per ~800ms,
    // bisa ratusan user = beberapa menit) tapi sebelumnya TIDAK pernah
    // lazyUbot.pin() - koneksi userbot bisa idle-disconnect otomatis di
    // tengah loop (default 3 menit nganggur, lihat system/lazyUbot.js).
    // Efeknya bukan fatal (auto-reconnect tetap jalan tiap panggilan method
    // berikutnya), tapi bikin broadcast panjang lebih rawan koneksi putus-
    // nyambung berkali-kali di tengah jalan. pin() di sini mengunci koneksi
    // selama loop kirim berjalan, unpin() di finally menjamin selalu dilepas
    // lagi walau ada error/return di tengah.
    lazyUbot.pin(userId);
    try {
      const dialogs = await ubot.client.getDialogs();
      const users = [];
      const botId = (await ubot.client.getMe()).id;
      
      for (const dialog of dialogs) {
        if (!dialog.isGroup && !dialog.isChannel && dialog.entity && dialog.entity.id) {
          const entityId = dialog.entity.id.toString();
          const isBot = dialog.entity.bot === true;
          
          if (entityId !== botId.toString() && !isBot) {
            users.push({
              id: dialog.entity.id,
              username: dialog.entity.username || '-',
              firstName: dialog.entity.firstName || '',
              lastName: dialog.entity.lastName || ''
            });
          }
        }
      }
      
      if (users.length === 0) {
        await safeEditMessageText(`
<blockquote>❌ <b><u>KOSONG</u></b>
👥 <b>Ga ada user yang pernah chat sama userbot lu.</b></blockquote>`, {
          chat_id: chatId,
          message_id: statusMsg.message_id,
          parse_mode: 'HTML'
        });
        return;
      }
      
      await safeEditMessageText(`
<blockquote>⏳ <b><u>MENGIRIM PESAN</u></b>
📨 <i>Lagi ngirim ke ${users.length} user...</i></blockquote>`, {
        chat_id: chatId,
        message_id: statusMsg.message_id,
        parse_mode: 'HTML'
      });
      
      const settings = await db.get('SELECT watermark, watermark_status FROM settings WHERE owner_id = ?', userId) || {};
      const role = await getUserRole(userId);
      
      let watermarkToUse = '';
      if (role === 'PREMIUM_NO_WM' || role === 'RESELLER' || role === 'OWNER') {
        if (settings.watermark && settings.watermark_status === 'ON') {
          watermarkToUse = settings.watermark;
        }
      } else {
        watermarkToUse = WM;
      }
      
      let messageContent = pesan;
      if (watermarkToUse && messageContent) {
        messageContent = `${messageContent}\n\n${watermarkToUse}`;
      } else if (watermarkToUse && !messageContent) {
        messageContent = watermarkToUse;
      }
      
      let sukses = 0;
      let gagal = 0;
      const gagalList = [];
      
      for (let i = 0; i < users.length; i++) {
        const user = users[i];
        try {
          if (type === 'photo' && fileId) {
            await ubot.client.sendPhoto(user.id, { file: fileId, caption: messageContent });
          } else if (type === 'video' && fileId) {
            await ubot.client.sendVideo(user.id, { file: fileId, caption: messageContent });
          } else if (type === 'document' && fileId) {
            await ubot.client.sendDocument(user.id, { file: fileId, caption: messageContent });
          } else if (type === 'audio' && fileId) {
            await ubot.client.sendAudio(user.id, { file: fileId, caption: messageContent });
          } else if (type === 'voice' && fileId) {
            await ubot.client.sendVoice(user.id, { file: fileId, caption: messageContent });
          } else {
            await ubot.client.sendMessage(user.id, { message: messageContent });
          }
          sukses++;
        } catch (err) {
          gagal++;
          if (err.message.includes('FLOOD')) {
            gagalList.push(`${user.firstName}: FLOOD WAIT`);
            await new Promise(r => setTimeout(r, 5000));
          } else if (err.message.includes('USER_BANNED')) {
            gagalList.push(`${user.firstName}: USER_BANNED`);
          } else if (err.message.includes('CHAT_NOT_FOUND')) {
            gagalList.push(`${user.firstName}: CHAT_NOT_FOUND`);
          } else {
            gagalList.push(`${user.firstName}: ${err.message.substring(0, 50)}`);
          }
        }
        
        if ((i + 1) % 10 === 0) {
          try {
            await safeEditMessageText(`
<blockquote>⏳ <b><u>PROGRESS BROADCAST PM</u></b>
✅ Sukses: ${sukses}
❌ Gagal: ${gagal}
📊 Progress: ${i + 1}/${users.length} user</blockquote>`, {
              chat_id: chatId,
              message_id: statusMsg.message_id,
              parse_mode: 'HTML'
            });
          } catch (e) {}
        }
        
        await new Promise(r => setTimeout(r, 800));
      }
      
      let hasil = `
<blockquote>✅ <b><u>BROADCAST PM SELESAI!</u></b></blockquote>
<blockquote><b>📊 STATISTIK</b>
 • <b>Total user</b> : ${users.length}
 • <b>Sukses</b> : ${sukses}
 • <b>Gagal</b> : ${gagal}</blockquote>

<i>Pesan berhasil dikirim ke ${sukses} user</i>`;

      if (gagalList.length > 0 && gagalList.length <= 10) {
        hasil += `

<blockquote><b>❌ GAGAL KIRIM KE:</b>
${gagalList.map(g => ` • ${g}`).join('\n')}</blockquote>`;
      } else if (gagalList.length > 10) {
        hasil += `

<blockquote><b>❌ ${gagalList.length} user gagal dikirimi pesan.</b></blockquote>`;
      }

      await safeEditMessageText(hasil, {
        chat_id: chatId,
        message_id: statusMsg.message_id,
        parse_mode: 'HTML'
      });
      
    } catch (error) {
      await safeEditMessageText(`
<blockquote>❌ <b><u>ERROR</u></b>
⚠️ <b>${error.message}</b></blockquote>`, {
        chat_id: chatId,
        message_id: statusMsg.message_id,
        parse_mode: 'HTML'
      });
    } finally {
      lazyUbot.unpin(userId);
    }
    return;
  }
  
if (text === '👥 Grup & Daftar') {
    await handleGrupList(userId, chatId);
    return;
  }
  
if (text === '📝 Kelola Daftar & Pesan') {
    await handleKelolaListPesan(userId, chatId);
    return;
  }
  
if (text === '⏱️ Pengaturan Share') {
    await handleDelayJeda(userId, chatId);
    return;
  }
  
if (text === '⏱️ Atur Delay') {
    await handleAturDelay(userId, chatId);
    return;
  }
  
if (global.waitingForDelay && global.waitingForDelay[userId]) {
    delete global.waitingForDelay[userId];
    
    const delay = validateDelay(text);
    if (!delay) {
      await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🔢 <b>Masukin angka minimal 100 ms dan maksimal 5000 ms.</b></blockquote>`, { parse_mode: 'HTML' });
      return;
    }
    
    await db.run('UPDATE settings SET delay = ? WHERE owner_id = ?', delay, userId);
    await bot.sendMessage(chatId, `
<blockquote>✅ <b><u>DELAY DIUPDATE</u></b>
⏰ <b>Delay diatur jadi ${delay} ms <i>(${delay/1000} detik)</i>.</b></blockquote>`, {
      parse_mode: 'HTML',
      reply_markup: await getDelayJedaKeyboard()
    });
    return;
  }
  
if (text === '⏸️ Atur Jeda') {
    await handleAturJeda(userId, chatId);
    return;
  }
  
if (global.waitingForJeda && global.waitingForJeda[userId]) {
    delete global.waitingForJeda[userId];
    
    const jeda = validateJeda(text);
    if (!jeda) {
      await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🔢 <b>Masukin angka minimal 1 menit.</b></blockquote>`, { parse_mode: 'HTML' });
      return;
    }
    
    await db.run('UPDATE settings SET jeda = ? WHERE owner_id = ?', jeda, userId);
    
    let jedaText = '';
    if (jeda >= 1440) {
      const hari = jeda / 1440;
      jedaText = `${jeda} menit (${hari} hari)`;
    } else if (jeda >= 60) {
      const jam = jeda / 60;
      jedaText = `${jeda} menit (${jam} jam)`;
    } else {
      jedaText = `${jeda} menit`;
    }
    
    await bot.sendMessage(chatId, `
<blockquote>✅ <b><u>JEDA DIUPDATE</u></b>
🕐 <b>Jeda diatur jadi ${jedaText}.</b></blockquote>`, {
      parse_mode: 'HTML',
      reply_markup: await getDelayJedaKeyboard()
    });
    return;
  }
  
if (text === '🗂️ Menu Lainnya') {
    await handleExpertExtra(userId, chatId);
    return;
  }
  
if (text === '🚪 Logout Userbot') {
    await handleLogoutUserbot(userId, chatId);
    return;
  }
  
if (text === '🔑 Lihat Token') {
    await handleLihatToken(userId, chatId);
    return;
  }
  
if (text === '➕ Gabung Grup') {
    await handleMasukGroup(userId, chatId);
    return;
  }
  
if (global.waitingForJoinGroup && global.waitingForJoinGroup[userId]) {
    const { targetUserId } = global.waitingForJoinGroup[userId];
    delete global.waitingForJoinGroup[userId];
    
    const ubot = userbots.find(ub => ub.owner_id === targetUserId);
    if (!ubot) {
      await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Userbot ga ketemu.</b></blockquote>`, { 
        parse_mode: 'HTML',
        reply_markup: await getBackKeyboard() 
      });
      return;
    }
    
    const inputs = text.split(',').map(i => i.trim());
    const statusMsg = await bot.sendMessage(chatId, `
<blockquote>🔄 <b><u>PROSES JOIN GROUP</u></b>
⏳ <i>Lagi proses join group...</i></blockquote>`, { parse_mode: 'HTML' });
    
    let success = 0;
    let failed = 0;
    const results = [];
    
    for (const input of inputs) {
      if (!input) continue;
      
      try {
        let resolvedChat;
        
        if (input.startsWith('https://t.me/')) {
          const inviteHash = input.replace('https://t.me/+', '').replace('https://t.me/', '');
          const importResult = await ubot.client.invoke(new Api.messages.ImportChatInvite({ hash: inviteHash }));
          resolvedChat = importResult && importResult.chats && importResult.chats[0];
        } else {
          const username = input.replace('@', '');
          resolvedChat = await ubot.client.getEntity(username);
          await ubot.client.invoke(new Api.channels.JoinChannel({ channel: resolvedChat }));
        }
        
        if (!resolvedChat) {
          throw new Error('Gagal resolve grup dari invite link');
        }
        
        const groupId = getMarkedGroupId(resolvedChat);
        const exists = await db.get('SELECT * FROM groups WHERE owner_id = ? AND group_id = ?', targetUserId, groupId);
        
        if (!exists) {
          await db.run(
            'INSERT INTO groups (owner_id, group_id, group_title, group_username, added_at) VALUES (?, ?, ?, ?, ?)',
            targetUserId, groupId, resolvedChat.title || 'Unknown', resolvedChat.username || '', Math.floor(Date.now() / 1000)
          );
        }
        
        success++;
        results.push(`✅ ${input}: Berhasil join`);
      } catch (error) {
        failed++;
        results.push(`❌ ${input}: Gagal - ${error.message}`);
      }
      
      await new Promise(r => setTimeout(r, 1000));
    }
    
    let resultText = `
<blockquote>📊 <b><u>HASIL JOIN GROUP</u></b></blockquote>`;
    for (const r of results) {
      resultText += `

<blockquote>${r}</blockquote>`;
    }
    resultText += `

<blockquote><b>✅ Sukses:</b> ${success} | <b>❌ Gagal:</b> ${failed}</blockquote>`;
    
    await safeDeleteMessage(chatId, statusMsg.message_id);
    await bot.sendMessage(chatId, resultText, { 
      parse_mode: 'HTML', 
      reply_markup: await getBackKeyboard() 
    });
    return;
  }
  
if (text === '➖ Keluar Grup') {
    await handleKeluarGroup(userId, chatId);
    return;
  }
  
if (global.waitingForLeaveGroup && global.waitingForLeaveGroup[userId]) {
    const { targetUserId } = global.waitingForLeaveGroup[userId];
    delete global.waitingForLeaveGroup[userId];
    
    const ubot = userbots.find(ub => ub.owner_id === targetUserId);
    if (!ubot) {
      await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Userbot ga ketemu.</b></blockquote>`, { 
        parse_mode: 'HTML',
        reply_markup: await getBackKeyboard() 
      });
      return;
    }
    
    const inputs = text.split(',').map(i => i.trim());
    const statusMsg = await bot.sendMessage(chatId, `
<blockquote>🔄 <b><u>PROSES KELUAR GROUP</u></b>
⏳ <i>Lagi proses keluar dari group...</i></blockquote>`, { parse_mode: 'HTML' });
    
    let success = 0;
    let failed = 0;
    const results = [];
    
    for (const input of inputs) {
      if (!input) continue;
      
      try {
        let entity;
        const username = input.replace('@', '');
        entity = await ubot.client.getEntity(username);
        
        await ubot.client.leaveChannel(entity);
        
        await db.run('DELETE FROM groups WHERE owner_id = ? AND group_id = ?', targetUserId, getMarkedGroupId(entity));
        
        success++;
        results.push(`✅ ${input}: Berhasil keluar`);
      } catch (error) {
        failed++;
        results.push(`❌ ${input}: Gagal - ${error.message}`);
      }
      
      await new Promise(r => setTimeout(r, 1000));
    }
    
    let resultText = `
<blockquote>📊 <b><u>HASIL KELUAR GROUP</u></b></blockquote>`;
    for (const r of results) {
      resultText += `

<blockquote>${r}</blockquote>`;
    }
    resultText += `

<blockquote><b>✅ Sukses:</b> ${success} | <b>❌ Gagal:</b> ${failed}</blockquote>`;
    
    await safeDeleteMessage(chatId, statusMsg.message_id);
    await bot.sendMessage(chatId, resultText, { 
      parse_mode: 'HTML', 
      reply_markup: await getBackKeyboard() 
    });
    return;
  }
  
if (text === '👑 Menu Reseller') {
    await handleMenuReseller(userId, chatId);
    return;
  }
  
if (text === '🆘 Bantuan') {
    await handleHelpMenu(userId, chatId);
    return;
  }
  
if (text === '📦 Pengaturan Premium') {
    await handleSettingPremium(userId, chatId);
    return;
  }
  
if (text === '👑 Pengaturan Reseller') {
    await handleSettingReseller(userId, chatId);
    return;
  }
  
if (text === '🎫 Pengaturan Token') {
    await handleSettingToken(userId, chatId);
    return;
  }
  
if (text === '🤖 Pengaturan Userbot') {
    await handleSettingUserbot(userId, chatId);
    return;
  }
  
if (text === '📊 Statistik Global' || text === '📊 Statistik') {
    await handleStatistikGlobal(userId, chatId);
    return;
  }
  
if (text === '🛍️ Toko') {
    await handleTokoUserbot(userId, chatId);
    return;
  }
  
if (text === '📘 Panduan') {
    await handlePanduan(userId, chatId);
    return;
  }
  
if (text === '🧑‍💻 Semua Admin') {
    await handleAdminchat(userId, chatId);
    return;
  }
  
if (text === '💌 Kredit') {
    await handletqcredit(userId, chatId);
    return;
  }
  
if (text === '🛍️ Beli Produk') {
    await handleBeliProduk(userId, chatId);
    return;
  }
  
if (text === '🤖 Clone Bot') {
    await handleSewaBot(userId, chatId);
    return;
  }
  
if (text === '🔄 Perpanjang Userbot') {
    await handlePerpanjangUserbot(userId, chatId);
    return;
  }
  
if (text === '📦 Pengaturan Produk' && isOwnerId(userId)) {
    await handleProdukDigital(userId, chatId);
    return;
  }
  
if (text === '➕ Tambah Produk' && isOwnerId(userId)) {
    await handleTambahProduk(userId, chatId);
    return;
  }
  
if (text === '🛡️ Klaim Garansi') {
    await handleTokenUserbot(userId, chatId);
    return;
  }
  
if (global.waitingForToken && global.waitingForToken[userId]) {
    delete global.waitingForToken[userId];
    
    const token = text.trim();
    
    const tokenData = await db.get('SELECT * FROM tokens WHERE token = ? AND used = 0 AND expired_at > ?', token, Math.floor(Date.now() / 1000));
    
    if (!tokenData) {
      await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🔑 <b>Token tidak valid, sudah dipakai, atau sudah kadaluarsa.</b></blockquote>`, {
        parse_mode: 'HTML',
        reply_markup: await getMainMenuKeyboard(userId)
      });
      return;
    }
    
    const userHasUbot = await userHasUserbot(userId);
    
    if (userHasUbot) {
      await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>GAGAL</u></b>
🤖 <b>Anda sudah memiliki userbot aktif. Token tidak bisa digunakan.</b></blockquote>`, {
        parse_mode: 'HTML',
        reply_markup: await getMainMenuKeyboard(userId)
      });
      return;
    }
    
    const role = tokenData.role;
    const expired = tokenData.expired_at;
    const days = Math.floor((expired - Math.floor(Date.now() / 1000)) / 86400);
    const expiredDate = new Date(expired * 1000).toLocaleString();
    
    const userExists = await db.get('SELECT * FROM users WHERE user_id = ?', userId);
    
    if (!userExists) {
      await db.run(
        'INSERT OR IGNORE INTO users (user_id, role, expired, created_at) VALUES (?, ?, ?, ?)',
        userId, role, expired, Math.floor(Date.now() / 1000)
      );
    } else {
      await db.run(
        'UPDATE users SET role = ?, expired = ? WHERE user_id = ?',
        role, expired, userId
      );
    }
    
    if (role === 'PREMIUM_WM') {
      await db.run('INSERT OR REPLACE INTO premium_wm (user_id, expired, added_by, created_at) VALUES (?, ?, ?, ?)',
        userId, expired, 'TOKEN_SYSTEM', Math.floor(Date.now() / 1000));
    } else if (role === 'PREMIUM_NO_WM') {
      await db.run('INSERT OR REPLACE INTO premium_no_wm (user_id, expired, added_by, created_at) VALUES (?, ?, ?, ?)',
        userId, expired, 'TOKEN_SYSTEM', Math.floor(Date.now() / 1000));
    } else if (role === 'RESELLER') {
      await db.run('INSERT OR REPLACE INTO reseller_list (user_id, added_by, added_at) VALUES (?, ?, ?)',
        userId, 'TOKEN_SYSTEM', Math.floor(Date.now() / 1000));
    }
    
    await db.run('UPDATE tokens SET used = 1, used_by = ?, used_at = ? WHERE token = ?', 
      userId, Math.floor(Date.now() / 1000), token);
    
    let paketNama = '';
    let emoji = '';
    if (role === 'PREMIUM_WM') {
      paketNama = 'Plan Basic';
      emoji = '🧩';
    } else if (role === 'PREMIUM_NO_WM') {
      paketNama = 'Plan Pro';
      emoji = '💎';
    } else if (role === 'RESELLER') {
      paketNama = 'Akses Reseller';
      emoji = '🎟';
    }
    
    await bot.sendMessage(chatId, `
<blockquote>✅ <b><u>TOKEN BERHASIL DI KLAIM!</u></b></blockquote>
<blockquote>${emoji} <b>Paket</b> : ${paketNama}
📅 <b>Durasi</b> : ${days} hari
⏰ <b>Habis</b> : ${expiredDate}</blockquote>

🚀 <b>Sekarang Anda bisa membuat userbot dengan tekan tombol di bawah!</b>`, {
      parse_mode: 'HTML',
      reply_markup: {
        keyboard: [['🤖 Deploy Userbot'], ['🔙 Kembali']],
        resize_keyboard: true
      }
    });

    const owner = await db.get('SELECT full_name, username FROM users WHERE user_id = ?', OWNER_ID);
    const user = await db.get('SELECT full_name, username FROM users WHERE user_id = ?', userId);
    
    await bot.sendMessage(OWNER_ID, `
<blockquote><b>📢 Token Claimed</b>

<b>User</b> : ${user?.full_name || 'Unknown'} ${user?.username ? '('+user.username+')' : ''}
<b>ID</b> : <code>${userId}</code>
<b>Token</b> : <code>${token.substring(0, 30)}...</code>
<b>Package</b> : ${emoji} ${paketNama}
<b>Duration</b> : ${days} days
<b>Expired</b> : ${expiredDate}
<b>Time</b> : ${moment().format('DD/MM/YYYY HH:mm:ss')}</blockquote>`, { parse_mode: 'HTML' });
    
    await db.run(
      'INSERT INTO activity_logs (user_id, action, details, timestamp) VALUES (?, ?, ?, ?)',
      userId, 'CLAIM_TOKEN', `Claim token untuk ${paketNama}`, Math.floor(Date.now() / 1000)
    );
    
    return;
  }
  
if (text === '🎫 Buat Token' && isOwnerId(userId)) {
    await handleCreateToken(userId, chatId);
    return;
  }
  
if (text === '🗑️ Hapus Token' && isOwnerId(userId)) {
    await handleHapusToken(userId, chatId);
    return;
  }
  
if (global.waitingForDeleteToken && isOwnerId(userId)) {
    delete global.waitingForDeleteToken;
    
    const index = parseInt(text) - 1;
    const tokens = global.tokenListForDelete;
    
    if (isNaN(index) || index < 0 || index >= tokens.length) {
      await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🔢 <b>Nomor ga valid.</b></blockquote>`, { parse_mode: 'HTML' });
      delete global.tokenListForDelete;
      return;
    }
    
    const token = tokens[index];
    
    await db.run('DELETE FROM tokens WHERE token = ?', token.token);
    
    await bot.sendMessage(chatId, `
<blockquote>✅ <b><u>BERHASIL</u></b>
🗑️ <b>Token berhasil dihapus!</b>
<code>${token.token}</code></blockquote>`, {
      parse_mode: 'HTML',
      reply_markup: await getOwnerMenuKeyboard()
    });
    
    delete global.tokenListForDelete;
    return;
  }
  
if (text === '📋 Daftar Token' && isOwnerId(userId)) {
    await handleListToken(userId, chatId);
    return;
  }
  
if (global.waitingForCreateToken && isOwnerId(userId)) {
    const inputText = text.trim();
    const parts = inputText.split(' ');
    
    if (parts.length < 2) {
      await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🔑 Format salah. Contoh: wm 30 atau nowm 7 atau reseller 365</blockquote>`, { parse_mode: 'HTML' });
      return;
    }
    
    const type = parts[0].toLowerCase();
    const days = parseInt(parts[1]);
    
    if (type !== 'wm' && type !== 'nowm' && type !== 'reseller') {
      await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🔑 Jenis harus: wm, nowm, atau reseller</blockquote>`, { parse_mode: 'HTML' });
      return;
    }
    
    if (isNaN(days) || days < 1 || days > 365) {
      await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🔢 Durasi harus angka 1-365 hari.</blockquote>`, { parse_mode: 'HTML' });
      return;
    }
    
    let role = '';
    if (type === 'wm') role = 'PREMIUM_WM';
    else if (type === 'nowm') role = 'PREMIUM_NO_WM';
    else if (type === 'reseller') role = 'RESELLER';
    
    const expired = Math.floor(Date.now() / 1000) + (days * 24 * 3600);
    const token = generateSecureToken();
    
    await db.run(
      'INSERT INTO tokens (token, owner_id, ubot_id, role, created_at, expired_at, used) VALUES (?, ?, ?, ?, ?, ?, ?)',
      token, userId, null, role, Math.floor(Date.now() / 1000), expired, 0
    );
    
    const paketNama = type === 'wm' ? 'PREMIUM WM' : type === 'nowm' ? 'PREMIUM NO WM' : 'RESELLER';
    const expiredDate = new Date(expired * 1000).toLocaleString();
    
    await bot.sendMessage(chatId, `
<blockquote>✅ <b><u>TOKEN BERHASIL DIBUAT!</u></b></blockquote>
<blockquote>Token: <code>${token}</code>
Paket: ${paketNama}
Durasi: ${days} hari
Habis: ${expiredDate}</blockquote>
<blockquote>Token ini bisa dikasih ke user buat claim akses.</blockquote>`, { parse_mode: 'HTML' });
    
    delete global.waitingForCreateToken;
    return;
  }
  
  if (global.waitingForAddGroup && global.waitingForAddGroup[userId]) {
    const { targetUserId } = global.waitingForAddGroup[userId];
    delete global.waitingForAddGroup[userId];

    const ubot = userbots.find(ub => ub.owner_id === targetUserId);
    if (!ubot) {
      await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🤖 <b>Userbot ga ketemu atau lagi mati.</b></blockquote>`, {
        parse_mode: 'HTML',
        reply_markup: await getKelolaGroupKeyboard()
      });
      return;
    }

    const role = await getUserRole(targetUserId);
    const isTrial = (role === 'TRIAL');
    const maxGroups = 20;

    const existingGroups = await db.all('SELECT COUNT(*) as count FROM groups WHERE owner_id = ?', targetUserId);
    let currentCount = existingGroups[0]?.count || 0;

    const inputs = text.split(',').map(i => i.trim()).filter(Boolean);

    const statusMsg = await bot.sendMessage(chatId, `
<blockquote>⚙️ <b><u>MEMPROSES GRUP</u></b>
⏳ <i>Lagi nambahin grup... Tunggu bentar.</i></blockquote>`, { parse_mode: 'HTML' });

    let added = 0;
    let failed = 0;
    let limitHit = false;
    const results = [];

    for (const input of inputs) {
      if (isTrial && currentCount >= maxGroups) {
        limitHit = true;
        results.push(`⚠️ ${input}: Dilewati (batas ${maxGroups} grup free tercapai)`);
        continue;
      }

      try {
        const cleanInput = input.replace('https://t.me/', '').trim();
        let entity;

        if (/^-?\d+$/.test(cleanInput)) {
          entity = await ubot.client.getEntity(parseInt(cleanInput));
        } else {
          entity = await ubot.client.getEntity(cleanInput.replace('@', ''));
        }

        const groupId = getMarkedGroupId(entity);
        const exists = await db.get('SELECT * FROM groups WHERE owner_id = ? AND group_id = ?', targetUserId, groupId);

        if (exists) {
          results.push(`⚠️ ${input}: Udah ada di daftar`);
          continue;
        }

        await db.run(
          'INSERT INTO groups (owner_id, group_id, group_title, group_username, added_at) VALUES (?, ?, ?, ?, ?)',
          targetUserId, groupId, entity.title || cleanInput, entity.username || '', Math.floor(Date.now() / 1000)
        );

        added++;
        currentCount++;
        results.push(`✅ ${input}: Berhasil ditambah`);
      } catch (error) {
        failed++;
        results.push(`❌ ${input}: Gagal - ${error.message}`);
      }

      await new Promise(r => setTimeout(r, 500));
    }

    let resultText = `
<blockquote>📊 <b><u>HASIL TAMBAH MANUAL</u></b></blockquote>`;
    for (const r of results) {
      resultText += `

<blockquote>${r}</blockquote>`;
    }
    resultText += `

<blockquote><b>✅ Berhasil:</b> ${added} | <b>❌ Gagal:</b> ${failed}</blockquote>`;

    if (limitHit) {
      resultText += `
<blockquote>⚠️ <b>Batas ${maxGroups} grup free tercapai!</b> Hapus grup lain atau upgrade ke premium buat nambah lebih banyak.</blockquote>`;
    }

    try { await safeDeleteMessage(chatId, statusMsg.message_id); } catch (e) {}
    await bot.sendMessage(chatId, resultText, {
      parse_mode: 'HTML',
      reply_markup: await getKelolaGroupKeyboard()
    });
    return;
  }
  
  if (global.waitingForAddBlacklist && global.waitingForAddBlacklist[userId]) {
    delete global.waitingForAddBlacklist[userId];
    
    const inputs = text.split(',').map(i => i.trim());
    let added = 0;
    
    for (const input of inputs) {
      let groupId = input;
      let groupTitle = input;
      
      try {
        if (input.startsWith('@')) {
          const chat = await bot.getChat(input);
          groupId = chat.id.toString();
          groupTitle = chat.title || input;
        }
        
        const exists = await db.get('SELECT * FROM blacklist_groups WHERE owner_id = ? AND group_id = ?', userId, groupId);
        
        if (!exists) {
          await db.run(
            'INSERT INTO blacklist_groups (owner_id, group_id, group_title, reason, added_at) VALUES (?, ?, ?, ?, ?)',
            userId, groupId, groupTitle, 'Manual blacklist', Math.floor(Date.now() / 1000)
          );
          added++;
          
          if (promosiProgress[userId] && promosiProgress[userId].running) {
            promosiProgress[userId].validGroups = promosiProgress[userId].validGroups.filter(g => g.group_id.toString() !== groupId);
          }
        }
      } catch (error) {
        await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>GAGAL</u></b>
🚫 <b>Gagal blacklist ${input}:</b> ${error.message}</blockquote>`, { parse_mode: 'HTML' });
      }
    }
    
    await bot.sendMessage(chatId, `
<blockquote>✅ <b><u>BERHASIL</u></b>
🚫 <b>Berhasil nambah ${added} group ke blacklist!</b></blockquote>`, {
      parse_mode: 'HTML',
      reply_markup: await getBlacklistGroupKeyboard()
    });
    return;
  }
  
if (global.waitingForDeleteBlacklist && global.waitingForDeleteBlacklist[userId]) {
    delete global.waitingForDeleteBlacklist[userId];
    
    const groupId = text;
    const result = await db.run('DELETE FROM blacklist_groups WHERE group_id = ? AND owner_id = ?', groupId, userId);
    
    if (result && result.changes && result.changes > 0) {
      await bot.sendMessage(chatId, `
<blockquote>✅ <b><u>BERHASIL</u></b>
🚫 <b>Group berhasil dihapus dari blacklist!</b></blockquote>`, {
        parse_mode: 'HTML',
        reply_markup: await getBlacklistGroupKeyboard()
      });
    } else {
      await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🚫 <b>Group ga ketemu di blacklist.</b></blockquote>`, { parse_mode: 'HTML' });
    }
    return;
  }
  
const isWaitingMessage = global.waitingForMessage && global.waitingForMessage[userId];
if (isWaitingMessage) {
  delete global.waitingForMessage[userId];
  
  let type = 'text';
  let fileId = null;
  let plainText = msg.text || msg.caption || '';
  let entities = msg.text ? msg.entities : msg.caption_entities;
  let entitiesJson = entities ? JSON.stringify(entities) : null;
  let rawText = plainText;
  
  if (msg.photo) {
    type = 'photo';
    fileId = msg.photo[msg.photo.length - 1].file_id;
    rawText = msg.caption || '';
    entitiesJson = msg.caption_entities ? JSON.stringify(msg.caption_entities) : null;
  } else if (msg.video) {
    type = 'video';
    fileId = msg.video.file_id;
    rawText = msg.caption || '';
    entitiesJson = msg.caption_entities ? JSON.stringify(msg.caption_entities) : null;
  } else if (msg.document) {
    type = 'document';
    fileId = msg.document.file_id;
    rawText = msg.caption || '';
    entitiesJson = msg.caption_entities ? JSON.stringify(msg.caption_entities) : null;
  } else if (msg.audio) {
    type = 'audio';
    fileId = msg.audio.file_id;
    rawText = msg.caption || '';
    entitiesJson = msg.caption_entities ? JSON.stringify(msg.caption_entities) : null;
  } else if (msg.voice) {
    type = 'voice';
    fileId = msg.voice.file_id;
    rawText = msg.caption || '';
    entitiesJson = msg.caption_entities ? JSON.stringify(msg.caption_entities) : null;
  } else if (msg.sticker) {
    type = 'sticker';
    fileId = msg.sticker.file_id;
    rawText = '';
    entitiesJson = null;
  } else if (msg.animation) {
    type = 'animation';
    fileId = msg.animation.file_id;
    rawText = msg.caption || '';
    entitiesJson = msg.caption_entities ? JSON.stringify(msg.caption_entities) : null;
  }
  
  if (type === 'text' && (!rawText || rawText.trim() === '')) {
    await bot.sendMessage(chatId, '<blockquote>❌ Pesan tidak boleh kosong.</blockquote>', { parse_mode: 'HTML' });
    return;
  }
  
  const lastMessage = await db.get('SELECT MAX(local_id) as max FROM messages WHERE owner_id = ?', userId);
  const nextLocalId = (lastMessage?.max || 0) + 1;
  
  await db.run(
    'INSERT INTO messages (owner_id, local_id, type, content, file_id, caption, entities_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
    userId, nextLocalId, type, rawText, fileId, rawText, entitiesJson, Math.floor(Date.now() / 1000)
  );
  
  const newMessage = await db.get('SELECT id FROM messages WHERE owner_id = ? AND local_id = ?', userId, nextLocalId);
  if (newMessage) {
    await db.run('UPDATE settings SET selected_message_id = ? WHERE owner_id = ?', newMessage.id, userId);
  }
  
  let pesanInfo = '';
  if (type === 'text') pesanInfo = 'Teks';
  else if (type === 'photo') pesanInfo = 'Foto';
  else if (type === 'video') pesanInfo = 'Video';
  else if (type === 'document') pesanInfo = 'Dokumen';
  else if (type === 'audio') pesanInfo = 'Audio';
  else if (type === 'voice') pesanInfo = 'Suara';
  else if (type === 'sticker') pesanInfo = 'Stiker';
  else if (type === 'animation') pesanInfo = 'GIF';
  
  await bot.sendMessage(chatId, `
<blockquote>✅ Pesan #${nextLocalId} (${pesanInfo}) berhasil disimpan dan dipilih sebagai pesan aktif!</blockquote>`, {
    parse_mode: 'HTML',
    reply_markup: await getKelolaPesanKeyboard(userId)
  });
  return;
}
  
if (text === `❌ Batalkan`) {
    await bot.sendMessage(chatId, `
<blockquote>➡️ <b><u>Tindakan Dibatalkan...</u></b></blockquote>`, { 
      parse_mode: 'HTML',
      reply_markup: await getMainMenuKeyboard(userId) 
    });
    return;
  }
  
if (text === '🏠 Beranda') {
    await handleBeranda(userId, chatId, msg);
    return;
  }
  
if (waitingForGiveUserId[userId]) {
    const targetUserId = text.trim();

    if (!/^\d+$/.test(targetUserId)) {
        await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>ERROR</u></b>
🆔 UserID harus berupa angka! Contoh: 123456789</blockquote>`, {
            parse_mode: 'HTML'
        });
        return;
    }

    delete waitingForGiveUserId[userId];

    const caption = `
<blockquote>🎁 <b><u>PILIH PAKET UNTUK USER ${targetUserId}</u></b></blockquote>
<blockquote>🧩 <b>Plan Basic</b>
• Bisa mengakses fitur AutoBC (Berwatermark Bot)
• Tidak bisa menggunakan AutoFW
• Nikmati akses userbot yang cukup untuk kebutuhan standar
• Fitur bisa bertambah atau berkurang sesuai dari pengembangan atau developer</blockquote>
<blockquote>💎 <b>Plan Pro</b>
• Unlock semua kemampuan fitur pro yang super lengkap tanpa watermark AutoBC
• Fitur akan terus dikembangkan dan bisa berubah sesuai keputusan developer</blockquote>
<blockquote>🎟 <b>Akses Reseller</b>
• Unlock semua kemampuan fitur pro yang super lengkap tanpa watermark AutoBC
• Bisa open akses sewa userbot menggunakan userbot kami (Tanpa batas user)
• Fitur akan terus dikembangkan dan bisa berubah sesuai keputusan developer</blockquote>`;

    await bot.sendMessage(chatId, caption, {
        parse_mode: 'HTML',
        reply_markup: {
            inline_keyboard: [
                [
                    { text: '🧩 Plan Basic', callback_data: `paket_wm_gift_${targetUserId}` },
                    { text: '💎 Plan Pro', callback_data: `paket_nowm_gift_${targetUserId}` }
                ],
                [
                    { text: '🎟 Akses Reseller', callback_data: `paket_reseller_gift_${targetUserId}` }
                ],
                [
                    { text: '⬅️ Kembali', callback_data: 'back_main' }
                ]
            ]
        }
    });
    return;
  }
  
if ((global.waitingForOTP && global.waitingForOTP[userId]) || 
      (global.waitingForOTPTrial && global.waitingForOTPTrial[userId])) {
    
    if (text === `❌ Batalkan`) {
      if (global.waitingForOTP && global.waitingForOTP[userId]) delete global.waitingForOTP[userId];
      if (global.waitingForOTPTrial && global.waitingForOTPTrial[userId]) delete global.waitingForOTPTrial[userId];
      if (global.loginSessions && global.loginSessions[userId]) delete global.loginSessions[userId];
      if (global.otpAttempts && global.otpAttempts[userId]) delete global.otpAttempts[userId];
      
      await bot.sendMessage(chatId, `
<blockquote>➡️ <b><u>Tindakan Dibatalkan...</u></b></blockquote>`, {
        parse_mode: 'HTML',
        reply_markup: await getMainMenuKeyboard(userId)
      });
      return;
    }
    
    const isTrial = global.waitingForOTPTrial && global.waitingForOTPTrial[userId] ? true : false;
    
    if (!global.otpAttempts) global.otpAttempts = {};
    if (!global.otpAttempts[userId]) global.otpAttempts[userId] = { count: 0, lastAttempt: 0 };
    
    let otpCode = text.replace(/\s+/g, '');
    
    if (!/^\d+$/.test(otpCode) || otpCode.length < 4 || otpCode.length > 6) {
      global.otpAttempts[userId].count++;
      
      if (global.otpAttempts[userId].count >= 3) {
        await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>TERLALU BANYAK PERCOBAAN</u></b>
🔄 <b>Mulai ulang dari awal ya.</b></blockquote>`, {
          parse_mode: 'HTML',
          reply_markup: await getMainMenuKeyboard(userId)
        });
        delete global.otpAttempts[userId];
        if (global.waitingForOTP && global.waitingForOTP[userId]) delete global.waitingForOTP[userId];
        if (global.waitingForOTPTrial && global.waitingForOTPTrial[userId]) delete global.waitingForOTPTrial[userId];
        if (global.loginSessions && global.loginSessions[userId]) delete global.loginSessions[userId];
        return;
      }
      
      const sisaCoba = 3 - global.otpAttempts[userId].count;
      await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>KODE OTP SALAH</u></b></blockquote>
<blockquote>Kode OTP harus berupa ANGKA (4-6 digit)!</blockquote>
<blockquote>Contoh format yang bener:
 • <code>12345</code> (tanpa spasi)
 • <code>1 2 3 4 5</code> (pake spasi)</blockquote>
<blockquote>⚠️ Sisa percobaan: ${sisaCoba} kali lagi</blockquote>`, {
        parse_mode: 'HTML',
        reply_markup: { keyboard: [[`❌ Batalkan`]], resize_keyboard: true, one_time_keyboard: true }
      });
      return;
    }
    
    delete global.otpAttempts[userId];
    
    if (global.waitingForOTP && global.waitingForOTP[userId]) delete global.waitingForOTP[userId];
    if (global.waitingForOTPTrial && global.waitingForOTPTrial[userId]) delete global.waitingForOTPTrial[userId];
    
    const statusMsg = await bot.sendMessage(chatId, `
<blockquote>⏳ <b><u>Lagi verifikasi kode OTP...</u></b></blockquote>`, { parse_mode: 'HTML' });
    
    await handleVerifyOTP(otpCode, userId, chatId, isTrial, statusMsg.message_id);
    return;
  }
  
if (global.waitingFor2FA && global.waitingFor2FA[userId]) {
    if (text === `❌ Batalkan`) {
      delete global.waitingFor2FA[userId];
      if (global.loginSessions && global.loginSessions[userId]) delete global.loginSessions[userId];
      if (global.twoFAAttempts && global.twoFAAttempts[userId]) delete global.twoFAAttempts[userId];
      
      await bot.sendMessage(chatId, `
<blockquote>➡️ <b>Tindakan Dibatalkan</b></blockquote>`, {
        parse_mode: 'HTML',
        reply_markup: await getMainMenuKeyboard(userId)
      });
      return;
    }
    
    if (!global.twoFAAttempts) global.twoFAAttempts = {};
    if (!global.twoFAAttempts[userId]) global.twoFAAttempts[userId] = { count: 0 };
    
    const data = global.waitingFor2FA[userId];
    delete global.waitingFor2FA[userId];
    
    const statusMsg = await bot.sendMessage(chatId, `
<blockquote>⏳ <b>Lagi verifikasi password 2FA...</b></blockquote>`, { parse_mode: 'HTML' });
    
    try {
      const passwordInfo = await data.client.invoke(new Api.account.GetPassword());
      const { A, M1 } = await computeCheck(passwordInfo, text);
      
      await data.client.invoke(new Api.auth.CheckPassword({
        password: new Api.InputCheckPasswordSRP({ srpId: passwordInfo.srpId, A: A, M1: M1 })
      }));
      
      delete global.twoFAAttempts[userId];
      
      const me = await data.client.getMe();
      const sessionString = data.client.session.save();
      await data.client.disconnect();
      
      let expired;
      let role;
      
      if (data.isTrial) {
        // Trial lifetime - 100 tahun
        expired = Math.floor(Date.now() / 1000) + (100 * 365 * 86400);
        role = 'TRIAL';
      } else {
        const user = await db.get('SELECT * FROM users WHERE user_id = ?', userId);
        if (user && user.expired) {
          expired = user.expired;
          role = user.role;
        } else {
          expired = Math.floor(Date.now() / 1000) + 30 * 24 * 3600;
          role = 'PREMIUM_WM';
        }
      }
      
      const existingUbot = await db.get('SELECT * FROM userbots WHERE ubot_id = ?', me.id.toString());
      if (existingUbot) {
        await db.run('DELETE FROM userbots WHERE ubot_id = ?', me.id.toString());
      }
      
      await db.run(
        'INSERT INTO userbots (ubot_id, owner_id, phone, session_string, status, created_at, expired) VALUES (?, ?, ?, ?, ?, ?, ?)',
        me.id.toString(), userId, data.phone, sessionString, 'AKTIF', Math.floor(Date.now() / 1000), expired
      );
      
      // trial_used tetap 0 biar bisa deploy free lagi
      await db.run(
        'UPDATE users SET role = ?, expired = ?, has_userbot = 1, trial_used = ? WHERE user_id = ?',
        role, expired, data.isTrial ? 0 : 0, userId
      );
      
      await db.run('INSERT INTO settings (owner_id) VALUES (?) ON CONFLICT(owner_id) DO NOTHING', userId);
      
      // Client "lazy" - lihat system/lazyUbot.js
      const ubot = lazyUbot.createLazyClient(userId, sessionString, API_ID, API_HASH, getTelegramClientConfig());
      
      const existingInMemory = userbots.findIndex(ub => ub.owner_id === userId);
      if (existingInMemory !== -1) {
        userbots.splice(existingInMemory, 1);
      }
      
      userbots.push({
        id: me.id.toString(),
        owner_id: userId,
        client: ubot,
        phone: data.phone,
        status: 'AKTIF'
      });
      
      let joinSuccess = false;
      const logGroupClean = LOG_GROUP.replace('@', '');
      
      for (let attempt = 1; attempt <= 3; attempt++) {
        try {
          await new Promise(r => setTimeout(r, 5000 * attempt));
          
          let entity;
          try {
            entity = await ubot.getEntity(logGroupClean);
          } catch (e) {
            entity = await ubot.getEntity(`https://t.me/${logGroupClean}`);
          }
          
          if (entity) {
            await ubot.invoke(new Api.channels.JoinChannel({ channel: entity }));
            joinSuccess = true;
            break;
          }
        } catch (joinErr) {}
      }
      
      await safeDeleteMessage(chatId, statusMsg.message_id);
      
      let token = null;
      if (!data.isTrial) {
        token = generateSecureToken();
        
        const existingToken = await db.get('SELECT * FROM tokens WHERE owner_id = ?', userId);
        if (existingToken) {
          await db.run('DELETE FROM tokens WHERE owner_id = ?', userId);
        }
        
        await db.run(
          'INSERT INTO tokens (token, owner_id, ubot_id, role, created_at, expired_at) VALUES (?, ?, ?, ?, ?, ?)',
          token, userId, me.id.toString(), role, Math.floor(Date.now() / 1000), expired
        );
        
        let paketName = '';
        if (role === 'PREMIUM_WM') paketName = '🧩 Plan Basic';
        else if (role === 'PREMIUM_NO_WM') paketName = '💎 Plan Pro';
        else if (role === 'RESELLER') paketName = '🎟 Akses Reseller';
        else paketName = role;
        
        const sisaHari = Math.floor((expired - Math.floor(Date.now() / 1000)) / 86400);
        
        const caption = `
<blockquote>🚀 <b><u>USERBOT BERHASIL AKTIF</u></b></blockquote>
<blockquote>👤 <b>Nama</b> : ${me.firstName || ''} ${me.lastName || ''}
🆔 <b>ID</b> : <code>${me.id}</code></blockquote>
<blockquote>🔑 <b>TOKEN CADANGAN</b>
📝 <code>${token}</code>
🛒 <b>Paket</b> : ${paketName}
⚠️ <i>Simpan baik-baik ya!</i></blockquote>
<blockquote>🗓 <b>MASA AKTIF</b>
🛒 <b>Paket</b> : ${paketName}
🗓 <b>Habis</b> : ${new Date(expired * 1000).toLocaleString()}
🕐 <b>Sisa</b> : ${sisaHari} Hari</blockquote>

<i>Pilih tombol di bawah</i>`;
        
        await bot.sendMessage(chatId, caption, { parse_mode: 'HTML' });
      } else {
        // Trial lifetime - tampilkan pesan berbeda
        const caption = `
<blockquote>✨ <b><u>FREE DEPLOY BERHASIL</u></b></blockquote>
<blockquote>👤 <b>Nama</b> : ${me.firstName || ''} ${me.lastName || ''}
🆔 <b>ID</b> : <code>${me.id}</code></blockquote>
<blockquote>🗓 <b>MASA AKTIF</b>
🛒 <b>Paket</b> : ✨ Free Lifetime
🗓 <b>Habis</b> : Selamanya
📊 <b>Batas Grup</b> : 50 Grup</blockquote>

<i>⚠️ Maksimal 20 grup target. Tambah grup otomatis dibatasi.</i>`;
        
        await bot.sendMessage(chatId, caption, { parse_mode: 'HTML' });
      }
      
      const userbotData = await db.get('SELECT * FROM userbots WHERE owner_id = ?', userId);
      const logInfo = !data.isTrial ? { token: token, ubot_id: userbotData?.ubot_id } : { type: 'FREE_LIFETIME', ubot_id: userbotData?.ubot_id };
      await sendLogNotification(userId, logInfo, 'login');
      
      await db.run(
        'INSERT INTO activity_logs (user_id, action, details, timestamp) VALUES (?, ?, ?, ?)',
        userId, data.isTrial ? 'FREE_DEPLOY_ACTIVATED' : 'USERBOT_ACTIVATED', `Userbot: ${me.id} (2FA)`, Math.floor(Date.now() / 1000)
      );
      
    } catch (error) {
      await safeDeleteMessage(chatId, statusMsg.message_id);
      
      global.twoFAAttempts[userId].count++;
      
      if (global.twoFAAttempts[userId].count >= 3) {
        await bot.sendMessage(chatId, `
<blockquote>❌ <b>TERLALU BANYAK PERCOBAAN</b>
Mulai ulang dari awal.</blockquote>`, { 
          parse_mode: 'HTML',
          reply_markup: await getMainMenuKeyboard(userId) 
        });
        delete global.twoFAAttempts[userId];
        if (global.loginSessions && global.loginSessions[userId]) delete global.loginSessions[userId];
        return;
      }
      
      const sisaCoba = 3 - global.twoFAAttempts[userId].count;
      await bot.sendMessage(chatId, `
<blockquote>❌ <b>PASSWORD 2FA SALAH</b></blockquote>
<blockquote>Sisa percobaan: ${sisaCoba} kali lagi</blockquote>

<i>Ketik password yang bener atau /cancel untuk batal.</i>`, { 
        parse_mode: 'HTML',
        reply_markup: { keyboard: [[`❌ Batalkan`]], resize_keyboard: true, one_time_keyboard: true }
      });
      
      global.waitingFor2FA[userId] = data;
    }
    return;
  }

  // ========== LOGIN DENGAN STRING SESSION ==========
  if (text === '🔑 Login dengan Session') {
    const isInPhoneWait = !!(global.waitingForPhone && global.waitingForPhone[userId]);
    const isInPhoneTrialWait = !!(global.waitingForPhoneTrial && global.waitingForPhoneTrial[userId]);

    // Hanya izinkan jika sedang di flow login (menunggu kontak)
    if (!isInPhoneWait && !isInPhoneTrialWait) {
      return; // abaikan kalau bukan dari menu login
    }

    const isTrial = isInPhoneTrialWait;
    // Bersihkan waiting phone supaya tidak bentrok
    if (global.waitingForPhone) delete global.waitingForPhone[userId];
    if (global.waitingForPhoneTrial) delete global.waitingForPhoneTrial[userId];

    await bot.sendMessage(chatId, `
<blockquote>🔑 <b><u>LOGIN DENGAN STRING SESSION</u></b></blockquote>
<blockquote>📝 Kirim <b>String Session</b> Pyrogram / Telethon / GramJS akun kamu.</blockquote>
<blockquote>⚠️ <b>PENTING:</b>
• Hanya kirim session milik akun yang mau di-deploy
• Jangan bagikan String Session ke siapapun
• Session harus valid & belum di-revoke</blockquote>

<i>Tempel String Session di sini, atau ketik ❌ Batalkan untuk batal.</i>`, {
      parse_mode: 'HTML',
      reply_markup: { keyboard: [[{ text: '❌ Batalkan' }]], resize_keyboard: true, one_time_keyboard: true }
    });

    if (isTrial) {
      global.waitingForSessionTrial = global.waitingForSessionTrial || {};
      global.waitingForSessionTrial[userId] = true;
    } else {
      global.waitingForSession = global.waitingForSession || {};
      global.waitingForSession[userId] = true;
    }
    return;
  }

  if ((global.waitingForSession && global.waitingForSession[userId]) ||
      (global.waitingForSessionTrial && global.waitingForSessionTrial[userId])) {

    if (text === '❌ Batalkan' || text === '/cancel') {
      if (global.waitingForSession) delete global.waitingForSession[userId];
      if (global.waitingForSessionTrial) delete global.waitingForSessionTrial[userId];
      await bot.sendMessage(chatId, `
<blockquote>➡️ <b><u>Tindakan Dibatalkan...</u></b></blockquote>`, {
        parse_mode: 'HTML',
        reply_markup: await getMainMenuKeyboard(userId)
      });
      return;
    }

    const isTrial = !!(global.waitingForSessionTrial && global.waitingForSessionTrial[userId]);
    if (global.waitingForSession) delete global.waitingForSession[userId];
    if (global.waitingForSessionTrial) delete global.waitingForSessionTrial[userId];

    // Bersihkan input session (hapus kutip, whitespace, wrapper StringSession(...), dll)
    let rawSession = (text || '').trim();
    // Hapus backtick / code formatting dari Telegram
    rawSession = rawSession.replace(/^`+|`+$/g, '').trim();
    // Hapus wrapper seperti StringSession("...") atau StringSession('...')
    const wrapperMatch = rawSession.match(/StringSession\s*\(\s*["'`]?([\s\S]*?)["'`]?\s*\)/i);
    if (wrapperMatch) rawSession = wrapperMatch[1].trim();
    // Hapus kutip di ujung
    rawSession = rawSession.replace(/^["'`]+|["'`]+$/g, '').trim();
    // Hapus semua whitespace internal
    rawSession = rawSession.replace(/\s+/g, '');

    if (!rawSession || rawSession.length < 30) {
      await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>STRING SESSION TIDAK VALID</u></b></blockquote>
<blockquote>String Session terlalu pendek / kosong / format salah.</blockquote>
<blockquote>📌 <b>Tips:</b>
• Paste langsung kode session saja (biasanya dimulai dengan angka <code>1</code>)
• Jangan sertakan teks lain
• Session harus dari Pyrogram / Telethon / GramJS yang masih aktif</blockquote>`, {
        parse_mode: 'HTML',
        reply_markup: await getBackKeyboard()
      });
      return;
    }

    // GramJS StringSession WAJIB diawali versi (biasanya karakter '1').
    // Telethon/Pyrogram biasanya sudah diawali '1'. Kalau belum, coba tambahkan.
    let sessionString = rawSession;
    if (sessionString[0] !== '1') {
      sessionString = '1' + sessionString;
    }

    const statusMsg = await bot.sendMessage(chatId, `
<blockquote>⏳ <b><u>Sedang menghubungkan userbot dengan String Session...</u></b></blockquote>`, { parse_mode: 'HTML' });

    try {
      let client;
      try {
        client = new TelegramClient(new StringSession(sessionString), API_ID, API_HASH, getTelegramClientConfig());
      } catch (sessErr) {
        // Coba lagi tanpa prefix '1' kalau yang tadi kita tambahkan
        if (sessionString !== rawSession) {
          try {
            client = new TelegramClient(new StringSession(rawSession), API_ID, API_HASH, getTelegramClientConfig());
            sessionString = rawSession;
          } catch (e2) {
            throw new Error('Format String Session tidak dikenali. Pastikan session dari Telethon/Pyrogram/GramJS yang valid dan diawali dengan "1".');
          }
        } else {
          throw new Error('Format String Session tidak dikenali. Pastikan session dari Telethon/Pyrogram/GramJS yang valid dan diawali dengan "1".');
        }
      }

      await client.connect();

      // Pastikan session valid dengan getMe
      const me = await client.getMe();
      if (!me || !me.id) {
        try { await client.disconnect(); } catch (e) {}
        throw new Error('Session tidak valid / akun tidak bisa diakses');
      }

      // ========== CEK KEPEMILIKAN SESSION ==========
      // Session HARUS milik akun yang sedang di-deploy oleh user ini.
      // Jika ubot_id (me.id) sudah terdaftar di owner_id LAIN → TOLAK.
      const existingByUbot = await db.get('SELECT * FROM userbots WHERE ubot_id = ?', me.id.toString());
      if (existingByUbot && String(existingByUbot.owner_id) !== String(userId)) {
        try { await client.disconnect(); } catch (e) {}
        await safeDeleteMessage(chatId, statusMsg.message_id).catch(() => {});
        await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>SESSION DITOLAK</u></b></blockquote>
<blockquote>🔒 String Session ini milik akun lain (bukan akun kamu).</blockquote>
<blockquote>👤 <b>Akun session:</b> <code>${me.id}</code>
🆔 <b>ID kamu:</b> <code>${userId}</code></blockquote>
<blockquote>⚠️ Kamu hanya boleh login dengan <b>String Session akun milikmu sendiri</b>.</blockquote>
<blockquote>Gunakan session dari akun Telegram yang memang kamu miliki, jangan memakai session orang lain.</blockquote>`, {
          parse_mode: 'HTML',
          reply_markup: await getBackKeyboard()
        });
        return;
      }

      // Simpan session yang sudah di-load (GramJS menormalisasi format)
      const savedSession = client.session.save();

      let userFullName = 'Unknown';
      let userUsername = '';
      try {
        const userInfo = await bot.getChat(userId);
        userFullName = escapeHtml(userInfo.first_name || '');
        if (userInfo.last_name) userFullName += ` ${escapeHtml(userInfo.last_name)}`;
        userUsername = userInfo.username ? `@${escapeHtml(userInfo.username)}` : '';
      } catch (e) {}

      await db.run(
        'UPDATE users SET username = ?, full_name = ? WHERE user_id = ?',
        userUsername, userFullName, userId
      );

      let expired;
      let role;

      if (isTrial) {
        expired = Math.floor(Date.now() / 1000) + (100 * 365 * 86400);
        role = 'TRIAL';
      } else {
        const user = await db.get('SELECT * FROM users WHERE user_id = ?', userId);
        if (user && user.expired) {
          expired = user.expired;
          role = user.role;
        } else {
          expired = Math.floor(Date.now() / 1000) + 30 * 24 * 3600;
          role = 'PREMIUM_WM';
        }
      }

      const existingUbot = await db.get('SELECT * FROM userbots WHERE ubot_id = ?', me.id.toString());
      if (existingUbot) {
        await db.run('DELETE FROM userbots WHERE ubot_id = ?', me.id.toString());
      }

      const phone = me.phone || '-';

      await db.run(
        'INSERT INTO userbots (ubot_id, owner_id, phone, session_string, status, created_at, expired) VALUES (?, ?, ?, ?, ?, ?, ?)',
        me.id.toString(), userId, phone, savedSession, 'AKTIF', Math.floor(Date.now() / 1000), expired
      );

      await db.run(
        'UPDATE users SET role = ?, expired = ?, has_userbot = 1, trial_used = ? WHERE user_id = ?',
        role, expired, 0, userId
      );

      await db.run('INSERT INTO settings (owner_id) VALUES (?) ON CONFLICT(owner_id) DO NOTHING', userId);

      // Buat lazy client
      const ubot = lazyUbot.createLazyClient(userId, savedSession, API_ID, API_HASH, getTelegramClientConfig());

      const existingInMemory = userbots.findIndex(ub => ub.owner_id === userId);
      if (existingInMemory !== -1) {
        userbots.splice(existingInMemory, 1);
      }

      userbots.push({
        id: me.id.toString(),
        owner_id: userId,
        client: ubot,
        phone: phone,
        status: 'AKTIF'
      });

      // Join channel/group wajib (best-effort, sama seperti OTP flow)
      try {
        const logGroupClean = LOG_GROUP.replace('@', '');
        const requiredChannelClean = REQUIRED_CHANNEL.replace('@', '');
        const requiredGroupClean = REQUIRED_GROUP.replace('@', '');
        const targets = [
          { name: 'Log Group', id: logGroupClean, type: 'group' },
          { name: 'Required Channel', id: requiredChannelClean, type: 'channel' },
          { name: 'Required Group', id: requiredGroupClean, type: 'group' }
        ];
        for (const target of targets) {
          try {
            let entity;
            try { entity = await ubot.getEntity(target.id); } catch (e) {
              try { entity = await ubot.getEntity(`https://t.me/${target.id}`); } catch (e2) {}
            }
            if (entity) {
              if (target.type === 'channel') {
                await ubot.invoke(new Api.channels.JoinChannel({ channel: entity })).catch(() => {});
              } else {
                await ubot.invoke(new Api.messages.ImportChatInvite({ hash: target.id })).catch(() => {});
              }
            }
          } catch (e) {}
        }
      } catch (e) {}

      await safeDeleteMessage(chatId, statusMsg.message_id);

      let token = null;
      if (!isTrial) {
        token = generateSecureToken();
        const existingToken = await db.get('SELECT * FROM tokens WHERE owner_id = ?', userId);
        if (existingToken) {
          await db.run('DELETE FROM tokens WHERE owner_id = ?', userId);
        }
        await db.run(
          'INSERT INTO tokens (token, owner_id, ubot_id, role, created_at, expired_at) VALUES (?, ?, ?, ?, ?, ?)',
          token, userId, me.id.toString(), role, Math.floor(Date.now() / 1000), expired
        );

        let paketName = '';
        if (role === 'PREMIUM_WM') paketName = '🧩 Plan Basic';
        else if (role === 'PREMIUM_NO_WM') paketName = '💎 Plan Pro';
        else if (role === 'RESELLER') paketName = '🎟 Akses Reseller';
        else paketName = role;

        const sisaHari = Math.floor((expired - Math.floor(Date.now() / 1000)) / 86400);

        const caption = `
<blockquote>🚀 <b><u>USERBOT BERHASIL AKTIF</u></b></blockquote>
<blockquote>👤 <b>Nama</b> : <i>${escapeHtml(me.firstName || '')} ${escapeHtml(me.lastName || '')}</i>
🆔 <b>ID</b> : <code>${me.id}</code></blockquote>
<blockquote>🔑 <b>TOKEN CADANGAN</b>
📝 <code>${token}</code>
🛒 <b>Paket</b> : <b><u>${paketName}</u></b>
⚠️ <i>Simpan baik-baik ya!</i></blockquote>
<blockquote>🗓 <b>MASA AKTIF</b>
🛒 <b>Paket</b> : <b><u>${paketName}</u></b>
🗓 <b>Habis</b> : <i>${new Date(expired * 1000).toLocaleString()}</i>
🕐 <b>Sisa</b> : <b><u>${sisaHari} Hari</u></b></blockquote>

<i>Pilih tombol di bawah</i>`;

        await bot.sendMessage(chatId, caption, { parse_mode: 'HTML' });
      } else {
        const caption = `
<blockquote>✨ <b><u>FREE DEPLOY BERHASIL</u></b></blockquote>
<blockquote>👤 <b>Nama</b> : <i>${escapeHtml(me.firstName || '')} ${escapeHtml(me.lastName || '')}</i>
🆔 <b>ID</b> : <code>${me.id}</code></blockquote>
<blockquote>🗓 <b>MASA AKTIF</b>
🛒 <b>Paket</b> : <b><u>✨ Free Lifetime</u></b>
🗓 <b>Habis</b> : <i>Selamanya</i>
📊 <b>Batas Grup</b> : <b><u>20 Grup</u></b></blockquote>

<i>⚠️ Maksimal 20 grup target. Tambah grup otomatis dibatasi.</i>`;

        await bot.sendMessage(chatId, caption, { parse_mode: 'HTML' });
      }

      // Kirim String Session milik akun ini saja (bukan akun lain)
      await bot.sendMessage(chatId, `
<code>${savedSession}</code>

<blockquote>ini adalah String Session akun anda berfungsi jika ingin connect ulang lebih cepat dan tanpa menggunakan otp, simpan ini, dan jangan berikan kepada siapapun!</blockquote>`, {
        parse_mode: 'HTML'
      });

      const userbotData = await db.get('SELECT * FROM userbots WHERE owner_id = ?', userId);
      const logInfo = !isTrial ? { token: token, ubot_id: userbotData?.ubot_id } : { type: 'TRIAL', ubot_id: userbotData?.ubot_id };
      await sendLogNotification(userId, logInfo, 'login');

      await db.run(
        'INSERT INTO activity_logs (user_id, action, details, timestamp) VALUES (?, ?, ?, ?)',
        userId, isTrial ? 'TRIAL_ACTIVATED' : 'USERBOT_ACTIVATED', `Userbot: ${me.id} (Session Login)`, Math.floor(Date.now() / 1000)
      );

      const keyboard = await getMainMenuKeyboard(userId);
      const ubotInfo = userbots.find(ub => ub.owner_id === userId);
      const settings = await db.get('SELECT promosi_status FROM settings WHERE owner_id = ?', userId) || { promosi_status: 'OFF' };
      const user = await db.get('SELECT expired, role FROM users WHERE user_id = ?', userId);
      let paketName = user?.role === 'TRIAL' ? `✨ Free deploy` : (user?.role === 'PREMIUM_WM' ? `🧩 Plan Basic` : user?.role === 'PREMIUM_NO_WM' ? `💎 Plan Pro` : user?.role === 'RESELLER' ? `🎟 Akses Reseller` : `👤 FREE`);
      const expiredTime = user?.expired ? moment(user.expired * 1000).format('DD-MM-YYYY HH:mm') : '-';
      const statusPromosi = settings.promosi_status === 'ON' ? `✅ Aktif` : `❌ Nonaktif`;

      const infoMessage = `
<blockquote>🤖 <b><u>INFO USERBOT</u></b></blockquote>
<blockquote>📣 <b>Auto Promosi</b> : <b><u>${statusPromosi}</u></b>
🆔 <b>ID Userbot</b> : <code>${ubotInfo?.id || '-'}</code>
🛒 <b>Paket</b> : <b><u>${paketName}</u></b>
🗓 <b>Habis</b> : <i>${expiredTime}</i></blockquote>

<i>Pilih tombol di bawah sesuai kebutuhan!</i>`;

      await bot.sendMessage(chatId, infoMessage, {
        parse_mode: 'HTML',
        disable_web_page_preview: true,
        reply_markup: keyboard
      });

      // Disconnect temporary client (lazy client sudah aktif)
      try { await client.disconnect(); } catch (e) {}

    } catch (error) {
      await safeDeleteMessage(chatId, statusMsg.message_id).catch(() => {});
      logger.error(`Login dengan session gagal (userId=${userId}): ${error.message}`);
      const errMsg = String(error.message || 'Session tidak valid / koneksi gagal');
      const isFormatError = /not a valid string|format string session|tidak dikenali/i.test(errMsg);
      await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>GAGAL LOGIN DENGAN SESSION</u></b></blockquote>
<blockquote>⚠️ <b>${escapeHtml(errMsg)}</b></blockquote>
${isFormatError ? `<blockquote>📌 <b>Cara perbaiki:</b>
• Pastikan kamu paste <b>hanya</b> kode session (biasanya dimulai dengan <code>1</code>)
• Jangan ada spasi, enter, atau teks tambahan
• Session harus dari Telethon / Pyrogram / GramJS
• Jangan pakai session yang sudah di-logout / di-revoke</blockquote>` : `<blockquote>Pastikan String Session masih aktif, belum di-logout dari HP, dan formatnya benar (Pyrogram / Telethon / GramJS).</blockquote>`}

<i>Coba lagi dari menu deploy.</i>`, {
        parse_mode: 'HTML',
        reply_markup: await getBackKeyboard()
      });
    }
    return;
  }
  // ========== END LOGIN DENGAN STRING SESSION ==========
  
if (global.waitingForPhone && global.waitingForPhone[userId]) {
    delete global.waitingForPhone[userId];
    
    let phone = text;
    
    if (msg.contact) {
      phone = msg.contact.phone_number;
    } else {
      phone = phone.replace(/[^\d+]/g, '');
      if (!phone.startsWith('+')) {
        phone = '+' + phone;
      }
    }
    
    if (phone.length < 8) {
      await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>NOMOR TIDAK VALID</u></b>
📱 <b>Pake format internasional: +62812xxxxxx</b></blockquote>`, {
        parse_mode: 'HTML',
        reply_markup: await getBackKeyboard()
      });
      return;
    }
    
    const statusMsg = await bot.sendMessage(chatId, `
<blockquote>⏳ <b><u>Lagi ngirim kode OTP...</u></b></blockquote>`, { parse_mode: 'HTML' });
    
    try {
      const client = new TelegramClient(new StringSession(''), API_ID, API_HASH, getTelegramClientConfig());
      await client.connect();
      
      const result = await client.sendCode({ apiId: API_ID, apiHash: API_HASH }, phone);
      
      global.loginSessions = global.loginSessions || {};
      global.loginSessions[userId] = {
        client: client,
        phone: phone,
        phoneCodeHash: result.phoneCodeHash,
        isTrial: false
      };
      
      await safeDeleteMessage(chatId, statusMsg.message_id);
      await bot.sendMessage(chatId, `
<blockquote><b><u>Kirim Kode Otp</u></b></blockquote>
<blockquote>Cek kode OTP dari akun <a href="tg://openmessage?user_id=777000">Telegram</a> resmi.</blockquote>
<blockquote>Kirim kode OTP dengan format <b>spasi</b> setiap angka.</blockquote>
<blockquote>Contoh:
 • Kode OTP: <code>12345</code>
 • Kirim: <code>1 2 3 4 5</code></blockquote>
<blockquote>Pastiin kodenya bener ya.</blockquote>`, {
        parse_mode: 'HTML',
        disable_web_page_preview: true,
        reply_markup: { keyboard: [[`❌ Batalkan`]], resize_keyboard: true, one_time_keyboard: true }
      });
      
      global.waitingForOTP = global.waitingForOTP || {};
      global.waitingForOTP[userId] = true;
      
    } catch (error) {
      await safeDeleteMessage(chatId, statusMsg.message_id);
      await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>GAGAL</u></b>
⚠️ <b>${error.message}</b></blockquote>`, { 
        parse_mode: 'HTML',
        reply_markup: await getBackKeyboard() 
      });
    }
    return;
  }
  
if (msg.contact) {
    const phone = msg.contact.phone_number;
    
    if (global.waitingForPhone && global.waitingForPhone[userId]) {
      delete global.waitingForPhone[userId];
      
      const statusMsg = await bot.sendMessage(chatId, `
<blockquote>⏳ <b><u>Lagi ngirim kode OTP...</u></b></blockquote>`, { parse_mode: 'HTML' });
      
      try {
        const client = new TelegramClient(new StringSession(''), API_ID, API_HASH, getTelegramClientConfig());
        await client.connect();
        
        const result = await client.sendCode({ apiId: API_ID, apiHash: API_HASH }, phone);
        
        global.loginSessions = global.loginSessions || {};
        global.loginSessions[userId] = {
          client: client,
          phone: phone,
          phoneCodeHash: result.phoneCodeHash,
          isTrial: false
        };
        
        await safeDeleteMessage(chatId, statusMsg.message_id);
        await bot.sendMessage(chatId, `
<blockquote><b><u>Kirim Kode Otp</u></b></blockquote>
<blockquote>Cek kode OTP dari akun <a href="tg://openmessage?user_id=777000">Telegram</a> resmi.</blockquote>
<blockquote>Kirim kode OTP dengan format <b>spasi</b> setiap angka.</blockquote>
<blockquote>Contoh:
 • Kode OTP: <code>12345</code>
 • Kirim: <code>1 2 3 4 5</code></blockquote>
<blockquote>Pastiin kodenya bener ya.</blockquote>`, {
          parse_mode: 'HTML',
          disable_web_page_preview: true,
          reply_markup: { keyboard: [[`❌ Batalkan`]], resize_keyboard: true, one_time_keyboard: true }
        });
        
        global.waitingForOTP = global.waitingForOTP || {};
        global.waitingForOTP[userId] = true;
        
      } catch (error) {
        await safeDeleteMessage(chatId, statusMsg.message_id);
        await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>GAGAL</u></b>
⚠️ <b>${error.message}</b></blockquote>`, { 
          parse_mode: 'HTML',
          reply_markup: await getBackKeyboard() 
        });
      }
      return;
    }
    
    if (global.waitingForPhoneTrial && global.waitingForPhoneTrial[userId]) {
      delete global.waitingForPhoneTrial[userId];
      
      const statusMsg = await bot.sendMessage(chatId, `
<blockquote>⏳ <b><u>Lagi ngirim kode OTP...</u></b></blockquote>`, { parse_mode: 'HTML' });
      
      try {
        const client = new TelegramClient(new StringSession(''), API_ID, API_HASH, getTelegramClientConfig());
        await client.connect();
        
        const result = await client.sendCode({ apiId: API_ID, apiHash: API_HASH }, phone);
        
        global.loginSessions = global.loginSessions || {};
        global.loginSessions[userId] = {
          client: client,
          phone: phone,
          phoneCodeHash: result.phoneCodeHash,
          isTrial: true
        };
        
        await safeDeleteMessage(chatId, statusMsg.message_id);
        await bot.sendMessage(chatId, `
<blockquote><b><u>Kirim Kode Otp</u></b></blockquote>
<blockquote>Cek kode OTP dari akun <a href="tg://openmessage?user_id=777000">Telegram</a> resmi.</blockquote>
<blockquote>Kirim kode OTP dengan format <b>spasi</b> setiap angka.</blockquote>
<blockquote>Contoh:
 • Kode OTP: <code>12345</code>
 • Kirim: <code>1 2 3 4 5</code></blockquote>
<blockquote>Pastiin kodenya bener ya.</blockquote>`, {
          parse_mode: 'HTML',
          disable_web_page_preview: true,
          reply_markup: { keyboard: [[`❌ Batalkan`]], resize_keyboard: true, one_time_keyboard: true }
        });
        
        global.waitingForOTPTrial = global.waitingForOTPTrial || {};
        global.waitingForOTPTrial[userId] = true;
        
      } catch (error) {
        await safeDeleteMessage(chatId, statusMsg.message_id);
        await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>GAGAL</u></b>
⚠️ <b>${error.message}</b></blockquote>`, { 
          parse_mode: 'HTML',
          reply_markup: await getBackKeyboard() 
        });
      }
      return;
    }
  }
  } catch (error) {
    logger.error(`message handler error (userId=${userId}, text="${text}"):`, error && error.stack ? error.stack : error);
    try {
      await bot.sendMessage(chatId, `
<blockquote>⚠️ <b><u>TERJADI ERROR</u></b>
🔄 <b>Coba lagi ya, atau ketik /start buat reset.</b></blockquote>`, { parse_mode: 'HTML' }).catch(() => {});
    } catch (e) {}
  }
});

async function restoreAndContinueBroadcasts() {
  logger.info('Memeriksa broadcast yang harus dilanjutkan...');
  
  const activePromos = await db.all('SELECT * FROM settings WHERE promosi_status = "ON"');
  
  for (const setting of activePromos) {
    const userId = setting.owner_id;
    
    const ubot = userbots.find(ub => ub.owner_id === userId);
    if (!ubot) {
      logger.warn(`Userbot ${userId} tidak ditemukan, matikan promosi`);
      await db.run('UPDATE settings SET promosi_status = "OFF" WHERE owner_id = ?', userId);
      continue;
    }
    
    const groups = await db.all('SELECT * FROM groups WHERE owner_id = ?', userId);
    const messages = await db.all('SELECT * FROM messages WHERE owner_id = ?', userId);
    const blacklistGroups = await db.all('SELECT group_id FROM blacklist_groups WHERE owner_id = ?', userId);
    const blacklistIds = blacklistGroups.map(b => b.group_id.toString());
    const validGroups = groups.filter(g => parseInt(g.group_id) < 0 && !blacklistIds.includes(g.group_id.toString()));
    
    if (validGroups.length === 0 || messages.length === 0) {
      await db.run('UPDATE settings SET promosi_status = "OFF" WHERE owner_id = ?', userId);
      continue;
    }
    
    let selectedMessage = messages.find(m => m.id === setting.selected_message_id);
    if (!selectedMessage) selectedMessage = messages[0];
    
    const role = await getUserRole(userId);
    let watermarkToUse = '';
    
    if (role === 'PREMIUM_NO_WM' || role === 'RESELLER' || role === 'OWNER') {
      const freshSettings = await db.get('SELECT watermark, watermark_status FROM settings WHERE owner_id = ?', userId);
      if (freshSettings && freshSettings.watermark && freshSettings.watermark_status === 'ON') {
        watermarkToUse = freshSettings.watermark;
      }
    } else if (selectedMessage.type !== 'forward') {
      watermarkToUse = WM;
    }
    
    let messageContent = selectedMessage.content || '';
    let entitiesToUse = null;
    
    if (selectedMessage.entities_json) {
      try {
        entitiesToUse = JSON.parse(selectedMessage.entities_json);
      } catch (e) {}
    }
    
    if (selectedMessage.type !== 'forward') {
      if (watermarkToUse && messageContent) {
        messageContent = messageContent + '\n\n' + watermarkToUse;
      } else if (watermarkToUse && !messageContent) {
        messageContent = watermarkToUse;
      }
    }
    
    const settingsData = await db.get('SELECT delay, jeda FROM settings WHERE owner_id = ?', userId) || { delay: 500, jeda: 15 };
    const notifSettings = await db.get('SELECT notif_target, notif_to_saved FROM settings WHERE owner_id = ?', userId);
    
    if (promosiProgress[userId]) {
      if (promosiProgress[userId].running) continue;
      delete promosiProgress[userId];
    }
    
    if (global.promoTimeouts && global.promoTimeouts[userId]) {
      clearTimeout(global.promoTimeouts[userId]);
      delete global.promoTimeouts[userId];
    }
    
    let currentProgress = 0;
    let currentSuccess = 0;
    let currentFailed = 0;
    let currentErrors = [];
    let lastHeartbeat = Date.now();
    
    const savedState = await db.get('SELECT promosi_round_data FROM settings WHERE owner_id = ?', userId);
    if (savedState && savedState.promosi_round_data) {
      try {
        const state = JSON.parse(savedState.promosi_round_data);
        if (state.current && state.current < validGroups.length) {
          currentProgress = state.current;
          currentSuccess = state.success || 0;
          currentFailed = state.failed || 0;
          currentErrors = state.errors || [];
          lastHeartbeat = state.lastHeartbeat || Date.now();
          logger.info(`Melanjutkan broadcast untuk ${userId} dari grup ${currentProgress}/${validGroups.length}`);
        }
      } catch (e) {}
    }
    
    promosiProgress[userId] = {
      validGroups: validGroups,
      current: currentProgress,
      success: currentSuccess,
      failed: currentFailed,
      errors: currentErrors,
      running: true,
      startTime: Date.now() - (currentProgress * (settingsData.delay || 500)),
      settings: settingsData,
      selectedMessage: {
        id: selectedMessage.id,
        local_id: selectedMessage.local_id,
        type: selectedMessage.type,
        content: selectedMessage.content,
        file_id: selectedMessage.file_id,
        caption: selectedMessage.caption,
        from_chat: selectedMessage.from_chat,
        forward_message_id: selectedMessage.forward_message_id,
        entities_json: entitiesToUse ? JSON.stringify(entitiesToUse) : null
      },
      messageContent: messageContent,
      chatId: null,
      lastActivity: Date.now(),
      lastHeartbeat: lastHeartbeat,
      notifTarget: notifSettings?.notif_target || userId,
      notifToSaved: notifSettings?.notif_to_saved === 1,
      isRestored: true
    };
    
    await savePromosiState(userId);
    await savePromosiStateToFile();
    await db.run('UPDATE settings SET promosi_status = "ON" WHERE owner_id = ?', userId);
    
    setTimeout(() => {
      if (promosiProgress[userId] && promosiProgress[userId].running) {
        if (currentProgress > 0) {
          logger.info(`Broadcast untuk user ${userId} dilanjutkan dari grup ${currentProgress}/${validGroups.length} (tanpa notifikasi awal)`);
        } else {
          logger.info(`Broadcast untuk user ${userId} dimulai round baru (tanpa notifikasi awal)`);
        }
        executePromoRound(userId, null, true);
      }
    }, 3000);
  }
}

async function startNewRound(userId, validGroups, selectedMessage, messageContent, settingsData) {
  if (promosiProgress[userId]) {
    if (promosiProgress[userId].running) return;
    delete promosiProgress[userId];
  }
  
  if (global.promoTimeouts && global.promoTimeouts[userId]) {
    clearTimeout(global.promoTimeouts[userId]);
    delete global.promoTimeouts[userId];
  }
  
  const notifSettings = await db.get('SELECT notif_target, notif_to_saved FROM settings WHERE owner_id = ?', userId);
  
  promosiProgress[userId] = {
    validGroups: validGroups,
    current: 0,
    success: 0,
    failed: 0,
    errors: [],
    running: true,
    startTime: Date.now(),
    settings: settingsData,
    selectedMessage: selectedMessage,
    messageContent: messageContent,
    chatId: null,
    lastActivity: Date.now(),
    lastHeartbeat: Date.now(),
    notifTarget: notifSettings?.notif_target || userId,
    notifToSaved: notifSettings?.notif_to_saved === 1
  };
  
  await savePromosiState(userId);
  await savePromosiStateToFile();
  await db.run('UPDATE settings SET promosi_status = "ON" WHERE owner_id = ?', userId);
  
  setTimeout(() => {
    if (promosiProgress[userId] && promosiProgress[userId].running) {
      executePromoRound(userId, null);
      logger.info(`Broadcast untuk user ${userId} dilanjutkan otomatis setelah restart`);
    }
  }, 1000);
}

async function continueExistingRound(userId, validGroups, selectedMessage, messageContent, settingsData, currentProgress, currentSuccess, currentFailed, currentErrors) {
  if (promosiProgress[userId]) {
    if (promosiProgress[userId].running) return;
    delete promosiProgress[userId];
  }
  
  if (global.promoTimeouts && global.promoTimeouts[userId]) {
    clearTimeout(global.promoTimeouts[userId]);
    delete global.promoTimeouts[userId];
  }
  
  const notifSettings = await db.get('SELECT notif_target, notif_to_saved FROM settings WHERE owner_id = ?', userId);
  
  promosiProgress[userId] = {
    validGroups: validGroups,
    current: currentProgress,
    success: currentSuccess,
    failed: currentFailed,
    errors: currentErrors,
    running: true,
    startTime: Date.now() - (currentProgress * (settingsData.delay || 500)),
    settings: settingsData,
    selectedMessage: selectedMessage,
    messageContent: messageContent,
    chatId: null,
    lastActivity: Date.now(),
    lastHeartbeat: Date.now(),
    notifTarget: notifSettings?.notif_target || userId,
    notifToSaved: notifSettings?.notif_to_saved === 1
  };
  
  await savePromosiState(userId);
  await savePromosiStateToFile();
  await db.run('UPDATE settings SET promosi_status = "ON" WHERE owner_id = ?', userId);
  
  setTimeout(() => {
    if (promosiProgress[userId] && promosiProgress[userId].running) {
      executePromoRound(userId, null);
      logger.info(`Broadcast untuk user ${userId} dilanjutkan dari grup ${currentProgress}/${validGroups.length}`);
    }
  }, 1000);
}

async function crashProofWatcher() {
  setInterval(async () => {
    // BUG FIX (v10.3 - STABILITAS): sebelumnya isi callback setInterval ini
    // TIDAK dibungkus try/catch sama sekali. Kalau satu entry promosiProgress
    // ada dalam state tak terduga (mis. promo.validGroups sempat undefined
    // di tengah proses restore/race dengan handler lain) dan melempar
    // exception, iterasi `for` di userId itu berhenti DI TENGAH JALAN -
    // sisa userId lain dalam loop yang sama (termasuk loop kedua yang
    // nyimpen state via savePromosiState) ikut TIDAK diproses pada siklus
    // itu. setInterval sendiri tidak berhenti (siklus berikutnya tetap
    // jalan 15 detik lagi), tapi state broadcast user lain bisa telat
    // tersimpan / telat direstart kalau stuck. Sekarang seluruh isi
    // callback dibungkus try/catch supaya satu entry yang error tidak
    // pernah mengganggu pemrosesan entry lain di siklus yang sama.
    try {
    for (const [userId, promo] of Object.entries(promosiProgress)) {
      if (promo && promo.running && promo.current < promo.validGroups.length) {
        const timeSinceLastActivity = Date.now() - (promo.lastActivity || promo.startTime);
        
        if (timeSinceLastActivity > 180000) {
          logger.warn(`Broadcast ${userId} stuck selama ${Math.floor(timeSinceLastActivity/1000)} detik, merestart...`);
          
          const ubot = userbots.find(ub => ub.owner_id === userId);
          if (!ubot) {
            logger.warn(`Userbot ${userId} tidak ada, hentikan broadcast`);
            delete promosiProgress[userId];
            await db.run('UPDATE settings SET promosi_status = "OFF" WHERE owner_id = ?', userId);
            continue;
          }
          
          try {
            const me = await ubot.client.getMe();
            if (!me) throw new Error('Userbot offline');
          } catch (err) {
            logger.warn(`Userbot ${userId} offline, hentikan broadcast`);
            delete promosiProgress[userId];
            await db.run('UPDATE settings SET promosi_status = "OFF" WHERE owner_id = ?', userId);
            continue;
          }
          
          promo.running = false;
          await savePromosiState(userId);
          
          setTimeout(() => {
            if (promosiProgress[userId]) {
              promosiProgress[userId].running = true;
              promosiProgress[userId].lastActivity = Date.now();
              executePromoRound(userId, promo.chatId);
              logger.info(`Broadcast ${userId} direstart setelah stuck`);
            }
          }, 5000);
        }
      }
    }
    
    for (const [userId, promo] of Object.entries(promosiProgress)) {
      if (promo && promo.running) {
        await savePromosiState(userId);
      }
    }
    
    savePromosiStateToFile();
    } catch (error) {
      logger.error('crashProofWatcher siklus gagal:', error && error.stack ? error.stack : error);
    }
  }, 15000);
}

async function executePromoRound(userId, chatId, isRestart = false) {
  const promo = promosiProgress[userId];
  if (!promo || !promo.running) return;
  
  const ubot = userbots.find(ub => ub.owner_id === userId);
  if (!ubot) {
    if (chatId) {
      await bot.sendMessage(chatId, '❌ Userbot ga ketemu. Promosi dihentiin.', { parse_mode: 'HTML' });
    }
    await db.run('UPDATE settings SET promosi_status = "OFF" WHERE owner_id = ?', userId);
    delete promosiProgress[userId];
    await savePromosiStateToFile();
    return;
  }
  
  // Kunci koneksi userbot ini selama ronde broadcast berjalan, supaya
  // TIDAK ke-disconnect otomatis di tengah proses walau ada jeda antar
  // grup. Dilepas lagi (unpin) di finally paling bawah fungsi ini -
  // apapun yang terjadi (error, stop manual, selesai normal), koneksi
  // akan tetap balik jadi "boleh idle-disconnect" seperti biasa.
  lazyUbot.pin(userId);
  try {

  let userbotDisplay = '';
  try {
    const me = await ubot.client.getMe();
    userbotDisplay = `${me.firstName || ''} ${me.lastName || ''}`.trim();
    if (!userbotDisplay) userbotDisplay = me.username || `ID: ${me.id}`;
  } catch (err) {
    userbotDisplay = `ID: ${ubot.id}`;
  }
  
  promo.lastActivity = Date.now();
  
  let success = promo.success || 0;
  let failed = promo.failed || 0;
  let delayMs = promo.settings.current_delay || promo.settings.delay || 500;
  let floodDetected = promo.settings.flood_detected || false;
  
  let totalGroups = promo.validGroups.length;
  let processedGroups = promo.current || 0;
  let failedGroups = [];
  let skippedGroups = [];
  
  const roundNum = (await db.get('SELECT COUNT(*) as count FROM promo_logs WHERE owner_id = ?', userId)).count + 1;
  const startTime = Date.now();
  const notifSettings = await db.get('SELECT notif_target, notif_to_saved FROM settings WHERE owner_id = ?', userId);
  const targetNotif = notifSettings?.notif_target || userId;
  const sendToSaved = notifSettings?.notif_to_saved === 1;
  
  if (!isRestart || processedGroups === 0) {
    const startMessage = `⚙️ BROADCAST DIMULAI

👤 User ID : ${userId}
🤖 Userbot : ${userbotDisplay}
📊 Putaran Ke : ${roundNum}
🎯 Target Grup : ${totalGroups} grup
⏰ Delay : ${delayMs} ms`;

    if (sendToSaved && ubot?.client) {
      try {
        await ubot.client.sendMessage('me', { message: startMessage });
      } catch(e) { console.error('Gagal kirim ke saved:', e.message); }
    } else if (targetNotif && targetNotif !== userId) {
      try {
        await ubot.client.sendMessage(targetNotif, { message: startMessage });
      } catch(e) { console.error('Gagal kirim ke target:', e.message); }
    } else {
      try {
        await bot.sendMessage(userId, startMessage, { parse_mode: 'HTML' });
      } catch(e) { console.error('Gagal kirim ke pemilik:', e.message); }
    }
  }
  
  for (let i = processedGroups; i < totalGroups; i++) {
    if (!promosiProgress[userId]?.running) {
      await savePromosiState(userId);
      await savePromosiStateToFile();
      return;
    }
    
    const group = promo.validGroups[i];
    let currentDelay = floodDetected ? Math.min(delayMs * 2, 5000) : delayMs;
    let sendSuccess = false;
    let retryCount = 0;
    const maxRetries = 2;
    let waitTime = 0;
    let errorReason = '';
    
    const blacklistCheck = await db.get('SELECT group_id FROM blacklist_groups WHERE owner_id = ? AND group_id = ?', userId, group.group_id.toString());
    if (blacklistCheck) {
      skippedGroups.push({
        name: group.group_username || group.group_title || group.group_id,
        id: group.group_id,
        reason: 'Blacklisted'
      });
      promo.current = i + 1;
      continue;
    }
    
    while (!sendSuccess && retryCount < maxRetries) {
      try {
        if (promo.selectedMessage.type === 'forward' && promo.selectedMessage.from_chat) {
          await ubot.client.forwardMessages(group.group_id, {
            fromPeer: promo.selectedMessage.from_chat,
            messages: [parseInt(promo.selectedMessage.forward_message_id)]
          });
        } 
        else if (promo.selectedMessage.file_id) {
          const fileId = promo.selectedMessage.file_id;
          const captionText = promo.messageContent || '';
          const entitiesJson = promo.selectedMessage.entities_json;
          
          let sendOptions = { file: fileId };
          
          if (captionText) {
            sendOptions.caption = captionText;
          }
          
          if (entitiesJson) {
            try {
              const entities = JSON.parse(entitiesJson);
              if (entities && entities.length > 0) {
                sendOptions.caption_entities = entities;
              }
            } catch (e) {}
          }
          
          if (promo.selectedMessage.type === 'sticker') {
            delete sendOptions.caption;
            await ubot.client.sendFile(group.group_id, { file: fileId });
          } else {
            await ubot.client.sendFile(group.group_id, sendOptions);
          }
        } 
        else {
          let messageToSend = promo.messageContent || '';
          const entitiesJson = promo.selectedMessage.entities_json;
          
          if (entitiesJson) {
            try {
              const entities = JSON.parse(entitiesJson);
              if (entities && entities.length > 0) {
                await ubot.client.sendMessage(group.group_id, { message: messageToSend, entities: entities });
              } else {
                await ubot.client.sendMessage(group.group_id, { message: messageToSend });
              }
            } catch (e) {
              await ubot.client.sendMessage(group.group_id, { message: messageToSend });
            }
          } else {
            await ubot.client.sendMessage(group.group_id, { message: messageToSend });
          }
        }
        sendSuccess = true;
        success++;
        
      } catch (err) {
        const errorMessage = err.message;
        errorReason = errorMessage;
        
        if (errorMessage.includes('USER_BANNED_IN_CHANNEL')) {
          errorReason = 'Userbot dibanned dari grup';
          sendSuccess = true;
          failed++;
          failedGroups.push({
            name: group.group_username || group.group_title || group.group_id,
            id: group.group_id,
            error: errorReason
          });
          break;
        }
        else if (errorMessage.includes('CHAT_NOT_FOUND')) {
          errorReason = 'Grup tidak ditemukan';
          sendSuccess = true;
          failed++;
          failedGroups.push({
            name: group.group_username || group.group_title || group.group_id,
            id: group.group_id,
            error: errorReason
          });
          break;
        }
        else if (errorMessage.includes('USER_NOT_PARTICIPANT')) {
          errorReason = 'Userbot tidak join ke grup';
          sendSuccess = true;
          failed++;
          failedGroups.push({
            name: group.group_username || group.group_title || group.group_id,
            id: group.group_id,
            error: errorReason
          });
          break;
        }
        else if (errorMessage.includes('CHAT_WRITE_FORBIDDEN')) {
          errorReason = 'Grup membatasi pesan (bisa jadi banned)';
          sendSuccess = true;
          failed++;
          failedGroups.push({
            name: group.group_username || group.group_title || group.group_id,
            id: group.group_id,
            error: errorReason
          });
          break;
        }
        else if (errorMessage.includes('CHAT_RESTRICTED')) {
          errorReason = 'Grup restricted (dibatasi)';
          sendSuccess = true;
          failed++;
          failedGroups.push({
            name: group.group_username || group.group_title || group.group_id,
            id: group.group_id,
            error: errorReason
          });
          break;
        }
        else if (errorMessage.includes('CHAT_SEND_PLAIN_FORBIDDEN')) {
          errorReason = 'Grup tidak mengizinkan kirim pesan plain';
          sendSuccess = true;
          failed++;
          failedGroups.push({
            name: group.group_username || group.group_title || group.group_id,
            id: group.group_id,
            error: errorReason
          });
          break;
        }
        else if (errorMessage.includes('ALLOW_PAYMENT_REQUIRED')) {
          errorReason = 'Grup berbayar (allow payment required)';
          sendSuccess = true;
          failed++;
          failedGroups.push({
            name: group.group_username || group.group_title || group.group_id,
            id: group.group_id,
            error: errorReason
          });
          break;
        }
        else if (errorMessage.includes('PEER_FLOOD')) {
          errorReason = 'Flood wait, grup tidak bisa menerima pesan';
          sendSuccess = true;
          failed++;
          failedGroups.push({
            name: group.group_username || group.group_title || group.group_id,
            id: group.group_id,
            error: errorReason
          });
          break;
        }
        else if (errorMessage.includes('FLOOD_WAIT')) {
          const match = errorMessage.match(/FLOOD_WAIT_(\d+)/);
          if (match) {
            waitTime = parseInt(match[1]);
            floodDetected = true;
            promo.settings.current_delay = Math.min(delayMs * 2, 5000);
            await db.run('UPDATE settings SET current_delay = ? WHERE owner_id = ?', promo.settings.current_delay, userId);
            
            if (sendToSaved && ubot?.client) {
              try {
                await ubot.client.sendMessage('me', { message: `⚠️ Flood! Tunggu ${waitTime} detik...` });
              } catch(e) {}
            } else if (targetNotif && targetNotif !== userId) {
              try {
                await ubot.client.sendMessage(targetNotif, { message: `⚠️ Flood! Tunggu ${waitTime} detik...` });
              } catch(e) {}
            } else {
              try {
                await bot.sendMessage(userId, `⚠️ Flood! Tunggu ${waitTime} detik...`, { parse_mode: 'HTML' });
              } catch(e) {}
            }
            await new Promise(r => setTimeout(r, waitTime * 1000));
          }
          continue;
          
        } else if (errorMessage.includes('FLOOD') || errorMessage.includes('Too Many Requests')) {
          floodDetected = true;
          promo.settings.current_delay = Math.min(delayMs * 1.5, 5000);
          await db.run('UPDATE settings SET current_delay = ? WHERE owner_id = ?', promo.settings.current_delay, userId);
          await new Promise(r => setTimeout(r, 5000));
          continue;
        }
        
        retryCount++;
        if (retryCount >= maxRetries) {
          failed++;
          failedGroups.push({
            name: group.group_username || group.group_title || group.group_id,
            id: group.group_id,
            error: errorReason.substring(0, 100)
          });
          sendSuccess = true;
        } else {
          await new Promise(r => setTimeout(r, 3000));
        }
      }
    }
    
    promo.current = i + 1;
    promo.success = success;
    promo.failed = failed;
    promo.lastActivity = Date.now();
    await savePromosiState(userId);
    
    if (i < totalGroups - 1) {
      await new Promise(r => setTimeout(r, currentDelay));
    }
  }
  
  if (!floodDetected && promo.settings.current_delay > promo.settings.delay) {
    promo.settings.current_delay = promo.settings.delay;
    await db.run('UPDATE settings SET current_delay = ? WHERE owner_id = ?', promo.settings.delay, userId);
  }
  
  await db.run('UPDATE settings SET promosi_active = 0, promosi_round_data = NULL WHERE owner_id = ?', userId);
  
  const totalWaktu = Math.floor((Date.now() - startTime) / 1000);
  const roundCount = await db.get('SELECT COUNT(*) as count FROM promo_logs WHERE owner_id = ?', userId);
  const roundNumber = (roundCount.count || 0) + 1;
  
  const menit = Math.floor(totalWaktu / 60);
  const detik = totalWaktu % 60;
  const jedaMenit = promo.settings.jeda || 15;
  
  const logDir = path.join(databaseDir, 'logs', userId);
  if (!fs.existsSync(logDir)) {
    fs.mkdirSync(logDir, { recursive: true });
  }
  
  const logFileName = `broadcast_${moment().format('YYYY-MM-DD')}.txt`;
  const logFilePath = path.join(logDir, logFileName);
  
  let logContent = `
${'='.repeat(60)}
[${moment().format('YYYY-MM-DD HH:mm:ss')}] BROADCAST SELESAI
Round Ke: ${roundNumber}
Target Grup: ${totalGroups}
Sukses: ${success}
Gagal: ${failed}
Waktu: ${menit} menit ${detik} detik
Jeda Round Berikutnya: ${jedaMenit} menit
${'='.repeat(60)}
`;
  
  if (failedGroups.length > 0) {
    logContent += `\nDAFTAR GRUP GAGAL:\n`;
    for (let idx = 0; idx < failedGroups.length; idx++) {
      const fg = failedGroups[idx];
      logContent += `${idx + 1}. ${fg.name}\n   ID: ${fg.id}\n   Error: ${fg.error}\n`;
    }
    logContent += `\n${'='.repeat(60)}\n`;
  }
  
  fs.appendFileSync(logFilePath, logContent, 'utf8');
  
  const resultMessage = `✅ BROADCAST SELESAI

👤 User ID : ${userId}
🤖 Userbot : ${userbotDisplay}
📊 Putaran Ke : ${roundNumber}
✅ Sukses : ${success} grup
❌ Gagal : ${failed} grup
📊 Total Target : ${totalGroups} grup
🕐 Waktu : ${menit} menit ${detik} detik
⏳ Putaran berikutnya dalam ${jedaMenit} menit`;

  if (failedGroups.length > 0) {
    let failedList = '\n\n❌ GRUP GAGAL:\n';
    for (let idx = 0; idx < Math.min(failedGroups.length, 10); idx++) {
      const fg = failedGroups[idx];
      failedList += `${idx + 1}. ${fg.name.substring(0, 30)}\n   Error: ${fg.error}\n`;
    }
    if (failedGroups.length > 10) {
      failedList += `\n... dan ${failedGroups.length - 10} grup lainnya (cek log untuk detail)`;
    }
  }

  try {
    if (sendToSaved && ubot?.client) {
      if (fs.existsSync(logFilePath)) {
        await ubot.client.sendFile('me', { file: logFilePath, caption: resultMessage });
      } else {
        await ubot.client.sendMessage('me', { message: resultMessage });
      }
    } else if (targetNotif && targetNotif !== userId) {
      if (fs.existsSync(logFilePath)) {
        await ubot.client.sendFile(targetNotif, { file: logFilePath, caption: resultMessage });
      } else {
        await ubot.client.sendMessage(targetNotif, { message: resultMessage });
      }
    } else {
      if (fs.existsSync(logFilePath)) {
        await bot.sendDocument(userId, logFilePath, { caption: resultMessage, parse_mode: 'HTML' });
      } else {
        await bot.sendMessage(userId, resultMessage, { parse_mode: 'HTML' });
      }
    }
  } catch (err) {
    try {
      await bot.sendMessage(userId, resultMessage, { parse_mode: 'HTML' });
    } catch(e) {}
  }

  await db.run(
    'INSERT INTO promo_logs (owner_id, round_number, total_groups, success, failed, errors, started_at, finished_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
    userId, roundNumber, totalGroups, success, failed, JSON.stringify(failedGroups.slice(0, 50)), Math.floor(startTime / 1000), Math.floor(Date.now() / 1000)
  );
  
  await db.run('UPDATE settings SET total_rounds = total_rounds + 1 WHERE owner_id = ?', userId);
  
  promo.running = false;
  promo.lastRunTime = Date.now();
  
  await savePromosiStateToFile();
  
  const jedaMs = jedaMenit * 60 * 1000;
  
  if (global.promoTimeouts && global.promoTimeouts[userId]) {
    clearTimeout(global.promoTimeouts[userId]);
  }
  if (!global.promoTimeouts) global.promoTimeouts = {};
  
  global.promoTimeouts[userId] = setTimeout(async () => {
    const settings = await db.get('SELECT promosi_status FROM settings WHERE owner_id = ?', userId);
    
    if (settings && settings.promosi_status === 'ON') {
      let groups = await db.all('SELECT * FROM groups WHERE owner_id = ?', userId);
      const blacklistGroups = await db.all('SELECT group_id FROM blacklist_groups WHERE owner_id = ?', userId);
      const blacklistIds = blacklistGroups.map(b => b.group_id.toString());
      let validGroups = groups.filter(g => {
        return parseInt(g.group_id) < 0 && !blacklistIds.includes(g.group_id.toString());
      });
      
      if (validGroups.length === 0) {
        await db.run('UPDATE settings SET promosi_status = "OFF" WHERE owner_id = ?', userId);
        return;
      }
      
      const selectedMessage = promo.selectedMessage;
      let messageContent = promo.messageContent;
      
      if (selectedMessage.type !== 'forward') {
        const role = await getUserRole(userId);
        let watermarkToUse = '';
        
        if (role === 'PREMIUM_NO_WM' || role === 'RESELLER' || role === 'OWNER') {
          const freshSettings = await db.get('SELECT watermark, watermark_status FROM settings WHERE owner_id = ?', userId);
          if (freshSettings && freshSettings.watermark && freshSettings.watermark_status === 'ON') {
            watermarkToUse = freshSettings.watermark;
          }
        } else {
          watermarkToUse = WM;
        }
        
        messageContent = selectedMessage.content || '';
        if (watermarkToUse && messageContent) {
          messageContent = messageContent + '\n\n' + watermarkToUse;
        } else if (watermarkToUse && !messageContent) {
          messageContent = watermarkToUse;
        }
      }
      
      promosiProgress[userId] = {
        validGroups: validGroups,
        current: 0,
        success: 0,
        failed: 0,
        errors: [],
        running: true,
        startTime: Date.now(),
        settings: promo.settings,
        selectedMessage: selectedMessage,
        messageContent: messageContent,
        lastActivity: Date.now(),
        chatId: chatId || promo.chatId,
        notifTarget: targetNotif,
        notifToSaved: sendToSaved
      };
      
      await savePromosiState(userId);
      await savePromosiStateToFile();
      
      executePromoRound(userId, targetNotif);
    }
  }, jedaMs);

  } finally {
    // Ronde ini selesai (atau berhenti/gagal) - koneksi boleh idle lagi.
    // Kalau ronde berikutnya mulai (lewat setTimeout jeda di atas), fungsi
    // ini dipanggil ulang dan akan pin() lagi otomatis di awal.
    lazyUbot.unpin(userId);
  }
}

async function startautoBroadcast(userId, chatId, progressMsgId = null) {
  if (promosiProgress[userId]?.running) {
    if (chatId) {
      await bot.sendMessage(chatId, `
<blockquote>⚠️ <b><u>Broadcast sedang jalan</u></b></blockquote>`, { parse_mode: 'HTML' });
    }
    return;
  }
  
  const settings = await db.get('SELECT * FROM settings WHERE owner_id = ?', userId) || {
    delay: 500, jeda: 15, promosi_status: 'OFF', selected_message_id: null
  };
  
  let groups = await db.all('SELECT * FROM groups WHERE owner_id = ?', userId);
  const messages = await db.all('SELECT * FROM messages WHERE owner_id = ?', userId);
  const ubot = userbots.find(ub => ub.owner_id === userId);
  const role = await getUserRole(userId);
  
  if (!ubot) {
    if (chatId) await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>Userbot tidak ditemukan</u></b></blockquote>`, { parse_mode: 'HTML' });
    await db.run('UPDATE settings SET promosi_status = "OFF" WHERE owner_id = ?', userId);
    return;
  }
  
  if (groups.length === 0) {
    if (chatId) await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>Belum ada grup target</u></b></blockquote>`, { parse_mode: 'HTML' });
    await db.run('UPDATE settings SET promosi_status = "OFF" WHERE owner_id = ?', userId);
    return;
  }
  
  if (messages.length === 0) {
    if (chatId) await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>Belum ada pesan tersimpan</u></b></blockquote>`, { parse_mode: 'HTML' });
    await db.run('UPDATE settings SET promosi_status = "OFF" WHERE owner_id = ?', userId);
    return;
  }
  
  let selectedMessage;
  if (settings.selected_message_id) {
    selectedMessage = messages.find(m => m.id === settings.selected_message_id);
  }
  if (!selectedMessage && messages.length > 0) {
    selectedMessage = messages[0];
  }
  
  if (!selectedMessage) {
    if (chatId) await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>Tidak ada pesan tersimpan</u></b></blockquote>`, { parse_mode: 'HTML' });
    await db.run('UPDATE settings SET promosi_status = "OFF" WHERE owner_id = ?', userId);
    return;
  }
  
  if (!selectedMessage.content && !selectedMessage.file_id && selectedMessage.type !== 'forward') {
    if (chatId) await bot.sendMessage(chatId, `
<blockquote>❌ <b><u>Pesan kosong</u></b></blockquote>`, { parse_mode: 'HTML' });
    await db.run('UPDATE settings SET promosi_status = "OFF" WHERE owner_id = ?', userId);
    return;
  }
  
  const blacklistGroups = await db.all('SELECT group_id FROM blacklist_groups WHERE owner_id = ?', userId);
  const blacklistIds = blacklistGroups.map(b => b.group_id.toString());
  
  let validGroups = groups.filter(g => {
    const groupIdStr = g.group_id.toString();
    return parseInt(g.group_id) < 0 && !blacklistIds.includes(groupIdStr);
  });
  
  if (validGroups.length === 0) {
    if (chatId) await bot.sendMessage(chatId, `
<blockquote>⚠️ <b><u>Tidak ada grup valid</u></b></blockquote>`, { parse_mode: 'HTML' });
    await db.run('UPDATE settings SET promosi_status = "OFF" WHERE owner_id = ?', userId);
    return;
  }
  
  // Batasi untuk trial maksimal 20 grup
  if (role === 'TRIAL' && validGroups.length > 20) {
    validGroups = validGroups.slice(0, 20);
    if (chatId) {
      await bot.sendMessage(chatId, `
<blockquote>⚠️ <b><u>BATAS GRUP FREE</u></b>
📊 <b>${validGroups.length} grup</b> digunakan dari 20 slot.
🗑️ Hapus grup yang ga perlu atau upgrade ke premium.</blockquote>`, { parse_mode: 'HTML' });
    }
  }
  
  let watermarkToUse = '';
  
  if (role === 'PREMIUM_NO_WM' || role === 'RESELLER' || role === 'OWNER') {
    const freshSettings = await db.get('SELECT watermark, watermark_status FROM settings WHERE owner_id = ?', userId);
    if (freshSettings && freshSettings.watermark && freshSettings.watermark_status === 'ON') {
      watermarkToUse = freshSettings.watermark;
    }
  } else if (selectedMessage.type !== 'forward') {
    watermarkToUse = WM;
  }
  
  let messageContent = selectedMessage.content || '';
  let entitiesToUse = null;
  
  if (selectedMessage.entities_json) {
    try {
      entitiesToUse = JSON.parse(selectedMessage.entities_json);
    } catch (e) {}
  }
  
  if (selectedMessage.type === 'forward') {
    messageContent = selectedMessage.content || '';
  } else {
    if (watermarkToUse && messageContent) {
      messageContent = messageContent + '\n\n' + watermarkToUse;
    } else if (watermarkToUse && !messageContent) {
      messageContent = watermarkToUse;
    }
  }
  
  let progressMsg;
  if (progressMsgId) {
    try {
      progressMsg = { message_id: progressMsgId };
    } catch {
      progressMsg = await bot.sendMessage(chatId, `
<blockquote>⏳ <b><u>Memulai broadcast</u></b></blockquote>`, { parse_mode: 'HTML' });
    }
  } else if (chatId) {
    progressMsg = await bot.sendMessage(chatId, `
<blockquote>⏳ <b><u>Memulai broadcast</u></b></blockquote>`, { parse_mode: 'HTML' });
  }
  
  if (global.promoTimeouts && global.promoTimeouts[userId]) {
    clearTimeout(global.promoTimeouts[userId]);
    delete global.promoTimeouts[userId];
  }
  
  promosiProgress[userId] = {
    validGroups: validGroups,
    current: 0,
    success: 0,
    failed: 0,
    errors: [],
    running: true,
    startTime: Date.now(),
    settings: settings,
    selectedMessage: {
      id: selectedMessage.id,
      local_id: selectedMessage.local_id,
      type: selectedMessage.type,
      content: selectedMessage.content,
      file_id: selectedMessage.file_id,
      caption: selectedMessage.caption,
      from_chat: selectedMessage.from_chat,
      forward_message_id: selectedMessage.forward_message_id,
      entities_json: entitiesToUse ? JSON.stringify(entitiesToUse) : null
    },
    messageContent: messageContent,
    chatId: chatId,
    lastActivity: Date.now(),
    progressMsgId: progressMsg ? progressMsg.message_id : null
  };
  
  await savePromosiState(userId);
  await savePromosiStateToFile();
  await db.run('UPDATE settings SET promosi_status = "ON" WHERE owner_id = ?', userId);
  
  await executePromoRound(userId, chatId);
}

// BUG FIX (v10.3 - STABILITAS): sebelumnya ada DUA function declaration
// bernama startPromosiWatcher() di file ini (yang satu lagi ada di bawah,
// dekat savePromosiState). Di JavaScript, kalau ada dua `function` dengan
// nama sama di scope yang sama, yang KEDUA otomatis menimpa yang pertama -
// jadi salinan ini sebenarnya sudah lama jadi dead code (tidak pernah
// benar-benar berjalan), sementara isinya nyaris identik dengan salinan
// aktif (cuma beda teks log). Dihapus di sini supaya tidak ada lagi 2 sumber
// kebenaran yang membingungkan kalau salah satunya diedit di masa depan -
// lihat startPromosiWatcher() yang aktif (dekat savePromosiState/
// restorePromosiState) untuk versi yang benar-benar jalan, yang sekarang
// juga sudah ditambah try/catch.

async function savePromosiStateToFile() {
  try {
    const states = {};
    for (const [userId, promo] of Object.entries(promosiProgress)) {
      if (promo && promo.running !== undefined) {
        states[userId] = {
          validGroups: promo.validGroups,
          current: promo.current,
          success: promo.success,
          failed: promo.failed,
          errors: promo.errors ? promo.errors.slice(0, 20) : [],
          startTime: promo.startTime,
          lastRunTime: promo.lastRunTime || Date.now(),
          settings: promo.settings,
          selectedMessage: promo.selectedMessage,
          messageContent: promo.messageContent,
          estimasi: promo.estimasi,
          running: promo.running,
          roundStartTime: promo.roundStartTime || Date.now(),
          chatId: promo.chatId
        };
      }
    }
    fs.writeFileSync(STATE_FILE, JSON.stringify(states, null, 2));
  } catch (error) {
    logger.error('Failed to save promo state to file:', error);
  }
}

async function restorePromosiFromFile() {
  try {
    if (!fs.existsSync(STATE_FILE)) return;
    
    const states = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
    
    for (const [userId, state] of Object.entries(states)) {
      const ubot = userbots.find(ub => ub.owner_id === userId);
      if (!ubot) {
        continue;
      }
      
      const blacklistIds = (await db.all('SELECT group_id FROM blacklist_groups WHERE owner_id = ?', userId))
        .map(b => b.group_id.toString());
      const validGroups = state.validGroups.filter(g => !blacklistIds.includes(g.group_id.toString()));
      
      if (validGroups.length === 0) {
        await db.run('UPDATE settings SET promosi_status = "OFF", promosi_active = 0 WHERE owner_id = ?', userId);
        continue;
      }
      
      const now = Date.now();
      const lastRunDiff = now - (state.lastRunTime || state.startTime);
      const jedaMs = (state.settings?.jeda || 20) * 60 * 1000;
      
      if (state.current < state.validGroups.length && state.running) {
        const timePerGroup = (state.settings?.current_delay || state.settings?.delay || 300);
        const estimatedRemaining = (state.validGroups.length - state.current) * timePerGroup;
        const elapsedSinceLast = now - (state.roundStartTime || state.startTime);
        
        if (elapsedSinceLast < estimatedRemaining + 120000) {
          promosiProgress[userId] = {
            ...state,
            validGroups: validGroups,
            running: true,
            startTime: state.startTime,
            current: state.current,
            success: state.success,
            failed: state.failed,
            errors: state.errors || [],
            progressMsgId: null
          };
          
          setTimeout(() => {
            if (promosiProgress[userId]) {
              executePromoRound(userId, null);
            }
          }, 3000);
        } else if (lastRunDiff < jedaMs) {
          const remainingTime = jedaMs - lastRunDiff;
          promosiProgress[userId] = {
            ...state,
            validGroups: validGroups,
            running: false,
            progressMsgId: null
          };
          
          setTimeout(() => {
            if (promosiProgress[userId]) {
              promosiProgress[userId].running = true;
              promosiProgress[userId].startTime = Date.now();
              promosiProgress[userId].current = 0;
              promosiProgress[userId].success = 0;
              promosiProgress[userId].failed = 0;
              promosiProgress[userId].errors = [];
              executePromoRound(userId, null);
            }
          }, remainingTime);
        } else {
          promosiProgress[userId] = {
            ...state,
            validGroups: validGroups,
            running: true,
            startTime: Date.now(),
            current: 0,
            success: 0,
            failed: 0,
            errors: [],
            progressMsgId: null
          };
          
          executePromoRound(userId, null);
        }
      } else if (lastRunDiff >= jedaMs) {
        promosiProgress[userId] = {
          ...state,
          validGroups: validGroups,
          running: true,
          startTime: Date.now(),
          current: 0,
          success: 0,
          failed: 0,
          errors: [],
          progressMsgId: null
        };
        
        executePromoRound(userId, null);
      }
    }
  } catch (error) {
    logger.error('Failed to restore promo from file:', error);
  }
}

async function restoreAllPromosiStates() {
  const activePromos = await db.all('SELECT * FROM settings WHERE promosi_status = "ON"');
  
  for (const setting of activePromos) {
    const userId = setting.owner_id;
    const ubot = userbots.find(ub => ub.owner_id === userId);
    
    if (!ubot) {
      logger.warn(`Userbot not found for ${userId}, skipping auto-restart`);
      continue;
    }
    
    logger.info(`Auto-restarting broadcast for user ${userId}`);
    
    const groups = await db.all('SELECT * FROM groups WHERE owner_id = ?', userId);
    const messages = await db.all('SELECT * FROM messages WHERE owner_id = ?', userId);
    const blacklistGroups = await db.all('SELECT group_id FROM blacklist_groups WHERE owner_id = ?', userId);
    const blacklistIds = blacklistGroups.map(b => b.group_id.toString());
    const validGroups = groups.filter(g => {
      return parseInt(g.group_id) < 0 && !blacklistIds.includes(g.group_id.toString());
    });
    
    if (validGroups.length === 0) {
      await db.run('UPDATE settings SET promosi_status = "OFF" WHERE owner_id = ?', userId);
      continue;
    }
    
    if (messages.length === 0) {
      await db.run('UPDATE settings SET promosi_status = "OFF" WHERE owner_id = ?', userId);
      continue;
    }
    
    let selectedMessage = messages.find(m => m.id === setting.selected_message_id);
    if (!selectedMessage) selectedMessage = messages[0];
    
    const role = await getUserRole(userId);
    let watermarkToUse = '';
    
    if (role === 'PREMIUM_NO_WM' || role === 'RESELLER' || role === 'OWNER') {
      const freshSettings = await db.get('SELECT watermark, watermark_status FROM settings WHERE owner_id = ?', userId);
      if (freshSettings && freshSettings.watermark && freshSettings.watermark_status === 'ON') {
        watermarkToUse = freshSettings.watermark;
      }
    } else if (selectedMessage.type !== 'forward') {
      watermarkToUse = WM;
    }
    
    let messageContent = selectedMessage.content || '';
    if (selectedMessage.type !== 'forward' && watermarkToUse && messageContent) {
      messageContent = `${messageContent}\n\n${watermarkToUse}`;
    } else if (selectedMessage.type !== 'forward' && watermarkToUse && !messageContent) {
      messageContent = watermarkToUse;
    }
    
    const settingsData = await db.get('SELECT * FROM settings WHERE owner_id = ?', userId) || {
      delay: 500, jeda: 15
    };
    
    if (global.promoTimeouts && global.promoTimeouts[userId]) {
      clearTimeout(global.promoTimeouts[userId]);
      delete global.promoTimeouts[userId];
    }
    
    let currentProgress = 0;
    let currentSuccess = 0;
    let currentFailed = 0;
    let currentErrors = [];
    let lastFinishTime = null;
    
    const savedState = await db.get('SELECT promosi_round_data FROM settings WHERE owner_id = ?', userId);
    if (savedState && savedState.promosi_round_data) {
      try {
        const state = JSON.parse(savedState.promosi_round_data);
        if (state.current && state.current < validGroups.length) {
          currentProgress = state.current;
          currentSuccess = state.success || 0;
          currentFailed = state.failed || 0;
          currentErrors = state.errors || [];
          lastFinishTime = state.finished_at || null;
          logger.info(`Resuming broadcast for ${userId} from group ${currentProgress}/${validGroups.length}`);
        }
      } catch (e) {}
    }
    
    const lastRunLog = await db.get('SELECT finished_at FROM promo_logs WHERE owner_id = ? ORDER BY finished_at DESC LIMIT 1', userId);
    if (lastRunLog && lastRunLog.finished_at) {
      lastFinishTime = lastRunLog.finished_at * 1000;
    }
    
    let jedaMs = (settingsData.jeda || 15) * 60 * 1000;
    let waktuTunggu = 0;
    
    if (lastFinishTime) {
      const waktuLalu = Date.now() - lastFinishTime;
      if (waktuLalu < jedaMs) {
        waktuTunggu = jedaMs - waktuLalu;
        logger.info(`Broadcast ${userId} masih dalam masa jeda, lanjut dalam ${Math.floor(waktuTunggu / 1000)} detik`);
      }
    }
    
    if (currentProgress >= validGroups.length || currentProgress === 0) {
      if (waktuTunggu > 0) {
        setTimeout(async () => {
          await startNewRound(userId, validGroups, selectedMessage, messageContent, settingsData);
        }, waktuTunggu);
      } else {
        await startNewRound(userId, validGroups, selectedMessage, messageContent, settingsData);
      }
    } else {
      setTimeout(async () => {
        await continueExistingRound(userId, validGroups, selectedMessage, messageContent, settingsData, currentProgress, currentSuccess, currentFailed, currentErrors);
      }, 1000);
    }
  }
}

function startPromosiWatcher() {
  setInterval(async () => {
    // BUG FIX (v10.3 - STABILITAS): sama seperti crashProofWatcher, callback
    // ini sebelumnya tidak dibungkus try/catch - satu entry promosiProgress
    // yang error bisa menghentikan sisa loop di siklus itu (termasuk
    // savePromosiStateToFile() di akhir). Dibungkus supaya tetap jalan penuh
    // tiap siklus walau ada 1 entry bermasalah.
    try {
    for (const [userId, promo] of Object.entries(promosiProgress)) {
      if (promo && promo.running && promo.current < promo.validGroups.length) {
        const timeSinceLastActivity = Date.now() - (promo.lastActivity || promo.startTime);
        
        if (timeSinceLastActivity > 300000) {
          logger.warn(`Promosi untuk user ${userId} seems stuck, restarting...`);
          promo.running = false;
          
          setTimeout(() => {
            if (promosiProgress[userId]) {
              promosiProgress[userId].running = true;
              promosiProgress[userId].lastActivity = Date.now();
              executePromoRound(userId, promo.chatId);
            }
          }, 5000);
        }
      }
    }
    
    savePromosiStateToFile();
    } catch (error) {
      logger.error('startPromosiWatcher siklus gagal:', error && error.stack ? error.stack : error);
    }
  }, 30000);
}

async function savePromosiState(userId) {
  const promo = promosiProgress[userId];
  if (!promo) return;
  
  const state = {
    validGroups: promo.validGroups,
    current: promo.current,
    success: promo.success,
    failed: promo.failed,
    errors: promo.errors.slice(0, 20),
    startTime: promo.startTime,
    settings: promo.settings,
    selectedMessage: promo.selectedMessage,
    messageContent: promo.messageContent,
    estimasi: promo.estimasi,
    roundStartTime: Date.now()
  };
  
  await db.run(
    'UPDATE settings SET promosi_active = 1, promosi_round_data = ? WHERE owner_id = ?',
    JSON.stringify(state), userId
  );
  
  promo.lastActivity = Date.now();
}

async function restorePromosiState() {
  const activePromos = await db.all('SELECT * FROM settings WHERE promosi_active = 1');
  
  for (const setting of activePromos) {
    const userId = setting.owner_id;
    const ubot = userbots.find(ub => ub.owner_id === userId);
    
    if (!ubot || !setting.promosi_round_data) continue;
    
    try {
      const state = JSON.parse(setting.promosi_round_data);
      const now = Date.now();
      const elapsed = Math.floor((now - state.startTime) / 1000);
      const jedaMs = (state.settings.jeda || 20) * 60 * 1000;
      const roundElapsed = Math.floor((now - state.roundStartTime) / 1000);

      if (state.current < state.validGroups.length && roundElapsed < state.estimasi) {
        const remainingGroups = state.validGroups.length - state.current;
        const remainingTime = remainingGroups * (state.settings.current_delay || state.settings.delay) / 1000;
        
        logger.info(`Melanjutkan broadcast buat user ${userId}, sisa ${remainingGroups} grup lagi`);
        
        const blacklistIds = (await db.all('SELECT group_id FROM blacklist_groups WHERE owner_id = ?', userId)).map(b => b.group_id.toString());
        const validGroups = state.validGroups.filter(g => !blacklistIds.includes(g.group_id.toString()));
        
        promosiProgress[userId] = {
          ...state,
          validGroups: validGroups,
          running: true,
          startTime: now - (state.current * (state.settings.current_delay || state.settings.delay)),
          progressMsgId: null
        };
        
        setTimeout(() => {
          if (promosiProgress[userId]) {
            executePromoRound(userId, null);
          }
        }, 1000);
      }
      
      else if (elapsed < jedaMs / 1000) {
        const remainingTime = jedaMs - (elapsed * 1000);
        
        logger.info(`Broadcast lagi istirahat buat user ${userId}, lanjut dalam ${Math.floor(remainingTime/1000)} detik`);
        
        promosiProgress[userId] = {
          ...state,
          running: false,
          progressMsgId: null
        };
        
        setTimeout(() => {
          if (promosiProgress[userId] && promosiProgress[userId].settings.promosi_status === 'ON') {
            promosiProgress[userId].running = true;
            promosiProgress[userId].startTime = Date.now();
            promosiProgress[userId].current = 0;
            promosiProgress[userId].success = 0;
            promosiProgress[userId].failed = 0;
            promosiProgress[userId].errors = [];
            executePromoRound(userId, null);
          }
        }, remainingTime);
      }

      else {
        logger.info(`Mulai round baru buat user ${userId}`);
        
        const blacklistIds = (await db.all('SELECT group_id FROM blacklist_groups WHERE owner_id = ?', userId)).map(b => b.group_id.toString());
        const validGroups = state.validGroups.filter(g => !blacklistIds.includes(g.group_id.toString()));
        
        if (validGroups.length === 0) {
          await db.run('UPDATE settings SET promosi_status = "OFF", promosi_active = 0 WHERE owner_id = ?', userId);
          continue;
        }
        
        promosiProgress[userId] = {
          ...state,
          validGroups: validGroups,
          running: true,
          startTime: Date.now(),
          current: 0,
          success: 0,
          failed: 0,
          errors: [],
          progressMsgId: null
        };
        
        executePromoRound(userId, null);
      }
      
    } catch (e) {
      logger.error(`Gagal restore promosi buat ${userId}:`, e);
      await db.run('UPDATE settings SET promosi_active = 0, promosi_round_data = NULL WHERE owner_id = ?', userId);
    }
  }
}

async function saveBroadcastStateToFile() {
  try {
    const broadcastStates = {};
    for (const [userId, promo] of Object.entries(promosiProgress)) {
      if (promo && promo.running !== undefined) {
        broadcastStates[userId] = {
          validGroups: promo.validGroups ? promo.validGroups.map(g => ({ group_id: g.group_id, group_title: g.group_title })) : [],
          current: promo.current || 0,
          success: promo.success || 0,
          failed: promo.failed || 0,
          errors: (promo.errors || []).slice(0, 50),
          startTime: promo.startTime || Date.now(),
          settings: {
            delay: promo.settings?.delay || 500,
            jeda: promo.settings?.jeda || 20,
            current_delay: promo.settings?.current_delay || 500
          },
          selectedMessage: promo.selectedMessage ? {
            id: promo.selectedMessage.id,
            local_id: promo.selectedMessage.local_id,
            type: promo.selectedMessage.type,
            content: promo.selectedMessage.content,
            file_id: promo.selectedMessage.file_id,
            from_chat: promo.selectedMessage.from_chat,
            forward_message_id: promo.selectedMessage.forward_message_id
          } : null,
          messageContent: promo.messageContent || '',
          running: promo.running || false,
          isPaused: promo.isPaused || false,
          lastActivity: promo.lastActivity || Date.now(),
          timestamp: Date.now()
        };
      }
    }
    fs.writeFileSync(AUTO_RESTORE_FILE, JSON.stringify(broadcastStates, null, 2));
  } catch (error) {
    logger.error('Failed to save broadcast state to file:', error);
  }
}

async function restoreBroadcastFromFile() {
  try {
    if (!fs.existsSync(AUTO_RESTORE_FILE)) {
      logger.info('No auto-restore file found, checking database for active broadcasts...');
      await restorePromosiFromFile();
      return;
    }
    
    const states = JSON.parse(fs.readFileSync(AUTO_RESTORE_FILE, 'utf8'));
    let restoredCount = 0;
    
    for (const [userId, state] of Object.entries(states)) {
      if (!state.running && !state.isPaused) continue;
      
      const ubot = userbots.find(ub => ub.owner_id === userId);
      if (!ubot) {
        logger.warn(`Userbot ${userId} not found, skipping auto-restore`);
        await db.run('UPDATE settings SET promosi_status = "OFF" WHERE owner_id = ?', userId);
        continue;
      }
      
      try {
        const me = await ubot.client.getMe();
        if (!me) {
          logger.warn(`Userbot ${userId} offline, skipping auto-restore`);
          continue;
        }
      } catch (err) {
        logger.warn(`Userbot ${userId} connection failed: ${err.message}`);
        continue;
      }
      
      const groups = await db.all('SELECT * FROM groups WHERE owner_id = ?', userId);
      const messages = await db.all('SELECT * FROM messages WHERE owner_id = ?', userId);
      const blacklistGroups = await db.all('SELECT group_id FROM blacklist_groups WHERE owner_id = ?', userId);
      const blacklistIds = blacklistGroups.map(b => b.group_id.toString());
      
      let validGroups = groups.filter(g => {
        return parseInt(g.group_id) < 0 && !blacklistIds.includes(g.group_id.toString());
      });
      
      if (validGroups.length === 0) {
        logger.warn(`User ${userId} has no valid groups, stopping auto-restore`);
        await db.run('UPDATE settings SET promosi_status = "OFF" WHERE owner_id = ?', userId);
        continue;
      }
      
      let selectedMessage = null;
      if (state.selectedMessage && state.selectedMessage.id) {
        selectedMessage = messages.find(m => m.id === state.selectedMessage.id);
      }
      if (!selectedMessage && messages.length > 0) {
        selectedMessage = messages[0];
      }
      if (!selectedMessage) {
        logger.warn(`User ${userId} has no messages, stopping auto-restore`);
        await db.run('UPDATE settings SET promosi_status = "OFF" WHERE owner_id = ?', userId);
        continue;
      }
      
      const role = await getUserRole(userId);
      let watermarkToUse = '';
      
      if (role === 'PREMIUM_NO_WM' || role === 'RESELLER' || role === 'OWNER') {
        const freshSettings = await db.get('SELECT watermark, watermark_status FROM settings WHERE owner_id = ?', userId);
        if (freshSettings && freshSettings.watermark && freshSettings.watermark_status === 'ON') {
          watermarkToUse = freshSettings.watermark;
        }
      } else if (selectedMessage.type !== 'forward') {
        watermarkToUse = WM;
      }
      
      let messageContent = selectedMessage.content || '';
      if (selectedMessage.type !== 'forward' && watermarkToUse && messageContent) {
        messageContent = `${messageContent}\n\n${watermarkToUse}`;
      } else if (selectedMessage.type !== 'forward' && watermarkToUse && !messageContent) {
        messageContent = watermarkToUse;
      }
      
      const now = Date.now();
      const timeSinceLastActivity = now - (state.lastActivity || state.startTime);
      const jedaMs = (state.settings?.jeda || 20) * 60 * 1000;
      
      let shouldResume = false;
      let resumeFromIndex = state.current || 0;
      
      if (state.running && !state.isPaused) {
        const estimatedTotalTime = validGroups.length * (state.settings?.delay || 500);
        const elapsedTime = timeSinceLastActivity;
        
        if (elapsedTime < estimatedTotalTime + 120000) {
          shouldResume = true;
          logger.info(`Resuming broadcast for user ${userId} from group ${resumeFromIndex}/${validGroups.length}`);
        } else if (timeSinceLastActivity < jedaMs) {
          shouldResume = false;
          const remainingTime = jedaMs - timeSinceLastActivity;
          logger.info(`Broadcast for user ${userId} is in cooldown, will auto-start in ${Math.floor(remainingTime/1000)}s`);
          
          setTimeout(async () => {
            await startNewRoundAfterCooldown(userId, validGroups, selectedMessage, messageContent, state.settings);
          }, remainingTime);
          continue;
        } else {
          resumeFromIndex = 0;
          shouldResume = true;
          logger.info(`Starting new round for user ${userId} (previous round timed out)`);
        }
      } else if (state.isPaused) {
        logger.info(`Broadcast for user ${userId} was paused, not auto-resuming`);
        continue;
      }
      
      if (shouldResume) {
        if (resumeFromIndex >= validGroups.length) {
          resumeFromIndex = 0;
          logger.info(`Broadcast for user ${userId} completed previous round, starting new round`);
        }
        
        if (global.promoTimeouts && global.promoTimeouts[userId]) {
          clearTimeout(global.promoTimeouts[userId]);
          delete global.promoTimeouts[userId];
        }
        
        const settingsData = await db.get('SELECT * FROM settings WHERE owner_id = ?', userId) || {
          delay: state.settings?.delay || 500,
          jeda: state.settings?.jeda || 20
        };
        
        promosiProgress[userId] = {
          validGroups: validGroups,
          current: resumeFromIndex,
          success: state.success || 0,
          failed: state.failed || 0,
          errors: state.errors || [],
          running: true,
          startTime: Date.now() - (resumeFromIndex * (settingsData.delay || 500)),
          settings: settingsData,
          selectedMessage: selectedMessage,
          messageContent: messageContent,
          chatId: null,
          lastActivity: Date.now(),
          lastHeartbeat: Date.now(),
          autoRestored: true
        };
        
        await db.run('UPDATE settings SET promosi_status = "ON" WHERE owner_id = ?', userId);
        await savePromosiState(userId);
        
        setTimeout(() => {
          if (promosiProgress[userId] && promosiProgress[userId].running) {
            executePromoRound(userId, null);
            logger.info(`Auto-restarted broadcast for user ${userId} from group ${resumeFromIndex}/${validGroups.length}`);
          }
        }, 2000);
        
        restoredCount++;
      }
    }
    
    if (restoredCount > 0) {
      logger.info(`Auto-restored ${restoredCount} broadcasts from file backup`);
    }
    
    fs.unlinkSync(AUTO_RESTORE_FILE);
    
  } catch (error) {
    logger.error('Failed to restore broadcast from file:', error);
  }
}

async function startNewRoundAfterCooldown(userId, validGroups, selectedMessage, messageContent, settings) {
  if (promosiProgress[userId] && promosiProgress[userId].running) return;
  
  const checkStatus = await db.get('SELECT promosi_status FROM settings WHERE owner_id = ?', userId);
  if (checkStatus && checkStatus.promosi_status !== 'ON') {
    return;
  }
  
  const blacklistGroups = await db.get('SELECT group_id FROM blacklist_groups WHERE owner_id = ?', userId);
  const blacklistIds = blacklistGroups ? blacklistGroups.map(b => b.group_id.toString()) : [];
  const freshGroups = validGroups.filter(g => !blacklistIds.includes(g.group_id.toString()));
  
  if (freshGroups.length === 0) {
    await db.run('UPDATE settings SET promosi_status = "OFF" WHERE owner_id = ?', userId);
    return;
  }
  
  const settingsData = await db.get('SELECT * FROM settings WHERE owner_id = ?', userId) || {
    delay: settings?.delay || 500,
    jeda: settings?.jeda || 20
  };
  
  if (global.promoTimeouts && global.promoTimeouts[userId]) {
    clearTimeout(global.promoTimeouts[userId]);
    delete global.promoTimeouts[userId];
  }
  
  promosiProgress[userId] = {
    validGroups: freshGroups,
    current: 0,
    success: 0,
    failed: 0,
    errors: [],
    running: true,
    startTime: Date.now(),
    settings: settingsData,
    selectedMessage: selectedMessage,
    messageContent: messageContent,
    chatId: null,
    lastActivity: Date.now(),
    lastHeartbeat: Date.now()
  };
  
  await savePromosiState(userId);
  await saveBroadcastStateToFile();
  await db.run('UPDATE settings SET promosi_status = "ON" WHERE owner_id = ?', userId);
  
  setTimeout(() => {
    if (promosiProgress[userId] && promosiProgress[userId].running) {
      executePromoRound(userId, null);
      logger.info(`Auto-started new broadcast round for user ${userId} after cooldown`);
    }
  }, 1000);
}

async function checkExpired() {
  try {
  const now = Math.floor(Date.now() / 1000);
  const lastCheck = global.lastExpiredCheck || 0;
  
  if (Date.now() - lastCheck < 60000) {
    return;
  }
  
  global.lastExpiredCheck = Date.now();
  
  if (!global.expiredNotified) global.expiredNotified = {};
  
  // Trial sekarang lifetime, tidak perlu expired check
// Tapi tetap cek user yang trial_used = 1 tapi role FREE (kondisi aneh)
const orphanFreeUsers = await db.all('SELECT * FROM users WHERE role = "FREE" AND trial_used = 1');
// Biarkan saja, tidak perlu dihapus karena mereka sudah selesai

// Hapus expiredTrials karena tidak ada expired untuk trial lifetime
// const expiredTrials = ...
  
  const expiredPremiumWMs = await db.all(`
    SELECT user_id FROM premium_wm WHERE expired <= ?
  `, now);
  
  for (const user of expiredPremiumWMs) {
    const alreadyNotified = global.expiredNotified[`wm_${user.user_id}`];
    if (alreadyNotified) {
      continue;
    }
    
    global.expiredNotified[`wm_${user.user_id}`] = true;
    
    await db.run('UPDATE users SET role = "FREE" WHERE user_id = ?', user.user_id);
    logger.info(`User ${user.user_id} downgraded from PREMIUM_WM to FREE due to expiration`);
    
    try {
      await bot.sendMessage(user.user_id, `
<blockquote><b><u>🧩 Plan Basic HABIS</u></b></blockquote>
<blockquote>Masa aktif Plan Basic kamu sudah habis.
Silakan perpanjang untuk menggunakan fitur kembali.</blockquote>
<blockquote>Hubungi ${OWNER_USERNAME} untuk perpanjang.</blockquote>`, { parse_mode: 'HTML' });
    } catch (e) {}
  }
  
  const expiredPremiumNoWMs = await db.all(`
    SELECT user_id FROM premium_no_wm WHERE expired <= ?
  `, now);
  
  for (const user of expiredPremiumNoWMs) {
    const alreadyNotified = global.expiredNotified[`nowm_${user.user_id}`];
    if (alreadyNotified) {
      continue;
    }
    
    global.expiredNotified[`nowm_${user.user_id}`] = true;
    
    await db.run('UPDATE users SET role = "FREE" WHERE user_id = ?', user.user_id);
    logger.info(`User ${user.user_id} downgraded from PREMIUM_NO_WM to FREE due to expiration`);
    
    try {
      await bot.sendMessage(user.user_id, `
<blockquote><b><u>💎 Plan Pro HABIS</u></b></blockquote>
<blockquote>Masa aktif Plan Pro kamu sudah habis.
Silakan perpanjang untuk menggunakan fitur kembali.</blockquote>
<blockquote>Hubungi ${OWNER_USERNAME} untuk perpanjang.</blockquote>`, { parse_mode: 'HTML' });
    } catch (e) {}
  }
  
  const inactiveUserbots = await db.all(`
    SELECT owner_id FROM userbots WHERE expired <= ?
  `, now);
  
  for (const userbot of inactiveUserbots) {
    const alreadyNotified = global.expiredNotified[`ubot_${userbot.owner_id}`];
    if (alreadyNotified) {
      continue;
    }
    
    global.expiredNotified[`ubot_${userbot.owner_id}`] = true;
    
    await cleanupUserData(userbot.owner_id, 'expired');
    logger.info(`Cleaned up expired userbot for user ${userbot.owner_id}`);
  }
  } catch (error) {
    logger.error('checkExpired error:', error && error.stack ? error.stack : error);
  }
}

async function handleUserbotLogout(userId, ubotId) {
  const logoutKey = `logout_${userId}`;
  
  if (!global.logoutProcessed) global.logoutProcessed = {};
  
  if (global.logoutProcessed[logoutKey]) {
    logger.info(`Logout for user ${userId} already processed, skipping`);
    return;
  }
  
  global.logoutProcessed[logoutKey] = true;
  
  setTimeout(() => {
    delete global.logoutProcessed[logoutKey];
  }, 3600000);
  
  try {
    const userbot = await db.get('SELECT * FROM userbots WHERE owner_id = ?', userId);
    
    await cleanupUserData(userId, 'logout');
    
    await sendLogNotification(userId, { ubot_id: ubotId || userbot?.ubot_id, reason: 'Session revoked/logout' }, 'logout');
    
    try {
      await bot.sendMessage(userId, `
<blockquote>⚠️ <b><u>USERBOT KELUAR SENDIRI</u></b></blockquote>
<blockquote>Userbot Anda tiba-tiba logout dari Telegram.</blockquote>
<blockquote><b>📌 Kemungkinan penyebab</b>
 • Anda logout manual dari userbot
 • Session kadaluarsa atau dicabut
 • Login di perangkat lain
 • Akun Telegram kena banned sementara</blockquote>
<blockquote><b>✅ Yang sudah dilakukan sistem</b>
 • Semua data userbot dihapus dari database
 • Session userbot dibersihkan
 • Grup dan pesan target dihapus</blockquote>
<blockquote><b>🔄 Solusi</b>
 • Bikin userbot baru dengan akun yang sama
 • Atau gunakan token cadangan jika punya
 • Hubungi owner jika masalah berlanjut</blockquote>

<i>Klik ➕ Deploy Userbot untuk memulai lagi</i>`, { parse_mode: 'HTML' });
    } catch (e) {}
    
    logger.info(`Userbot logout udah ditangani buat user ${userId}`);
  } catch (error) {
    logger.error(`Error pas nanganin logout buat ${userId}:`, error);
  }
}

async function checkUserbotStatus() {
  for (const ubot of userbots) {
    try {
      // BUG FIX (PENYEBAB "RESET/RESTART SENDIRI"): sebelumnya kode ini
      // `.catch(() => null)` di getMe(), jadi SATU kali gagal doang -
      // termasuk hiccup jaringan sesaat, FLOOD_WAIT, atau lagi proses
      // reconnect otomatis dari lazyUbot (userbot idle 3 menit lalu
      // dipakai lagi) - langsung dianggap "logout permanen". Begitu
      // dianggap logout, `handleUserbotLogout` MENGHAPUS SEMUA data
      // userbot itu (grup target, list pesan, blacklist, token, settings,
      // role di-downgrade ke FREE, trial direset) setiap 15 detik dicek
      // ulang untuk SEMUA userbot. Kalau ada gangguan jaringan sesaat, efeknya
      // kelihatan kayak "semuanya kereset/restart sendiri" padahal
      // sebenarnya cuma 1x gagal cek status yang sifatnya sementara.
      //
      // lazyUbot.js SUDAH punya circuit breaker yang jauh lebih hati-hati
      // (retry + beda-in error transient vs fatal, baru ditandai 'dead'
      // setelah gagal beruntun / auth error beneran). Sekarang
      // checkUserbotStatus PERCAYA ke keputusan itu, bukan bikin
      // keputusan sendiri dari 1x percobaan yang gagal.
      await ubot.client.getMe();
    } catch (error) {
      const isFatal = lazyUbot.isFatalAuthError(error) || lazyUbot.isDead(ubot.owner_id);
      if (isFatal) {
        const reason = lazyUbot.getDeadReason(ubot.owner_id) || error.message;
        logger.warn(`Userbot ${ubot.id} logout/revoked (fatal): ${reason}`);
        await handleUserbotLogout(ubot.owner_id, ubot.id);
      } else {
        // Transient (jaringan/flood/lagi reconnect) -> JANGAN dianggap logout.
        // Cukup dicatat, biarkan lazyUbot yang urus retry & circuit breaker-nya.
        logger.warn(`Userbot ${ubot.id} gagal dicek sesaat (transient, tidak dianggap logout): ${error.message}`);
      }
    }
  }
}

async function cleanupUserData(userId, reason = 'unknown') {
  const cleanupKey = `cleanup_${userId}`;
  
  if (global.cleaningUsers && global.cleaningUsers[cleanupKey]) {
    return false;
  }
  
  if (!global.cleaningUsers) global.cleaningUsers = {};
  global.cleaningUsers[cleanupKey] = true;
  
  try {
    const ubotData = await db.get('SELECT * FROM userbots WHERE owner_id = ?', userId);
    
    if (!ubotData) {
      delete global.cleaningUsers[cleanupKey];
      return true;
    }
    
    if (promosiProgress[userId]) {
      promosiProgress[userId].running = false;
      delete promosiProgress[userId];
    }
    
    await db.run('DELETE FROM groups WHERE owner_id = ?', userId);
    await db.run('DELETE FROM messages WHERE owner_id = ?', userId);
    await db.run('DELETE FROM blacklist_groups WHERE owner_id = ?', userId);
    await db.run('DELETE FROM tokens WHERE owner_id = ?', userId);
    await db.run('DELETE FROM reseller_added WHERE reseller_id = ? OR user_id = ?', userId, userId);
    await db.run('DELETE FROM admin_controls WHERE owner_id = ?', userId);
    await db.run('DELETE FROM admin_controls WHERE admin_id = ?', userId);
    await db.run('DELETE FROM settings WHERE owner_id = ?', userId);
    // trial_used = 0 biar user bisa deploy free lagi kapan aja setelah userbot-nya dibersihin
    await db.run('UPDATE users SET has_userbot = 0, role = "FREE", trial_used = 0, expired = NULL WHERE user_id = ?', userId);
    await db.run('DELETE FROM userbots WHERE owner_id = ?', userId);
    
    // Bersihin koneksi lazy & timer-nya biar gak nyangkut di memori
    lazyUbot.remove(userId);
    const idxInMemory = userbots.findIndex(ub => ub.owner_id === userId);
    if (idxInMemory !== -1) userbots.splice(idxInMemory, 1);
    
    delete global.cleaningUsers[cleanupKey];
    
    await optimizeDatabase();
    
    return true;
    
  } catch (error) {
    console.error(`Cleanup error for ${userId}:`, error);
    delete global.cleaningUsers[cleanupKey];
    return false;
  }
}

async function optimizeDatabase() {
  try {
    await db.exec('VACUUM');
    logger.info('Database VACUUM completed - size optimized');
  } catch (error) {
    logger.error('VACUUM failed:', error);
  }
}

async function cleanExpiredPremium() {
  const now = Math.floor(Date.now() / 1000);
  
  const expiredWM = await db.all('SELECT user_id FROM premium_wm WHERE expired <= ?', now);
  for (const user of expiredWM) {
    await db.run('DELETE FROM premium_wm WHERE user_id = ?', user.user_id);
    await db.run('UPDATE users SET role = "FREE" WHERE user_id = ?', user.user_id);
    logger.info(`Removed expired premium_wm for ${user.user_id}`);
  }
  
  const expiredNoWM = await db.all('SELECT user_id FROM premium_no_wm WHERE expired <= ?', now);
  for (const user of expiredNoWM) {
    await db.run('DELETE FROM premium_no_wm WHERE user_id = ?', user.user_id);
    await db.run('UPDATE users SET role = "FREE" WHERE user_id = ?', user.user_id);
    logger.info(`Removed expired premium_no_wm for ${user.user_id}`);
  }
  
  // HAPUS RESELLER YANG EXPIRED - PASTIKAN ADA EXPIRED NYA
  const expiredResellerList = await db.all('SELECT user_id FROM reseller_list WHERE expired <= ? AND expired IS NOT NULL', now);
  for (const user of expiredResellerList) {
    await db.run('DELETE FROM reseller_list WHERE user_id = ?', user.user_id);
    await db.run('UPDATE users SET role = "FREE" WHERE user_id = ?', user.user_id);
    logger.info(`Removed expired reseller for ${user.user_id}`);
  }
  
  // Hapus juga reseller yang expired di list_access.json
  const accessList = loadListAccess();
  let changed = false;
  for (const item of accessList) {
    if (item.role === 'reseller' && item.expired_at <= now && item.duration !== 'lifetime') {
      changed = true;
    }
  }
  if (changed) {
    const filtered = accessList.filter(item => !(item.role === 'reseller' && item.expired_at <= now && item.duration !== 'lifetime'));
    saveListAccess(filtered);
  }
  
  const expiredResellerAdded = await db.all('SELECT rowid FROM reseller_added WHERE expired <= ?', now);
  for (const row of expiredResellerAdded) {
    await db.run('DELETE FROM reseller_added WHERE rowid = ?', row.rowid);
  }
  
  const expiredTokens = await db.all('SELECT token FROM tokens WHERE expired_at <= ? AND used = 0', now);
  for (const token of expiredTokens) {
    await db.run('DELETE FROM tokens WHERE token = ?', token.token);
    logger.info(`Removed expired token ${token.token}`);
  }
  
  const oldPromoLogs = await db.all('SELECT id FROM promo_logs WHERE finished_at <= ?', now - (60 * 24 * 3600));
  for (const log of oldPromoLogs) {
    await db.run('DELETE FROM promo_logs WHERE id = ?', log.id);
  }
  
  const oldActivityLogs = await db.all('SELECT id FROM activity_logs WHERE timestamp <= ?', now - (30 * 24 * 3600));
  for (const log of oldActivityLogs) {
    await db.run('DELETE FROM activity_logs WHERE id = ?', log.id);
  }
  
  await optimizeDatabase();
}

async function cleanOrphanedData() {
  const orphanedSettings = await db.all(`
    SELECT s.owner_id FROM settings s 
    WHERE NOT EXISTS (SELECT 1 FROM users u WHERE u.user_id = s.owner_id)
  `);
  for (const setting of orphanedSettings) {
    await db.run('DELETE FROM settings WHERE owner_id = ?', setting.owner_id);
    logger.info(`Removed orphaned settings for ${setting.owner_id}`);
  }
  
  const orphanedGroups = await db.all(`
    SELECT g.rowid FROM groups g 
    WHERE NOT EXISTS (SELECT 1 FROM users u WHERE u.user_id = g.owner_id)
  `);
  for (const group of orphanedGroups) {
    await db.run('DELETE FROM groups WHERE rowid = ?', group.rowid);
  }
  
  const orphanedMessages = await db.all(`
    SELECT m.rowid FROM messages m 
    WHERE NOT EXISTS (SELECT 1 FROM users u WHERE u.user_id = m.owner_id)
  `);
  for (const message of orphanedMessages) {
    await db.run('DELETE FROM messages WHERE rowid = ?', message.rowid);
  }
  
  const orphanedBlacklist = await db.all(`
    SELECT b.rowid FROM blacklist_groups b 
    WHERE NOT EXISTS (SELECT 1 FROM users u WHERE u.user_id = b.owner_id)
  `);
  for (const blacklist of orphanedBlacklist) {
    await db.run('DELETE FROM blacklist_groups WHERE rowid = ?', blacklist.rowid);
  }
  
  const orphanedTokens = await db.all(`
    SELECT t.rowid FROM tokens t 
    WHERE NOT EXISTS (SELECT 1 FROM users u WHERE u.user_id = t.owner_id) AND t.used_by IS NULL
  `);
  for (const token of orphanedTokens) {
    await db.run('DELETE FROM tokens WHERE rowid = ?', token.rowid);
  }
  
  await optimizeDatabase();
}

async function getDatabaseSize() {
  try {
    const stats = fs.statSync(DB_PATH);
    const sizeMB = (stats.size / (1024 * 1024)).toFixed(2);
    logger.info(`Database size: ${sizeMB} MB`);
    return sizeMB;
  } catch (error) {
    logger.error('Failed to get database size:', error);
    return 'unknown';
  }
}

async function scheduledCleanup() {
  try {
  const beforeSize = await getDatabaseSize();
  logger.info(`Starting scheduled cleanup, DB size: ${beforeSize} MB`);
  
  await cleanExpiredPremium();
  await cleanOrphanedData();
  await optimizeDatabase();
  
  const afterSize = await getDatabaseSize();
  logger.info(`Scheduled cleanup completed, DB size: ${afterSize} MB`);
  } catch (error) {
    logger.error('scheduledCleanup error:', error && error.stack ? error.stack : error);
  }
}

// Bersihin state navigasi (halaman menu, dsb) yang tersimpan di memori.
// Ini murni state UI sementara (posisi halaman/list) jadi aman di-reset
// berkala — user yang lagi buka menu paling cuma balik ke halaman 1,
// nggak ada data penting yang hilang. Tanpa ini, tiap user baru yang
// pernah buka menu-menu ini bakal numpuk selamanya di RAM.
const NAVIGATION_STATE_KEYS = [
  'hargaPage',
  'adminDelPesanPage', 'adminDelPesanMsgId',
  'adminListPesanPage', 'adminListPesanMsgId',
  'adminHapusGroupPage', 'adminHapusGroupMsgId',
  'adminGroupListPage', 'adminListGroupMsgId',
  'userListPesanPage', 'userListPesanMsgId'
];

function cleanupNavigationState() {
  let totalCleared = 0;
  for (const key of NAVIGATION_STATE_KEYS) {
    if (global[key]) {
      totalCleared += Object.keys(global[key]).length;
      global[key] = {};
    }
  }
  if (totalCleared > 0) {
    logger.info(`Navigation state dibersihkan: ${totalCleared} entri dihapus dari memori`);
  }
}

// Percobaan OTP/2FA yang gagal disimpan biar bisa dibatasi (max 3x),
// tapi kalau user diem aja setelah gagal, entrinya nggak pernah kehapus.
// Prune entri yang udah lebih dari 1 jam nggak ada aktivitas.
function cleanupStaleAttemptCounters() {
  const now = Date.now();
  const maxAgeMs = 60 * 60 * 1000; // 1 jam
  let cleared = 0;
  
  if (global.otpAttempts) {
    for (const uid of Object.keys(global.otpAttempts)) {
      const lastAttempt = global.otpAttempts[uid]?.lastAttempt || 0;
      if (now - lastAttempt > maxAgeMs) {
        delete global.otpAttempts[uid];
        cleared++;
      }
    }
  }
  
  if (cleared > 0) {
    logger.info(`Attempt counter kadaluarsa dibersihkan: ${cleared} entri`);
  }
}

function cleanupInMemoryState() {
  cleanupNavigationState();
  cleanupStaleAttemptCounters();
  
  // Buang entri cache cek-join yang udah kadaluarsa biar Map-nya gak numpuk terus
  if (global.joinCheckCache) {
    const now = Date.now();
    for (const [uid, entry] of global.joinCheckCache.entries()) {
      if (now - entry.ts > JOIN_CHECK_CACHE_TTL) {
        global.joinCheckCache.delete(uid);
      }
    }
  }
}

async function createBackupZip() {
  return new Promise(async (resolve, reject) => {
    try {
      // PENTING: database jalan di mode WAL (PRAGMA journal_mode = WAL).
      // Di mode ini, transaksi yang baru saja di-commit (misalnya insert
      // premium_wm/premium_no_wm dari pembelian) sempat "mengambang" dulu
      // di file database.sqlite-wal sebelum dipindah ke database.sqlite.
      // Kalau kita backup database.sqlite mentah-mentah tanpa checkpoint
      // dulu, data terbaru itu bisa ketinggalan dari hasil backup meskipun
      // sudah tersimpan valid di database live. TRUNCATE checkpoint
      // memaksa semua data di WAL pindah ke file utama sebelum kita salin.
      try {
        if (db) await db.exec('PRAGMA wal_checkpoint(TRUNCATE);');
      } catch (checkpointErr) {
        logger.warn('WAL checkpoint sebelum backup gagal (lanjut backup tetap jalan):', checkpointErr.message);
      }

      const timestamp = moment().format('YYYY-MM-DD_HH-mm-ss');
      const backupDir = path.join(__dirname, '../database/backups');

      if (!fs.existsSync(backupDir)) {
        fs.mkdirSync(backupDir, { recursive: true });
      }
      
      const zipFileName = `backup_${timestamp}.zip`;
      const zipFilePath = path.join(backupDir, zipFileName);
      
      const output = fs.createWriteStream(zipFilePath);
      const archive = archiver('zip', {
        zlib: { level: 9 }
      });
      
      output.on('close', () => {
        if (fs.existsSync(zipFilePath)) {
          const stats = fs.statSync(zipFilePath);
          const sizeMB = (stats.size / (1024 * 1024)).toFixed(2);
          logger.info(`Backup ZIP created: ${zipFileName} (${sizeMB} MB)`);
          resolve({ path: zipFilePath, name: zipFileName, size: sizeMB });
        } else {
          reject(new Error('ZIP file not created'));
        }
      });
      
      output.on('error', (err) => {
        reject(err);
      });
      
      archive.on('error', (err) => {
        reject(err);
      });
      
      archive.pipe(output);
      
      if (fs.existsSync(DB_PATH)) {
        archive.file(DB_PATH, { name: 'database.sqlite' });
      }

      // Jaga-jaga: kalau checkpoint di atas tidak sempat mengosongkan WAL
      // sepenuhnya (misalnya ada koneksi lain yang masih baca), sertakan
      // juga file sidecar -wal dan -shm biar tidak ada data yang hilang
      // saat file ini nanti dipakai untuk restore.
      const walPath = `${DB_PATH}-wal`;
      if (fs.existsSync(walPath)) {
        archive.file(walPath, { name: 'database.sqlite-wal' });
      }
      const shmPath = `${DB_PATH}-shm`;
      if (fs.existsSync(shmPath)) {
        archive.file(shmPath, { name: 'database.sqlite-shm' });
      }
      
      const produkBaruFile = path.join(__dirname, '../database/produk_baru.json');
      if (fs.existsSync(produkBaruFile)) {
        archive.file(produkBaruFile, { name: 'produk_baru.json' });
      }
      
      const orderBaruFile = path.join(__dirname, '../database/order_baru.json');
      if (fs.existsSync(orderBaruFile)) {
        archive.file(orderBaruFile, { name: 'order_baru.json' });
      }
      
      const produkBalanceFile = path.join(__dirname, '../database/produk_balance.json');
      if (fs.existsSync(produkBalanceFile)) {
        archive.file(produkBalanceFile, { name: 'produk_balance.json' });
      }
      
      const produkTransactionsFile = path.join(__dirname, '../database/produk_transactions.json');
if (fs.existsSync(produkTransactionsFile)) {
  archive.file(produkTransactionsFile, { name: 'produk_transactions.json' });
}

const listAccessFile = path.join(__dirname, '../database/list_access.json');
if (fs.existsSync(listAccessFile)) {
  archive.file(listAccessFile, { name: 'list_access.json' });
}
      
      const stateFile = path.join(__dirname, '../database/state.json');
      if (fs.existsSync(stateFile)) {
        archive.file(stateFile, { name: 'state.json' });
      }
      
      const autoRestoreFile = path.join(__dirname, '../database/auto_restore_state.json');
      if (fs.existsSync(autoRestoreFile)) {
        archive.file(autoRestoreFile, { name: 'auto_restore_state.json' });
      }
      
      const autoRestartFile = path.join(__dirname, '../database/auto_restart.json');
      if (fs.existsSync(autoRestartFile)) {
        archive.file(autoRestartFile, { name: 'auto_restart.json' });
      }
      
      const logsDir = path.join(__dirname, '../database/logs');
      if (fs.existsSync(logsDir)) {
        archive.directory(logsDir, 'logs');
      }
      
      await archive.finalize();
      
    } catch (error) {
      logger.error('Backup ZIP failed:', error);
      reject(error);
    }
  });
}

async function backupDatabaseOnly() {
  try {
    // Sama seperti createBackupZip(): pastikan data yang masih di WAL
    // sudah pindah ke file utama sebelum disalin, biar backup tidak
    // ketinggalan perubahan (mis. premium) yang baru saja tersimpan.
    try {
      if (db) await db.exec('PRAGMA wal_checkpoint(TRUNCATE);');
    } catch (checkpointErr) {
      logger.warn('WAL checkpoint sebelum backup gagal (lanjut backup tetap jalan):', checkpointErr.message);
    }

    const timestamp = Math.floor(Date.now() / 1000);
    const backupDir = path.join(__dirname, '../database/backups');
    
    if (!fs.existsSync(backupDir)) {
      fs.mkdirSync(backupDir, { recursive: true });
    }
    
    const backupFile = path.join(backupDir, `backup_${timestamp}.db`);
    
    if (fs.existsSync(DB_PATH)) {
      fs.copyFileSync(DB_PATH, backupFile);
      const stats = fs.statSync(backupFile);
      const sizeMB = (stats.size / (1024 * 1024)).toFixed(2);
      return { path: backupFile, name: `backup_${timestamp}.db`, size: sizeMB };
    }
    return null;
  } catch (error) {
    logger.error('Database backup failed:', error);
    return null;
  }
}

// ============================================================
// FITUR /update (v10.6)
// ============================================================
// Owner kirim /update, lalu upload SATU file .zip. Bot deteksi otomatis
// dari nama filenya:
//  - Nama mengandung "database"/"backup" (persis nama yang dipakai
//    createBackupZip/backupDatabaseOnly) -> dianggap backup DATABASE,
//    diekstrak ke folder database/, lalu file zip-nya dihapus.
//  - Nama lain -> dianggap update KODE: setiap file di dalam zip dicocokkan
//    ke SELURUH project (berdasarkan nama file persis), file yang namanya
//    cocok akan DITIMPA. File di zip yang namanya tidak cocok dengan file
//    manapun di project akan DILEWATI (tidak ditambahkan sebagai file baru
//    -- biar aman, tidak asal nyuntik file baru ke project).
// Sebelum menimpa apa pun, versi lama selalu dibackup dulu ke
// database/backups/pre_update_*/, dan owner selalu diberi menu konfirmasi
// + tombol restart di akhir (tidak ada yang otomatis committed diam-diam).

function buildProjectFileIndex(rootDir) {
  const excludeDirs = new Set(['node_modules', '.git', 'database', 'backups', 'tmp_update']);
  const index = {}; // basename -> [fullPath, ...]
  function walk(dir) {
    let entries;
    try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch (e) { return; }
    for (const entry of entries) {
      if (entry.isDirectory()) {
        if (excludeDirs.has(entry.name)) continue;
        walk(path.join(dir, entry.name));
      } else {
        const full = path.join(dir, entry.name);
        if (!index[entry.name]) index[entry.name] = [];
        index[entry.name].push(full);
      }
    }
  }
  walk(rootDir);
  return index;
}

async function processDatabaseUpdate(chatId, statusMessageId, zipPath, tmpDir) {
  try {
    const zip = new AdmZip(zipPath);
    const entries = zip.getEntries().filter(e => !e.isDirectory);

    if (entries.length === 0) {
      await safeEditMessageText(`<blockquote>❌ <b>Zip kosong atau bukan file zip yang valid.</b></blockquote>`, { chat_id: chatId, message_id: statusMessageId, parse_mode: 'HTML' });
      return;
    }

    const dbDir = path.join(__dirname, '../database');
    const backupDir = path.join(dbDir, 'backups', `pre_update_db_${Date.now()}`);

    // Backup semua file yang BAKAL ketimpa (bukan seluruh folder database,
    // biar cepat & gak dobel sama backup rutin yang udah ada).
    for (const entry of entries) {
      const destPath = path.join(dbDir, entry.entryName);
      if (fs.existsSync(destPath) && fs.statSync(destPath).isFile()) {
        const backupTarget = path.join(backupDir, entry.entryName);
        fs.mkdirSync(path.dirname(backupTarget), { recursive: true });
        fs.copyFileSync(destPath, backupTarget);
      }
    }

    // PENTING: koneksi SQLite yang sedang berjalan tetap membaca file lama
    // dari cache/handle-nya sampai proses di-restart. Jadi file baru
    // diekstrak ke tempatnya sekarang, tapi WAJIB restart biar databasenya
    // benar-benar ke-load ulang dari file yang baru.
    zip.extractAllTo(dbDir, true);

    fs.rmSync(zipPath, { force: true });
    fs.rmSync(tmpDir, { recursive: true, force: true });

    const fileList = entries.map(e => `• <code>${escapeHtml(e.entryName)}</code>`).join('\n');
    const isPm2 = !!(process.env.pm_id || process.env.PM2_HOME);

    await safeEditMessageText(`
<blockquote>✅ <b><u>DATABASE BERHASIL DIPERBARUI</u></b></blockquote>
<blockquote>${fileList}</blockquote>
<blockquote>💾 <b>Versi lama dibackup ke:</b>
<code>database/backups/${escapeHtml(path.basename(backupDir))}</code></blockquote>
<blockquote>⚠️ <b>WAJIB restart</b> supaya database baru benar-benar terpakai.${isPm2 ? '' : ' Proses ini TIDAK terdeteksi berjalan via PM2 -- kalau ditekan restart dan bot tidak balik online sendiri, jalankan ulang manual lewat SSH.'}</blockquote>`, {
      chat_id: chatId,
      message_id: statusMessageId,
      parse_mode: 'HTML',
      reply_markup: { inline_keyboard: [[{ text: '🔄 Restart Sekarang', callback_data: 'confirm_update_restart' }]] }
    });
  } catch (err) {
    logger.error('processDatabaseUpdate error:', err);
    await safeEditMessageText(`<blockquote>❌ <b>Gagal update database:</b> ${escapeHtml(err.message)}</blockquote>`, { chat_id: chatId, message_id: statusMessageId, parse_mode: 'HTML' });
  }
}

async function processCodeUpdate(chatId, statusMessageId, zipPath, tmpDir) {
  try {
    const zip = new AdmZip(zipPath);
    const entries = zip.getEntries().filter(e => !e.isDirectory);

    if (entries.length === 0) {
      await safeEditMessageText(`<blockquote>❌ <b>Zip kosong atau bukan file zip yang valid.</b></blockquote>`, { chat_id: chatId, message_id: statusMessageId, parse_mode: 'HTML' });
      return;
    }

    const projectRoot = path.join(__dirname, '..');
    const fileIndex = buildProjectFileIndex(projectRoot);
    const backupDir = path.join(projectRoot, 'database', 'backups', `pre_update_code_${Date.now()}`);

    const updated = [];
    const skipped = [];

    for (const entry of entries) {
      const baseName = path.basename(entry.entryName);
      const matches = fileIndex[baseName];
      if (!matches || matches.length === 0) {
        skipped.push(baseName);
        continue;
      }
      const newContent = entry.getData();
      for (const targetPath of matches) {
        const relPath = path.relative(projectRoot, targetPath);
        const backupTarget = path.join(backupDir, relPath);
        fs.mkdirSync(path.dirname(backupTarget), { recursive: true });
        fs.copyFileSync(targetPath, backupTarget);
        fs.writeFileSync(targetPath, newContent);
        updated.push(relPath);
      }
    }

    fs.rmSync(zipPath, { force: true });
    fs.rmSync(tmpDir, { recursive: true, force: true });

    let msgText = `<blockquote>✅ <b><u>UPDATE KODE SELESAI</u></b></blockquote>\n`;
    msgText += `<blockquote><b>✏️ Diganti (${updated.length}):</b>\n${updated.length ? updated.map(f => `• <code>${escapeHtml(f)}</code>`).join('\n') : '-'}</blockquote>\n`;
    if (skipped.length) {
      msgText += `<blockquote><b>⏭️ Dilewati, nama file tidak ditemukan di project (${skipped.length}):</b>\n${skipped.map(f => `• <code>${escapeHtml(f)}</code>`).join('\n')}</blockquote>\n`;
    }

    if (updated.length > 0) {
      const isPm2 = !!(process.env.pm_id || process.env.PM2_HOME);
      msgText += `<blockquote>💾 <b>Versi lama dibackup ke:</b>\n<code>database/backups/${escapeHtml(path.basename(backupDir))}</code></blockquote>\n`;
      msgText += `<blockquote>⚠️ <b>WAJIB restart</b> supaya kode baru terpakai.${isPm2 ? '' : ' Proses ini TIDAK terdeteksi berjalan via PM2 -- kalau ditekan restart dan bot tidak balik online sendiri, jalankan ulang manual lewat SSH.'}</blockquote>`;
      await safeEditMessageText(msgText, {
        chat_id: chatId,
        message_id: statusMessageId,
        parse_mode: 'HTML',
        reply_markup: { inline_keyboard: [[{ text: '🔄 Restart Sekarang', callback_data: 'confirm_update_restart' }]] }
      });
    } else {
      msgText += `<i>Tidak ada nama file yang cocok, jadi tidak ada yang diubah/di-restart.</i>`;
      await safeEditMessageText(msgText, { chat_id: chatId, message_id: statusMessageId, parse_mode: 'HTML' });
    }
  } catch (err) {
    logger.error('processCodeUpdate error:', err);
    await safeEditMessageText(`<blockquote>❌ <b>Gagal update kode:</b> ${escapeHtml(err.message)}</blockquote>`, { chat_id: chatId, message_id: statusMessageId, parse_mode: 'HTML' });
  }
}

async function handleUpdateFileUpload(userId, chatId, msg) {
  global.waitingForUpdateFile = false;
  clearTimeout(global.waitingForUpdateFileTimeout);

  const fileName = msg.document.file_name || '';
  if (!fileName.toLowerCase().endsWith('.zip')) {
    await bot.sendMessage(chatId, `<blockquote>❌ <b>File harus berformat .zip</b></blockquote>\n\n<i>Ketik /update lagi buat coba ulang.</i>`, { parse_mode: 'HTML' });
    return;
  }

  const statusMsg = await bot.sendMessage(chatId, `<blockquote>⏳ <b>Mengunduh file...</b></blockquote>`, { parse_mode: 'HTML' });

  const tmpDir = path.join(__dirname, '../database/tmp_update');
  try { fs.rmSync(tmpDir, { recursive: true, force: true }); } catch (e) {}
  fs.mkdirSync(tmpDir, { recursive: true });

  let downloadedPath;
  try {
    downloadedPath = await bot.downloadFile(msg.document.file_id, tmpDir);
  } catch (err) {
    await safeEditMessageText(`<blockquote>❌ <b>Gagal mengunduh file:</b> ${escapeHtml(err.message)}</blockquote>`, { chat_id: chatId, message_id: statusMsg.message_id, parse_mode: 'HTML' });
    return;
  }

  await safeEditMessageText(`<blockquote>⏳ <b>Memproses file...</b></blockquote>`, { chat_id: chatId, message_id: statusMsg.message_id, parse_mode: 'HTML' });

  // Deteksi tipe dari nama file -- persis nama yang dipakai sistem backup
  // otomatis bot ini (backup_<timestamp>.zip / backup_<timestamp>.db, dan
  // isinya "database.sqlite" dkk).
  const isDatabaseUpdate = /database|backup/i.test(fileName);

  if (isDatabaseUpdate) {
    await processDatabaseUpdate(chatId, statusMsg.message_id, downloadedPath, tmpDir);
  } else {
    await processCodeUpdate(chatId, statusMsg.message_id, downloadedPath, tmpDir);
  }
}

bot.onText(/\/updatefile/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();

  if (!isOwnerId(userId)) {
    await bot.sendMessage(chatId, `<blockquote>❌ <b><u>No Permission</u></b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }

  global.waitingForUpdateFile = true;
  clearTimeout(global.waitingForUpdateFileTimeout);
  global.waitingForUpdateFileTimeout = setTimeout(() => { global.waitingForUpdateFile = false; }, 10 * 60 * 1000);

  await bot.sendMessage(chatId, `
<blockquote>🔄 <b><u>UPDATE FILE</u></b></blockquote>
<blockquote>Kirim 1 file <b>.zip</b> sekarang (berlaku 10 menit).</blockquote>
<blockquote><b>Otomatis dideteksi dari nama file:</b>
 • Nama mengandung <code>database</code>/<code>backup</code> → diekstrak ke folder <code>database/</code>
 • Nama lain → dianggap update kode: file di dalam zip menimpa file lain di project yang namanya sama (nama yang tidak cocok dilewati)</blockquote>
<blockquote>💾 Versi lama selalu dibackup dulu sebelum ditimpa.</blockquote>`, { parse_mode: 'HTML' });
});


async function manualBackupCommand(userId, chatId) {
  const isOwner = isOwnerId(userId);
  if (!isOwner) {
    await bot.sendMessage(chatId, `<blockquote>❌ <b>No Permission</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const statusMsg = await bot.sendMessage(chatId, `<blockquote>⏳ <b>Membuat backup lengkap...</b></blockquote>`, { parse_mode: 'HTML' });
  
  try {
    const backup = await createBackupZip();
    
    if (backup && fs.existsSync(backup.path)) {
      const caption = `
<blockquote>📂 <b><u>BACKUP DATABASE</u></b>
🗓 <b>Waktu</b> : ${moment().format('DD/MM/YYYY HH:mm:ss')}
📤 <b>File</b> : ${backup.name}
💰 <b>Size</b> : ${backup.size} MB
✅ <b>Status</b> : Berhasil</blockquote>`;

      await bot.sendDocument(chatId, backup.path, {
        caption: caption,
        parse_mode: 'HTML'
      });
      
      fs.unlinkSync(backup.path);
    } else {
      throw new Error('Backup gagal dibuat');
    }
    
    await safeDeleteMessage(chatId, statusMsg.message_id);
    
  } catch (error) {
    await safeDeleteMessage(chatId, statusMsg.message_id);
    await bot.sendMessage(chatId, `<blockquote>❌ <b>BACKUP GAGAL</b>\n⚠️ ${error.message}</blockquote>`, { parse_mode: 'HTML' });
  }
}

async function getBackupInfo(userId, chatId) {
  const isOwner = isOwnerId(userId);
  if (!isOwner) {
    await bot.sendMessage(chatId, `<blockquote>❌ <b>No Permission</b></blockquote>`, { parse_mode: 'HTML' });
    return;
  }
  
  const backupDir = path.join(__dirname, 'backups');
  let backups = [];
  let totalSize = 0;
  
  if (fs.existsSync(backupDir)) {
    const files = fs.readdirSync(backupDir);
    for (const file of files) {
      if (file.endsWith('.db')) {
        const filePath = path.join(backupDir, file);
        const stats = fs.statSync(filePath);
        const sizeMB = (stats.size / (1024 * 1024)).toFixed(2);
        totalSize += parseFloat(sizeMB);
        backups.push({ name: file, size: sizeMB, date: stats.mtime });
      }
    }
  }
  
  backups.sort((a, b) => b.date - a.date);
  
  let dbSize = 'N/A';
  if (fs.existsSync(DB_PATH)) {
    const stats = fs.statSync(DB_PATH);
    dbSize = (stats.size / (1024 * 1024)).toFixed(2) + ' MB';
  }
  
  let info = `
<blockquote>📂 <b><u>INFORMASI BACKUP</u></b>
📊 <b>Database Size</b> : ${dbSize}
📖 <b>Total Backup</b> : ${backups.length} file
💰 <b>Total Backup Size</b> : ${totalSize.toFixed(2)} MB</blockquote>
<blockquote>🗓 <b>JADWAL BACKUP</b>
 • Backup DB : Setiap 1 jam
 • Backup ZIP : Setiap 2 jam</blockquote>
<blockquote>📖 <b>BACKUP TERBARU</b></blockquote>`;

  for (let i = 0; i < Math.min(backups.length, 5); i++) {
    const b = backups[i];
    info += `
<blockquote><b>${i + 1}.</b> ${b.name}
   🗓 ${moment(b.date).format('DD/MM/YYYY HH:mm:ss')}
   💰 ${b.size} MB</blockquote>`;
  }

  info += `
<blockquote><i>Klik tombol di bawah untuk backup manual.</i></blockquote>`;

  await bot.sendMessage(chatId, info, {
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [
          { text: '📦 Backup Now', callback_data: 'manual_backup' }
        ],
        [
          { text: '⬅️ Kembali', callback_data: 'back_main' }
        ]
      ]
    }
  });
}

async function sendBackupToOwner() {
  try {
    const backup = await createBackupZip();
    
    if (!backup || !backup.path || !fs.existsSync(backup.path)) {
      throw new Error('File backup tidak ditemukan');
    }
    
    const caption = `
<blockquote>📂 <b><u>AUTO BACKUP</u></b>
🗓 <b>Waktu</b> : ${moment().format('DD/MM/YYYY HH:mm:ss')}
📤 <b>File</b> : ${backup.name}
💰 <b>Size</b> : ${backup.size} MB
✅ <b>Status</b> : Berhasil</blockquote>`;

    const fileStream = fs.createReadStream(backup.path);
    
    await bot.sendDocument(OWNER_ID, fileStream, {
      caption: caption,
      parse_mode: 'HTML'
    });
    
    if (fs.existsSync(backupsDir)) {
      const files = fs.readdirSync(backupsDir);
      const zipFiles = files.filter(f => f.endsWith('.zip')).sort();
      
      while (zipFiles.length > 5) {
        const oldest = zipFiles.shift();
        try {
          fs.unlinkSync(path.join(backupsDir, oldest));
        } catch (e) {}
      }
    }
    
    try {
      if (fs.existsSync(backup.path)) {
        fs.unlinkSync(backup.path);
      }
    } catch (e) {}
    
  } catch (error) {
    logger.error('Failed to send backup to owner:', error);
    
    try {
      await bot.sendMessage(OWNER_ID, `
<blockquote>❌ <b><u>AUTO BACKUP GAGAL</u></b>
🗓 <b>Waktu</b> : ${moment().format('DD/MM/YYYY HH:mm:ss')}
❌ <b>Error</b> : ${error.message || 'Unknown error'}</blockquote>`, { parse_mode: 'HTML' });
    } catch (e) {}
  }
}

async function fullBackupAndSend() {
  try {
    const botInfo = await getCachedBotInfo().catch(() => null);
    if (!botInfo) {
      logger.error('Bot not connected, skipping backup');
      return;
    }
    
    await backupDatabaseOnly();
    
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    await sendBackupToOwner();
  } catch (error) {
    logger.error('Full backup failed:', error);
  }
}

async function saveAutoRestartState() {
  const activePromos = [];
  for (const [userId, promo] of Object.entries(promosiProgress)) {
    if (promo && promo.running) {
      activePromos.push({
        userId: userId,
        current: promo.current,
        success: promo.success,
        failed: promo.failed,
        startTime: promo.startTime
      });
    }
  }
  fs.writeFileSync(AUTO_RESTART_FILE, JSON.stringify({
    timestamp: Date.now(),
    activePromos: activePromos
  }, null, 2));
}

function safeInterval(fn, ms, label) {
  setInterval(() => {
    Promise.resolve()
      .then(() => fn())
      .catch((error) => {
        logger.error(`Interval job "${label}" gagal:`, error && error.stack ? error.stack : error);
      });
  }, ms);
}

safeInterval(saveAutoRestartState, 10000, 'saveAutoRestartState');
safeInterval(checkExpired, 30 * 1000, 'checkExpired');
safeInterval(checkUserbotStatus, 15 * 1000, 'checkUserbotStatus');
safeInterval(savePromosiStateToFile, 60000, 'savePromosiStateToFile');
safeInterval(scheduledCleanup, 24 * 60 * 60 * 1000, 'scheduledCleanup');
safeInterval(cleanupInMemoryState, 60 * 60 * 1000, 'cleanupInMemoryState'); // bersihin state navigasi & attempt counter tiap 1 jam
safeInterval(fullBackupAndSend, 2 * 60 * 60 * 1000, 'fullBackupAndSend');
safeInterval(saveBroadcastStateToFile, 15000, 'saveBroadcastStateToFile');

safeInterval(async () => {
  await backupDatabaseOnly();
}, 1 * 60 * 60 * 1000, 'backupDatabaseOnly');

safeInterval(async () => {
  await cleanExpiredPremium();
}, 6 * 60 * 60 * 1000, 'cleanExpiredPremium');

safeInterval(async () => {
  await cleanOrphanedData();
}, 12 * 60 * 60 * 1000, 'cleanOrphanedData');

safeInterval(async () => {
  for (const [userId, promo] of Object.entries(promosiProgress)) {
    if (promo && promo.running) {
      await savePromosiState(userId);
    }
  }
}, 5000, 'savePromosiState-tick');

safeInterval(async () => {
  for (const [userId, promo] of Object.entries(promosiProgress)) {
    if (promo && promo.running && promo.current < promo.validGroups.length) {
      const lastHeartbeat = promo.lastHeartbeat || Date.now();
      if (Date.now() - lastHeartbeat > 60000) {
        promo.lastHeartbeat = Date.now();
        await savePromosiState(userId);
      }
    }
  }
}, 30000, 'promosi-heartbeat');

process.on('SIGINT', async () => {
  logger.info('Saving states before shutdown...');
  for (const [userId, promo] of Object.entries(promosiProgress)) {
    if (promo && promo.running) {
      await savePromosiState(userId);
      promo.running = false;
    }
  }
  await savePromosiStateToFile();
  await saveBroadcastStateToFile();
  await saveAutoRestartState();
  await sendShutdownNotification(bot, OWNER_ID, db);
  process.exit(0);
});

process.on('SIGTERM', async () => {
  logger.info('Saving states before shutdown...');
  for (const [userId, promo] of Object.entries(promosiProgress)) {
    if (promo && promo.running) {
      await savePromosiState(userId);
      promo.running = false;
    }
  }
  await savePromosiStateToFile();
  await saveBroadcastStateToFile();
  await saveAutoRestartState();
  await sendShutdownNotification(bot, OWNER_ID, db);
  process.exit(0);
});

async function startBot() {
  const winstonLogsDir = path.join(__dirname, '../logs');
  if (!fs.existsSync(winstonLogsDir)) fs.mkdirSync(winstonLogsDir, { recursive: true });
  await initDatabase();
  produkBaruLoad();
 
  await loadProdukBalance();
  await loadProdukTransactions();
  await syncDatabaseToAccessList();
  await restorePendingDepositOrders();
  
  logger.info('Memeriksa broadcast yang berjalan sebelum restart...');
  
  await restoreBroadcastFromFile();
  await restoreAndContinueBroadcasts();
  crashProofWatcher();
  startPromosiWatcher();
  
  logger.info('Bot Actived...');

  await sendStartupNotification(bot, OWNER_ID, db);

  // BUG FIX: polling baru dimulai DI SINI, paling akhir, setelah database
  // dan semua state sudah siap. Sebelum ini bot belum nerima update sama
  // sekali dari Telegram, jadi gak ada lagi celah user "kepancing" mengirim
  // pesan/klik tombol sebelum tabel database selesai di-seed.
  await bot.startPolling();
  logger.info('Bot mulai menerima pesan (polling aktif).');
}

bot.on('photo', async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  
  try {
    // Handler untuk bukti deposit
    if (global.waitingForDepositProof && global.waitingForDepositProof[userId]) {
      await handleDepositProof(userId, chatId, msg);
      return;
    }
  } catch (error) {
    logger.error(`photo handler error (userId=${userId}):`, error && error.stack ? error.stack : error);
  }
});

bot.on('polling_error', (error) => {
  logger.error('POLLING ERROR:', error && error.stack ? error.stack : error);
});

bot.on('webhook_error', (error) => {
  logger.error('WEBHOOK ERROR:', error && error.stack ? error.stack : error);
});

startBot().catch((err) => {
  logger.error('startBot() FAILED:', err && err.stack ? err.stack : err);
});