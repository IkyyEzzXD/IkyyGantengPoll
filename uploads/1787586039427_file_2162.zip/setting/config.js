const BOT_TOKEN = '8759182980:AAHYMRbyEzQdnGm5OP4GAJaNMgeqpcns-So';
const OWNER_ID = '195387257';
const OWNER_USERNAME = '@umeey';
const LOG_GROUP = '@LoggUserbot';
const REQUIRED_CHANNEL = '@unmeynya';
const REQUIRED_GROUP = '@InformasiUserbot';
// ID numerik chat yang dipakai buat CEK STATUS JOIN (bukan username).
// ID lebih stabil daripada username (username bisa diganti kapan aja,
// ID chat gak pernah berubah). Bisa isi ID grup ATAU channel, apa aja
// asal user pasti ke-join situ waktu join folder di bawah - satu ID ini
// aja yang dites ke Telegram, hasilnya dipakai buat wakilin ketiganya
// (channel + komunitas + log group) karena user join semua sekaligus
// lewat folder.
// Grup: biasanya diawali -100 (contoh: -1001234567890)
// Channel: juga diawali -100
const JOIN_CHECK_CHAT_ID = '-1003991893589';
// Folder invite yang isinya Channel Resmi + Komunitas + Log Group sekaligus.
// User cukup pencet 1 tombol ini buat join semuanya otomatis.
const JOIN_FOLDER_LINK = 'https://t.me/addlist/4OuKs6mPs8M2YzJl';
const API_ID = 32423519;
const API_HASH = '5eb95e3c374e11442cd11bcf68f4bfb6';
const WM = '𝖠𝗎𝗍𝗈𝖲𝗁𝖺𝗋𝖾 𝖦𝗋𝖺𝗍𝗂𝗌 @AutoBCrobot';

// Bisa pake link URL, path lokal, atau buffer
const QRIS_IMAGE = 'https://files.catbox.moe/qauujk.jpg'; // Bisa pake link

// ===== KONFIGURASI DEPOSIT OTOMATIS (PAKASIR) =====
// Isi 3 baris ini dengan data dari dashboard Pakasir kamu.
// Kalau PAKASIR_SLUG / PAKASIR_APIKEY dikosongkan, menu deposit
// otomatis akan otomatis disembunyikan dan bot fallback ke deposit
// manual saja (tidak akan error/crash).
const PAKASIR_SLUG = 'unmey-2';
const PAKASIR_APIKEY = 'x7S0YcOpnuulqwEUOPRQjp1a1FPB9K2S';
const PAKASIR_METHOD = 'qris';

// Biaya tambahan admin khusus deposit OTOMATIS (Pakasir), dalam Rupiah.
// Deposit manual (upload bukti) TIDAK kena biaya ini.
const PAKASIR_ADMIN_FEE = 200;

// Berapa lama link/QR pembayaran Pakasir berlaku sebelum dianggap
// kedaluwarsa kalau API tidak mengirimkan expired_at.
const PAKASIR_EXPIRY_MS = 10 * 60 * 1000; // 10 menit

// Seberapa sering job background mengecek status semua order Pakasir
// yang masih PENDING (auto-detect pembayaran masuk).
const PAKASIR_POLL_INTERVAL_MS = 15 * 1000; // 15 detik

let config = {
  ENABLED: true,
  DURATION_HOURS: 6
};

let maintenanceMode = {
  enabled: false,
  reason: 'Bot sedang dalam perawatan. Mohon kembali lagi nanti.'
};

const menuEffects = [
  "5104841245755180586",
  "5107584321108051014",
  "5159385139981059251",
  "5046509860389126442"
];

const getRandomEffect = () => menuEffects[Math.floor(Math.random() * menuEffects.length)];

const { Logger } = require('telegram/extensions/Logger');

// Logger internal GramJS di-silent-in total supaya console nggak dibanjiri
// warning "flood wait" / "Telegram is having internal issues RPCError".
// Kalau butuh debug manual, ganti 'none' jadi 'error' sementara.
const silentLogger = new Logger('none');

function getTelegramClientConfig() {
  return {
    connectionRetries: 5,
    deviceModel: "Userbot Public",
    systemVersion: "iOS 18.01",
    appVersion: "Telegram iOS 11.5",
    baseLogger: silentLogger
  };
}

module.exports = {
  BOT_TOKEN,
  OWNER_ID,
  OWNER_USERNAME,
  LOG_GROUP,
  REQUIRED_CHANNEL,
  REQUIRED_GROUP,
  JOIN_CHECK_CHAT_ID,
  JOIN_FOLDER_LINK,
  API_ID,
  API_HASH,
  WM,
  QRIS_IMAGE,
  PAKASIR_SLUG,
  PAKASIR_APIKEY,
  PAKASIR_METHOD,
  PAKASIR_ADMIN_FEE,
  PAKASIR_EXPIRY_MS,
  PAKASIR_POLL_INTERVAL_MS,
  menuEffects,
  getRandomEffect,
  config,
  getTelegramClientConfig,
  maintenanceMode
};