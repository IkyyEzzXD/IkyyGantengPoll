const moment = require('moment');

async function sendStartupNotification(bot, ownerId, db) {
  try {
    const botInfo = await bot.getMe();
    const botName = botInfo.first_name;
    const botUsername = botInfo.username;
    
    const uptimeSeconds = process.uptime();
    const days = Math.floor(uptimeSeconds / 86400);
    const hours = Math.floor((uptimeSeconds % 86400) / 3600);
    const minutes = Math.floor((uptimeSeconds % 3600) / 60);
    const seconds = Math.floor(uptimeSeconds % 60);
    
    let uptimeString = '';
    if (days > 0) uptimeString += `${days} hari `;
    if (hours > 0) uptimeString += `${hours} jam `;
    if (minutes > 0) uptimeString += `${minutes} menit `;
    uptimeString += `${seconds} detik`;
    
    const memoryUsage = process.memoryUsage();
    const memoryMB = (memoryUsage.rss / 1024 / 1024).toFixed(2);
    
    const nodeVersion = process.version;
    
    let totalUsers = 0;
    let totalUserbots = 0;
    
    try {
      const userCount = await db.get('SELECT COUNT(*) as count FROM users');
      totalUsers = userCount?.count || 0;
      
      const ubotCount = await db.get('SELECT COUNT(*) as count FROM userbots WHERE status = "AKTIF"');
      totalUserbots = ubotCount?.count || 0;
    } catch (err) {
      console.error('Gagal ambil statistik:', err.message);
    }
    
    const message = `
<blockquote>🤖 <b>${botName} BERHASIL DIAKTIFKAN</b></blockquote>
<blockquote>
📁 <b>Node.js</b> : ${nodeVersion}
📘 <b>Uptime</b> : ${uptimeString}
📙 <b>Memory</b> : ${memoryMB} MB</blockquote>
<blockquote>
👥 <b>Total Users</b> : ${totalUsers}
🤖 <b>Total Userbots</b> : ${totalUserbots}</blockquote>
<blockquote>
👤 <b>Username</b> : @${botUsername}
🆔 <b>ID</b> : <code>${botInfo.id}</code></blockquote>
<i>Bot siap digunakan!</i>`;

    await bot.sendMessage(ownerId, message, { parse_mode: 'HTML' });
    
  } catch (error) {
    console.error('Gagal kirim notifikasi startup:', error.message);
  }
}

async function sendShutdownNotification(bot, ownerId, db) {
  try {
    const botInfo = await bot.getMe();
    const botName = botInfo.first_name || 'Xavier-Jaseb Bot';
    
    let totalUsers = 0;
    let totalUserbots = 0;
    
    try {
      const userCount = await db.get('SELECT COUNT(*) as count FROM users');
      totalUsers = userCount?.count || 0;
      
      const ubotCount = await db.get('SELECT COUNT(*) as count FROM userbots WHERE status = "AKTIF"');
      totalUserbots = ubotCount?.count || 0;
    } catch (err) {}
    
    const message = `
<blockquote>🛑 <b>${botName} DIMATIKAN</b></blockquote>
<blockquote>
👥 <b>Total Users</b> : ${totalUsers}
🤖 <b>Total Userbots</b> : ${totalUserbots}</blockquote>
<i>Bot dimatikan pada ${moment().format('DD/MM/YYYY HH:mm:ss')}</i>`;

    await bot.sendMessage(ownerId, message, { parse_mode: 'HTML' });
    
  } catch (error) {
    console.error('Gagal kirim notifikasi shutdown:', error.message);
  }
}

module.exports = { sendStartupNotification, sendShutdownNotification };