/**
 * lazyUbot.js
 * ------------------------------------------------------------------
 * Manajer koneksi "lazy" untuk userbot (GramJS TelegramClient).
 *
 * Tujuan:
 *  - Userbot TIDAK menahan koneksi MTProto terus-menerus kalau lagi
 *    nggak dipakai -> hemat memori & socket, apalagi kalau banyak
 *    user trial yang jarang aktif.
 *  - Koneksi otomatis dibuat ulang ("reconnect") begitu ada aksi yang
 *    butuh userbot (kirim pesan, ambil daftar grup, dll) -> user
 *    nggak akan ngerasa ada bedanya, karena `client` yang dipakai di
 *    seluruh kode lain TETAP dipanggil persis seperti biasa.
 *  - Selama auto-share/broadcast lagi jalan, koneksi DIKUNCI (pin)
 *    supaya nggak mungkin ke-disconnect di tengah proses -> auto
 *    share nggak akan pernah mati sendiri gara-gara idle-timeout.
 *  - Kalau session sudah tidak valid (di-revoke / logout dari HP /
 *    kena banned), lazyUbot BERHENTI mencoba reconnect terus-menerus
 *    (circuit breaker) dan menandai client sebagai "dead" supaya
 *    kode pemanggil bisa cleanup dengan tepat, bukan nge-loop retry
 *    yang sia-sia dan membebani proses.
 *
 * Cara pakai (lihat integrasi di modules/index.js):
 *   const lazyUbot = require('../system/lazyUbot');
 *   const client = lazyUbot.createLazyClient(ownerId, sessionString, apiId, apiHash, clientConfig);
 *   userbots.push({ id, owner_id: ownerId, client, phone, status: 'AKTIF' });
 *   // `client` di atas adalah Proxy - dipakai PERSIS seperti TelegramClient
 *   // biasa (ubot.client.sendMessage(...), ubot.client.getDialogs(), dst)
 *   // TANPA perlu ubah kode di tempat lain. Connect/reconnect kejadian
 *   // otomatis di balik layar pas method-nya dipanggil.
 *
 *   lazyUbot.pin(ownerId);    // panggil pas mulai proses penting (broadcast)
 *   lazyUbot.unpin(ownerId);  // panggil pas proses selesai (taruh di finally!)
 *
 *   // Opsional: kalau mau tahu / bereaksi begitu suatu userbot dinyatakan
 *   // "mati" permanen (session invalid), pasang listener:
 *   lazyUbot.onDead((ownerId, reason) => { ...cleanup ke DB... });
 * ------------------------------------------------------------------
 */

const { TelegramClient } = require('telegram');
const { StringSession } = require('telegram/sessions');

// Berapa lama nganggur (nggak ada pemanggilan method sama sekali)
// sebelum koneksi userbot diputus otomatis buat hemat memori.
const IDLE_DISCONNECT_MS = 3 * 60 * 1000; // 3 menit

// Berapa kali dicoba ulang kalau connect gagal (mis. jaringan lagi jelek),
// dengan jeda yang makin lama tiap percobaan (backoff).
const CONNECT_MAX_RETRY = 3;
const CONNECT_RETRY_BASE_MS = 1500;
const CONNECT_RETRY_MAX_MS = 15000;

// Circuit breaker: kalau connect gagal beruntun sebanyak ini (di luar
// percobaan internal ensureConnected), client ditandai "dead" dan
// TIDAK akan dicoba connect lagi sampai di-reset manual (createLazyClient
// ulang / relogin). Ini mencegah retry-storm kalau session sudah invalid.
const MAX_CONSECUTIVE_FAILURES = 5;

// Pola pesan error dari GramJS/MTProto yang menandakan session sudah
// TIDAK VALID (bukan sekadar gangguan jaringan sementara) -> begitu
// ketemu salah satu ini, langsung dead tanpa perlu habiskan retry budget.
const FATAL_AUTH_ERROR_PATTERNS = [
  'AUTH_KEY_UNREGISTERED',
  'AUTH_KEY_INVALID',
  'SESSION_REVOKED',
  'SESSION_EXPIRED',
  'USER_DEACTIVATED',
  'USER_DEACTIVATED_BAN',
];

// Pola error yang SIFATNYA SEMENTARA -> jangan pernah dihitung sebagai
// kegagalan permanen walau muncul berkali-kali. FLOOD_WAIT sangat umum
// terjadi di userbot yang sering dipakai (banyak request beruntun), dan
// TIDAK berarti session-nya rusak -> harus di-backoff sesuai durasi yang
// diminta Telegram, bukan didiamkan sampai kena circuit breaker.
const TRANSIENT_ERROR_PATTERNS = [
  'FLOOD_WAIT',
  'TIMEOUT',
  'ECONNRESET',
  'ECONNREFUSED',
  'ETIMEDOUT',
  'ENOTFOUND',
  'EAI_AGAIN',
  'NETWORK',
  'CONNECTION',
];

function isFatalAuthError(err) {
  const msg = String((err && (err.errorMessage || err.message)) || '').toUpperCase();
  return FATAL_AUTH_ERROR_PATTERNS.some((p) => msg.includes(p));
}

function isTransientError(err) {
  const msg = String((err && (err.errorMessage || err.message)) || '').toUpperCase();
  return TRANSIENT_ERROR_PATTERNS.some((p) => msg.includes(p));
}

// Ambil durasi tunggu (detik) dari pesan FLOOD_WAIT_123, kalau ada.
function getFloodWaitSeconds(err) {
  const msg = String((err && (err.errorMessage || err.message)) || '');
  const match = msg.match(/FLOOD_WAIT_(\d+)/i);
  return match ? parseInt(match[1], 10) : null;
}

// state per ownerId -> meta
const registry = new Map();

// listener eksternal yang dipanggil begitu suatu client dinyatakan dead
const deadListeners = [];

let logger = console; // default; bisa diganti lewat setLogger()

function setLogger(customLogger) {
  if (customLogger && typeof customLogger.info === 'function') {
    logger = customLogger;
  }
}

function log(level, msg) {
  try {
    const fn = logger[level] || logger.info || console.log;
    fn.call(logger, `[lazyUbot] ${msg}`);
  } catch (e) {
    console.log(`[lazyUbot] ${msg}`);
  }
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Daftarkan fungsi yang dipanggil begitu sebuah userbot dinyatakan mati
 * permanen (session invalid / auth error fatal / kehabisan retry budget).
 * Dipakai supaya modules/index.js bisa update status di DB & notify owner
 * tanpa lazyUbot.js perlu tahu apa-apa soal DB/bot Telegram.
 */
function onDead(fn) {
  if (typeof fn === 'function') deadListeners.push(fn);
}

function notifyDead(ownerId, reason) {
  for (const fn of deadListeners) {
    try {
      fn(ownerId, reason);
    } catch (e) {
      log('error', `onDead listener error untuk ${ownerId}: ${e.message}`);
    }
  }
}

/**
 * Bikin client "lazy" untuk satu owner. Kalau owner ini sudah pernah
 * punya client sebelumnya (misal relogin/redeploy), entry lama
 * dibersihkan dulu supaya nggak ada timer nyangkut di memori.
 */
function createLazyClient(ownerId, sessionString, apiId, apiHash, clientConfig) {
  ownerId = String(ownerId);

  if (registry.has(ownerId)) {
    remove(ownerId);
  }

  const real = new TelegramClient(new StringSession(sessionString), apiId, apiHash, clientConfig);

  const meta = {
    real,
    pinCount: 0,
    busyCount: 0,
    idleTimer: null,
    connecting: null, // Promise yang sedang berjalan, dipakai semua caller yang tabrakan
    dead: false,
    deadReason: null,
    consecutiveFailures: 0,
  };

  function clearIdleTimer() {
    if (meta.idleTimer) {
      clearTimeout(meta.idleTimer);
      meta.idleTimer = null;
    }
  }

  function scheduleIdleDisconnect() {
    clearIdleTimer();
    if (meta.dead) return;
    if (meta.pinCount > 0 || meta.busyCount > 0) return;

    meta.idleTimer = setTimeout(async () => {
      meta.idleTimer = null;
      if (meta.pinCount > 0 || meta.busyCount > 0) return;
      try {
        if (real.connected) {
          await real.disconnect();
          log('info', `Userbot ${ownerId} nganggur -> disconnect otomatis (hemat memori)`);
        }
      } catch (e) {
        log('error', `Gagal disconnect userbot ${ownerId}: ${e.message}`);
      }
    }, IDLE_DISCONNECT_MS);

    if (meta.idleTimer.unref) meta.idleTimer.unref();
  }

  function markDead(reason) {
    if (meta.dead) return;
    meta.dead = true;
    meta.deadReason = reason;
    clearIdleTimer();
    log('error', `Userbot ${ownerId} ditandai DEAD (${reason}) -> berhenti retry otomatis`);
    try {
      if (real.connected) real.disconnect().catch(() => {});
    } catch (e) {}
    notifyDead(ownerId, reason);
  }

  /**
   * Satu-satunya jalur untuk connect. Kalau ada pemanggilan yang
   * tabrakan (dua method dipanggil bersamaan sebelum connect selesai),
   * semuanya menunggu Promise `meta.connecting` YANG SAMA -> tidak ada
   * connect ganda / retry-storm.
   */
  async function ensureConnected(reentryCount = 0) {
    if (meta.dead) {
      throw new Error(`Userbot ${ownerId} sudah dinonaktifkan (${meta.deadReason || 'dead'})`);
    }
    if (real.connected) return;

    if (meta.connecting) {
      await meta.connecting;
      // Re-check: promise yang ditunggu tadi bisa saja punya hasil
      // yang berbeda dari ekspektasi kita (mis. selesai duluan lalu
      // idle-disconnect kepicu sebelum kita lanjut) -> pastikan lagi.
      //
      // BUG FIX (v10.3 - STABILITAS): sebelumnya baris ini memanggil
      // ensureConnected() lagi TANPA batas rekursi dan TANPA delay sama
      // sekali. Kalau real.connected terus-menerus false padahal belum
      // dead (skenario langka tapi mungkin: connect() resolve lalu
      // idle-disconnect kepicu tepat sebelum re-check ini, berulang-ulang
      // karena timing yang selalu pas-pasan), ini jadi tight-loop rekursif
      // yang bisa menghabiskan CPU / stack tanpa pernah berhenti - proses
      // Node bisa macet/lambat drastis. Sekarang dibatasi maksimal 5x
      // percobaan ulang dengan jeda kecil di antaranya; kalau tetap gagal
      // setelah itu, lempar error yang jelas alih-alih diam-diam infinite loop.
      if (!real.connected && !meta.dead) {
        if (reentryCount >= 5) {
          throw new Error(`Userbot ${ownerId} gagal memastikan koneksi setelah beberapa kali percobaan ulang (kemungkinan race condition idle-disconnect)`);
        }
        await sleep(200);
        return ensureConnected(reentryCount + 1);
      }
      return;
    }

    meta.connecting = (async () => {
      let lastErr;
      for (let attempt = 1; attempt <= CONNECT_MAX_RETRY; attempt++) {
        try {
          await real.connect();
          meta.consecutiveFailures = 0;
          log('info', `Userbot ${ownerId} connect on-demand (percobaan ${attempt})`);
          return;
        } catch (e) {
          lastErr = e;
          log('error', `Userbot ${ownerId} gagal connect (percobaan ${attempt}): ${e.message}`);

          // Session sudah tidak valid -> tidak perlu retry sama sekali,
          // langsung tandai dead supaya nggak buang-buang waktu/API call.
          if (isFatalAuthError(e)) {
            markDead(e.errorMessage || e.message || 'fatal_auth_error');
            throw e;
          }

          // FLOOD_WAIT / error jaringan sementara -> ini BUKAN tanda
          // session rusak. Tunggu sesuai durasi yang diminta Telegram
          // (kalau ada), dan jangan hitung ini sebagai "consecutive
          // failure" yang bisa mematikan userbot secara permanen.
          if (isTransientError(e)) {
            const floodSeconds = getFloodWaitSeconds(e);
            if (floodSeconds !== null) {
              const waitMs = Math.min((floodSeconds + 1) * 1000, 60 * 1000);
              log('info', `Userbot ${ownerId} kena FLOOD_WAIT ${floodSeconds}s -> menunggu sebelum retry`);
              await sleep(waitMs);
            } else if (attempt < CONNECT_MAX_RETRY) {
              const backoff = Math.min(CONNECT_RETRY_BASE_MS * attempt, CONNECT_RETRY_MAX_MS);
              await sleep(backoff);
            }
            continue;
          }

          if (attempt < CONNECT_MAX_RETRY) {
            const backoff = Math.min(CONNECT_RETRY_BASE_MS * attempt, CONNECT_RETRY_MAX_MS);
            await sleep(backoff);
          }
        }
      }

      // Kehabisan retry budget untuk percobaan kali ini. Error transient
      // (flood wait/jaringan) tidak menyumbang ke circuit breaker supaya
      // userbot yang sehat tidak ditandai dead hanya karena lagi sibuk.
      if (!isTransientError(lastErr)) {
        meta.consecutiveFailures++;
        if (meta.consecutiveFailures >= MAX_CONSECUTIVE_FAILURES) {
          markDead('max_consecutive_connect_failures');
        }
      } else {
        log('info', `Userbot ${ownerId} gagal connect sementara (transient) -> tidak dihitung ke circuit breaker`);
      }

      throw lastErr || new Error('Gagal connect userbot (sebab tidak diketahui)');
    })();

    try {
      await meta.connecting;
    } finally {
      meta.connecting = null;
    }
  }

  // Simpan fungsi-fungsi ini di meta supaya pin()/unpin() dari luar bisa
  // manggil ulang scheduler yang sama persis (bukan duplikat logika).
  meta.clearIdleTimer = clearIdleTimer;
  meta.scheduleIdleDisconnect = scheduleIdleDisconnect;
  meta.markDead = markDead;

  const proxy = new Proxy(real, {
    get(target, prop, receiver) {
      const value = Reflect.get(target, prop, receiver);

      // Bukan method (properti biasa, mis. .session) -> teruskan apa adanya
      if (typeof value !== 'function') return value;

      if (prop === 'connect') {
        return async function (...args) {
          clearIdleTimer();
          await ensureConnected();
          scheduleIdleDisconnect();
          return true;
        };
      }
      if (prop === 'disconnect') {
        return async function (...args) {
          clearIdleTimer();
          meta.busyCount = 0; // disconnect manual membatalkan semua "busy" yang tercatat
          meta.pinCount = 0; // idem untuk pin, biar gak nyangkut kalau ada logic error di caller
          return value.apply(target, args);
        };
      }

      // Semua method lain: pastikan konek dulu (auto reconnect kalau perlu),
      // baru jalankan method aslinya. Setelah selesai, jadwalkan lagi
      // idle-disconnect kalau memang sudah gak ada yang pakai/pin.
      return async function (...args) {
        if (meta.dead) {
          throw new Error(`Userbot ${ownerId} sudah dinonaktifkan (${meta.deadReason || 'dead'})`);
        }
        clearIdleTimer();
        meta.busyCount++;
        try {
          await ensureConnected();
          return await value.apply(target, args);
        } catch (e) {
          // Error fatal bisa saja muncul BUKAN dari proses connect (mis.
          // request tiba-tiba ditolak karena session baru saja di-revoke).
          // FLOOD_WAIT/error jaringan sementara TIDAK pernah menandai
          // dead -> itu bukan tanda session rusak, cuma lagi kena limit.
          if (isFatalAuthError(e)) {
            markDead(e.errorMessage || e.message || 'fatal_auth_error');
          }
          throw e;
        } finally {
          meta.busyCount--;
          if (meta.busyCount === 0) scheduleIdleDisconnect();
        }
      };
    },
  });

  meta.proxy = proxy;
  registry.set(ownerId, meta);

  return proxy;
}

/**
 * Kunci koneksi supaya TIDAK di-disconnect otomatis walau lagi idle
 * sesaat di antara pemanggilan method (mis. selama 1 ronde broadcast
 * berjalan). WAJIB dipasangkan dengan unpin() di blok finally, supaya
 * auto-share tidak pernah "lupa" melepas kuncinya kalau terjadi error.
 */
function pin(ownerId) {
  const meta = registry.get(String(ownerId));
  if (!meta) return;
  meta.pinCount++;
  meta.clearIdleTimer();
}

function unpin(ownerId) {
  const meta = registry.get(String(ownerId));
  if (!meta) return;
  meta.pinCount = Math.max(0, meta.pinCount - 1);
  if (meta.pinCount === 0 && meta.busyCount === 0) {
    meta.scheduleIdleDisconnect();
  }
}

/**
 * Cek status koneksi saat ini (mis. buat ditampilkan di menu status).
 */
function isConnected(ownerId) {
  const meta = registry.get(String(ownerId));
  return !!(meta && !meta.dead && meta.real.connected);
}

/**
 * Cek apakah userbot ini sudah ditandai mati permanen (session invalid /
 * kehabisan retry). Berguna sebelum memanggil method supaya kode
 * pemanggil bisa langsung kasih pesan yang jelas ke user, tanpa perlu
 * nunggu exception dulu.
 */
function isDead(ownerId) {
  const meta = registry.get(String(ownerId));
  return !!(meta && meta.dead);
}

function getDeadReason(ownerId) {
  const meta = registry.get(String(ownerId));
  return meta ? meta.deadReason : null;
}

/**
 * Ringkasan status satu userbot dalam satu pemanggilan -> praktis
 * dipakai di menu status/monitoring tanpa harus panggil 3 fungsi terpisah.
 */
function getStatus(ownerId) {
  const meta = registry.get(String(ownerId));
  if (!meta) {
    return { registered: false, connected: false, dead: false, deadReason: null, pinCount: 0, busyCount: 0 };
  }
  return {
    registered: true,
    connected: !!meta.real.connected,
    dead: meta.dead,
    deadReason: meta.deadReason,
    pinCount: meta.pinCount,
    busyCount: meta.busyCount,
  };
}

/**
 * Bersihin state (dipanggil pas userbot logout/dihapus/cleanup)
 * supaya nggak ada timer yang nyangkut nganggur di memori.
 */
function remove(ownerId) {
  ownerId = String(ownerId);
  const meta = registry.get(ownerId);
  if (meta) {
    meta.clearIdleTimer();
    try {
      if (meta.real.connected) meta.real.disconnect().catch(() => {});
    } catch (e) {}
  }
  registry.delete(ownerId);
}

/**
 * Ringkasan seluruh registry, berguna buat command debug/monitoring
 * (mis. /status khusus owner bot).
 */
function stats() {
  const out = [];
  for (const [ownerId, meta] of registry.entries()) {
    out.push({
      ownerId,
      connected: !!meta.real.connected,
      pinCount: meta.pinCount,
      busyCount: meta.busyCount,
      dead: meta.dead,
      deadReason: meta.deadReason,
    });
  }
  return out;
}

module.exports = {
  createLazyClient,
  pin,
  unpin,
  isConnected,
  isDead,
  getDeadReason,
  getStatus,
  remove,
  setLogger,
  onDead,
  stats,
  isFatalAuthError,
  isTransientError,
  getFloodWaitSeconds,
  IDLE_DISCONNECT_MS,
};
