const chalk = require('chalk');
const fs = require('fs');
const path = require('path');
const moment = require('moment');

// BUG FIX: LOGS_DIR sebelumnya path relatif ('./database/logs'), yang
// di-resolve terhadap process.cwd() (bisa beda-beda tergantung dari mana
// proses dijalankan, mis. pm2 start dari /root), bukan terhadap lokasi file
// ini. Kalau cwd beda, folder ini nunjuk ke tempat yang salah/gak ada ->
// appendFileSync ENOENT diam-diam (di-catch kosong di writeToFile). Diganti
// absolut berbasis __dirname biar selalu konsisten ke folder project.
const LOGS_DIR = path.join(__dirname, '../database/logs');
// BUG FIX: sebelumnya di sini ada `require('../modules/index.js').bot`.
// Itu circular require (index.js require logger.js, logger.js require balik
// index.js) DAN index.js gak pernah punya `module.exports.bot` sama sekali -
// jadi `bot` di logger.js SELALU undefined, bikin sendErrorToOwner() gak
// pernah berhasil kirim notif error ke owner (diam-diam gagal terus, gak
// ada pesan apapun). Sekarang bot instance di-set dari index.js lewat
// setBotInstance() setelah bot beneran dibuat, bukan lewat require balik.
let bot = null;
let ownerId = null;
function setBotInstance(botInstance) {
  bot = botInstance;
}
function setOwnerId(id) {
  ownerId = id;
}

if (!fs.existsSync(LOGS_DIR)) {
  fs.mkdirSync(LOGS_DIR, { recursive: true });
}

async function sendErrorToOwner(errorDetails) {
  try {
    // BUG FIX: sebelumnya pakai process.env.OWNER_ID, padahal OWNER_ID cuma
    // ada sebagai konstanta di setting/config.js, BUKAN environment variable
    // -> selalu undefined, notif error ke owner gak pernah kekirim sama
    // sekali (gagal diam-diam). Sekarang di-set dari index.js lewat setOwnerId().
    if (!bot || !ownerId) return;
    
    const message = `
<blockquote>🔥 <b><u>ERROR DETEKSI</u></b></blockquote>
<blockquote>
<b>📝 Pesan</b> : ${errorDetails.message}
<b>📍 Lokasi</b> : ${errorDetails.location || 'Unknown'}
<b>📅 Waktu</b> : ${moment().format('DD/MM/YYYY HH:mm:ss')}
${errorDetails.stack ? `<b>📚 Stack</b> : <code>${errorDetails.stack.substring(0, 500)}</code>` : ''}</blockquote>`;

    await bot.sendMessage(ownerId, message, { parse_mode: 'HTML' });
  } catch (err) {
    console.error('Gagal kirim error ke owner:', err.message);
  }
}

// BUG FIX: hampir SEMUA pemanggilan logger.error()/warn() di seluruh project
// (index.js dkk) manggilnya kayak console.error(pesan, errorObjectOrStack) —
// argumen kedua langsung berupa Error object / string stack, BUKAN object
// {user, action, error, stack} kayak yang diharapkan fungsi ini. Akibatnya
// data.stack / data.error selalu undefined dan detail error-nya HILANG dari
// console — makanya di log cuma nongol judulnya doang ("message handler
// error (userId=..., text="..."):") tanpa keterangan errornya sama sekali.
// Fungsi ini sekarang normalize dulu: kalau argumen kedua bukan plain object
// biasa (string / Error / apapun), otomatis dibungkus jadi { error, stack }.
function normalizeLogData(raw) {
  if (raw === undefined || raw === null) return {};
  if (raw instanceof Error) {
    return { error: raw.message, stack: raw.stack };
  }
  if (typeof raw === 'string') {
    // String panjang berformat stack trace ("Error: ...\n    at ...") vs pesan pendek biasa.
    return raw.includes('\n') || raw.length > 150 ? { stack: raw } : { error: raw };
  }
  if (typeof raw === 'object') {
    // Object kosong (default {} karena caller cuma kirim 1 argumen) -> anggap "gak ada data tambahan".
    if (Object.keys(raw).length === 0) return {};
    // Kalau ini plain data object beneran (punya salah satu key yang dikenal), pakai apa adanya.
    if ('user' in raw || 'action' in raw || 'error' in raw || 'stack' in raw || 'duration' in raw) {
      return raw;
    }
    // Object lain (misal hasil JSON.parse dsb) — tetap tampilkan sebagai error biar gak hilang.
    try {
      return { error: JSON.stringify(raw) };
    } catch (e) {
      return { error: String(raw) };
    }
  }
  return { error: String(raw) };
}

const logger = {
  info: (message, data = {}) => {
    data = normalizeLogData(data);
    const timestamp = moment().format('HH:mm:ss');
    console.log(chalk.hex('#00CED1')('╭────────────────────────────────────────────╮'));
    console.log(chalk.hex('#00CED1')(`│ ${chalk.bgHex('#00CED1').black(' INFO ')}  │ ${chalk.hex('#FFFFFF')(timestamp)}`));
    console.log(chalk.hex('#00CED1')('├────────────────────────────────────────────┤'));
    console.log(chalk.hex('#00CED1')(`│ ${chalk.hex('#FFFFFF')('📝')} ${chalk.hex('#E0E0E0')(message)}`));
    if (data.user) console.log(chalk.hex('#00CED1')(`│ ${chalk.hex('#FF69B4')('👤 User:')} ${chalk.hex('#FFFFFF')(data.user)}`));
    if (data.action) console.log(chalk.hex('#00CED1')(`│ ${chalk.hex('#FFD700')('⚡ Action:')} ${chalk.hex('#FFFFFF')(data.action)}`));
    if (data.duration) console.log(chalk.hex('#00CED1')(`│ ${chalk.hex('#00BFFF')('⏱️ Duration:')} ${chalk.hex('#FFFFFF')(data.duration)}ms`));
    console.log(chalk.hex('#00CED1')('└────────────────────────────────────────────╯'));
    logger.writeToFile('INFO', message, data);
  },
  
  error: (message, data = {}) => {
    data = normalizeLogData(data);
    const timestamp = moment().format('HH:mm:ss');
    console.log(chalk.hex('#FF4444')('╭────────────────────────────────────────────╮'));
    console.log(chalk.hex('#FF4444')(`│ ${chalk.bgHex('#FF4444').black(' ERROR ')} │ ${chalk.hex('#FFFFFF')(timestamp)}`));
    console.log(chalk.hex('#FF4444')('├────────────────────────────────────────────┤'));
    console.log(chalk.hex('#FF4444')(`│ ${chalk.hex('#FFFFFF')('❌')} ${chalk.hex('#FF8888')(message)}`));
    if (data.user) console.log(chalk.hex('#FF4444')(`│ ${chalk.hex('#FF69B4')('👤 User:')} ${chalk.hex('#FFFFFF')(data.user)}`));
    if (data.action) console.log(chalk.hex('#FF4444')(`│ ${chalk.hex('#FFD700')('⚡ Action:')} ${chalk.hex('#FFFFFF')(data.action)}`));
    if (data.error) console.log(chalk.hex('#FF4444')(`│ ${chalk.hex('#FF8888')('⚠️ Error:')} ${chalk.hex('#FFFFFF')(data.error)}`));
    if (data.stack) console.log(chalk.hex('#FF4444')(`│ ${chalk.hex('#FF8888')('📚 Stack:')} ${chalk.hex('#FFFFFF')(data.stack.substring(0, 500))}`));
    console.log(chalk.hex('#FF4444')('└────────────────────────────────────────────╯'));
    logger.writeToFile('ERROR', message, data);
    
    sendErrorToOwner({
      message: message,
      location: data.action || 'Unknown',
      stack: data.stack || data.error,
      user: data.user
    });
  },
  
  warn: (message, data = {}) => {
    data = normalizeLogData(data);
    const timestamp = moment().format('HH:mm:ss');
    console.log(chalk.hex('#FFA500')('╭────────────────────────────────────────────╮'));
    console.log(chalk.hex('#FFA500')(`│ ${chalk.bgHex('#FFA500').black(' WARN ')}  │ ${chalk.hex('#FFFFFF')(timestamp)}`));
    console.log(chalk.hex('#FFA500')('├────────────────────────────────────────────┤'));
    console.log(chalk.hex('#FFA500')(`│ ${chalk.hex('#FFFFFF')('⚠️')} ${chalk.hex('#FFD700')(message)}`));
    if (data.user) console.log(chalk.hex('#FFA500')(`│ ${chalk.hex('#FF69B4')('👤 User:')} ${chalk.hex('#FFFFFF')(data.user)}`));
    if (data.action) console.log(chalk.hex('#FFA500')(`│ ${chalk.hex('#FFD700')('⚡ Action:')} ${chalk.hex('#FFFFFF')(data.action)}`));
    if (data.error) console.log(chalk.hex('#FFA500')(`│ ${chalk.hex('#FF8888')('⚠️ Error:')} ${chalk.hex('#FFFFFF')(data.error)}`));
    console.log(chalk.hex('#FFA500')('└────────────────────────────────────────────╯'));
    logger.writeToFile('WARN', message, data);
  },
  
  success: (message, data = {}) => {
    data = normalizeLogData(data);
    const timestamp = moment().format('HH:mm:ss');
    console.log(chalk.hex('#00FF88')('╭────────────────────────────────────────────╮'));
    console.log(chalk.hex('#00FF88')(`│ ${chalk.bgHex('#00FF88').black(' SUCCESS ')} │ ${chalk.hex('#FFFFFF')(timestamp)}`));
    console.log(chalk.hex('#00FF88')('├────────────────────────────────────────────┤'));
    console.log(chalk.hex('#00FF88')(`│ ${chalk.hex('#FFFFFF')('✔️')} ${chalk.hex('#90EE90')(message)}`));
    if (data.user) console.log(chalk.hex('#00FF88')(`│ ${chalk.hex('#FF69B4')('👤 User:')} ${chalk.hex('#FFFFFF')(data.user)}`));
    if (data.action) console.log(chalk.hex('#00FF88')(`│ ${chalk.hex('#FFD700')('⚡ Action:')} ${chalk.hex('#FFFFFF')(data.action)}`));
    console.log(chalk.hex('#00FF88')('└────────────────────────────────────────────╯'));
    logger.writeToFile('SUCCESS', message, data);
  },
  
  debug: (message, data = {}) => {
    data = normalizeLogData(data);
    const timestamp = moment().format('HH:mm:ss');
    console.log(chalk.hex('#9B59B6')('╭────────────────────────────────────────────╮'));
    console.log(chalk.hex('#9B59B6')(`│ ${chalk.bgHex('#9B59B6').black(' DEBUG ')} │ ${chalk.hex('#FFFFFF')(timestamp)}`));
    console.log(chalk.hex('#9B59B6')('├────────────────────────────────────────────┤'));
    console.log(chalk.hex('#9B59B6')(`│ ${chalk.hex('#FFFFFF')('🔧')} ${chalk.hex('#D291BC')(message)}`));
    if (data.user) console.log(chalk.hex('#9B59B6')(`│ ${chalk.hex('#FF69B4')('👤 User:')} ${chalk.hex('#FFFFFF')(data.user)}`));
    console.log(chalk.hex('#9B59B6')('└────────────────────────────────────────────╯'));
    logger.writeToFile('DEBUG', message, data);
  },
  
  writeToFile: (level, message, data = {}) => {
    try {
      const timestamp = new Date().toISOString();
      const logEntry = {
        timestamp,
        level,
        message,
        ...data
      };
      
      const combinedLog = path.join(LOGS_DIR, 'combined.log');
      fs.appendFileSync(combinedLog, JSON.stringify(logEntry) + '\n');
      
      if (level === 'ERROR') {
        const errorLog = path.join(LOGS_DIR, 'error.log');
        fs.appendFileSync(errorLog, JSON.stringify(logEntry) + '\n');
      }
      
      const stats = fs.statSync(combinedLog);
      if (stats.size > 5 * 1024 * 1024) {
        const backup = path.join(LOGS_DIR, `combined_${Date.now()}.log`);
        fs.renameSync(combinedLog, backup);
        
        const files = fs.readdirSync(LOGS_DIR);
        const backups = files.filter(f => f.startsWith('combined_') && f.endsWith('.log')).sort();
        while (backups.length > 5) {
          const oldest = backups.shift();
          fs.unlinkSync(path.join(LOGS_DIR, oldest));
        }
      }
    } catch (err) {}
  }
};

module.exports = logger;
module.exports.setBotInstance = setBotInstance;
module.exports.setOwnerId = setOwnerId;