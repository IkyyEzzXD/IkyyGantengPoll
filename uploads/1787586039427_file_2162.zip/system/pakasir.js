/**
 * pakasir.js
 * ------------------------------------------------------------------
 * Wrapper tipis untuk Payment Gateway Pakasir (https://pakasir.com).
 * Dipakai untuk fitur deposit saldo otomatis (QRIS) di bot.
 *
 * Referensi resmi: https://pakasir.com/p/docs
 *
 * Cara pakai:
 *   const pakasir = require('../system/pakasir')(PAKASIR_SLUG, PAKASIR_APIKEY);
 *   const payment = await pakasir.createPayment('qris', orderId, amount);
 *   const detail  = await pakasir.detailPayment(orderId, amount);
 *   const cancel  = await pakasir.cancelPayment(orderId, amount);
 * ------------------------------------------------------------------
 */

const axios = require('axios');

const BASE_URL = 'https://app.pakasir.com';
const REQUEST_TIMEOUT_MS = 15000;

// Method pembayaran yang valid sesuai dokumentasi Pakasir.
const VALID_METHODS = [
  'qris',
  'cimb_niaga_va',
  'bni_va',
  'sampoerna_va',
  'bnc_va',
  'maybank_va',
  'permata_va',
  'atm_bersama_va',
  'artha_graha_va',
  'bri_va',
];

function buildClient(slug, apiKey) {
  if (!slug || !apiKey) {
    throw new Error('PAKASIR_SLUG dan PAKASIR_APIKEY wajib diisi di config sebelum pakai fitur deposit otomatis.');
  }

  const http = axios.create({
    baseURL: BASE_URL,
    timeout: REQUEST_TIMEOUT_MS,
    headers: { 'Content-Type': 'application/json' },
  });

  /**
   * Buat transaksi pembayaran baru.
   * @param {string} method - salah satu dari VALID_METHODS (default: 'qris')
   * @param {string} orderId - ID unik transaksi di sistem kita
   * @param {number} amount - nominal dalam Rupiah (integer, tanpa titik/koma)
   */
  async function createPayment(method, orderId, amount) {
    const paymentMethod = (method || 'qris').toLowerCase();
    if (!VALID_METHODS.includes(paymentMethod)) {
      throw new Error(`Metode pembayaran "${paymentMethod}" tidak valid. Pilihan: ${VALID_METHODS.join(', ')}`);
    }
    if (!orderId) throw new Error('orderId wajib diisi');
    const numericAmount = Math.round(Number(amount));
    if (!numericAmount || numericAmount <= 0) {
      throw new Error('amount harus berupa angka positif');
    }

    const res = await http.post(`/api/transactioncreate/${paymentMethod}`, {
      project: slug,
      order_id: orderId,
      amount: numericAmount,
      api_key: apiKey,
    });

    const payment = res.data && res.data.payment;
    if (!payment) return null;

    // Dokumentasi resmi tidak selalu mengembalikan payment_url langsung,
    // jadi kita bangun sendiri sebagai fallback (halaman checkout hosted).
    const fallbackUrl = `${BASE_URL}/pay/${slug}/${numericAmount}?order_id=${encodeURIComponent(orderId)}&qris_only=1`;

    return {
      order_id: payment.order_id,
      amount: payment.amount,
      fee: payment.fee,
      total_payment: payment.total_payment,
      payment_method: payment.payment_method,
      payment_number: payment.payment_number,
      payment_url: payment.payment_url || fallbackUrl,
      expired_at: payment.expired_at,
    };
  }

  /**
   * Ambil detail/status transaksi.
   * @param {string} orderId
   * @param {number} amount - nominal HARUS sama persis dengan saat createPayment
   */
  async function detailPayment(orderId, amount) {
    if (!orderId) throw new Error('orderId wajib diisi');
    const res = await http.get('/api/transactiondetail', {
      params: {
        project: slug,
        amount: Math.round(Number(amount) || 0),
        order_id: orderId,
        api_key: apiKey,
      },
    });

    const tx = res.data && res.data.transaction;
    if (!tx) return null;

    return {
      order_id: tx.order_id,
      amount: tx.amount,
      total_payment: tx.total_payment || tx.amount,
      project: tx.project,
      status: tx.status, // 'pending' | 'completed' | 'canceled' (sesuai API)
      payment_method: tx.payment_method,
      completed_at: tx.completed_at,
      expired_at: tx.expired_at,
    };
  }

  /**
   * Batalkan transaksi yang masih pending.
   *
   * PENTING: endpoint /api/transactioncancel Pakasir TIDAK selalu balas
   * body yang mengandung "order_id" (kadang cuma `{ success: true }` atau
   * `{ status: "canceled" }`). Kode lama mewajibkan `result.order_id` ada,
   * jadi pembatalan yang sebenarnya SUKSES di sisi Pakasir tetap dianggap
   * gagal oleh bot. Sekarang kita terima beberapa bentuk respons yang
   * menandakan sukses, dan baru anggap null kalau memang tidak ada
   * penanda sukses sama sekali.
   */
  async function cancelPayment(orderId, amount) {
    if (!orderId) throw new Error('orderId wajib diisi');

    let res;
    try {
      res = await http.post('/api/transactioncancel', {
        project: slug,
        order_id: orderId,
        amount: Math.round(Number(amount) || 0),
        api_key: apiKey,
      });
    } catch (err) {
      // Kalau Pakasir sudah menganggap transaksi ini tidak lagi pending
      // (contoh: sudah expired/completed/dibatalkan sebelumnya), API bisa
      // saja balas 4xx dengan pesan spesifik. Kita lempar pesan asli dari
      // Pakasir (kalau ada) supaya errornya informatif, bukan cuma
      // "Request failed with status code 400".
      const apiMessage = err.response && err.response.data &&
        (err.response.data.message || err.response.data.error);
      if (apiMessage) throw new Error(apiMessage);
      throw err;
    }

    const body = res.data || {};
    const result = body.transaction || body.payment || body;

    const isExplicitSuccess = body.success === true || result.success === true;
    const hasSuccessStatus = result.status === 'canceled' || result.status === 'cancelled';
    const hasOrderId = !!result.order_id;

    if (!isExplicitSuccess && !hasSuccessStatus && !hasOrderId) {
      return null;
    }

    return {
      order_id: result.order_id || orderId,
      status: result.status || 'canceled',
      success: true,
    };
  }

  return { createPayment, detailPayment, cancelPayment, VALID_METHODS };
}

module.exports = buildClient;
