const API = 'https://www.sankavollerei.com/anime';
const PLACEHOLDER = 'https://placehold.co/400x600/1a1a1a/E50914?text=No+Image';

const defaultHeaders = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'application/json',
    'Referer': 'https://www.sankavollerei.com/',
};

let currentTab = 'home';
let currentAnime = null;
let currentAnimeSlug = null;
let episodesList = [];
let currentEpisodeIndex = 0;
let currentEpisodeData = null;
let serversList = [];
let currentServer = null;

let allAnimeList = [];
let displayedCount = 0;
let isLoadingMore = false;
let totalAnimeCount = 0;
let scrollObserver = null;

const content = document.getElementById('content');
const searchInput = document.getElementById('searchInput');

function setActiveNav(tab) {
    document.getElementById('navHome').classList.remove('active');
    document.getElementById('navAll').classList.remove('active');
    document.getElementById('navOngoing').classList.remove('active');
    document.getElementById('navComplete').classList.remove('active');
    if (tab === 'home') document.getElementById('navHome').classList.add('active');
    if (tab === 'all') document.getElementById('navAll').classList.add('active');
    if (tab === 'ongoing') document.getElementById('navOngoing').classList.add('active');
    if (tab === 'complete') document.getElementById('navComplete').classList.add('active');
}

function showLoading() {
    content.innerHTML = `<div class="loading"><div class="spinner"></div><p>Memuat 4NHUB...</p></div>`;
}

function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>]/g, function(m) {
        if (m === '&') return '&amp;';
        if (m === '<') return '&lt;';
        if (m === '>') return '&gt;';
        return m;
    });
}

function getPosterUrl(poster) {
    if (!poster) return PLACEHOLDER;
    if (poster.startsWith('http://') || poster.startsWith('https://')) {
        return poster;
    }
    return `https://www.sankavollerei.com${poster.startsWith('/') ? poster : '/' + poster}`;
}

async function fetchAPI(url) {
    try {
        const res = await fetch(url, { headers: defaultHeaders });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        return await res.json();
    } catch(e) {
        console.error('Fetch error:', e);
        return null;
    }
}

async function loadHome() {
    currentTab = 'home';
    setActiveNav('home');
    showLoading();

    const data = await fetchAPI(`${API}/home`);
    if (!data || !data.data) {
        content.innerHTML = `<div class="error-box"><i class="fas fa-exclamation-triangle" style="font-size:48px; color:#E50914"></i><p>Gagal memuat data</p><button class="retry-btn" onclick="loadHome()">Coba Lagi</button></div>`;
        return;
    }

    const ongoing = (data.data.ongoing?.animeList || []).slice(0, 10);
    const complete = (data.data.completed?.animeList || []).slice(0, 10);

    const allAnime = [...(data.data.ongoing?.animeList || []), ...(data.data.completed?.animeList || [])];
    const recommendations = allAnime.slice(0, 8);

    content.innerHTML = `
        <div class="section">
            <div class="section-title">
                <span>📺 Ongoing</span>
                <span style="font-size:12px; color:#aaa;">${ongoing.length} judul</span>
            </div>
            <div class="scroll-horizontal">
                ${ongoing.map(a => `
                    <div class="scroll-card" onclick="loadAnimeDetail('${a.animeId || ''}')">
                        <img src="${getPosterUrl(a.poster)}" onerror="this.src='${PLACEHOLDER}'; this.onerror=null;">
                        <div class="title">${escapeHtml(a.title || '?')}</div>
                    </div>
                `).join('')}
            </div>
        </div>
        <div class="section">
            <div class="section-title">
                <span>✅ Complete</span>
                <span style="font-size:12px; color:#aaa;">${complete.length} judul</span>
            </div>
            <div class="scroll-horizontal">
                ${complete.map(a => `
                    <div class="scroll-card" onclick="loadAnimeDetail('${a.animeId || ''}')">
                        <img src="${getPosterUrl(a.poster)}" onerror="this.src='${PLACEHOLDER}'; this.onerror=null;">
                        <div class="title">${escapeHtml(a.title || '?')}</div>
                    </div>
                `).join('')}
            </div>
        </div>
        <div class="section">
            <div class="section-title">🔥 Rekomendasi Untukmu</div>
            <div class="anime-grid">
                ${recommendations.map(a => `
                    <div class="anime-card" onclick="loadAnimeDetail('${a.animeId || ''}')">
                        <img src="${getPosterUrl(a.poster)}" onerror="this.src='${PLACEHOLDER}'; this.onerror=null;">
                        <div class="title">${escapeHtml(a.title || '?')}</div>
                    </div>
                `).join('')}
            </div>
        </div>
    `;
}

async function loadAllAnime() {
    currentTab = 'all';
    setActiveNav('all');
    showLoading();

    allAnimeList = [];
    displayedCount = 0;
    totalAnimeCount = 0;

    if (scrollObserver) {
        scrollObserver.disconnect();
    }

    const combinedMap = new Map();

    for (let page = 1; page <= 20; page++) {
        const data = await fetchAPI(`${API}/ongoing-anime?page=${page}`);
        if (!data?.data?.animeList || data.data.animeList.length === 0) break;

        for (const a of data.data.animeList) {
            if (a && a.animeId && !combinedMap.has(a.animeId)) {
                combinedMap.set(a.animeId, {
                    id: a.animeId,
                    title: a.title || 'Unknown',
                    poster: getPosterUrl(a.poster)
                });
            }
        }
        await new Promise(r => setTimeout(r, 200));
    }

    for (let page = 1; page <= 20; page++) {
        const data = await fetchAPI(`${API}/complete-anime?page=${page}`);
        if (!data?.data?.animeList || data.data.animeList.length === 0) break;

        for (const a of data.data.animeList) {
            if (a && a.animeId && !combinedMap.has(a.animeId)) {
                combinedMap.set(a.animeId, {
                    id: a.animeId,
                    title: a.title || 'Unknown',
                    poster: getPosterUrl(a.poster)
                });
            }
        }
        await new Promise(r => setTimeout(r, 200));
    }

    allAnimeList = Array.from(combinedMap.values());
    totalAnimeCount = allAnimeList.length;

    if (allAnimeList.length === 0) {
        content.innerHTML = `<div class="error-box">
            <i class="fas fa-exclamation-triangle" style="font-size:48px; color:#E50914"></i>
            <p>Gagal memuat daftar anime</p>
            <button class="retry-btn" onclick="loadAllAnime()">Coba Lagi</button>
        </div>`;
        return;
    }

    renderAllAnimeGrid();
    setupInfiniteScroll();
}

function renderAllAnimeGrid() {
    const itemsPerLoad = 24;
    const animeToShow = allAnimeList.slice(0, displayedCount + itemsPerLoad);
    displayedCount = animeToShow.length;
    const hasMore = displayedCount < totalAnimeCount;

    const gridHtml = `
        <div class="section-title">
            <span>📋 Semua Anime</span>
            <span class="total-count">${totalAnimeCount} judul</span>
        </div>
        <div class="anime-grid" id="animeGrid">
            ${animeToShow.map(a => `
                <div class="anime-card" onclick="loadAnimeDetail('${a.id}')">
                    <img src="${a.poster}" loading="lazy" onerror="this.src='${PLACEHOLDER}'; this.onerror=null;">
                    <div class="title">${escapeHtml(a.title)}</div>
                </div>
            `).join('')}
        </div>
        ${hasMore ? `<div id="loadMoreTrigger" class="loading-more"><i class="fas fa-spinner fa-pulse"></i> Scroll untuk memuat lebih banyak...</div>` : `
            <div class="loading-more"><i class="fas fa-check-circle"></i> Semua anime telah dimuat (${totalAnimeCount} judul)</div>
        `}
    `;

    if (document.getElementById('animeGrid')) {
        document.getElementById('animeGrid').innerHTML = animeToShow.map(a => `
            <div class="anime-card" onclick="loadAnimeDetail('${a.id}')">
                <img src="${a.poster}" loading="lazy" onerror="this.src='${PLACEHOLDER}'; this.onerror=null;">
                <div class="title">${escapeHtml(a.title)}</div>
            </div>
        `).join('');

        const trigger = document.getElementById('loadMoreTrigger');
        if (trigger) {
            if (hasMore) {
                trigger.innerHTML = `<i class="fas fa-spinner fa-pulse"></i> Scroll untuk memuat lebih banyak...`;
            } else {
                trigger.innerHTML = `<i class="fas fa-check-circle"></i> Semua anime telah dimuat (${totalAnimeCount} judul)`;
            }
        }
    } else {
        content.innerHTML = gridHtml;
    }
}

function loadMoreAnime() {
    if (isLoadingMore) return;
    if (displayedCount >= totalAnimeCount) return;

    isLoadingMore = true;

    const trigger = document.getElementById('loadMoreTrigger');
    if (trigger) {
        trigger.innerHTML = `<i class="fas fa-spinner fa-pulse"></i> Memuat lebih banyak anime...`;
    }

    setTimeout(() => {
        renderAllAnimeGrid();
        isLoadingMore = false;
    }, 300);
}

function setupInfiniteScroll() {
    const options = {
        root: null,
        rootMargin: '0px',
        threshold: 0.1
    };

    scrollObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting && !isLoadingMore && displayedCount < totalAnimeCount) {
                loadMoreAnime();
            }
        });
    }, options);

    const observeTrigger = () => {
        const trigger = document.getElementById('loadMoreTrigger');
        if (trigger) {
            scrollObserver.observe(trigger);
        }
    };

    setTimeout(observeTrigger, 100);

    const observerCallback = new MutationObserver(() => {
        const trigger = document.getElementById('loadMoreTrigger');
        if (trigger && !scrollObserver.observing) {
            scrollObserver.observe(trigger);
        }
    });
    observerCallback.observe(content, { childList: true, subtree: true });
}

async function loadAnimeDetail(slug) {
    if (!slug) {
        alert('Invalid anime');
        return;
    }
    showLoading();

    const data = await fetchAPI(`${API}/anime/${slug}`);
    if (!data || !data.data) {
        content.innerHTML = `<div class="error-box"><p>Gagal memuat detail</p><button class="retry-btn" onclick="loadHome()">Kembali</button></div>`;
        return;
    }

    currentAnime = data.data;
    currentAnimeSlug = slug;
    episodesList = data.data.episodeList || [];

    const anime = currentAnime;

    content.innerHTML = `
        <button class="back-btn" onclick="loadHome()"><i class="fas fa-arrow-left"></i> Kembali</button>
        <div class="detail-info">
            <div class="detail-poster">
                <img src="${getPosterUrl(anime.poster)}" onerror="this.src='${PLACEHOLDER}'; this.onerror=null;">
            </div>
            <div class="detail-text">
                <h2>${escapeHtml(anime.title || '-')}</h2>
                <p>${escapeHtml(anime.japanese || '')}</p>
                <p>⭐ ${anime.score || '-'} | ${anime.status || '-'} | ${anime.episodes || '-'} eps</p>
            </div>
        </div>
        <div class="section-title">📋 Daftar Episode</div>
        <div class="episode-grid">
            ${episodesList.map((ep, i) => `
                <div class="episode-btn" onclick="playEpisode(${i})">
                    <div>Episode ${ep.eps || i+1}</div>
                </div>
            `).join('')}
        </div>
    `;
}

async function playEpisode(index) {
    if (!episodesList[index]) return;

    currentEpisodeIndex = index;
    showLoading();

    const episode = episodesList[index];
    const data = await fetchAPI(`${API}/episode/${episode.episodeId}`);

    if (!data || !data.data) {
        content.innerHTML = `<div class="error-box"><p>Gagal memuat episode</p><button class="retry-btn" onclick="loadAnimeDetail('${currentAnimeSlug}')">Kembali</button></div>`;
        return;
    }

    currentEpisodeData = data.data;
    await parseServers();
    renderPlayerWithRotation();
    await autoPlay();
}

async function parseServers() {
    serversList = [];
    if (currentEpisodeData?.server?.qualities) {
        for (const q of currentEpisodeData.server.qualities) {
            for (const s of q.serverList) {
                serversList.push({
                    quality: q.title,
                    name: s.title,
                    id: s.serverId
                });
            }
        }
    }
}

async function getStreamUrl(serverId) {
    const data = await fetchAPI(`${API}/server/${serverId}`);
    return data?.data?.stream_url || data?.stream_url || null;
}

async function autoPlay() {
    for (const server of serversList) {
        const url = await getStreamUrl(server.id);
        if (url) {
            currentServer = server;
            const iframe = document.getElementById('videoFrame');
            if (iframe) iframe.src = url;
            updateServerButtons();
            return;
        }
    }
    if (currentEpisodeData?.defaultStreamingUrl) {
        const iframe = document.getElementById('videoFrame');
        if (iframe) iframe.src = currentEpisodeData.defaultStreamingUrl;
    }
}

async function changeServer(server) {
    const url = await getStreamUrl(server.id);
    if (url) {
        currentServer = server;
        const iframe = document.getElementById('videoFrame');
        if (iframe) iframe.src = url;
        updateServerButtons();
    }
}

function updateServerButtons() {
    const container = document.getElementById('serverList');
    if (!container) return;
    if (serversList.length === 0) {
        container.innerHTML = '<span style="color:#aaa">Tidak ada server</span>';
        return;
    }
    container.innerHTML = serversList.map(s => `
        <button class="server-btn ${currentServer?.id === s.id ? 'active' : ''}" 
                onclick="changeServer(${JSON.stringify(s).replace(/"/g, '&quot;')})">
            ${s.quality} • ${s.name}
        </button>
    `).join('');
}

function renderPlayerWithRotation() {
    const episode = episodesList[currentEpisodeIndex];
    const nextEp = currentEpisodeIndex < episodesList.length - 1 ? episodesList[currentEpisodeIndex + 1] : null;
    const prevEp = currentEpisodeIndex > 0 ? episodesList[currentEpisodeIndex - 1] : null;

    content.innerHTML = `
        <button class="back-btn" onclick="loadAnimeDetail('${currentAnimeSlug}')"><i class="fas fa-arrow-left"></i> Kembali</button>

        <div class="player-container" id="playerContainer">
            <div class="player-wrapper landscape" id="videoWrapper">
                <iframe id="videoFrame" src="" allowfullscreen></iframe>
            </div>
        </div>

        <div class="server-list" id="serverList">
            <span style="color:#aaa">Memuat server...</span>
        </div>

        <div class="nav-episode">
            ${prevEp ? `<button class="nav-btn" onclick="playEpisode(${currentEpisodeIndex-1})"><i class="fas fa-backward"></i> Prev</button>` : ''}
            ${nextEp ? `<button class="nav-btn" onclick="playEpisode(${currentEpisodeIndex+1})">Next <i class="fas fa-forward"></i></button>` : ''}
        </div>

        <div style="background:#1a1a1a; border-radius:12px; padding:16px; margin-top:16px">
            <div style="font-weight:bold">${escapeHtml(episode?.title || `Episode ${episode?.eps || currentEpisodeIndex+1}`)}</div>
        </div>
    `;
    updateServerButtons();
}

async function loadOngoing() {
    currentTab = 'ongoing';
    setActiveNav('ongoing');
    showLoading();

    const data = await fetchAPI(`${API}/ongoing-anime?page=1`);
    let animeList = [];

    if (data?.data?.animeList) {
        animeList = data.data.animeList.filter(a => a && a.animeId).map(a => ({
            id: a.animeId,
            title: a.title || 'Unknown',
            poster: getPosterUrl(a.poster)
        }));
    }

    if (animeList.length === 0) {
        content.innerHTML = `<div class="error-box"><p>Gagal memuat ongoing</p><button class="retry-btn" onclick="loadOngoing()">Coba Lagi</button></div>`;
        return;
    }

    content.innerHTML = `
        <div class="section-title">📺 Ongoing Anime (${animeList.length})</div>
        <div class="anime-grid">
            ${animeList.map(a => `
                <div class="anime-card" onclick="loadAnimeDetail('${a.id}')">
                    <img src="${a.poster}" loading="lazy" onerror="this.src='${PLACEHOLDER}'; this.onerror=null;">
                    <div class="title">${escapeHtml(a.title)}</div>
                </div>
            `).join('')}
        </div>
    `;
}

async function loadComplete() {
    currentTab = 'complete';
    setActiveNav('complete');
    showLoading();

    const data = await fetchAPI(`${API}/complete-anime?page=1`);
    let animeList = [];

    if (data?.data?.animeList) {
        animeList = data.data.animeList.filter(a => a && a.animeId).map(a => ({
            id: a.animeId,
            title: a.title || 'Unknown',
            poster: getPosterUrl(a.poster)
        }));
    }

    if (animeList.length === 0) {
        content.innerHTML = `<div class="error-box"><p>Gagal memuat complete</p><button class="retry-btn" onclick="loadComplete()">Coba Lagi</button></div>`;
        return;
    }

    content.innerHTML = `
        <div class="section-title">✅ Complete Anime (${animeList.length})</div>
        <div class="anime-grid">
            ${animeList.map(a => `
                <div class="anime-card" onclick="loadAnimeDetail('${a.id}')">
                    <img src="${a.poster}" loading="lazy" onerror="this.src='${PLACEHOLDER}'; this.onerror=null;">
                    <div class="title">${escapeHtml(a.title)}</div>
                </div>
            `).join('')}
        </div>
    `;
}

searchInput.addEventListener('keypress', async (e) => {
    if (e.key === 'Enter') {
        const query = searchInput.value.trim();
        if (!query) return loadHome();

        showLoading();
        const data = await fetchAPI(`${API}/search/${encodeURIComponent(query)}`);
        let animeList = [];

        if (data?.data?.animeList) {
            animeList = data.data.animeList.filter(a => a && a.animeId).map(a => ({
                id: a.animeId,
                title: a.title || 'Unknown',
                poster: getPosterUrl(a.poster)
            }));
        }

        if (animeList.length === 0) {
            content.innerHTML = `<div class="error-box"><p>🔍 Tidak ditemukan: "${escapeHtml(query)}"</p><button class="retry-btn" onclick="loadHome()">Kembali</button></div>`;
            return;
        }

        content.innerHTML = `
            <div class="section-title">🔍 Hasil: "${escapeHtml(query)}" (${animeList.length})</div>
            <div class="anime-grid">
                ${animeList.map(a => `
                    <div class="anime-card" onclick="loadAnimeDetail('${a.id}')">
                        <img src="${a.poster}" loading="lazy" onerror="this.src='${PLACEHOLDER}'; this.onerror=null;">
                        <div class="title">${escapeHtml(a.title)}</div>
                    </div>
                `).join('')}
            </div>
        `;
    }
});

loadHome();