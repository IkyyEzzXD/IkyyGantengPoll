const API_BASE = 'https://www.sankavollerei.com/anime/donghua';
const PLACEHOLDER = 'https://placehold.co/400x600/1a1a1a/666?text=No+Image';

const defaultHeaders = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'application/json',
    'Referer': 'https://www.sankavollerei.com/',
};

let currentTab = 'home';
let currentSlug = null;
let episodesList = [];
let currentEpisodeData = null;
let serversList = [];
let currentServer = null;

let allDonghuaList = [];
let displayedCount = 0;
let isLoadingMore = false;
let totalDonghuaCount = 0;
let scrollObserver = null;
let allDonghuaPage = 1;
let isLoadingAll = false;
let hasMoreAll = true;

const content = document.getElementById('content');
const searchInput = document.getElementById('searchInput');

function setActiveNav(tab) {
    document.getElementById('navHome').classList.remove('active');
    document.getElementById('navAll').classList.remove('active');
    document.getElementById('navOngoing').classList.remove('active');
    document.getElementById('navCompleted').classList.remove('active');
    if (tab === 'Home') document.getElementById('navHome').classList.add('active');
    if (tab === 'All') document.getElementById('navAll').classList.add('active');
    if (tab === 'Ongoing') document.getElementById('navOngoing').classList.add('active');
    if (tab === 'Completed') document.getElementById('navCompleted').classList.add('active');
}

function showLoading() {
    content.innerHTML = `<div class="loading"><div class="spinner"></div><p>Memuat Donghua...</p></div>`;
}

function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>]/g, function(m) {
        if (m === '&') return '&amp;';
        if (m === '<') return '&lt;';
        if (m === '>') return '&gt;';
        return m;
    });
}

function getPosterUrl(poster) {
    if (!poster) return PLACEHOLDER;
    if (poster.startsWith('http://') || poster.startsWith('https://')) {
        return poster;
    }
    return poster;
}

async function fetchAPI(url) {
    try {
        const res = await fetch(url, { headers: defaultHeaders });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        return await res.json();
    } catch(e) {
        console.error('Fetch error:', url, e);
        return null;
    }
}

async function loadHome() {
    currentTab = 'Home';
    setActiveNav('Home');
    showLoading();
    
    const data = await fetchAPI(`${API_BASE}/home/1`);
    if (!data) {
        content.innerHTML = `<div class="error-box"><i class="fas fa-exclamation-triangle" style="font-size:48px; color:#E50914"></i><p>Gagal memuat data</p><button class="retry-btn" onclick="loadHome()">Coba Lagi</button></div>`;
        return;
    }
    
    const latestRelease = data.latest_release || [];
    const completed = data.completed_donghua || [];
    
    content.innerHTML = `
        <div class="section">
            <div class="section-title">
                <span>🔥 Release Terbaru</span>
            </div>
            <div class="scroll-horizontal">
                ${latestRelease.map(a => `
                    <div class="scroll-card" onclick="playEpisodeBySlug('${a.slug?.replace(/\/$/, '') || ''}')">
                        <img src="${getPosterUrl(a.poster)}" onerror="this.src='${PLACEHOLDER}'; this.onerror=null;">
                        <div class="title">${escapeHtml(a.title || '?')}</div>
                    </div>
                `).join('')}
            </div>
        </div>
        <div class="section">
            <div class="section-title">
                <span>✅ Complete Donghua</span>
            </div>
            <div class="scroll-horizontal">
                ${completed.slice(0, 15).map(a => `
                    <div class="scroll-card" onclick="loadDetail('${a.slug?.replace(/\/$/, '') || ''}')">
                        <img src="${getPosterUrl(a.poster)}" onerror="this.src='${PLACEHOLDER}'; this.onerror=null;">
                        <div class="title">${escapeHtml(a.title || '?')}</div>
                    </div>
                `).join('')}
            </div>
        </div>
        <div class="section">
            <div class="section-title">🔥 Rekomendasi</div>
            <div class="anime-grid">
                ${[...latestRelease, ...completed].slice(0, 8).map(a => `
                    <div class="anime-card" onclick="loadDetail('${a.slug?.replace(/\/$/, '') || ''}')">
                        <img src="${getPosterUrl(a.poster)}" onerror="this.src='${PLACEHOLDER}'; this.onerror=null;">
                        <div class="title">${escapeHtml(a.title || '?')}</div>
                    </div>
                `).join('')}
            </div>
        </div>
    `;
}

async function loadAllDonghua() {
    currentTab = 'All';
    setActiveNav('All');
    showLoading();
    
    allDonghuaList = [];
    displayedCount = 0;
    totalDonghuaCount = 0;
    allDonghuaPage = 1;
    hasMoreAll = true;
    isLoadingAll = false;
    
    if (scrollObserver) scrollObserver.disconnect();
    
    await loadMoreAllDonghua();
}

async function loadMoreAllDonghua() {
    if (isLoadingAll) return;
    isLoadingAll = true;
    
    const combinedMap = new Map();
    
    const ongoingData = await fetchAPI(`${API_BASE}/ongoing/${allDonghuaPage}`);
    if (ongoingData?.ongoing_donghua) {
        for (const a of ongoingData.ongoing_donghua) {
            if (a && a.slug && !combinedMap.has(a.slug)) {
                combinedMap.set(a.slug, {
                    id: a.slug.replace(/\/$/, ''),
                    title: a.title || 'Unknown',
                    poster: getPosterUrl(a.poster)
                });
            }
        }
    }
    
    const completedData = await fetchAPI(`${API_BASE}/completed/${allDonghuaPage}`);
    if (completedData?.completed_donghua) {
        for (const a of completedData.completed_donghua) {
            if (a && a.slug && !combinedMap.has(a.slug)) {
                combinedMap.set(a.slug, {
                    id: a.slug.replace(/\/$/, ''),
                    title: a.title || 'Unknown',
                    poster: getPosterUrl(a.poster)
                });
            }
        }
    }
    
    const latestData = await fetchAPI(`${API_BASE}/latest/${allDonghuaPage}`);
    if (latestData?.latest_donghua) {
        for (const a of latestData.latest_donghua) {
            if (a && a.slug && !combinedMap.has(a.slug)) {
                combinedMap.set(a.slug, {
                    id: a.slug.replace(/\/$/, ''),
                    title: a.title || 'Unknown',
                    poster: getPosterUrl(a.poster)
                });
            }
        }
    }
    
    const newItems = Array.from(combinedMap.values());
    
    if (newItems.length === 0) {
        hasMoreAll = false;
        isLoadingAll = false;
        if (allDonghuaList.length === 0) {
            content.innerHTML = `<div class="error-box"><p>Gagal memuat daftar donghua</p><button class="retry-btn" onclick="loadAllDonghua()">Coba Lagi</button></div>`;
        }
        return;
    }
    
    const existingIds = new Set(allDonghuaList.map(item => item.id));
    for (const item of newItems) {
        if (!existingIds.has(item.id)) {
            allDonghuaList.push(item);
        }
    }
    
    totalDonghuaCount = allDonghuaList.length;
    allDonghuaPage++;
    
    if (newItems.length < 15) hasMoreAll = false;
    
    isLoadingAll = false;
    renderAllDonghuaGrid();
    setupInfiniteScrollAll();
}

function renderAllDonghuaGrid() {
    const itemsPerLoad = 24;
    const toShow = allDonghuaList.slice(0, displayedCount + itemsPerLoad);
    displayedCount = toShow.length;
    const hasMore = hasMoreAll || displayedCount < totalDonghuaCount;
    
    const html = `
        <div class="section-title">
            <span>📋 Semua Donghua</span>
            <span class="total-count">${totalDonghuaCount} judul</span>
        </div>
        <div class="anime-grid" id="donghuaGridAll">
            ${toShow.map(a => `
                <div class="anime-card" onclick="loadDetail('${a.id}')">
                    <img src="${a.poster}" loading="lazy" onerror="this.src='${PLACEHOLDER}'; this.onerror=null;">
                    <div class="title">${escapeHtml(a.title)}</div>
                </div>
            `).join('')}
        </div>
        ${hasMore ? `<div id="loadMoreTrigger" class="loading-more"><i class="fas fa-spinner fa-pulse"></i> Scroll untuk memuat lebih banyak...</div>` : `
            <div class="loading-more"><i class="fas fa-check-circle"></i> Semua donghua telah dimuat (${totalDonghuaCount} judul)</div>
        `}
    `;
    
    if (document.getElementById('donghuaGridAll')) {
        document.getElementById('donghuaGridAll').innerHTML = toShow.map(a => `
            <div class="anime-card" onclick="loadDetail('${a.id}')">
                <img src="${a.poster}" loading="lazy" onerror="this.src='${PLACEHOLDER}'; this.onerror=null;">
                <div class="title">${escapeHtml(a.title)}</div>
            </div>
        `).join('');
    } else {
        content.innerHTML = html;
    }
}

function setupInfiniteScrollAll() {
    if (scrollObserver) scrollObserver.disconnect();
    
    const options = { root: null, rootMargin: '100px', threshold: 0.1 };
    scrollObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting && !isLoadingAll) {
                if (displayedCount < totalDonghuaCount) {
                    renderAllDonghuaGrid();
                } else if (hasMoreAll) {
                    loadMoreAllDonghua();
                }
            }
        });
    }, options);
    
    setTimeout(() => {
        const trigger = document.getElementById('loadMoreTrigger');
        if (trigger) scrollObserver.observe(trigger);
    }, 100);
}

async function loadOngoing() {
    currentTab = 'Ongoing';
    setActiveNav('Ongoing');
    showLoading();
    
    let allOngoing = [];
    for (let page = 1; page <= 5; page++) {
        const data = await fetchAPI(`${API_BASE}/ongoing/${page}`);
        const list = data?.ongoing_donghua || [];
        if (list.length === 0) break;
        allOngoing = [...allOngoing, ...list];
        await new Promise(r => setTimeout(r, 200));
    }
    
    if (allOngoing.length === 0) {
        content.innerHTML = `<div class="error-box"><p>Gagal memuat ongoing</p><button class="retry-btn" onclick="loadOngoing()">Coba Lagi</button></div>`;
        return;
    }
    
    content.innerHTML = `
        <div class="section-title">
            <span>📺 Ongoing Donghua</span>
            <span class="total-count">${allOngoing.length} judul</span>
        </div>
        <div class="anime-grid">
            ${allOngoing.map(a => `
                <div class="anime-card" onclick="loadDetail('${a.slug?.replace(/\/$/, '') || ''}')">
                    <img src="${getPosterUrl(a.poster)}" onerror="this.src='${PLACEHOLDER}'; this.onerror=null;">
                    <div class="title">${escapeHtml(a.title || '?')}</div>
                </div>
            `).join('')}
        </div>
    `;
}

async function loadCompleted() {
    currentTab = 'Completed';
    setActiveNav('Completed');
    showLoading();
    
    let allCompleted = [];
    for (let page = 1; page <= 5; page++) {
        const data = await fetchAPI(`${API_BASE}/completed/${page}`);
        const list = data?.completed_donghua || [];
        if (list.length === 0) break;
        allCompleted = [...allCompleted, ...list];
        await new Promise(r => setTimeout(r, 200));
    }
    
    if (allCompleted.length === 0) {
        content.innerHTML = `<div class="error-box"><p>Gagal memuat complete</p><button class="retry-btn" onclick="loadCompleted()">Coba Lagi</button></div>`;
        return;
    }
    
    content.innerHTML = `
        <div class="section-title">
            <span>✅ Complete Donghua</span>
            <span class="total-count">${allCompleted.length} judul</span>
        </div>
        <div class="anime-grid">
            ${allCompleted.map(a => `
                <div class="anime-card" onclick="loadDetail('${a.slug?.replace(/\/$/, '') || ''}')">
                    <img src="${getPosterUrl(a.poster)}" onerror="this.src='${PLACEHOLDER}'; this.onerror=null;">
                    <div class="title">${escapeHtml(a.title || '?')}</div>
                </div>
            `).join('')}
        </div>
    `;
}

async function loadDetail(slug) {
    if (!slug) {
        alert('Invalid donghua');
        return;
    }
    showLoading();
    
    const data = await fetchAPI(`${API_BASE}/detail/${slug}`);
    if (!data) {
        content.innerHTML = `<div class="error-box"><p>Gagal memuat detail</p><button class="retry-btn" onclick="loadHome()">Kembali</button></div>`;
        return;
    }
    
    currentSlug = slug;
    episodesList = data.episodes_list || [];
    const genres = data.genres || [];
    
    content.innerHTML = `
        <button class="back-btn" onclick="loadHome()"><i class="fas fa-arrow-left"></i> Kembali</button>
        <div class="detail-info">
            <div class="detail-poster">
                <img src="${getPosterUrl(data.poster)}" onerror="this.src='${PLACEHOLDER}'; this.onerror=null;">
            </div>
            <div class="detail-text">
                <h2>${escapeHtml(data.title || '-')}</h2>
                <p>${escapeHtml(data.alter_title || '')}</p>
                <p>⭐ ${data.rating || '-'} | ${data.type || 'Donghua'} | ${data.episodes_count || '-'} eps</p>
                ${data.studio ? `<p>🎬 Studio: ${escapeHtml(data.studio)}</p>` : ''}
            </div>
        </div>
        ${genres.length ? `
            <div class="genre-list">
                ${genres.map(g => `<span class="genre-badge" onclick="searchByGenre('${g.slug}')">${escapeHtml(g.name)}</span>`).join('')}
            </div>
        ` : ''}
        ${data.synopsis ? `<div style="background:#1a1a1a; padding:16px; border-radius:12px; margin:16px 0; font-size:13px; line-height:1.5"><strong>Sinopsis:</strong><br>${escapeHtml(data.synopsis)}</div>` : ''}
        <div class="section-title">📋 Daftar Episode</div>
        <div class="episode-grid">
            ${episodesList.map((ep, i) => `
                <div class="episode-btn" onclick="playEpisodeBySlug('${ep.slug}')">
                    <div>Episode ${ep.episode?.match(/\d+/)?.[0] || i+1}</div>
                </div>
            `).join('')}
        </div>
    `;
}

async function playEpisodeBySlug(episodeSlug) {
    if (!episodeSlug) return;
    showLoading();
    
    const data = await fetchAPI(`${API_BASE}/episode/${episodeSlug}`);
    if (!data) {
        content.innerHTML = `<div class="error-box"><p>Gagal memuat episode</p><button class="retry-btn" onclick="loadHome()">Kembali</button></div>`;
        return;
    }
    
    currentEpisodeData = data;
    serversList = [];
    
    if (data.streaming?.servers && Array.isArray(data.streaming.servers)) {
        serversList = data.streaming.servers.map(s => ({ name: s.name, url: s.url }));
    }
    if (data.streaming?.main_url) {
        serversList.unshift({ name: data.streaming.main_url.name, url: data.streaming.main_url.url });
    }
    
    renderPlayer();
    
    if (serversList.length > 0) {
        currentServer = serversList[0];
        const iframe = document.getElementById('videoFrame');
        if (iframe) iframe.src = currentServer.url;
        updateServerButtons();
    }
}

function changeServer(server) {
    currentServer = server;
    const iframe = document.getElementById('videoFrame');
    if (iframe) iframe.src = server.url;
    updateServerButtons();
}

function updateServerButtons() {
    const container = document.getElementById('serverList');
    if (!container) return;
    if (serversList.length === 0) {
        container.innerHTML = '<span style="color:#aaa">Tidak ada server</span>';
        return;
    }
    container.innerHTML = serversList.map(s => `
        <button class="server-btn ${currentServer?.url === s.url ? 'active' : ''}" 
                onclick='changeServer(${JSON.stringify(s).replace(/'/g, "\\'")})'>
            ${s.name}
        </button>
    `).join('');
}

function renderPlayer() {
    const navigation = currentEpisodeData?.navigation || {};
    const prevSlug = navigation.previous_episode?.slug;
    const nextSlug = navigation.next_episode?.slug;
    const episodeTitle = currentEpisodeData?.episode || 'Now Playing';
    
    content.innerHTML = `
        <button class="back-btn" onclick="loadDetail('${currentSlug}')"><i class="fas fa-arrow-left"></i> Kembali</button>
        
        <div class="player-wrapper">
            <iframe id="videoFrame" src="" allowfullscreen></iframe>
        </div>
        
        <div class="server-list" id="serverList"></div>
        
        <div class="nav-episode">
            ${prevSlug ? `<button class="nav-btn" onclick="playEpisodeBySlug('${prevSlug}')"><i class="fas fa-backward"></i> Prev</button>` : ''}
            ${nextSlug ? `<button class="nav-btn" onclick="playEpisodeBySlug('${nextSlug}')">Next <i class="fas fa-forward"></i></button>` : ''}
        </div>
        
        <div style="background:#1a1a1a; border-radius:12px; padding:16px; margin-top:16px">
            <div style="font-weight:bold">${escapeHtml(episodeTitle)}</div>
            <div style="font-size:12px; color:#aaa; margin-top:8px">💡 Ganti server jika video tidak muncul</div>
        </div>
    `;
    updateServerButtons();
}

async function searchDonghua(query) {
    if (!query.trim()) return loadHome();
    showLoading();
    
    const data = await fetchAPI(`${API_BASE}/search/${encodeURIComponent(query)}`);
    let list = data?.data || [];
    if (Array.isArray(data)) list = data;
    
    if (list.length === 0) {
        content.innerHTML = `<div class="error-box"><p>🔍 Tidak ditemukan: "${escapeHtml(query)}"</p><button class="retry-btn" onclick="loadHome()">Kembali</button></div>`;
        return;
    }
    
    content.innerHTML = `
        <button class="back-btn" onclick="loadHome()"><i class="fas fa-arrow-left"></i> Kembali</button>
        <div class="section-title">🔍 Hasil: "${escapeHtml(query)}" (${list.length})</div>
        <div class="anime-grid">
            ${list.map(a => `
                <div class="anime-card" onclick="loadDetail('${a.slug || ''}')">
                    <img src="${getPosterUrl(a.poster)}" onerror="this.src='${PLACEHOLDER}'; this.onerror=null;">
                    <div class="title">${escapeHtml(a.title || '?')}</div>
                </div>
            `).join('')}
        </div>
    `;
}

async function searchByGenre(genreSlug) {
    showLoading();
    const data = await fetchAPI(`${API_BASE}/genres/${genreSlug}/1`);
    const list = data?.data || data?.animeList || [];
    
    if (list.length === 0) {
        content.innerHTML = `<div class="error-box"><p>Gagal memuat genre</p><button class="retry-btn" onclick="loadHome()">Kembali</button></div>`;
        return;
    }
    
    content.innerHTML = `
        <button class="back-btn" onclick="loadHome()"><i class="fas fa-arrow-left"></i> Kembali</button>
        <div class="section-title">🎭 Genre: ${escapeHtml(genreSlug)} (${list.length})</div>
        <div class="anime-grid">
            ${list.map(a => `
                <div class="anime-card" onclick="loadDetail('${a.slug || ''}')">
                    <img src="${getPosterUrl(a.poster)}" onerror="this.src='${PLACEHOLDER}'; this.onerror=null;">
                    <div class="title">${escapeHtml(a.title || '?')}</div>
                </div>
            `).join('')}
        </div>
    `;
}

searchInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') searchDonghua(searchInput.value);
});

loadHome();