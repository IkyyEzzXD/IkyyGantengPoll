(function(){
  const KEY = 'elinn_music';
  function loadState(){
    try { return JSON.parse(localStorage.getItem(KEY) || '{}') || {}; } catch { return {}; }
  }
  function saveState(state){
    try { localStorage.setItem(KEY, JSON.stringify(state || {})); } catch {}
  }
  function defaultTrack(){
    const cfg = window.ELINN_CONFIG || {};
    return {
      src: String(cfg.musicUrl || '/media/elinn-track.mp3').trim(),
      title: cfg.musicTitle || 'Elinn Signal Track',
      artist: cfg.musicArtist || 'Creator Elinn',
      volume: 0.7,
      position: 0,
      duration: 0,
      isPlaying: false,
      updatedAt: Date.now()
    };
  }
  window.MusicState = {
    save(state){ saveState(state); },
    load(){ return { ...defaultTrack(), ...loadState() }; },
    saveProgress(audioEl, extra={}){
      const current = this.load();
      const next = {
        ...current,
        ...(extra || {}),
        src: String(extra?.src || current.src || audioEl?.currentSrc || audioEl?.src || '').trim(),
        position: Number(audioEl?.currentTime || 0) || 0,
        duration: Number(audioEl?.duration || current.duration || 0) || 0,
        volume: Number(audioEl?.volume ?? current.volume ?? 0.7) || 0,
        isPlaying: !!(!audioEl?.paused && !audioEl?.ended),
        updatedAt: Date.now(),
      };
      saveState(next);
      return next;
    },
    resume(audioEl){
      const s = this.load();
      if(!audioEl || !s.src) return s;
      audioEl.src = s.src;
      try { audioEl.currentTime = Number(s.position || 0) || 0; } catch {}
      audioEl.volume = s.volume == null ? 0.7 : Number(s.volume || 0.7);
      if (s.isPlaying) audioEl.play().catch(() => {});
      return s;
    }
  };
})();
