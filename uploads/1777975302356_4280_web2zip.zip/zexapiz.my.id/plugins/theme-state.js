(function(){
  const root = document.documentElement;
  const ThemeState = window.ThemeState = {
    KEY: 'elinn_theme_v1',
    THEMES: {
      dark:   { '--color-bg':'#1a1a1a','--color-surface':'#242424','--color-surface-alt':'#2e2e2e','--color-black':'#ffffff','--color-white':'#1a1a1a','--color-text-main':'#ffffff','--color-text-muted':'#aaaaaa','--color-border':'#ffffff' },
      light:  {},
      amoled: { '--color-bg':'#000000','--color-surface':'#0a0a0a','--color-surface-alt':'#111111','--color-black':'#ffffff','--color-white':'#000000','--color-text-main':'#ffffff','--color-text-muted':'#888888','--color-border':'#ffffff' },
    },
    apply(theme){ const chosen=this.THEMES[theme]?theme:'light'; Object.keys(this.THEMES.dark).forEach((k)=>root.style.removeProperty(k)); Object.entries(this.THEMES[chosen]||{}).forEach(([k,v])=>root.style.setProperty(k,v)); try{localStorage.setItem(this.KEY,chosen);}catch{} root.setAttribute('data-theme-state',chosen); return chosen; },
    current(){ try{return localStorage.getItem(this.KEY)||'light';}catch{return'light';} },
    cycle(){ const order=['light','dark','amoled']; const cur=this.current(); return this.apply(order[(order.indexOf(cur)+1+order.length)%order.length]); },
    init(){ return this.apply(this.current()); }
  };
  document.addEventListener('DOMContentLoaded',()=>ThemeState.init(),{once:true});
})();
