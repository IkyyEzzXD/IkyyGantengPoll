      // Define art menu data
       let artMenuItems = [];

fetch("./artMenu.json")
  .then(res => {
    if (!res.ok) throw new Error("Gagal load artMenu.json");
    return res.json();
  })
  .then(data => {
    artMenuItems = data;
    populateArtMenu(); // ✅ INI KUNCI UTAMA
    populateArtDropdown();
  })
  .catch(console.error);

        // Function to create art card HTML
        function createArtCard(item) {
            return `
                <div class="card-hover bg-card-bg border border-border-dark rounded-2xl overflow-hidden transition-all duration-500 animate-slide-up" style="animation-delay: ${item.id * 0.1}s">
                    ${item.popular ? `
                        <div class="absolute top-4 right-4 z-10">
                            <span class="px-3 py-1 bg-accent text-white text-xs font-semibold rounded-full">POPULAR</span>
                        </div>
                    ` : ''}
                    
                    <div class="relative h-48 overflow-hidden">
                        <img 
                            src="${item.image}" 
                            alt="${item.title} artwork example" 
                            class="w-full h-full object-cover transition-transform duration-700 hover:scale-110"
                            loading="lazy"
                        />
                        <div class="absolute inset-0 bg-gradient-to-t from-card-bg/80 to-transparent"></div>
                    </div>
                    
                    <div class="p-6">
                        <div class="flex justify-between items-start mb-3">
                            <h3 class="text-xl font-bold font-poppins">${item.title}</h3>
                            <div class="text-2xl font-bold text-accent">${item.price}</div>
                        </div>
                        
                        <p class="text-gray-400 text-sm mb-4">${item.description}</p>
                        
                        <ul class="space-y-2 mb-6">
                            ${item.features.map(feature => `
                                <li class="flex items-center text-sm">
                                    <svg class="w-4 h-4 text-accent mr-2" fill="currentColor" viewBox="0 0 20 20">
                                        <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/>
                                    </svg>
                                    ${feature}
                                </li>
                            `).join('')}
                        </ul>
                        
                        <button class="w-full py-3 bg-primary border border-accent text-accent font-semibold rounded-lg hover:bg-accent hover:text-white transition-all duration-300 flex items-center justify-center space-x-2 order-art-btn" data-art="${item.title}" data-price="${item.price}">
                            <span>Pilih Art Ini</span>
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
                            </svg>
                        </button>
                    </div>
                </div>
            `;
        }

        // Function to populate art menu
        function populateArtMenu() {
            const artMenuContainer = document.querySelector('#art-menu .grid');
            if (artMenuContainer) {
                artMenuContainer.innerHTML = artMenuItems.map(item => createArtCard(item)).join('');
                
                // Add event listeners to order buttons
                document.querySelectorAll('.order-art-btn').forEach(button => {
                    button.addEventListener('click', function() {
                        const artType = this.getAttribute('data-art');
                        const price = this.getAttribute('data-price');
                        
                        // Scroll to order form
                        document.getElementById('order').scrollIntoView({ behavior: 'smooth' });
                        
                        // Set the selected art in dropdown
                        const artSelect = document.getElementById('artType');
                        for (let option of artSelect.options) {
                            if (option.value === artType) {
                                artSelect.value = artType;
                                break;
                            }
                        }
                        
                        // If not found in options, add it
                        if (artSelect.value !== artType) {
                            const newOption = new Option(`${artType} (${price})`, artType);
                            artSelect.add(newOption);
                            artSelect.value = artType;
                        }
                    });
                });
            }
        }

        // Function to populate art type dropdown
        function populateArtDropdown() {
            const artSelect = document.getElementById('artType');
            if (artSelect) {
                // Clear existing options except the first one
                while (artSelect.options.length > 1) {
                    artSelect.remove(1);
                }
                
                // Add art menu items as options
                artMenuItems.forEach(item => {
                    const option = new Option(`${item.title} (${item.price})`, item.title);
                    artSelect.add(option);
                });
            }
        }

        // Function to handle form submission
        function handleOrderFormSubmit(e) {
            e.preventDefault();
            
            // Get form values
            const name = document.getElementById('name').value;
            const artType = document.getElementById('artType').value;
            const message = document.getElementById('message').value;
            
            // Validate form
            if (!name || !artType) {
                alert("Please fill in all required fields");
                return;
            }
            
            // Create WhatsApp message
            const whatsappMessage = `Halo putri Art! Saya ingin order artwork dengan detail berikut:%0A%0ANama: ${name}%0AJenis Art: ${artType}%0APesan: ${message || 'Tidak ada pesan tambahan'}%0A%0ASaya tertarik untuk melanjutkan order ini.`;
            
            // WhatsApp number (replace with actual number)
            const whatsappNumber = "6283879506381";
            
            // Open WhatsApp
            window.open(`https://wa.me/${whatsappNumber}?text=${whatsappMessage}`, '_blank');
            
            // Reset form
            document.getElementById('orderForm').reset();
            
            // Show success message
            alert("Terima kasih! Anda akan diarahkan ke WhatsApp untuk menyelesaikan order.");
        }

        // Function to initialize mobile menu
        function initMobileMenu() {
            const mobileMenuButton = document.querySelector('button.md\\:hidden');
            const navLinks = document.querySelector('.hidden.md\\:flex');
            
            if (mobileMenuButton) {
                mobileMenuButton.addEventListener('click', () => {
                    navLinks.classList.toggle('hidden');
                    navLinks.classList.toggle('flex');
                    navLinks.classList.toggle('flex-col');
                    navLinks.classList.toggle('absolute');
                    navLinks.classList.toggle('top-16');
                    navLinks.classList.toggle('left-0');
                    navLinks.classList.toggle('right-0');
                    navLinks.classList.toggle('bg-dark-bg');
                    navLinks.classList.toggle('p-4');
                    navLinks.classList.toggle('space-y-4');
                    navLinks.classList.toggle('border-t');
                    navLinks.classList.toggle('border-border-dark');
                });
            }
        }

        // Function to initialize smooth scrolling for anchor links
        function initSmoothScrolling() {
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', function(e) {
                    e.preventDefault();
                    
                    const targetId = this.getAttribute('href');
                    if (targetId === '#') return;
                    
                    const targetElement = document.querySelector(targetId);
                    if (targetElement) {
                        // Close mobile menu if open
                        const navLinks = document.querySelector('.hidden.md\\:flex');
                        if (navLinks && navLinks.classList.contains('flex')) {
                            navLinks.classList.add('hidden');
                            navLinks.classList.remove('flex', 'flex-col', 'absolute', 'top-16', 'left-0', 'right-0', 'bg-dark-bg', 'p-4', 'space-y-4', 'border-t', 'border-border-dark');
                        }
                        
                        targetElement.scrollIntoView({
                            behavior: 'smooth',
                            block: 'start'
                        });
                    }
                });
            });
        }

        // Initialize everything when DOM is loaded
        document.addEventListener('DOMContentLoaded', function() {
            populateArtMenu();
            populateArtDropdown();
            initMobileMenu();
            initSmoothScrolling();
            
            // Add form submit handler
            const orderForm = document.getElementById('orderForm');
            if (orderForm) {
                orderForm.addEventListener('submit', handleOrderFormSubmit);
            }
            
            // Add hover effects to cards
            const cards = document.querySelectorAll('.card-hover');
            cards.forEach(card => {
                card.addEventListener('mouseenter', function() {
                    this.style.transform = 'translateY(-8px)';
                });
                
                card.addEventListener('mouseleave', function() {
                    this.style.transform = 'translateY(0)';
                });
            });
            
            // Add animation on scroll
            const observerOptions = {
                threshold: 0.1,
                rootMargin: '0px 0px -50px 0px'
            };
            
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.style.opacity = '1';
                        entry.target.style.transform = 'translateY(0)';
                    }
                });
            }, observerOptions);
            
            // Observe all animated elements
            document.querySelectorAll('.animate-slide-up').forEach(el => {
                el.style.opacity = '0';
                el.style.transform = 'translateY(20px)';
                el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
                observer.observe(el);
            });
        });