const {
default: makeWASocket,
useMultiFileAuthState,
DisconnectReason,
fetchLatestBaileysVersion
} = require('@whiskeysockets/baileys');
const P = require('pino');
const readline = require('readline');
const config = require('./config');

const commands = {

ping: async (sock, msg, jid) => {
await sock.sendMessage(jid, { text: 'Pong!' }, { quoted: msg });
},

test: async (sock, msg, jid, args) => {
const teks = args.join(' ') || 'kosong';
await sock.sendMessage(jid, {
text:
`Test berhasil!
Input: ${teks}
Dari: ${msg.pushName || 'Unknown'}
Waktu: ${new Date().toLocaleString('id-ID')}`
}, { quoted: msg });
},

menu: async (sock, msg, jid) => {
const list = Object.keys(commands)
.map(c => `${config.prefix[0]}${c}`)
.join('\n');

await sock.sendMessage(jid, {
text:
`${config.botName}
Menu:
${list}
Ketik command-nya langsung ya.`
}, { quoted: msg });
}

};

function getText(m) {
return (
m.message?.conversation ||
m.message?.extendedTextMessage?.text ||
m.message?.imageMessage?.caption ||
m.message?.videoMessage?.caption ||
''
);
}

function getNumber(jid = '') {
return jid.split('@')[0].split(':')[0];
}

function isOwner(jid) {
const num = getNumber(jid);
return config.owner.map(n => n.replace(/\D/g, '')).includes(num);
}

function askPhoneNumber() {
return new Promise((resolve) => {
const rl = readline.createInterface({
input: process.stdin,
output: process.stdout
});
rl.question('Masukkan nomor WA bot (format 62xxx): ', (ans) => {
rl.close();
const num = ans.replace(/\D/g, '');
if (num.length < 8) {
console.log('Nomor tidak valid, coba lagi.\n');
return askPhoneNumber().then(resolve);
}
resolve(num);
});
});
}

async function startBot() {
const { state, saveCreds } = await useMultiFileAuthState('session');
const { version } = await fetchLatestBaileysVersion();

const sock = makeWASocket({
version,
auth: state,
logger: P({ level: config.logLevel }),
printQRInTerminal: false,
browser: ['Thewilzu', 'Chrome', '1.0.0'],
});

sock.ev.on('creds.update', saveCreds);

if (!sock.authState.creds.registered) {
console.log('Bot belum login. Perlu pairing.\n');
const phone = await askPhoneNumber();

try {
await new Promise(r => setTimeout(r, 1500));
const code = await sock.requestPairingCode(phone);

console.log(`\nPAIRING CODE: ${code}\n`);
console.log('WhatsApp > Perangkat Tertaut > Tautkan dengan nomor telepon');
console.log('Lalu masukkan kode di atas.\n');
} catch (err) {
console.error('Gagal minta pairing code:', err.message);
process.exit(1);
}
}

sock.ev.on('connection.update', ({ connection, lastDisconnect }) => {
if (connection === 'open') {
console.log('Bot terkoneksi!');
console.log(`Owner: ${config.owner.join(', ')}\n`);
}
if (connection === 'close') {
const code = lastDisconnect?.error?.output?.statusCode;
const reconnect = code !== DisconnectReason.loggedOut;
console.log(`Terputus (${code}). Reconnect: ${reconnect}`);
if (reconnect) startBot();
}
});

sock.ev.on('messages.upsert', async ({ messages, type }) => {
if (type !== 'notify') return;

for (const msg of messages) {
if (!msg.message || msg.key.fromMe) continue;

const jid = msg.key.remoteJid;
const sender = msg.key.participant || msg.key.remoteJid;
const teks = getText(msg);

console.log('\n=== PESAN MASUK ===');
console.log(JSON.stringify(msg, undefined, 2));
console.log('===================\n');

if (!teks) continue;

const p = config.prefix.find(p => teks.startsWith(p));
if (!p) continue;

if (!isOwner(sender)) {
console.log(`Non-owner (${getNumber(sender)}) coba akses: ${teks}`);
if (config.replyNonOwner) {
await sock.sendMessage(jid, {
text: 'Akses ditolak. Bot ini hanya bisa dipakai owner.'
}, { quoted: msg });
}
continue;
}

const parts = teks.slice(p.length).trim().split(/\s+/);
const cmd = parts[0].toLowerCase();
const args = parts.slice(1);

const fn = commands[cmd];
if (!fn) {
await sock.sendMessage(jid, {
text: `Command ${p}${cmd} tidak dikenal.\nKetik ${p}menu`
}, { quoted: msg });
continue;
}

try {
await fn(sock, msg, jid, args);
console.log(`Command "${cmd}" dijalankan oleh owner`);
} catch (err) {
console.error(`Error "${cmd}":`, err);
await sock.sendMessage(jid, {
text: `Error: ${err.message}`
}, { quoted: msg });
}
}
});
}

startBot();