module.exports = {
/*
-@ Wilzu------------- 
🔺The function null
*/
owner: ['6285863131467'],
prefix: ['!', '.'],
botName: 'Bot Simpel',
logLevel: 'silent',
replyNonOwner: true,
};