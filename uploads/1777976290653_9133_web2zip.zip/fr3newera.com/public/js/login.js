// === Block 1 ===
const togglePass = document.getElementById('togglePass');
const passInput  = document.getElementById('passInput');
const eyeIcon    = document.getElementById('eyeIcon');
const loginForm  = document.getElementById('loginForm');
const submitBtn  = document.getElementById('submitBtn');

togglePass.addEventListener('click', function() {
  const isPass = passInput.type === 'password';
  passInput.type = isPass ? 'text' : 'password';
  eyeIcon.className = isPass ? 'fa-solid fa-eye' : 'fa-solid fa-eye-slash';
});

loginForm.addEventListener('submit', function() {
  submitBtn.classList.add('loading');
  submitBtn.disabled = true;
});

const urlParams = new URLSearchParams(window.location.search);
if (urlParams.get('registered') === '1') {
  const t   = document.getElementById('toast-verif');
  const txt = document.getElementById('toast-verif-text');
  t.style.display = 'flex';
  txt.textContent = 'Akun berhasil dibuat! Cek email kamu dan klik link verifikasi sebelum login.';
}
