const assert = require('assert');
const Module = require('module');
const { EventEmitter } = require('events');

process.env.MONGODB_RETRY_BASE_MS = '5';
process.env.MONGODB_RETRY_MAX_MS = '20';
process.env.MONGODB_RETRY_BUDGET_MS = '800';

const store = new Map();
const clients = [];

function notConnected() {
  const e = new Error('MongoClient must be connected before running operations');
  e.name = 'MongoNotConnectedError';
  return e;
}

function matchesFilter(doc, filter) {
  return Object.entries(filter || {}).every(([k, v]) => {
    if (v && typeof v === 'object' && !Array.isArray(v)) return true;
    return doc[k] === v;
  });
}

class FakeCollection {
  constructor(client, name) {
    this.client = client;
    this.name = name;
  }

  get docs() {
    if (!store.has(this.name)) store.set(this.name, []);
    return store.get(this.name);
  }

  guard() {
    if (this.client.closed) throw notConnected();
  }

  async findOne(filter) {
    this.guard();
    const d = this.docs.find(x => matchesFilter(x, filter));
    return d ? Object.assign({}, d) : null;
  }

  find(filter) {
    this.guard();
    const res = this.docs.filter(x => matchesFilter(x, filter)).map(x => Object.assign({}, x));
    const cur = {
      sort: () => cur,
      skip: () => cur,
      limit: () => cur,
      toArray: async () => res
    };
    return cur;
  }

  async countDocuments(filter) {
    this.guard();
    return this.docs.filter(x => matchesFilter(x, filter)).length;
  }

  async insertOne(doc) {
    this.guard();
    const d = Object.assign({ _id: `o${this.docs.length + 1}` }, doc);
    this.docs.push(d);
    return { insertedId: d._id };
  }

  async updateOne(filter, update, opts = {}) {
    this.guard();
    let d = this.docs.find(x => matchesFilter(x, filter));
    if (!d && opts.upsert) {
      d = Object.assign({}, filter);
      this.docs.push(d);
    }
    if (d) {
      Object.assign(d, update.$set || {});
      for (const [k, v] of Object.entries(update.$inc || {})) d[k] = (d[k] || 0) + v;
    }
    return { matchedCount: d ? 1 : 0, upsertedCount: 0 };
  }

  async createIndex() {
    this.guard();
    return 'ok';
  }

  async findOneAndUpdate(filter, update) {
    this.guard();
    let d = this.docs.find(x => matchesFilter(x, filter));
    if (!d) {
      d = Object.assign({}, filter);
      this.docs.push(d);
    }
    for (const [k, v] of Object.entries(update.$inc || {})) d[k] = (d[k] || 0) + v;
    return Object.assign({}, d);
  }
}

class FakeDatabase {
  constructor(client) {
    this.client = client;
  }

  collection(name) {
    return new FakeCollection(this.client, name);
  }

  async command() {
    if (this.client.closed) throw notConnected();
    return { ok: 1 };
  }
}

class FakeMongoClient extends EventEmitter {
  constructor() {
    super();
    this.closed = false;
    this.broken = false;
    clients.push(this);
  }

  async connect() {
    if (this.broken) throw notConnected();
    this.closed = false;
    return this;
  }

  db() {
    return new FakeDatabase(this);
  }

  async close() {
    this.closed = true;
  }
}

const origLoad = Module._load;
Module._load = function (request, ...rest) {
  if (request === 'mongodb') return { MongoClient: FakeMongoClient, ObjectId: class {} };
  return origLoad.call(this, request, ...rest);
};

const mongoAdapter = require('../src/storage/mongoAdapter');

let failed = 0;
async function t(name, fn) {
  try {
    await fn();
    console.log('ok   :', name);
  } catch (e) {
    failed++;
    console.log('GAGAL:', name, '-', e.message);
  }
}

(async () => {
  const adapter = await mongoAdapter.connect('mongodb://fake', 'uji');

  await t('koneksi lama mati: wrapper memakai koneksi baru setelah revive', async () => {
    store.set('kv_store', [{ _id: 'k1', payload: { a: 1 } }]);
    const col = mongoAdapter.getDatabase().collection('kv_store');
    const first = clients[clients.length - 1];
    first.broken = true;
    first.closed = true;
    const doc = await col.findOne({ _id: 'k1' });
    assert.ok(doc && doc.payload.a === 1);
    assert.ok(clients.length >= 2);
    assert.notStrictEqual(clients[clients.length - 1], first);
  });

  await t('koneksi lama mati: update kv_store tetap tersimpan lewat koneksi baru', async () => {
    const cur = clients[clients.length - 1];
    cur.broken = true;
    cur.closed = true;
    const col = mongoAdapter.getDatabase().collection('kv_store');
    await col.updateOne({ _id: 'k2' }, { $set: { payload: { b: 2 } } }, { upsert: true });
    const saved = store.get('kv_store').find(d => d._id === 'k2');
    assert.ok(saved && saved.payload.b === 2);
  });

  await t('update kv_store beruntun digabung dan nilai terakhir yang menang', async () => {
    const col = mongoAdapter.getDatabase().collection('kv_store');
    await Promise.all([1, 2, 3, 4, 5].map(i => col.updateOne({ _id: 'k3' }, { $set: { payload: { n: i } } }, { upsert: true })));
    const saved = store.get('kv_store').find(d => d._id === 'k3');
    assert.strictEqual(saved.payload.n, 5);
  });

  await t('tulis lewat wrapper ke tabel SQL membersihkan cache SELECT', async () => {
    await adapter.exec('CREATE TABLE IF NOT EXISTS catatan (id INTEGER PRIMARY KEY AUTOINCREMENT, isi TEXT)');
    const before = await adapter.all('SELECT * FROM catatan');
    assert.strictEqual(before.length, 0);
    await mongoAdapter.getDatabase().collection('catatan').insertOne({ id: 1, isi: 'halo' });
    const after = await adapter.all('SELECT * FROM catatan');
    assert.strictEqual(after.length, 1);
  });

  await t('stats menampilkan antrean baca dan tulis', async () => {
    const s = adapter.stats();
    assert.ok(s.queueRead && s.queueWrite);
    assert.strictEqual(s.queueRead.active, 0);
  });

  await t('close menunggu antrean kosong dan menolak operasi baru tanpa retry', async () => {
    const col = mongoAdapter.getDatabase().collection('kv_store');
    await adapter.close();
    assert.strictEqual(mongoAdapter.getDatabase(), null);
    await assert.rejects(col.findOne({ _id: 'k1' }));
  });

  if (failed) {
    console.log(`\n${failed} TES GAGAL`);
    process.exit(1);
  }
  console.log('\nSEMUA LOLOS');
  process.exit(0);
})();
