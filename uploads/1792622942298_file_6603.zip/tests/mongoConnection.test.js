const assert = require('assert');

process.env.MONGODB_QUEUE_MAX_WAITING = '100';
process.env.MONGODB_QUEUE_WAIT_MS = '300';
process.env.MONGODB_OP_CONCURRENCY = '8';
process.env.MONGODB_WRITE_CONCURRENCY = '4';
process.env.MONGODB_RETRY_BASE_MS = '5';
process.env.MONGODB_RETRY_MAX_MS = '20';
process.env.MONGODB_RETRY_BUDGET_MS = '400';

const mc = require('../src/system/mongoConnection');
const { Semaphore, withLock } = require('../src/system/concurrency');
const { JobQueue } = require('../src/system/jobQueue');

let failed = 0;
async function t(name, fn) {
  try {
    mc.resetQueues();
    await fn();
    console.log('ok   :', name);
  } catch (e) {
    failed++;
    console.log('GAGAL:', name, '-', e.message);
  }
}

const sleep = ms => new Promise(r => setTimeout(r, ms));

function netErr(msg, name) {
  const e = new Error(msg);
  e.name = name || 'MongoNetworkError';
  return e;
}

(async () => {
  await t('pool: minPoolSize tidak melebihi maxPoolSize', () => {
    process.env.MONGODB_POOL_MAX = '60';
    process.env.MONGODB_POOL_MIN = '200';
    const o = mc.loadPoolOptions();
    delete process.env.MONGODB_POOL_MAX;
    delete process.env.MONGODB_POOL_MIN;
    assert(o.minPoolSize <= o.maxPoolSize);
  });

  await t('antrean: batas konkurensi dipatuhi', async () => {
    let act = 0;
    let max = 0;
    await Promise.all(Array.from({ length: 40 }, () => mc.withDbRetry(async () => {
      act++;
      max = Math.max(max, act);
      await sleep(5);
      act--;
    }, { mode: 'read' })));
    assert(max <= 8, `konkurensi ${max}`);
  });

  await t('antrean: penuh ditolak cepat tanpa retry dan tanpa membocorkan slot', async () => {
    const q = new mc.OpQueue(1, { maxWaiting: 3, waitMs: 0 });
    let release;
    const gate = new Promise(r => { release = r; });
    const running = q.run(() => gate);
    const waiting = [q.run(async () => 1), q.run(async () => 2), q.run(async () => 3)];
    let err = null;
    try { await q.run(async () => 4); } catch (e) { err = e; }
    assert(err && err.name === 'MongoQueueOverflowError' && err.backpressure === true);
    release();
    await running;
    assert.deepStrictEqual(await Promise.all(waiting), [1, 2, 3]);
    assert.strictEqual(q.stats().active, 0);
    assert.strictEqual(q.stats().waiting, 0);
  });

  await t('antrean: menunggu terlalu lama dilepas dari antrean (tidak menumpuk)', async () => {
    const q = new mc.OpQueue(1, { maxWaiting: 50, waitMs: 40 });
    let release;
    const gate = new Promise(r => { release = r; });
    const running = q.run(() => gate);
    const results = await Promise.allSettled(Array.from({ length: 10 }, () => q.run(async () => 1)));
    assert(results.every(r => r.status === 'rejected' && r.reason.name === 'MongoQueueTimeoutError'));
    assert.strictEqual(q.stats().waiting, 0);
    release();
    await running;
    assert.strictEqual(await q.run(async () => 'ok'), 'ok');
  });

  await t('retry: slot dilepas saat backoff, operasi lain tidak terblokir', async () => {
    const q = mc.OpQueue;
    const tiny = new q(1, { maxWaiting: 10, waitMs: 0 });
    let calls = 0;
    const flaky = async () => {
      for (let i = 0; i < 3; i++) {
        try {
          return await tiny.run(async () => {
            calls++;
            if (calls < 3) throw netErr('boom');
            return 'ok';
          });
        } catch (e) {
          await sleep(60);
        }
      }
      throw new Error('gagal');
    };
    const started = Date.now();
    const p = flaky();
    await sleep(10);
    const other = await tiny.run(async () => 'lain');
    assert.strictEqual(other, 'lain');
    assert(Date.now() - started < 60, 'operasi lain menunggu backoff');
    assert.strictEqual(await p, 'ok');
  });

  await t('retry baca: error jaringan diulang sampai berhasil', async () => {
    let n = 0;
    const r = await mc.withDbRetry(async () => {
      n++;
      if (n < 3) throw netErr('connection 1 to h:27017 timed out', 'MongoNetworkTimeoutError');
      return 'ok';
    }, { mode: 'read' });
    assert.strictEqual(r, 'ok');
    assert.strictEqual(n, 3);
  });

  await t('retry tulis tidak idempoten: error ambigu TIDAK diulang (cegah $inc/insert ganda)', async () => {
    let n = 0;
    await assert.rejects(mc.withDbRetry(async () => {
      n++;
      throw netErr('connection 1 to h:27017 timed out', 'MongoNetworkTimeoutError');
    }, { mode: 'write' }));
    assert.strictEqual(n, 1);
  });

  await t('retry tulis tidak idempoten: error sebelum terkirim tetap diulang', async () => {
    let n = 0;
    const r = await mc.withDbRetry(async () => {
      n++;
      if (n < 3) throw netErr('Server selection timed out after 20000 ms', 'MongoServerSelectionError');
      return 'ok';
    }, { mode: 'write' });
    assert.strictEqual(r, 'ok');
    assert.strictEqual(n, 3);
  });

  await t('retry tulis idempoten: error ambigu diulang', async () => {
    let n = 0;
    const r = await mc.withDbRetry(async () => {
      n++;
      if (n < 2) throw netErr('read ECONNRESET');
      return 'ok';
    }, { mode: 'idem' });
    assert.strictEqual(r, 'ok');
  });

  await t('retry: error non-transient langsung dilempar', async () => {
    let n = 0;
    const e = new Error('E11000 duplicate key');
    e.code = 11000;
    await assert.rejects(mc.withDbRetry(async () => { n++; throw e; }, { mode: 'idem' }));
    assert.strictEqual(n, 1);
  });

  await t('retry: berhenti sesuai budget waktu', async () => {
    const started = Date.now();
    await assert.rejects(mc.withDbRetry(async () => { throw netErr('boom'); }, { mode: 'read' }));
    assert(Date.now() - started < 1500);
  });

  await t('retry: sedang menutup koneksi tidak mengulang', async () => {
    let n = 0;
    await assert.rejects(mc.withDbRetry(async () => { n++; throw netErr('boom'); }, { mode: 'read', isClosing: () => true }));
    assert.strictEqual(n, 1);
  });

  await t('retry: MongoNotConnectedError memicu revive sekali lalu lanjut', async () => {
    let revived = 0;
    let n = 0;
    const r = await mc.withDbRetry(async () => {
      n++;
      if (n === 1) throw netErr('must be connected before running operations', 'MongoNotConnectedError');
      return 'ok';
    }, { mode: 'read', onNotConnected: async () => { revived++; } });
    assert.strictEqual(r, 'ok');
    assert.strictEqual(revived, 1);
  });

  await t('retry: revive berjalan di luar slot antrean (tidak deadlock saat slot penuh)', async () => {
    const q = mc.OpQueue;
    mc.resetQueues();
    let n = 0;
    const jobs = Array.from({ length: 30 }, () => mc.withDbRetry(async () => {
      n++;
      if (n <= 8) throw netErr('x', 'MongoNotConnectedError');
      return 'ok';
    }, { mode: 'read', onNotConnected: async () => { await sleep(20); } }));
    const res = await Promise.all(jobs);
    assert(res.every(x => x === 'ok'));
    assert(q);
  });

  await t('retry: pemetaan mode update ($inc = tulis biasa, $set = idempoten)', () => {
    assert.strictEqual(mc.modeForUpdate({ $set: { a: 1 } }), 'idem');
    assert.strictEqual(mc.modeForUpdate({ $max: { a: 1 }, $setOnInsert: { b: 1 } }), 'idem');
    assert.strictEqual(mc.modeForUpdate({ $inc: { a: 1 } }), 'write');
    assert.strictEqual(mc.modeForUpdate({ $set: { a: 1 }, $push: { b: 1 } }), 'write');
    assert.strictEqual(mc.modeForUpdate([{ $set: { a: 1 } }]), 'write');
  });

  await t('semaphore: tidak melebihi batas walau ada yang menyerobot saat release', async () => {
    const s = new Semaphore(1);
    await s.acquire();
    const waiter = s.acquire();
    s.release();
    const barger = s.acquire();
    const first = await Promise.race([waiter.then(() => 'waiter'), barger.then(() => 'barger')]);
    assert.strictEqual(first, 'waiter');
    assert.strictEqual(s.stats.active, 1);
  });

  await t('semaphore: konkurensi tetap sesuai batas pada beban besar', async () => {
    const s = new Semaphore(3);
    let act = 0;
    let max = 0;
    await Promise.all(Array.from({ length: 300 }, () => s.run(async () => {
      act++;
      max = Math.max(max, act);
      await sleep(1);
      act--;
    })));
    assert(max <= 3);
    assert.strictEqual(s.stats.active, 0);
  });

  await t('withLock: saling eksklusif dan bersih setelah selesai', async () => {
    let act = 0;
    let max = 0;
    await Promise.all(Array.from({ length: 40 }, () => withLock('kunci-uji', async () => {
      act++;
      max = Math.max(max, act);
      await sleep(1);
      act--;
    })));
    assert.strictEqual(max, 1);
    await withLock('kunci-uji', async () => {});
  });

  await t('withLock: error di dalam tidak mengunci selamanya', async () => {
    await assert.rejects(withLock('kunci-err', async () => { throw new Error('x'); }));
    assert.strictEqual(await withLock('kunci-err', async () => 'ok'), 'ok');
  });

  await t('jobQueue: hitungan pending tidak berkurang ganda saat job gagal', async () => {
    const q = new JobQueue({ name: 'uji', concurrency: 1, maxPending: 50 });
    let release;
    const gate = new Promise(r => { release = r; });
    const a = q.add(() => gate);
    const b = q.add(async () => { throw new Error('gagal'); });
    const c = q.add(async () => 'c');
    const d = q.add(async () => 'd');
    await sleep(5);
    assert.strictEqual(q.stats.pending, 3);
    release();
    await a;
    await assert.rejects(b);
    await Promise.all([c, d]);
    assert.strictEqual(q.stats.pending, 0);
    assert.strictEqual(q.stats.running, 0);
  });

  if (failed) {
    console.log(`\n${failed} TES GAGAL`);
    process.exit(1);
  }
  console.log('\nSEMUA LOLOS');
})();
