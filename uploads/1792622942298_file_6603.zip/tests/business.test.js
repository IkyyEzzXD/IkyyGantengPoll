// Tes perbaikan celah bisnis. Tidak butuh node_modules.
// Potongan kode diambil dari src/index.js lalu dijalankan dengan db palsu,
// jadi yang diuji adalah kode ASLI, bukan salinan.
const fs = require('fs');
const os = require('os');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

let failed = 0;
async function t(name, fn) {
  try { await fn(); console.log('ok   :', name); }
  catch (e) { failed++; console.log('GAGAL:', name, '-', e.message); }
}

const src = fs.readFileSync(path.join(__dirname, '../src/index.js'), 'utf8');

function slice(from, to) {
  const a = src.indexOf(from), b = src.indexOf(to, a);
  assert(a >= 0 && b > a, `potongan tidak ketemu: ${from}`);
  return src.slice(a, b);
}

function isolatedReferral() {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'jaseb-ref-'));
  fs.mkdirSync(path.join(tmp, 'src/system'), { recursive: true });
  fs.mkdirSync(path.join(tmp, 'database'));
  fs.mkdirSync(path.join(tmp, 'src/storage'), { recursive: true });
  for (const f of ['mongoAdapter.js', 'sqlParser.js']) fs.copyFileSync(path.join(__dirname, '../src/storage', f), path.join(tmp, 'src/storage', f));
  fs.copyFileSync(path.join(__dirname, '../src/system/mongoConnection.js'), path.join(tmp, 'src/system/mongoConnection.js'));
  fs.copyFileSync(path.join(__dirname, '../src/system/referral.js'), path.join(tmp, 'src/system/referral.js'));
  fs.copyFileSync(path.join(__dirname, '../src/system/kvDoc.js'), path.join(tmp, 'src/system/kvDoc.js'));
  return require(path.join(tmp, 'src/system/referral.js'));
}

function isolatedWithFakeDb(collection) {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'jaseb-refdb-'));
  fs.mkdirSync(path.join(tmp, 'src/system'), { recursive: true });
  fs.mkdirSync(path.join(tmp, 'src/storage'), { recursive: true });
  fs.writeFileSync(path.join(tmp, 'src/storage/mongoAdapter.js'), 'let impl = null;\nmodule.exports = { getDatabase: () => impl, __set: (v) => { impl = v; } };\n');
  for (const f of ['referral.js', 'kvDoc.js']) fs.copyFileSync(path.join(__dirname, '../src/system', f), path.join(tmp, 'src/system', f));
  const adapter = require(path.join(tmp, 'src/storage/mongoAdapter.js'));
  adapter.__set({ collection: () => collection });
  return require(path.join(tmp, 'src/system/referral.js'));
}

async function isolatedWithSeed(seed) {
  const ref = isolatedWithFakeDb({ findOne: async () => ({ payload: JSON.parse(JSON.stringify(seed)) }), updateOne: async () => ({}) });
  await ref.reloadFromMongo();
  return ref;
}

// Sandbox untuk gerbang akses promosi (hasLapsedSubscription + promoAccessLapsed)
function gateSandbox({ role, lapsedTables = [], ownerId = '1' }) {
  const sandbox = {
    OWNER_ID: ownerId,
    logger: { warn() {}, info() {}, error() {} },
    getUserRole: async () => role,
    db: {
      async get(sql) {
        const m = /FROM (\w+) WHERE/.exec(sql);
        return m && lapsedTables.includes(m[1]) ? { x: 1 } : undefined;
      },
    },
  };
  vm.createContext(sandbox);
  vm.runInContext(
    slice('async function hasLapsedSubscription(', 'async function haltPromoForLapsedAccess(') +
      '\nthis.api={hasLapsedSubscription,promoAccessLapsed};',
    sandbox
  );
  return sandbox.api;
}

(async () => {
  // ---------- Referral anti-farming ----------
  // Model hadiah: dicatat saat start, DIBAYAR saat deposit pertama (REFERRAL_REWARD_MODE default 'deposit').
  await t('referral: saat start dicatat menunggu, belum ada hadiah tetapi langsung masuk kontes', async () => {
    const ref = isolatedReferral();
    const r = ref.registerReferral('9001', '777');
    assert.strictEqual(r.ok, true);
    assert.strictEqual(r.pending, true);
    assert.strictEqual(r.reward, 0);
    assert.strictEqual(ref.getStats('777').count, 0);
    assert.strictEqual(ref.getPendingCount('777'), 1);
    const lb = ref.getContestLeaderboard(10);
    assert.deepStrictEqual(lb.entries, [{ userId: '777', score: 1 }]);
    assert.strictEqual(ref.getInviteCount('777').total, 1);
  });
  await t('referral: skor kontes tidak ganda saat deposit pertama dibayar', async () => {
    const ref = isolatedReferral();
    ref.registerReferral('9101', '777');
    ref.registerReferral('9102', '777');
    ref.settleReferral('9101', 5000);
    assert.deepStrictEqual(ref.getContestLeaderboard(10).entries, [{ userId: '777', score: 2 }]);
    assert.deepStrictEqual(ref.getContestStanding('777'), { rank: 1, score: 2, total: 1 });
    assert.strictEqual(ref.getContestStanding('424242').rank, null);
  });
  await t('referral: urutan kontes konsisten (skor lalu userId) dan hanya invite valid', async () => {
    const ref = isolatedReferral();
    ref.registerReferral('1', 'b');
    ref.registerReferral('2', 'a');
    ref.registerReferral('3', 'a');
    ref.registerReferral('3', 'c');
    ref.registerReferral('4', '4');
    assert.deepStrictEqual(ref.getContestLeaderboard(10).entries, [{ userId: 'a', score: 2 }, { userId: 'b', score: 1 }]);
  });
  await t('referral: batas harian tidak menghapus undangan, tetap menunggu dan terhitung kontes', async () => {
    const ref = isolatedReferral();
    for (let i = 0; i < ref.REFERRAL_DAILY_CAP + 1; i++) {
      ref.registerReferral(`5000${i}`, '777');
      ref.settleReferral(`5000${i}`, 5000);
    }
    assert.strictEqual(ref.getPendingCount('777'), 1);
    assert.strictEqual(ref.getContestLeaderboard(10).entries[0].score, ref.REFERRAL_DAILY_CAP + 1);
  });
  await t('referral: undangan lama yang tertutup karena batas harian dibuka kembali saat dimuat', async () => {
    const seed = { referredBy: { '55': { by: '777', at: Date.now(), rewarded: false, status: 'closed', closedReason: 'daily_cap' } } };
    const ref = await isolatedWithSeed(seed);
    assert.strictEqual(ref.getPendingCount('777'), 1);
    assert.strictEqual(ref.settleReferral('55', 5000).ok, true);
  });
  await t('referral: kunci bulan kontes mengikuti zona waktu WIB, bukan UTC', async () => {
    const ref = isolatedReferral();
    assert.strictEqual(ref.monthKeyOf(Date.UTC(2026, 9, 31, 17, 30)), '2026-11');
    assert.strictEqual(ref.monthKeyOf(Date.UTC(2026, 9, 31, 16, 59)), '2026-10');
    assert.strictEqual(ref.monthKeyOf('bukan-angka'), null);
  });
  await t('referral: gagal memuat dari database tidak menimpa data yang tersimpan', async () => {
    const stored = { referredBy: { '1': { by: '9', at: Date.now(), rewarded: true, status: 'rewarded' } }, everStarted: { '1': 1 } };
    const writes = [];
    let failLoad = true;
    const ref = isolatedWithFakeDb({
      findOne: async () => { if (failLoad) throw new Error('timeout'); return { payload: JSON.parse(JSON.stringify(stored)) }; },
      updateOne: async (f, u) => { writes.push(JSON.parse(JSON.stringify(u.$set.payload))); return {}; }
    });
    ref.registerReferral('2', '9');
    await ref.flush().catch(() => {});
    assert.strictEqual(writes.length, 0);
    failLoad = false;
    await ref.reloadFromMongo();
    await ref.flush();
    assert.strictEqual(writes.length >= 1, true);
    const last = writes[writes.length - 1];
    assert.strictEqual(!!last.referredBy['1'], true);
    assert.strictEqual(!!last.referredBy['2'], true);
    assert.strictEqual(last.everStarted['1'], 1);
  });
  await t('referral: perubahan yang gagal disimpan dicoba ulang sampai berhasil', async () => {
    let failNext = 1;
    const writes = [];
    const ref = isolatedWithFakeDb({
      findOne: async () => null,
      updateOne: async (f, u) => { if (failNext > 0) { failNext--; throw new Error('putus'); } writes.push(u.$set.payload); return {}; }
    });
    await ref.reloadFromMongo();
    ref.registerReferral('11', '22');
    await ref.flush();
    await ref.flush();
    assert.strictEqual(writes.length >= 1, true);
    assert.strictEqual(!!writes[writes.length - 1].referredBy['11'], true);
  });
  await t('referral: kegagalan kredit saldo dicatat untuk dicoba ulang', async () => {
    const ref = isolatedReferral();
    ref.recordPayoutFailure('9', { referrer: '1', reward: 200, l2Referrer: null, l2Reward: 0, l1Done: false, l2Done: true });
    assert.strictEqual(ref.getFailedPayouts().length, 1);
    ref.clearPayoutFailure('9');
    assert.strictEqual(ref.getFailedPayouts().length, 0);
  });
  await t('referral: deposit pertama membayar hadiah tepat sekali', async () => {
    const ref = isolatedReferral();
    ref.registerReferral('9002', '777');
    const a = ref.settleReferral('9002', 5000);
    assert.strictEqual(a.ok, true);
    assert.strictEqual(a.reward, ref.REFERRAL_REWARD);
    assert.strictEqual(ref.getStats('777').count, 1);
    const b = ref.settleReferral('9002', 5000); // deposit kedua
    assert.strictEqual(b.ok, false);
    assert.strictEqual(ref.getStats('777').count, 1);
    assert.strictEqual(ref.getPendingCount('777'), 0);
  });
  await t('referral: deposit di bawah minimum tidak membayar dan tetap menunggu', async () => {
    const ref = isolatedReferral();
    ref.registerReferral('9003', '777');
    assert.strictEqual(ref.settleReferral('9003', ref.REFERRAL_MIN_DEPOSIT - 1).ok, false);
    assert.strictEqual(ref.getPendingCount('777'), 1);
    assert.strictEqual(ref.settleReferral('9003', ref.REFERRAL_MIN_DEPOSIT).ok, true);
  });
  await t('referral: user tanpa undangan yang deposit tidak memicu apa pun', async () => {
    const ref = isolatedReferral();
    assert.strictEqual(ref.settleReferral('12345', 10000).ok, false);
  });
  await t('referral: level 2 ikut dibayar saat deposit pertama, bukan saat start', async () => {
    const ref = isolatedReferral();
    ref.registerReferral('2001', '1000');      // 2001 diundang oleh 1000
    ref.settleReferral('2001', 5000);
    ref.registerReferral('2002', '2001');      // 2002 diundang oleh 2001 -> induknya (L2) adalah 1000
    assert.strictEqual(ref.getStats('1000').countL2, 0);
    const r = ref.settleReferral('2002', 5000);
    assert.strictEqual(r.l2Referrer, '1000');
    assert.strictEqual(ref.getStats('1000').countL2, 1);
  });
  await t('referral: pengundang dibatasi REFERRAL_DAILY_CAP per 24 jam (dihitung saat dibayar)', async () => {
    const ref = isolatedReferral();
    let ok = 0, ditolak = 0;
    for (let i = 0; i < ref.REFERRAL_DAILY_CAP + 5; i++) {
      ref.registerReferral(`9000${i}`, '777');
      const r = ref.settleReferral(`9000${i}`, 5000);
      if (r.ok) ok++; else if (r.reason === 'daily_cap') ditolak++;
    }
    assert.strictEqual(ok, ref.REFERRAL_DAILY_CAP);
    assert.strictEqual(ditolak, 5);
  });
  await t('referral: pengundang lain tidak terdampak batas harian', async () => {
    const ref = isolatedReferral();
    for (let i = 0; i < ref.REFERRAL_DAILY_CAP + 2; i++) { ref.registerReferral(`8000${i}`, '777'); ref.settleReferral(`8000${i}`, 5000); }
    ref.registerReferral('123456', '888');
    assert.strictEqual(ref.settleReferral('123456', 5000).ok, true);
  });
  await t("referral: mode 'start' (REFERRAL_REWARD_MODE=start) tetap membayar langsung", async () => {
    const prev = process.env.REFERRAL_REWARD_MODE;
    process.env.REFERRAL_REWARD_MODE = 'start';
    try {
      const ref = isolatedReferral();
      const r = ref.registerReferral('7001', '777');
      assert.strictEqual(r.ok, true);
      assert.strictEqual(!!r.pending, false);
      assert.strictEqual(ref.getStats('777').count, 1);
      assert.strictEqual(ref.settleReferral('7001', 5000).ok, false); // tidak dibayar dua kali
    } finally {
      if (prev === undefined) delete process.env.REFERRAL_REWARD_MODE; else process.env.REFERRAL_REWARD_MODE = prev;
    }
  });
  await t('referral: deposit otomatis & kedua jalur deposit manual memanggil hadiah deposit pertama', async () => {
    const auto = slice('async function handleFelixPaymentSettled(', '// Handle user kirim bukti deposit');
    assert(/rewardReferralOnFirstDeposit\(/.test(auto));
    const accept = slice('async function handleDepositAccept(', '// Owner TOLAK deposit dari tombol inline');
    assert(/rewardReferralOnFirstDeposit\(/.test(accept));
    const acc = slice('async function accDeposit(', '// ===== NOTIF CHANNEL');
    assert(/rewardReferralOnFirstDeposit\(/.test(acc));
  });
  await t('referral: self-referral tetap ditolak', async () => {
    const ref = isolatedReferral();
    assert.strictEqual(ref.registerReferral('5', '5').reason, 'self_referral');
  });

  // ---------- Gerbang akses promosi ----------
  await t('gerbang: role FREE + langganan lewat tanggal -> dihentikan', async () => {
    const g = gateSandbox({ role: 'FREE', lapsedTables: ['premium_wm'] });
    assert.strictEqual(await g.promoAccessLapsed('42'), true);
  });
  await t('gerbang: reseller lewat tanggal juga terdeteksi', async () => {
    const g = gateSandbox({ role: 'FREE', lapsedTables: ['reseller_list'] });
    assert.strictEqual(await g.promoAccessLapsed('42'), true);
  });
  await t('gerbang: role premium aktif -> tidak dihentikan', async () => {
    for (const role of ['PREMIUM_WM', 'PREMIUM_NO_WM', 'RESELLER', 'TRIAL']) {
      const g = gateSandbox({ role, lapsedTables: ['premium_wm'] });
      assert.strictEqual(await g.promoAccessLapsed('42'), false, role);
    }
  });
  await t('gerbang: user lama FREE tanpa baris langganan sama sekali -> TIDAK disentuh', async () => {
    const g = gateSandbox({ role: 'FREE', lapsedTables: [] });
    assert.strictEqual(await g.promoAccessLapsed('42'), false);
  });
  await t('gerbang: owner tidak pernah dihentikan', async () => {
    const g = gateSandbox({ role: 'FREE', lapsedTables: ['premium_wm'], ownerId: '42' });
    assert.strictEqual(await g.promoAccessLapsed('42'), false);
  });
  await t('gerbang: error saat memeriksa -> promosi user tidak dihentikan', async () => {
    const sandbox = {
      OWNER_ID: '1',
      logger: { warn() {}, info() {}, error() {} },
      getUserRole: async () => { throw new Error('db down'); },
      db: { async get() {} },
    };
    vm.createContext(sandbox);
    vm.runInContext(
      slice('async function hasLapsedSubscription(', 'async function haltPromoForLapsedAccess(') + '\nthis.api={promoAccessLapsed};',
      sandbox
    );
    assert.strictEqual(await sandbox.api.promoAccessLapsed('42'), false);
  });

  // ---------- Pemasangan kode (anti-regresi) ----------
  await t('ronde promosi memanggil gerbang akses di awal dan berkala', () => {
    const body = fs.readFileSync(path.join(__dirname, '../src/features/promoRoundInner.js'), 'utf8');
    assert(/promoAccessLapsed\(userId\)/.test(body), 'gerbang awal ronde tidak ada');
    assert(/% 15 === 0/.test(body), 'pemeriksaan berkala tidak ada');
  });
  await t('token: diklaim atomik (UPDATE ... AND used = 0) sebelum akses diberikan', () => {
    const a = src.indexOf("UPDATE tokens SET used = 1, used_by = ?, used_at = ? WHERE token = ? AND used = 0");
    const b = src.indexOf("INSERT OR REPLACE INTO premium_wm (user_id, expired, added_by, created_at) VALUES (?, ?, ?, ?)',\n        userId, expired, 'TOKEN_SYSTEM'");
    assert(a > 0 && b > a, 'klaim atomik harus ada SEBELUM pemberian akses');
    assert(/claim\.changes !== 1/.test(src));
  });
  await t('token reseller menulis kolom expired dan tidak memakai INSERT OR REPLACE', () => {
    assert(!/INSERT OR REPLACE INTO reseller_list \(user_id, added_by, added_at\) VALUES \(\?, \?, \?\)',\s*userId, 'TOKEN_SYSTEM'/.test(src));
    assert(/ON CONFLICT\(user_id\) DO UPDATE SET added_by = excluded.added_by, expired = excluded.expired',\s*userId, 'TOKEN_SYSTEM'/.test(src));
  });
  await t('deposit manual: order diklaim atomik sebelum saldo ditambah', () => {
    const accept = slice('async function handleDepositAccept(', 'async function accDeposit(').length ? slice('async function handleDepositAccept(', '\n}\n') : '';
    const c = accept.indexOf('AND status = "pending"');
    const d = accept.indexOf("updateProdukBalance(order.user_id");
    assert(c > 0 && d > c, 'klaim harus sebelum penambahan saldo');
    const acc = slice('async function accDeposit(', 'const now = moment()');
    assert(acc.indexOf('AND status = "PENDING"') < acc.indexOf('updateProdukBalance(payment.user_id'));
  });
  await t('penyapu: penanda expired tidak dipasang kalau pencabutan dilewati/gagal', () => {
    assert(/r\.skipped === 'in_progress' \|\| r\.error/.test(src));
  });
  await t('role reseller memeriksa kolom expired', () => {
    assert(/FROM reseller_list WHERE user_id = \? AND \(expired IS NULL OR expired > \?\)/.test(src));
  });
  await t('tidak ada throttle/pembuangan update di processUpdate', () => {
    assert(!/bot\.processUpdate = function/.test(src) && !/floodGuard/.test(src));
  });

  console.log(failed ? `\n${failed} GAGAL` : '\nSEMUA LOLOS');
  process.exit(failed ? 1 : 0);
})();
