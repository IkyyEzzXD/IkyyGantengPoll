module.exports = function createPromoRoundInner(ctx) {
  return async function _executePromoRoundInner(userId, chatId, isRestart = false) {
    const promosiProgress = ctx.promosiProgress;
    const promoRoundLocks = ctx.promoRoundLocks;
    const userbots = ctx.userbots;
    const lazyUbot = ctx.lazyUbot;
    const logger = ctx.logger;
    const telegramGuards = ctx.telegramGuards;
    const resolveGroupPeer = ctx.resolveGroupPeer;
    const isMediaForbiddenError = ctx.isMediaForbiddenError;
    const isPermanentGroupError = ctx.isPermanentGroupError;
    const promoAccessLapsed = ctx.promoAccessLapsed;
    const haltPromoForLapsedAccess = ctx.haltPromoForLapsedAccess;
    const savePromosiState = ctx.savePromosiState;
    const savePromosiStateToFile = ctx.savePromosiStateToFile;
    const executePromoRound = (...a) => ctx.executePromoRound(...a);
    const startautoBroadcast = (...a) => ctx.startautoBroadcast(...a);
    const db = ctx.getDb();
    const bot = ctx.getBot();
    const resolveForwardPeer = ctx.resolveForwardPeer;
    const resolveMediaForSend = ctx.resolveMediaForSend;
    const handleUserbotLogout = ctx.handleUserbotLogout;
    const escapeHtml = ctx.escapeHtml;
    const retention = ctx.retention;
    const payStreakReward = ctx.payStreakReward;
    const PROMO_MEDIA_TYPES = ctx.PROMO_MEDIA_TYPES;
    const getUserRole = ctx.getUserRole;
    const canUseMediaForPromo = ctx.canUseMediaForPromo;
    const WM = ctx.WM;

  const promo = promosiProgress[userId];
  if (!promo || !promo.running) return;

  if (promoRoundLocks[userId]) {
    logger.warn(`executePromoRound skip: user ${userId} masih locked (ronde sedang jalan)`);
    return;
  }
  promoRoundLocks[userId] = true;
  promo.completedNormally = false;
  if (global.promoCompletedOk) delete global.promoCompletedOk[userId];
  
  const ubot = userbots.find(ub => ub.owner_id === userId);
  if (!ubot) {
    if (chatId) {
      try { await bot.sendMessage(chatId, '❌ Userbot ga ketemu. Promosi dihentiin.', { parse_mode: 'HTML' }); } catch (e) {}
    }
    await db.run('UPDATE settings SET promosi_status = "OFF" WHERE owner_id = ?', userId);
    delete promosiProgress[userId];
    delete promoRoundLocks[userId];
    await savePromosiStateToFile();
    return;
  }

  if (await promoAccessLapsed(userId)) {
    delete promoRoundLocks[userId];
    await haltPromoForLapsedAccess(userId, chatId);
    return;
  }
  
  lazyUbot.pin(userId);
  try {

  let userbotDisplay = '';
  const [meResult, countRow, notifSettings] = await Promise.all([
    ubot.client.getMe().catch(() => null),
    db.get('SELECT COUNT(*) as count FROM promo_logs WHERE owner_id = ?', userId),
    db.get('SELECT notif_target, notif_to_saved FROM settings WHERE owner_id = ?', userId)
  ]);
  if (meResult) {
    userbotDisplay = `${meResult.firstName || ''} ${meResult.lastName || ''}`.trim();
    if (!userbotDisplay) userbotDisplay = meResult.username || `ID: ${meResult.id}`;
  } else {
    userbotDisplay = `ID: ${ubot.id}`;
  }
  
  promo.lastActivity = Date.now();
  
  let success = promo.success || 0;
  let failed = promo.failed || 0;
  let delayMs = promo.settings.current_delay || promo.settings.delay || 500;
  let floodDetected = promo.settings.flood_detected || false;
  
  let totalGroups = promo.validGroups.length;
  let processedGroups = promo.current || 0;
  let failedGroups = [];
  let skippedGroups = [];
  
  const roundNum = countRow.count + 1;
  const startTime = Date.now();
  const targetNotif = notifSettings?.notif_target || userId;
  const sendToSaved = notifSettings?.notif_to_saved === 1;
  
  if (!isRestart || processedGroups === 0) {
    const startMessage = `⚙️ BROADCAST DIMULAI\n\n👤 User ID : ${userId}\n🤖 Userbot : ${userbotDisplay}\n📊 Putaran Ke : ${roundNum}\n🎯 Target Grup : ${totalGroups} grup\n⏰ Delay : ${delayMs} ms`;

    (async () => {
      if (sendToSaved && ubot?.client) {
        try {
          await ubot.client.sendMessage('me', { message: startMessage });
        } catch(e) { console.error('Gagal kirim ke saved:', e.message); }
      } else if (targetNotif && String(targetNotif) !== String(userId)) {
        await telegramGuards.sendNotif({ ubot, bot, target: targetNotif, ownerId: userId, plain: startMessage, log: logger });
      } else {
        try {
          await bot.sendMessage(userId, startMessage, { parse_mode: 'HTML' });
        } catch(e) { console.error('Gagal kirim ke pemilik:', e.message); }
      }
    })().catch(() => {});
  }
  
  for (let i = processedGroups; i < totalGroups; i++) {
    if (!promosiProgress[userId]?.running) {
      await savePromosiState(userId);
      await savePromosiStateToFile();
      return;
    }

    if (i > processedGroups && (i - processedGroups) % 15 === 0 && await promoAccessLapsed(userId)) {
      await haltPromoForLapsedAccess(userId, chatId);
      return;
    }
    
    const group = promo.validGroups[i];
    let currentDelay = floodDetected ? Math.min(delayMs * 2, 5000) : delayMs;
    let sendSuccess = false;
    let retryCount = 0;
    const maxRetries = 2;
    let waitTime = 0;
    let errorReason = '';
    
    const blacklistCheck = await db.get('SELECT group_id FROM blacklist_groups WHERE owner_id = ? AND group_id = ?', userId, group.group_id.toString());
    if (blacklistCheck) {
      skippedGroups.push({
        name: group.group_username || group.group_title || group.group_id,
        id: group.group_id,
        reason: 'Blacklisted'
      });
      promo.current = i + 1;
      continue;
    }
    
    let targetPeer = group.group_id;
    try {
      targetPeer = await resolveGroupPeer(ubot.client, group);
    } catch (e) {
      targetPeer = group.group_id;
    }

    const sendTextOnly = async () => {
      let messageToSend = promo.messageContent || '';
      if (!messageToSend || !String(messageToSend).trim()) {
        messageToSend = (promo.selectedMessage.content || promo.selectedMessage.caption || '').toString();
      }
      if (!messageToSend || !String(messageToSend).trim()) {
        throw new Error('Tidak ada teks untuk dikirim (media dilarang & caption kosong)');
      }
      const entitiesJson = promo.selectedMessage.entities_json;
      if (entitiesJson) {
        try {
          const entities = JSON.parse(entitiesJson);
          if (entities && entities.length > 0) {
            await ubot.client.sendMessage(targetPeer, { message: messageToSend, entities: entities });
            return;
          }
        } catch (e) {}
      }
      await ubot.client.sendMessage(targetPeer, { message: messageToSend });
    };

    while (!sendSuccess && retryCount < maxRetries) {
      try {
        if (promo.selectedMessage.type === 'forward' && promo.selectedMessage.from_chat) {
          const fromPeer = await resolveForwardPeer(ubot.client, promo.selectedMessage);
          await ubot.client.forwardMessages(targetPeer, {
            fromPeer: fromPeer,
            messages: [parseInt(promo.selectedMessage.forward_message_id)]
          });
        }
        else if (promo.selectedMessage.file_id || promo.selectedMessage.media_path) {
          const captionText = promo.messageContent || '';
          const entitiesJson = promo.selectedMessage.entities_json;

          const mediaFile = await resolveMediaForSend(promo.selectedMessage);
          if (!mediaFile) {
            await sendTextOnly();
          } else {
            let sendOptions = { file: mediaFile };
            if (captionText) {
              sendOptions.caption = captionText;
            }
            if (entitiesJson) {
              try {
                const entities = JSON.parse(entitiesJson);
                if (entities && entities.length > 0) {
                  sendOptions.formattingEntities = entities;
                  sendOptions.caption_entities = entities;
                }
              } catch (e) {}
            }

            try {
              if (promo.selectedMessage.type === 'sticker') {
                await ubot.client.sendFile(targetPeer, { file: mediaFile });
              } else {
                await ubot.client.sendFile(targetPeer, sendOptions);
              }
            } catch (mediaErr) {
              const mediaErrMsg = mediaErr.message || String(mediaErr);
              if (isMediaForbiddenError(mediaErrMsg)) {
                await sendTextOnly();
              } else {
                throw mediaErr;
              }
            }
          }
        }
        else {
          await sendTextOnly();
        }
        sendSuccess = true;
        success++;

      } catch (err) {
        const errorMessage = err.message || String(err);
        errorReason = errorMessage;

        if (lazyUbot.isFatalAuthError(err)) {
          logger.warn(`executePromoRound: userbot ${userId} kena fatal auth error (${errorMessage}), hentikan broadcast & cleanup`);
          promo.completedNormally = true;
          delete promosiProgress[userId];
          await savePromosiStateToFile();
          try { await handleUserbotLogout(userId, ubot.id); } catch (cleanupErr) {
            logger.error(`gagal cleanup setelah fatal auth error userId=${userId}: ${cleanupErr.message}`);
          }
          return;
        }

        if (isPermanentGroupError(errorMessage)) {
          if (errorMessage.includes('USER_BANNED_IN_CHANNEL')) errorReason = 'Userbot dibanned dari grup';
          else if (errorMessage.includes('CHAT_NOT_FOUND') || errorMessage.includes('PEER_ID_INVALID')) errorReason = 'Grup tidak ditemukan / peer invalid';
          else if (errorMessage.includes('CHANNEL_PRIVATE')) errorReason = 'Channel/grup private';
          else if (errorMessage.includes('USER_NOT_PARTICIPANT')) errorReason = 'Userbot tidak join ke grup';
          else if (errorMessage.includes('CHAT_WRITE_FORBIDDEN')) errorReason = 'Grup membatasi pesan (banned/restrict)';
          else if (errorMessage.includes('CHAT_RESTRICTED')) errorReason = 'Grup restricted (dibatasi)';
          else if (errorMessage.includes('CHAT_SEND_PLAIN_FORBIDDEN')) errorReason = 'Grup tidak mengizinkan kirim pesan plain';
          else if (errorMessage.includes('ALLOW_PAYMENT_REQUIRED')) errorReason = 'Grup berbayar (allow payment required)';
          else if (errorMessage.includes('PEER_FLOOD')) errorReason = 'Peer flood, grup tidak bisa menerima pesan';
          else if (errorMessage.includes('CHAT_ADMIN_REQUIRED')) errorReason = 'Butuh admin untuk kirim pesan';
          else errorReason = errorMessage.substring(0, 100);

          sendSuccess = true;
          failed++;
          failedGroups.push({
            name: group.group_username || group.group_title || group.group_id,
            id: group.group_id,
            error: errorReason
          });
          break;
        }
        else if (errorMessage.includes('FLOOD_WAIT')) {
          const match = errorMessage.match(/FLOOD_WAIT[_\s]?(\d+)/i);
          if (match) {
            waitTime = parseInt(match[1]);
            floodDetected = true;
            promo.settings.current_delay = Math.min(delayMs * 2, 5000);
            await db.run('UPDATE settings SET current_delay = ? WHERE owner_id = ?', promo.settings.current_delay, userId);

            if (sendToSaved && ubot?.client) {
              try {
                await ubot.client.sendMessage('me', { message: `⚠️ Flood! Tunggu ${waitTime} detik...` });
              } catch(e) {}
            } else if (targetNotif && String(targetNotif) !== String(userId)) {
              await telegramGuards.sendNotif({ ubot, bot, target: targetNotif, ownerId: userId, plain: `⚠️ Flood! Tunggu ${waitTime} detik...`, log: logger });
            } else {
              try {
                await bot.sendMessage(userId, `⚠️ Flood! Tunggu ${waitTime} detik...`, { parse_mode: 'HTML' });
              } catch(e) {}
            }
            await new Promise(r => setTimeout(r, Math.min(waitTime, 300) * 1000));
          }
          continue;

        } else if (errorMessage.includes('FLOOD') || errorMessage.includes('Too Many Requests')) {
          floodDetected = true;
          promo.settings.current_delay = Math.min(delayMs * 1.5, 5000);
          await db.run('UPDATE settings SET current_delay = ? WHERE owner_id = ?', promo.settings.current_delay, userId);
          await new Promise(r => setTimeout(r, 5000));
          continue;
        }

        retryCount++;
        if (retryCount >= maxRetries) {
          failed++;
          failedGroups.push({
            name: group.group_username || group.group_title || group.group_id,
            id: group.group_id,
            error: (errorReason || 'Unknown').toString().substring(0, 100)
          });
          sendSuccess = true;
        } else {
          await new Promise(r => setTimeout(r, 3000));
        }
      }
    }
    
    promo.current = i + 1;
    promo.success = success;
    promo.failed = failed;
    promo.lastActivity = Date.now();
    await savePromosiState(userId);
    
    if (i < totalGroups - 1) {
      await new Promise(r => setTimeout(r, currentDelay));
    }
  }
  
  if (!floodDetected && promo.settings.current_delay > promo.settings.delay) {
    promo.settings.current_delay = promo.settings.delay;
    await db.run('UPDATE settings SET current_delay = ? WHERE owner_id = ?', promo.settings.delay, userId);
  }
  
  await db.run('UPDATE settings SET promosi_active = 0, promosi_round_data = NULL WHERE owner_id = ?', userId);
  
  const totalWaktu = Math.floor((Date.now() - startTime) / 1000);
  const roundCount = await db.get('SELECT COUNT(*) as count FROM promo_logs WHERE owner_id = ?', userId);
  const roundNumber = (roundCount.count || 0) + 1;
  
  const menit = Math.floor(totalWaktu / 60);
  const detik = totalWaktu % 60;
  const jedaMenit = promo.settings.jeda || 15;
  
  const resultMessage = `✅ BROADCAST SELESAI

👤 User ID : ${userId}
🤖 Userbot : ${userbotDisplay}
📊 Putaran Ke : ${roundNumber}
✅ Sukses : ${success} grup
❌ Gagal : ${failed} grup
📊 Total Target : ${totalGroups} grup
🕐 Waktu : ${menit} menit ${detik} detik
⏳ Putaran berikutnya dalam ${jedaMenit} menit`;

  const successRate = totalGroups > 0 ? Math.round((success / totalGroups) * 100) : 0;

  const summaryHTML = `<blockquote>✅ <b><u>BROADCAST SELESAI</u></b></blockquote>
<blockquote><b>📊 Ringkasan Putaran ke-${roundNumber}</b>
├ 👤 User ID : ${userId}
├ 🤖 Userbot : ${escapeHtml(userbotDisplay)}
├ 🎯 Total Target : ${totalGroups} grup
├ ✅ Sukses : ${success} grup
├ ❌ Gagal : ${failed} grup
├ 📈 Rate Sukses : ${successRate}%
├ 🕐 Waktu : ${menit} menit ${detik} detik
└ ⏳ Putaran berikutnya : ${jedaMenit} menit lagi</blockquote>`;

  const summaryPlain = `✅ BROADCAST SELESAI

📊 Ringkasan Putaran ke-${roundNumber}
├ 👤 User ID : ${userId}
├ 🤖 Userbot : ${userbotDisplay}
├ 🎯 Total Target : ${totalGroups} grup
├ ✅ Sukses : ${success} grup
├ ❌ Gagal : ${failed} grup
├ 📈 Rate Sukses : ${successRate}%
├ 🕐 Waktu : ${menit} menit ${detik} detik
└ ⏳ Putaran berikutnya : ${jedaMenit} menit lagi`;

  const MAX_FAILED_SHOWN = 30;
  const MAX_FAILED_CHARS = 2500;

  let failedDetailHTML = '';
  let failedDetailPlain = '';
  if (failedGroups.length > 0) {
    const shown = failedGroups.slice(0, MAX_FAILED_SHOWN);
    const moreNote = failedGroups.length > MAX_FAILED_SHOWN
      ? `\n\n... dan ${failedGroups.length - MAX_FAILED_SHOWN} grup lainnya`
      : '';

    let rowsHTML = shown.map((fg, idx) =>
      `${idx + 1}. ${escapeHtml(String(fg.name).substring(0, 40))} — <i>${escapeHtml(String(fg.error).substring(0, 80))}</i>`
    ).join('\n') + moreNote;
    if (rowsHTML.length > MAX_FAILED_CHARS) {
      rowsHTML = rowsHTML.slice(0, MAX_FAILED_CHARS) + `\n\n... (dipotong)`;
    }

    let rowsPlain = shown.map((fg, idx) =>
      `${idx + 1}. ${String(fg.name).substring(0, 40)} — ${String(fg.error).substring(0, 80)}`
    ).join('\n') + moreNote;
    if (rowsPlain.length > MAX_FAILED_CHARS) {
      rowsPlain = rowsPlain.slice(0, MAX_FAILED_CHARS) + `\n\n... (dipotong)`;
    }

    failedDetailHTML = `\n<blockquote expandable><b>❌ Daftar Grup Gagal (${failedGroups.length})</b>\n${rowsHTML}</blockquote>`;
    failedDetailPlain = `\n\n❌ Daftar Grup Gagal (${failedGroups.length}):\n${rowsPlain}`;
  }

  const htmlFullMsg = summaryHTML + failedDetailHTML;
  const plainFullMsg = summaryPlain + failedDetailPlain;

  const sendFinishNotif = async () => {
    const htmlMsg = htmlFullMsg;
    const plainMsg = plainFullMsg;

    if (sendToSaved && ubot?.client) {
      try {
        await ubot.client.sendMessage('me', { message: plainMsg });
        return;
      } catch (e1) {
        logger.warn(`Notif selesai ke Saved gagal (coba ulang): ${e1.message}`);
        await new Promise(r => setTimeout(r, 1500));
        try {
          await ubot.client.sendMessage('me', { message: plainMsg });
          return;
        } catch (e2) {
          logger.warn(`Notif selesai ke Saved gagal lagi: ${e2.message}`);
        }
      }
    }

    if (targetNotif && String(targetNotif) !== String(userId)) {
      const via = await telegramGuards.sendNotif({ ubot, bot, target: targetNotif, ownerId: userId, plain: plainMsg, html: htmlMsg, log: logger });
      if (via) return;
    }

    try {
      await bot.sendMessage(userId, htmlMsg, { parse_mode: 'HTML' });
    } catch (e1) {
      try {
        await bot.sendMessage(userId, plainMsg);
      } catch (e2) {
        logger.error(`Notif selesai ke user ${userId} gagal total: ${e2.message}`);
      }
    }
  };

  try {
    await sendFinishNotif();
  } catch (err) {
    try {
      await bot.sendMessage(userId, plainFullMsg);
    } catch (e) {}
  }

  await db.run(
    'INSERT INTO promo_logs (owner_id, round_number, total_groups, success, failed, started_at, finished_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
    userId, roundNumber, totalGroups, success, failed, Math.floor(startTime / 1000), Math.floor(Date.now() / 1000)
  );

  if (success > 0) {
    try {
      await db.run(
        'UPDATE userbots SET total_sent = COALESCE(total_sent, 0) + ?, last_active = ?, last_used = ? WHERE owner_id = ?',
        success, Math.floor(Date.now() / 1000), Math.floor(Date.now() / 1000), userId
      );
    } catch (e) {
      logger.error(`Gagal update total_sent untuk ${userId}: ${e.message}`);
    }
  }
  
  await db.run('UPDATE settings SET total_rounds = total_rounds + 1 WHERE owner_id = ?', userId);
  
  promo.running = false;
  promo.lastRunTime = Date.now();
  promo.completedNormally = true;
  promo.roundCompletedAt = Date.now();

  try { retention.recordPromoRun(userId); } catch (_) {}
  try {
    const promoAct = retention.recordActivity(userId);
    if (promoAct && promoAct.reward > 0) await payStreakReward(userId, promoAct.reward);
  } catch (_) {}
  
  await savePromosiStateToFile();
  
  const jedaMs = jedaMenit * 60 * 1000;

  if (!global.promoNextRunAt) global.promoNextRunAt = {};
  global.promoNextRunAt[userId] = Date.now() + jedaMs;
  if (!global.promoCompletedOk) global.promoCompletedOk = {};
  global.promoCompletedOk[userId] = true;
  
  if (global.promoTimeouts && global.promoTimeouts[userId]) {
    clearTimeout(global.promoTimeouts[userId]);
  }
  if (!global.promoTimeouts) global.promoTimeouts = {};
  
  global.promoTimeouts[userId] = setTimeout(async () => {
    try {
      delete global.promoTimeouts[userId];
      delete global.promoNextRunAt[userId];
      const settings = await db.get('SELECT promosi_status FROM settings WHERE owner_id = ?', userId);
      
      if (settings && settings.promosi_status === 'ON') {
        let groups = await db.all('SELECT * FROM groups WHERE owner_id = ?', userId);
        const blacklistGroups = await db.all('SELECT group_id FROM blacklist_groups WHERE owner_id = ?', userId);
        const blacklistIds = blacklistGroups.map(b => b.group_id.toString());
        let validGroups = groups.filter(g => {
          return parseInt(g.group_id) < 0 && !blacklistIds.includes(g.group_id.toString());
        });
        
        if (validGroups.length === 0) {
          await db.run('UPDATE settings SET promosi_status = "OFF" WHERE owner_id = ?', userId);
          return;
        }
        
        const selectedMessage = promo.selectedMessage;
        let messageContent = promo.messageContent;

        if (selectedMessage && PROMO_MEDIA_TYPES.includes(selectedMessage.type)) {
          const roleForNextRound = await getUserRole(userId);
          if (!canUseMediaForPromo(roleForNextRound)) {
            const fallbackText = (selectedMessage.content || selectedMessage.caption || '').toString().trim();
            if (!fallbackText) {
              logger.warn(`executePromoRound(jeda): stop user ${userId} - pesan media tanpa caption & plan (${roleForNextRound}) tidak boleh media`);
              await db.run('UPDATE settings SET promosi_status = "OFF" WHERE owner_id = ?', userId);
              return;
            }
            selectedMessage.type = 'text';
            selectedMessage.content = fallbackText;
            selectedMessage.file_id = null;
            selectedMessage.media_path = null;
          }
        }
        
        if (selectedMessage && selectedMessage.type !== 'forward') {
          const role = await getUserRole(userId);
          let watermarkToUse = '';
          
          if (role === 'PREMIUM_NO_WM' || role === 'RESELLER' || role === 'OWNER') {
            const freshSettings = await db.get('SELECT watermark, watermark_status FROM settings WHERE owner_id = ?', userId);
            if (freshSettings && freshSettings.watermark && freshSettings.watermark_status === 'ON') {
              watermarkToUse = freshSettings.watermark;
            }
          } else {
            watermarkToUse = WM;
          }
          
          messageContent = selectedMessage.content || '';
          if (watermarkToUse && messageContent) {
            messageContent = messageContent + '\n\n' + watermarkToUse;
          } else if (watermarkToUse && !messageContent) {
            messageContent = watermarkToUse;
          }
        }
        
        if (promoRoundLocks[userId] || promosiProgress[userId]?.running) {
          logger.warn(`Skip start ronde berikutnya ${userId}: masih locked/running`);
          return;
        }

        promosiProgress[userId] = {
          validGroups: validGroups,
          current: 0,
          success: 0,
          failed: 0,
          errors: [],
          running: true,
          startTime: Date.now(),
          settings: promo.settings,
          selectedMessage: selectedMessage,
          messageContent: messageContent,
          lastActivity: Date.now(),
          lastHeartbeat: Date.now(),
          chatId: chatId || promo.chatId,
          notifTarget: targetNotif,
          notifToSaved: sendToSaved
        };
        
        await savePromosiState(userId);
        await savePromosiStateToFile();
        
        executePromoRound(userId, targetNotif).catch(e => {
          logger.error(`executePromoRound setelah jeda gagal (${userId}):`, e && e.stack ? e.stack : e);
        });
      }
    } catch (jedaErr) {
      logger.error(`Jeda callback gagal (${userId}):`, jedaErr && jedaErr.stack ? jedaErr.stack : jedaErr);
      try {
        if (!global.promoTimeouts) global.promoTimeouts = {};
        if (!global.promoTimeouts[userId]) {
          global.promoTimeouts[userId] = setTimeout(() => {
            startautoBroadcast(userId, null).catch(() => {});
          }, 60000);
        }
      } catch (e) {}
    }
  }, jedaMs);

  } finally {
    try { lazyUbot.unpin(userId); } catch (e) {}
    delete promoRoundLocks[userId];
  }
  };
};
