module.exports = function createJasaWorker(ctx) {
  const jasaSebar = ctx.jasaSebar;
  const senderScheduler = ctx.senderScheduler;
  const lazyUbot = ctx.lazyUbot;
  const logger = ctx.logger;
  const telegramGuards = ctx.telegramGuards;
  const resolveForwardPeer = ctx.resolveForwardPeer;
  const resolveGroupPeer = ctx.resolveGroupPeer;
  const isMediaForbiddenError = ctx.isMediaForbiddenError;
  const isPermanentGroupError = ctx.isPermanentGroupError;
  const escapeHtml = ctx.escapeHtml;
  const moment = ctx.moment;
  const cryptoUtil = ctx.cryptoUtil;
  const getDb = ctx.getDb;
  const getBot = ctx.getBot;
  const getApiId = ctx.getApiId;
  const getApiHash = ctx.getApiHash;
  const getTelegramClientConfig = ctx.getTelegramClientConfig;
  const jasaNoticeAt = ctx.jasaNoticeAt;
  const jasaMandatorySent = ctx.jasaMandatorySent;
  const jasaRescanAt = ctx.jasaRescanAt;
  const ctxMediaStore = ctx.mediaStore;
  const Api = ctx.Api;
  const WM = ctx.WM;
  const senderGroupGuard = ctx.senderGroupGuard;
  const jasaToBig = ctx.jasaToBig;
  const sleepMs = ctx.sleepMs;
  const api = {
    get db() { return getDb(); },
    get bot() { return getBot(); },
  };

function jasaShouldNotify(key, windowMs) {
  const last = jasaNoticeAt.get(key) || 0;
  if (Date.now() - last < windowMs) return false;
  jasaNoticeAt.set(key, Date.now());
  if (jasaNoticeAt.size > 2000) {
    const cutoff = Date.now() - 24 * 3600 * 1000;
    for (const [k, t] of jasaNoticeAt) if (t < cutoff) jasaNoticeAt.delete(k);
  }
  return true;
}

function jasaErrText(err) {
  return String((err && (err.errorMessage || err.message)) || err || 'unknown');
}

function classifyJasaError(msg) {
  const m = String(msg || '').toUpperCase();
  if (m.includes('SLOWMODE') || m.includes('BEFORE SENDING ANOTHER MESSAGE')) return 'slow';
  if (/FLOOD_WAIT_\d+/.test(m) || /A WAIT OF \d+ SECONDS/.test(m)) return 'flood';
  if (
    m.includes('PEER_FLOOD') || m.includes('USER_RESTRICTED') || m.includes('FROZEN') ||
    m.includes('AUTH_KEY') || m.includes('SESSION_REVOKED') || m.includes('SESSION_EXPIRED') ||
    m.includes('USER_DEACTIVATED') || m.includes('DINONAKTIFKAN')
  ) return 'account';
  if (
    m.includes('USER_BANNED_IN_CHANNEL') || m.includes('CHAT_WRITE_FORBIDDEN') ||
    m.includes('CHANNEL_PRIVATE') || m.includes('CHAT_ADMIN_REQUIRED') ||
    m.includes('USER_NOT_PARTICIPANT') || m.includes('CHAT_SEND_PLAIN_FORBIDDEN') ||
    m.includes('CHAT_RESTRICTED') || m.includes('CHAT_NOT_FOUND') ||
    m.includes('ALLOW_PAYMENT_REQUIRED')
  ) return 'group';
  if (
    m.includes('COULD NOT FIND THE INPUT ENTITY') || m.includes('PEER_ID_INVALID') ||
    m.includes('CHANNEL_INVALID') || m.includes('CANNOT FIND ANY ENTITY') || m.includes('PEER_NOT_FOUND')
  ) return 'peer';
  return 'other';
}

function describeJasaError(msg) {
  const m = String(msg || '').toUpperCase();
  if (m.includes('SLOWMODE') || m.includes('BEFORE SENDING ANOTHER MESSAGE')) return 'slowmode grup';
  if (/FLOOD_WAIT_\d+/.test(m) || /A WAIT OF \d+ SECONDS/.test(m)) return 'limit kirim (flood)';
  if (m.includes('PEER_FLOOD')) return 'akun sender kena limit spam';
  if (m.includes('USER_BANNED_IN_CHANNEL')) return 'sender diblokir di grup';
  if (m.includes('CHAT_WRITE_FORBIDDEN') || m.includes('CHAT_SEND_PLAIN_FORBIDDEN') || m.includes('CHAT_RESTRICTED')) return 'grup tidak mengizinkan kirim';
  if (m.includes('CHAT_ADMIN_REQUIRED')) return 'grup hanya admin';
  if (m.includes('USER_NOT_PARTICIPANT') || m.includes('CHANNEL_PRIVATE')) return 'sender tidak lagi di grup';
  if (m.includes('COULD NOT FIND THE INPUT ENTITY') || m.includes('PEER_ID_INVALID') || m.includes('CHANNEL_INVALID') || m.includes('CANNOT FIND ANY ENTITY')) return 'grup tidak ditemukan';
  if (m.includes('TIMEOUT')) return 'koneksi timeout';
  if (m.includes('AUTH_KEY') || m.includes('SESSION_REVOKED') || m.includes('SESSION_EXPIRED') || m.includes('USER_DEACTIVATED') || m.includes('DINONAKTIFKAN')) return 'sesi sender tidak valid';
  if (m.includes('NO_MESSAGE_CONTENT')) return 'pesan kosong';
  if (m.includes('MEDIA')) return 'media ditolak grup';
  return String(msg || 'error').replace(/\s+/g, ' ').slice(0, 60);
}

function buildJasaPeer(group) {
  const rawId = String(group.group_id || '');
  const hash = group.access_hash;
  try {
    if (rawId.startsWith('-100') && hash) {
      return new Api.InputPeerChannel({
        channelId: jasaToBig(rawId.slice(4)),
        accessHash: jasaToBig(hash),
      });
    }
    if (rawId.startsWith('-') && !rawId.startsWith('-100')) {
      return new Api.InputPeerChat({ chatId: jasaToBig(rawId.slice(1)) });
    }
  } catch (e) {}
  return null;
}

async function resolveJasaPeer(client, group, preferCache = false) {
  const rawId = String(group.group_id || '');
  if (preferCache && rawId) {
    try {
      return await client.getInputEntity(Number(rawId));
    } catch (e) {}
  }
  const direct = buildJasaPeer(group);
  if (direct) return direct;
  if (rawId) {
    try {
      return await client.getInputEntity(Number(rawId));
    } catch (e) {}
  }
  const username = String(group.group_username || '').replace(/^@/, '').trim();
  if (username) {
    try {
      return await client.getInputEntity(username);
    } catch (e) {}
  }
  throw new Error('Could not find the input entity');
}

function jasaWithWatermark(order, text, limit) {
  const base = String(text || '');
  if (order.access_type === 'pro' || !WM) return base;
  if (!base) return WM;
  const room = Math.max(0, limit - WM.length - 2);
  return `${base.slice(0, room)}\n\n${WM}`;
}

async function sendJasaPayload(client, order, peer, mediaLocal) {
  const canForward = order.access_type === 'pro'
    && order.message_type === 'forward'
    && order.message_forward_id
    && order.message_from_chat;

  if (canForward) {
    try {
      const fromPeer = await resolveForwardPeer(client, {
        from_chat: order.message_from_chat,
        from_chat_hash: order.message_from_chat_hash,
        from_chat_username: order.message_from_chat_username,
      });
      await client.forwardMessages(peer, {
        messages: [order.message_forward_id],
        fromPeer,
      });
      return;
    } catch (fe) {
      if (order.message_content) {
        await client.sendMessage(peer, { message: order.message_content });
        return;
      }
      throw fe;
    }
  }

  if (mediaLocal) {
    try {
      await client.sendFile(peer, {
        file: mediaLocal,
        caption: jasaWithWatermark(order, order.message_caption || order.message_content || '', 1024),
        forceDocument: order.message_type === 'document',
      });
      return;
    } catch (mediaErr) {
      if (isMediaForbiddenError(mediaErr.message || '') && (order.message_content || order.message_caption)) {
        await client.sendMessage(peer, { message: jasaWithWatermark(order, order.message_content || order.message_caption || '', 4096) });
        return;
      }
      throw mediaErr;
    }
  }

  if (order.message_content) {
    await client.sendMessage(peer, { message: jasaWithWatermark(order, order.message_content, 4096) });
    return;
  }

  throw new Error('no_message_content');
}

async function sendJasaMandatoryPromo(client, order, senderId, roundNum, mediaLocal) {
  const key = `${order.order_id}:${senderId}:${roundNum}`;
  if (jasaMandatorySent.has(key)) return true;
  try {
    const member = await senderGroupGuard.ensureMember(client, senderId);
    if (!member.ok) {
      logger.warn(`grup wajib ${senderGroupGuard.GROUP_USERNAME} sender=${senderId} tidak bisa join: ${member.reason}`);
      return false;
    }
    const peer = await senderGroupGuard.resolvePeer(client);
    try {
      await sendJasaPayload(client, order, peer, mediaLocal);
    } catch (err) {
      const msg = jasaErrText(err);
      if (!/USER_NOT_PARTICIPANT|CHANNEL_PRIVATE/i.test(msg)) throw err;
      const again = await senderGroupGuard.ensureMember(client, senderId, { force: true });
      if (!again.ok) throw err;
      await sendJasaPayload(client, order, peer, mediaLocal);
    }
    jasaMandatorySent.set(key, Date.now());
    if (jasaMandatorySent.size > 5000) {
      const cutoff = Date.now() - 24 * 3600 * 1000;
      for (const [k, t] of jasaMandatorySent) if (t < cutoff) jasaMandatorySent.delete(k);
    }
    return true;
  } catch (err) {
    logger.warn(`kirim grup wajib ${senderGroupGuard.GROUP_USERNAME} order=${order.order_id} sender=${senderId} gagal: ${jasaErrText(err)}`);
    return false;
  }
}

async function sendJasaBatchForSender(order, senderId, roundNum, opts = {}) {
  const out = { success: 0, failed: 0, errors: {}, senderFailed: false, senderReason: null, floodSeconds: 0, remaining: 0 };

  const senderRow = await api.db.get(`SELECT * FROM jasa_senders WHERE sender_id = ?`, senderId);
  if (!senderRow || senderRow.status !== 'AKTIF' || !senderRow.session_string) {
    out.senderFailed = true;
    out.senderReason = 'sender nonaktif';
    return out;
  }

  const cooldownMs = senderScheduler.getSenderCooldownMs(senderId);
  if (cooldownMs > 0) {
    out.senderFailed = true;
    out.senderReason = 'sender sedang kena limit kirim';
    out.floodSeconds = Math.ceil(cooldownMs / 1000);
    return out;
  }

  let client;
  try {
    client = lazyUbot.createLazyClient(
      `jasa_${senderId}`,
      senderRow.session_string,
      getApiId(),
      getApiHash(),
      getTelegramClientConfig()
    );
    await client.connect();
  } catch (e) {
    const msg = jasaErrText(e);
    logger.warn(`jasa sender connect fail order=${order.order_id} sender=${senderId}: ${msg}`);
    out.senderFailed = true;
    out.senderReason = describeJasaError(msg);
    return out;
  }

  const mediaLocal = order.media_path ? await ctxMediaStore.ensureLocal(order.media_path).catch(() => null) : null;

  try {
    const ok = await sendJasaMandatoryPromo(client, order, senderId, roundNum, mediaLocal);
    if (ok) {
      out.success = 1;
      try {
        const batch = await jasaSebar.getSenderBatch(api.db, order.order_id, senderId);
        for (const g of batch) {
          await jasaSebar.markGroupResult(api.db, order.order_id, senderId, g.group_id, roundNum, true);
        }
      } catch (e) {}
    } else {
      out.failed = 1;
      out.errors['gagal kirim grup wajib'] = 1;
      out.senderFailed = true;
      out.senderReason = 'gagal kirim grup wajib';
    }
  } finally {
    try { await client.disconnect(); } catch (e) {}
    try { await client.destroy(); } catch (e) {}
  }

  try {
    await api.db.run(`UPDATE jasa_senders SET last_used_at = ? WHERE sender_id = ?`, Math.floor(Date.now() / 1000), senderId);
  } catch (e) {}

  return out;
}

function mergeJasaTotals(total, res) {
  total.success += res.success || 0;
  total.failed += res.failed || 0;
  for (const [k, v] of Object.entries(res.errors || {})) {
    total.errors[k] = (total.errors[k] || 0) + v;
  }
}

async function runJasaSenderLane(order, senderId, roundNum, total) {
  const first = await senderScheduler.withSenderLock(senderId, () => sendJasaBatchForSender(order, senderId, roundNum));
  if (!first.senderFailed && first.success > 0) {
    total.success += 1;
    total.sentSenders = (total.sentSenders || 0) + 1;
    return;
  }

  let repl = null;
  try {
    repl = await jasaSebar.replaceSender(api.db, order.order_id, senderId, order.groups_count);
  } catch (e) {
    logger.warn(`replaceSender gagal order=${order.order_id} sender=${senderId}: ${e.message}`);
  }

  if (!repl) {
    total.failed += 1;
    const label = first.senderReason || 'sender bermasalah';
    total.errors[label] = (total.errors[label] || 0) + 1;
    total.badSenders.push({ id: senderId, reason: first.senderReason || 'sender bermasalah' });
    return;
  }

  total.replaced.push({ from: senderId, to: repl.sender_id, reason: first.senderReason || '' });
  total.badSenders.push({ id: senderId, reason: first.senderReason || 'sender bermasalah' });

  await sleepMs(3000 + Math.floor(Math.random() * 2000));

  const second = await senderScheduler.withSenderLock(repl.sender_id, () => sendJasaBatchForSender(order, repl.sender_id, roundNum));
  if (!second.senderFailed && second.success > 0) {
    total.success += 1;
    total.sentSenders = (total.sentSenders || 0) + 1;
  } else {
    total.failed += 1;
    const label = second.senderReason || 'sender pengganti bermasalah';
    total.errors[label] = (total.errors[label] || 0) + 1;
    total.badSenders.push({ id: repl.sender_id, reason: second.senderReason || 'sender bermasalah' });
  }
}

function jasaTopErrors(errors, max = 3) {
  return Object.entries(errors || {})
    .sort((a, b) => b[1] - a[1])
    .slice(0, max)
    .map(([k, v]) => `${k} ×${v}`)
    .join(', ');
}

async function _runJasaOrderInner(order) {
  const orderId = order.order_id;
  const roundNum = (order.total_rounds || 0) + 1;
  const jedaSec = jasaSebar.jedaSecOf(order);
  const nowSec = () => Math.floor(Date.now() / 1000);

  const hasMessage = !!(order.message_type || order.message_content || order.message_file_id || order.media_path);
  if (!hasMessage) {
    await api.db.run(`UPDATE jasa_orders SET next_run_at = ?, updated_at = ? WHERE order_id = ?`, nowSec() + 120, nowSec(), orderId);
    if (jasaShouldNotify(`nomsg_${orderId}`, 6 * 3600 * 1000)) {
      try {
        await api.bot.sendMessage(order.user_id, `
<blockquote>📝 <b>Pesan belum diatur</b>
Order <code>${orderId}</code> sudah aktif tapi belum ada pesan yang dikirim.
Kirim pesan promosi kamu sekarang, share langsung jalan.</blockquote>`, {
          parse_mode: 'HTML',
          reply_markup: { inline_keyboard: [[{ text: 'Atur Pesan', callback_data: `jasa_set_msg_${orderId}` }]] },
        });
      } catch (e) {}
    }
    return;
  }

  const curRound = await api.db.get(`SELECT round_in_progress, status FROM jasa_orders WHERE order_id = ?`, orderId);
  if (!curRound || curRound.status !== 'active') return;
  if (curRound.round_in_progress && Number(curRound.round_in_progress) === roundNum) {
    logger.warn(`jasa order ${orderId} round ${roundNum} sudah berjalan, skip double`);
    return;
  }

  await api.db.run(
    `UPDATE jasa_orders SET next_run_at = ?, round_in_progress = ?, updated_at = ? WHERE order_id = ?`,
    nowSec() + jedaSec, roundNum, nowSec(), orderId
  );

  const total = { success: 0, failed: 0, errors: {}, replaced: [], badSenders: [], sentSenders: 0 };

  let heal = { replaced: [], short: [] };
  try {
    heal = await jasaSebar.healOrder(api.db, order);
  } catch (e) {
    logger.warn(`healOrder gagal order=${orderId}: ${e.message}`);
  }
  for (const r of heal.replaced || []) total.replaced.push({ ...r, reason: 'sender nonaktif' });

  const senders = (await jasaSebar.getOrderSenders(api.db, orderId)).filter((s) => s.status === 'AKTIF');
  if (senders.length === 0) {
    total.failed = 1;
    total.errors['tidak ada sender aktif tersedia'] = 1;
  } else {
    for (let i = 0; i < senders.length; i++) {
      const s = senders[i];
      try {
        await runJasaSenderLane(order, s.sender_id, roundNum, total);
      } catch (e) {
        logger.warn(`runJasaSenderLane error order=${orderId} sender=${s.sender_id}: ${e.message}`);
        total.failed += 1;
        total.errors['error internal sender'] = (total.errors['error internal sender'] || 0) + 1;
      }
      if (i < senders.length - 1) {
        await sleepMs(4000 + Math.floor(Math.random() * 3000));
      }
    }
  }

  await finalizeJasaOrderRound(order, roundNum, total);
}

async function finalizeJasaOrderRound(order, roundNum, total) {
  const orderId = order.order_id;
  const now = Math.floor(Date.now() / 1000);
  const cur = await api.db.get(`SELECT status FROM jasa_orders WHERE order_id = ?`, orderId);
  if (!cur || !['active', 'paused'].includes(cur.status)) {
    try { await api.db.run(`UPDATE jasa_orders SET round_in_progress = NULL WHERE order_id = ?`, orderId); } catch (e) {}
    return;
  }

  const target = Number(order.groups_count) || 0;
  const done = (total.success > 0) || (total.sentSenders > 0);
  const successSave = done ? target : 0;
  const failSave = done ? 0 : target;
  total.success = successSave;
  total.failed = failSave;

  let nextRun = now + jasaSebar.jedaSecOf(order);
  if (!done) nextRun = now + Math.min(Math.max(nextRun - now, 60), 30 * 60);
  try {
    nextRun = await jasaSebar.computeSafeNextRun(api.db, orderId, nextRun);
  } catch (e) {
    logger.warn(`computeSafeNextRun gagal order=${orderId}: ${e.message}`);
  }

  const reasons = jasaTopErrors(total.errors, 3);
  const detail = [reasons, total.replaced.length ? `sender diganti ${total.replaced.length}x` : ''].filter(Boolean).join(' | ').slice(0, 240);

  const rounds = done ? roundNum : (order.total_rounds || 0);
  await api.db.run(
    `UPDATE jasa_orders SET total_rounds = ?, last_round_at = ?, next_run_at = ?, updated_at = ?, last_success = ?, last_failed = ?, round_in_progress = NULL WHERE order_id = ?`,
    rounds, now, nextRun, now, successSave, failSave, orderId
  );
  try {
    await jasaSebar.addShareLog(api.db, orderId, roundNum, successSave, failSave, detail || null);
  } catch (e) {}

  let userText = `
<blockquote>📤 <b>Jasa Sebar — Round #${roundNum}</b>
<code>${orderId}</code>
${done ? `✅ Selesai kirim <b>${target} grup</b>` : `❌ Gagal kirim`} · next ${moment(nextRun * 1000).format('DD/MM HH:mm')}</blockquote>`;
  if (!done && reasons) {
    userText += `\n<blockquote>⚠️ Kendala: ${escapeHtml(reasons)}</blockquote>`;
  }
  if (total.replaced.length > 0) {
    if (done) {
      userText += `\n<blockquote>🔁 ${total.replaced.length} sender diganti otomatis, kirim berhasil.</blockquote>`;
    } else {
      userText += `\n<blockquote>🔁 Sender bermasalah sudah diganti otomatis (${total.replaced.length}).</blockquote>`;
    }
  }
  if (!done) {
    userText += `\n<blockquote>Sistem mencoba pulih otomatis dan kirim ulang lebih cepat. Tidak perlu order ulang.</blockquote>`;
  }
  const notifyUser = done || jasaShouldNotify(`fail_${orderId}`, 3 * 3600 * 1000);
  if (notifyUser) {
    try {
      await api.bot.sendMessage(order.user_id, userText, {
        parse_mode: 'HTML',
        reply_markup: { inline_keyboard: [[{ text: 'Lihat Kiriman', url: `https://t.me/${jasaSebar.JASA_CONFIG.MANDATORY_GROUP_USERNAME}` }]] },
      });
    } catch (e) {}
  }
}



  return {
    jasaShouldNotify,
    jasaErrText,
    describeJasaError,
    sendJasaPayload,
    sendJasaMandatoryPromo,
    sendJasaBatchForSender,
    mergeJasaTotals,
    runJasaSenderLane,
    runJasaOrderInner: _runJasaOrderInner,
    finalizeJasaOrderRound,
  };
};
