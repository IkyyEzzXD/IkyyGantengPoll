const DEFAULTS = {
  maxPoolSize: 400,
  minPoolSize: 30,
  maxIdleTimeMS: 5 * 60 * 1000,
  waitQueueTimeoutMS: 12000,
  serverSelectionTimeoutMS: 20000,
  connectTimeoutMS: 25000,
  socketTimeoutMS: 120000,
  heartbeatFrequencyMS: 10000,
  keepAliveInitialDelay: 15000,
  retryBudgetMS: 45000,
  retryMaxAttempts: 10,
  retryBaseMs: 200,
  retryMaxMs: 4000,
  connectMaxAttempts: 0,
  ipFamily: 4,
  monitorMode: 'poll',
  opConcurrency: 48,
  writeConcurrency: 24,
  cacheTtlMs: 30000,
  cacheMaxEntries: 8000,
  cacheMaxRows: 300,
  cacheTotalRows: 40000,
  queueMaxWaiting: 4000,
  queueWaitMs: 15000
};

function numEnv(key, fallback) {
  const raw = process.env[key];
  if (raw === undefined || raw === null || raw === '') return fallback;
  const n = Number(raw);
  return Number.isFinite(n) ? n : fallback;
}

function strEnv(key, fallback) {
  const raw = process.env[key];
  if (raw === undefined || raw === null || raw === '') return fallback;
  return String(raw);
}

function loadPoolOptions() {
  const maxPoolSize = Math.max(50, numEnv('MONGODB_POOL_MAX', DEFAULTS.maxPoolSize));
  const minPoolSize = Math.min(maxPoolSize, Math.max(0, numEnv('MONGODB_POOL_MIN', DEFAULTS.minPoolSize)));
  return {
    maxPoolSize,
    minPoolSize,
    maxIdleTimeMS: numEnv('MONGODB_MAX_IDLE_MS', DEFAULTS.maxIdleTimeMS),
    waitQueueTimeoutMS: numEnv('MONGODB_WAIT_QUEUE_TIMEOUT_MS', DEFAULTS.waitQueueTimeoutMS),
    serverSelectionTimeoutMS: numEnv('MONGODB_SELECTION_TIMEOUT_MS', DEFAULTS.serverSelectionTimeoutMS),
    connectTimeoutMS: numEnv('MONGODB_CONNECT_TIMEOUT_MS', DEFAULTS.connectTimeoutMS),
    socketTimeoutMS: numEnv('MONGODB_SOCKET_TIMEOUT_MS', DEFAULTS.socketTimeoutMS),
    heartbeatFrequencyMS: numEnv('MONGODB_HEARTBEAT_MS', DEFAULTS.heartbeatFrequencyMS),
    keepAliveInitialDelay: numEnv('MONGODB_KEEPALIVE_DELAY_MS', DEFAULTS.keepAliveInitialDelay),
    retryReads: true,
    retryWrites: true
  };
}

function loadRetryOptions() {
  return {
    budgetMs: numEnv('MONGODB_RETRY_BUDGET_MS', DEFAULTS.retryBudgetMS),
    maxAttempts: numEnv('MONGODB_RETRY_MAX_ATTEMPTS', DEFAULTS.retryMaxAttempts),
    baseMs: numEnv('MONGODB_RETRY_BASE_MS', DEFAULTS.retryBaseMs),
    maxMs: numEnv('MONGODB_RETRY_MAX_MS', DEFAULTS.retryMaxMs)
  };
}

function loadConnectOptions() {
  return {
    maxAttempts: numEnv('MONGODB_CONNECT_MAX_ATTEMPTS', DEFAULTS.connectMaxAttempts),
    ipFamily: numEnv('MONGODB_IP_FAMILY', DEFAULTS.ipFamily),
    monitorMode: strEnv('MONGODB_MONITOR_MODE', DEFAULTS.monitorMode)
  };
}

function loadQueueOptions() {
  return {
    opConcurrency: Math.max(8, numEnv('MONGODB_OP_CONCURRENCY', DEFAULTS.opConcurrency)),
    writeConcurrency: Math.max(4, numEnv('MONGODB_WRITE_CONCURRENCY', DEFAULTS.writeConcurrency)),
    maxWaiting: Math.max(100, numEnv('MONGODB_QUEUE_MAX_WAITING', DEFAULTS.queueMaxWaiting)),
    waitMs: Math.max(0, numEnv('MONGODB_QUEUE_WAIT_MS', DEFAULTS.queueWaitMs))
  };
}

function loadCacheOptions() {
  return {
    ttlMs: Math.max(1000, numEnv('MONGODB_READ_CACHE_TTL_MS', DEFAULTS.cacheTtlMs)),
    maxEntries: Math.max(500, numEnv('MONGODB_CACHE_MAX_ENTRIES', DEFAULTS.cacheMaxEntries)),
    maxRows: Math.max(50, numEnv('MONGODB_CACHE_MAX_ROWS', DEFAULTS.cacheMaxRows)),
    totalRows: Math.max(1000, numEnv('MONGODB_CACHE_TOTAL_ROWS', DEFAULTS.cacheTotalRows))
  };
}

const TRANSIENT_NAMES = new Set([
  'MongoNetworkError',
  'MongoNetworkTimeoutError',
  'MongoServerSelectionError',
  'MongoPoolClearedError',
  'MongoWaitQueueTimeoutError',
  'PoolClearedOnNetworkError',
  'MongoTopologyClosedError',
  'MongoNotConnectedError'
]);

const TRANSIENT_CODES = new Set([6, 7, 89, 91, 189, 9001, 10107, 11600, 11602, 13435, 13436]);

const TRANSIENT_MSG = /secureConnect|server monitor timeout|connection <monitor>|connection pool .*cleared|interrupted due to|ECONNRESET|ETIMEDOUT|ECONNREFUSED|ENOTFOUND|EAI_AGAIN|ENETUNREACH|EHOSTUNREACH|EPIPE|socket hang up|topology (is|was) closed|ReplicaSetNoPrimary|no primary|timed out|Timeout|network error|not primary|node is recovering|interrupted at shutdown|must be connected before running operations|getaddrinfo/i;

function isTransientError(err, forWrite) {
  if (!err) return false;
  const name = err.name || '';
  const code = err.code;
  const msg = String(err.message || '');
  if (TRANSIENT_NAMES.has(name)) return true;
  if (TRANSIENT_CODES.has(code)) return true;
  if (typeof err.hasErrorLabel === 'function') {
    if (err.hasErrorLabel('RetryableWriteError') || err.hasErrorLabel('TransientTransactionError') || err.hasErrorLabel('RetryableError')) return true;
  }
  if (TRANSIENT_MSG.test(msg)) return true;
  if (forWrite === true && /WriteConflict|TransientTransactionError/i.test(msg)) return true;
  return false;
}

function isNotConnectedError(err) {
  return !!err && (
    err.name === 'MongoNotConnectedError' ||
    /must be connected before running operations/i.test(String(err.message || ''))
  );
}

const PRE_SEND_NAMES = new Set([
  'MongoServerSelectionError',
  'MongoPoolClearedError',
  'PoolClearedOnNetworkError',
  'MongoWaitQueueTimeoutError',
  'MongoTopologyClosedError',
  'MongoNotConnectedError'
]);

const PRE_SEND_CODES = new Set([91, 112, 10107, 13435, 13436]);

const PRE_SEND_MSG = /secureConnect|ECONNREFUSED|ENOTFOUND|EAI_AGAIN|ENETUNREACH|EHOSTUNREACH|getaddrinfo|must be connected before running operations|topology (is|was) closed|connection pool .*cleared|not primary|NotWritablePrimary|node is recovering|WriteConflict/i;

function isPreSendError(err) {
  if (!err) return false;
  if (PRE_SEND_NAMES.has(err.name)) return true;
  if (PRE_SEND_CODES.has(err.code)) return true;
  return PRE_SEND_MSG.test(String(err.message || ''));
}

const IDEMPOTENT_UPDATE_OPS = new Set(['$set', '$unset', '$setOnInsert', '$max', '$min', '$currentDate']);

function modeForUpdate(update) {
  if (!update || Array.isArray(update) || typeof update !== 'object') return 'write';
  const keys = Object.keys(update);
  if (!keys.length) return 'idem';
  return keys.every(k => IDEMPOTENT_UPDATE_OPS.has(k)) ? 'idem' : 'write';
}

function normalizeMode(mode) {
  if (mode === true || mode === 'write') return 'write';
  if (mode === 'idem') return 'idem';
  return 'read';
}

function isRetryable(err, mode) {
  if (!err || err.backpressure) return false;
  if (mode === 'write') return isPreSendError(err);
  return isTransientError(err, mode === 'idem');
}

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

function backoffMs(attempt, opts) {
  const base = opts.baseMs || DEFAULTS.retryBaseMs;
  const cap = opts.maxMs || DEFAULTS.retryMaxMs;
  const exp = Math.min(base * Math.pow(2, Math.min(attempt, 5)), cap);
  return exp + Math.floor(Math.random() * Math.min(200, base));
}

function backpressureError(name, message) {
  const e = new Error(message);
  e.name = name;
  e.backpressure = true;
  return e;
}

class OpQueue {
  constructor(max, opts = {}) {
    this.max = Math.max(1, max | 0);
    this.maxWaiting = opts.maxWaiting > 0 ? opts.maxWaiting : Infinity;
    this.waitMs = opts.waitMs > 0 ? opts.waitMs : 0;
    this.active = 0;
    this.queue = [];
    this.rejected = 0;
    this.expired = 0;
  }

  setMax(n) {
    this.max = Math.max(1, n | 0);
    this._pump();
  }

  stats() {
    return {
      active: this.active,
      waiting: this.queue.length,
      max: this.max,
      maxWaiting: this.maxWaiting,
      rejected: this.rejected,
      expired: this.expired
    };
  }

  run(fn) {
    return new Promise((resolve, reject) => {
      if (this.active < this.max && this.queue.length === 0) {
        this._start({ fn, resolve, reject, timer: null });
        return;
      }
      if (this.queue.length >= this.maxWaiting) {
        this.rejected++;
        reject(backpressureError('MongoQueueOverflowError', `antrean MongoDB penuh (${this.queue.length} menunggu, ${this.active} berjalan)`));
        return;
      }
      const job = { fn, resolve, reject, timer: null };
      if (this.waitMs > 0) {
        job.timer = setTimeout(() => {
          const i = this.queue.indexOf(job);
          if (i === -1) return;
          this.queue.splice(i, 1);
          this.expired++;
          reject(backpressureError('MongoQueueTimeoutError', `menunggu antrean MongoDB lebih dari ${this.waitMs} ms`));
        }, this.waitMs);
      }
      this.queue.push(job);
    });
  }

  _start(job) {
    this.active++;
    let p;
    try {
      p = Promise.resolve(job.fn());
    } catch (e) {
      p = Promise.reject(e);
    }
    p.then(job.resolve, job.reject).then(() => {
      this.active = Math.max(0, this.active - 1);
      this._pump();
    });
  }

  _pump() {
    while (this.active < this.max && this.queue.length > 0) {
      const job = this.queue.shift();
      if (job.timer) clearTimeout(job.timer);
      this._start(job);
    }
  }

  async drain(timeoutMs) {
    const end = Date.now() + timeoutMs;
    while ((this.active > 0 || this.queue.length > 0) && Date.now() < end) await sleep(25);
  }
}

let readQueue = null;
let writeQueue = null;

function ensureQueues() {
  if (!readQueue || !writeQueue) {
    const q = loadQueueOptions();
    const shared = { maxWaiting: q.maxWaiting, waitMs: q.waitMs };
    readQueue = new OpQueue(q.opConcurrency, shared);
    writeQueue = new OpQueue(q.writeConcurrency, shared);
  }
  return { readQueue, writeQueue };
}

function resetQueues() {
  readQueue = null;
  writeQueue = null;
}

function queueStats() {
  ensureQueues();
  return { read: readQueue.stats(), write: writeQueue.stats() };
}

async function drainQueues(timeoutMs) {
  ensureQueues();
  await Promise.all([readQueue.drain(timeoutMs), writeQueue.drain(timeoutMs)]);
}

function withQueuedOp(fn, isWrite) {
  const q = ensureQueues();
  return (isWrite ? q.writeQueue : q.readQueue).run(fn);
}

async function withDbRetry(fn, options = {}) {
  const mode = normalizeMode(options.mode);
  const retry = Object.assign({}, loadRetryOptions(), options.retry || {});
  const queues = ensureQueues();
  const queue = mode === 'read' ? queues.readQueue : queues.writeQueue;
  const started = Date.now();
  const maxAttempts = retry.maxAttempts > 0 ? retry.maxAttempts : 50;
  let revived = false;
  let last;
  for (let i = 0; i < maxAttempts; i++) {
    try {
      return await queue.run(fn);
    } catch (e) {
      last = e;
      if (!e || e.backpressure) throw e;
      if (typeof options.isClosing === 'function' && options.isClosing()) throw e;
      if (isNotConnectedError(e) && !revived && typeof options.onNotConnected === 'function') {
        revived = true;
        try {
          await options.onNotConnected();
        } catch (_) {}
        continue;
      }
      if (!isRetryable(e, mode)) throw e;
      const elapsed = Date.now() - started;
      if (elapsed >= retry.budgetMs) throw e;
      const wait = Math.min(backoffMs(i, retry), Math.max(0, retry.budgetMs - elapsed));
      if (wait > 0) await sleep(wait);
    }
  }
  throw last || new Error('MongoDB retry exhausted');
}

function buildClientOptions(extra = {}) {
  const pool = loadPoolOptions();
  const conn = loadConnectOptions();
  const base = Object.assign({}, pool, {
    serverMonitoringMode: conn.monitorMode
  });
  if (conn.ipFamily === 4 || conn.ipFamily === 6) {
    base.family = conn.ipFamily;
  }
  return Object.assign(base, extra || {});
}

function createMongoClient(uri, MongoClientCtor, extra = {}) {
  const opts = buildClientOptions(extra);
  try {
    return new MongoClientCtor(uri, opts);
  } catch (_) {
    const { family, serverMonitoringMode, ...safe } = opts;
    return new MongoClientCtor(uri, safe);
  }
}

module.exports = {
  DEFAULTS,
  loadPoolOptions,
  loadRetryOptions,
  loadConnectOptions,
  loadQueueOptions,
  loadCacheOptions,
  isTransientError,
  isNotConnectedError,
  isPreSendError,
  isRetryable,
  modeForUpdate,
  withDbRetry,
  withQueuedOp,
  queueStats,
  drainQueues,
  resetQueues,
  OpQueue,
  buildClientOptions,
  createMongoClient,
  sleep,
  backoffMs,
  TRANSIENT_NAMES,
  TRANSIENT_MSG
};
