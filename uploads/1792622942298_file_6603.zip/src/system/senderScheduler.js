const DEFAULT_TICK_MS = 10 * 1000;
const DEFAULT_MAX_ORDERS = 6;
const DEFAULT_REST_SEC = 180;

function restMs() {
  const sec = Number(process.env.SENDER_REST_SEC);
  return (Number.isFinite(sec) && sec >= 0 ? sec : DEFAULT_REST_SEC) * 1000;
}

let db = null;
let logger = console;
let runOrder = null;
let tickMs = DEFAULT_TICK_MS;
let maxOrders = DEFAULT_MAX_ORDERS;
let started = false;
let tickTimer = null;
let tickRunning = false;

const runningOrders = new Set();
const senderChains = new Map();
const senderCooldownUntil = new Map();
const senderInUse = new Map();
const senderRestUntil = new Map();

function log(level, msg) {
  try {
    const fn = (logger && logger[level]) || (logger && logger.info) || console.log;
    fn.call(logger, `[senderScheduler] ${msg}`);
  } catch (e) {
    console.log(`[senderScheduler] ${msg}`);
  }
}

function init(opts) {
  db = opts.db;
  logger = opts.logger || console;
  runOrder = opts.runOrder;
  if (opts.tickMs) tickMs = opts.tickMs;
  if (opts.maxOrders) maxOrders = opts.maxOrders;
}

function withSenderLock(senderId, fn) {
  const prev = senderChains.get(senderId) || Promise.resolve();
  const next = prev.catch(() => {}).then(fn);
  const tail = next.catch(() => {});
  senderChains.set(senderId, tail);
  tail.then(() => {
    if (senderChains.get(senderId) === tail) senderChains.delete(senderId);
  });
  return next;
}

function setSenderCooldown(senderId, ms) {
  senderCooldownUntil.set(senderId, Date.now() + Math.max(0, ms));
}

function getSenderCooldownMs(senderId) {
  const until = senderCooldownUntil.get(senderId);
  if (!until) return 0;
  const left = until - Date.now();
  if (left <= 0) {
    senderCooldownUntil.delete(senderId);
    return 0;
  }
  return left;
}

function clearSender(senderId) {
  senderCooldownUntil.delete(String(senderId));
  senderRestUntil.delete(String(senderId));
  senderInUse.delete(String(senderId));
}

async function getOrderSenderIds(orderId) {
  const rows = await db.all(`SELECT sender_id FROM jasa_order_senders WHERE order_id = ?`, orderId);
  return (rows || []).map((r) => String(r.sender_id));
}

function markSendersBusy(ids) {
  for (const id of ids) senderInUse.set(id, (senderInUse.get(id) || 0) + 1);
}

function releaseSenders(ids) {
  const until = Date.now() + restMs();
  for (const id of ids) {
    const left = (senderInUse.get(id) || 0) - 1;
    if (left > 0) senderInUse.set(id, left);
    else senderInUse.delete(id);
    senderRestUntil.set(id, until);
  }
}

function senderReadyIn(id) {
  if (senderInUse.has(id)) return Infinity;
  return Math.max(0, (senderRestUntil.get(id) || 0) - Date.now());
}

async function runOne(order, senderIds) {
  runningOrders.add(order.order_id);
  markSendersBusy(senderIds);
  try {
    await runOrder(order);
  } catch (e) {
    log('error', `order ${order.order_id} gagal: ${e.message}`);
    try {
      const now = Math.floor(Date.now() / 1000);
      await db.run(
        `UPDATE jasa_orders SET next_run_at = ?, updated_at = ? WHERE order_id = ? AND status = 'active'`,
        now + 300, now, order.order_id
      );
    } catch (e2) {}
  } finally {
    releaseSenders(senderIds);
    runningOrders.delete(order.order_id);
  }
}

function pruneMaps() {
  const now = Date.now();
  for (const [id, until] of senderCooldownUntil) {
    if (until <= now) senderCooldownUntil.delete(id);
  }
  for (const [id, until] of senderRestUntil) {
    if (until <= now) senderRestUntil.delete(id);
  }
  if (senderChains.size > 2000) {
    for (const [id, p] of senderChains) {
      if (senderChains.size <= 1000) break;
      senderChains.delete(id);
    }
  }
}

async function tick() {
  if (tickRunning) return;
  tickRunning = true;
  try {
    pruneMaps();
    const now = Math.floor(Date.now() / 1000);
    const rows = await db.all(
      `SELECT * FROM jasa_orders WHERE status = 'active' AND next_run_at IS NOT NULL AND next_run_at <= ? ORDER BY next_run_at ASC`,
      now
    );
    const blocked = new Set();
    for (const order of rows || []) {
      if (runningOrders.size >= maxOrders) break;
      if (runningOrders.has(order.order_id)) continue;
      const ids = await getOrderSenderIds(order.order_id);
      const notReady = ids.some((id) => blocked.has(id) || senderReadyIn(id) > 0);
      for (const id of ids) blocked.add(id);
      if (notReady) continue;
      runOne(order, ids);
    }
  } catch (e) {
    log('error', `tick gagal: ${e.message}`);
  } finally {
    tickRunning = false;
  }
}

function start() {
  if (started) return;
  started = true;
  if (tickTimer) clearInterval(tickTimer);
  tickTimer = setInterval(tick, tickMs);
  if (tickTimer.unref) tickTimer.unref();
  log('info', `Scheduler started (tick ${tickMs / 1000}s, max ${maxOrders} order paralel)`);
  tick();
}

function stop() {
  started = false;
  if (tickTimer) clearInterval(tickTimer);
  tickTimer = null;
}

function getStatus() {
  return {
    runningOrders: Array.from(runningOrders),
    resting: Array.from(senderRestUntil.entries())
      .filter(([, until]) => until > Date.now())
      .map(([id, until]) => ({ sender_id: id, remaining_ms: until - Date.now() })),
    cooling: Array.from(senderCooldownUntil.entries()).map(([id, until]) => ({
      sender_id: id,
      remaining_ms: Math.max(0, until - Date.now()),
    })),
  };
}

module.exports = {
  init,
  start,
  stop,
  getStatus,
  withSenderLock,
  setSenderCooldown,
  getSenderCooldownMs,
  clearSender,
  _tick: tick,
};
