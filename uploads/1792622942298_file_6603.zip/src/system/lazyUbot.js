/**
 * lazyUbot.js
 * ------------------------------------------------------------------
 * Manajer koneksi "lazy" untuk userbot (GramJS TelegramClient).
 *
 * Tujuan:
 *  - Userbot TIDAK menahan koneksi MTProto terus-menerus kalau lagi
 *    nggak dipakai -> hemat memori & socket, apalagi kalau banyak
 *    user trial yang jarang aktif.
 *  - Koneksi otomatis dibuat ulang ("reconnect") begitu ada aksi yang
 *    butuh userbot (kirim pesan, ambil daftar grup, dll) -> user
 *    nggak akan ngerasa ada bedanya, karena `client` yang dipakai di
 *    seluruh kode lain TETAP dipanggil persis seperti biasa.
 *  - Selama auto-share/broadcast lagi jalan, koneksi DIKUNCI (pin)
 *    supaya nggak mungkin ke-disconnect di tengah proses -> auto
 *    share nggak akan pernah mati sendiri gara-gara idle-timeout.
 *  - Kalau session sudah tidak valid (di-revoke / logout dari HP /
 *    kena banned), lazyUbot BERHENTI mencoba reconnect terus-menerus
 *    (circuit breaker) dan menandai client sebagai "dead" supaya
 *    kode pemanggil bisa cleanup dengan tepat, bukan nge-loop retry
 *    yang sia-sia dan membebani proses.
 *
 * Cara pakai (lihat integrasi di modules/index.js):
 *   const lazyUbot = require('../system/lazyUbot');
 *   const client = lazyUbot.createLazyClient(ownerId, sessionString, apiId, apiHash, clientConfig);
 *   userbots.push({ id, owner_id: ownerId, client, phone, status: 'AKTIF' });
 *   // `client` di atas adalah Proxy - dipakai PERSIS seperti TelegramClient
 *   // biasa (ubot.client.sendMessage(...), ubot.client.getDialogs(), dst)
 *   // TANPA perlu ubah kode di tempat lain. Connect/reconnect kejadian
 *   // otomatis di balik layar pas method-nya dipanggil.
 *
 *   lazyUbot.pin(ownerId);    // panggil pas mulai proses penting (broadcast)
 *   lazyUbot.unpin(ownerId);  // panggil pas proses selesai (taruh di finally!)
 *
 *   // Opsional: kalau mau tahu / bereaksi begitu suatu userbot dinyatakan
 *   // "mati" permanen (session invalid), pasang listener:
 *   lazyUbot.onDead((ownerId, reason) => { ...cleanup ke DB... });
 * ------------------------------------------------------------------
 */

// Batas waktu maksimum untuk SATU pemanggilan method client (mis. sendMessage,
// getMe, getEntity). Tanpa ini, kalau koneksi TCP/MTProto secara diam-diam
// "mati" (bukan error, bukan disconnect resmi - OS masih anggap socket
// terbuka tapi remote sudah tidak pernah balas, umum terjadi pada koneksi
// jangka panjang di VPS setelah berhari-hari uptime / NAT timeout tanpa
// RST), `await value.apply(...)` di bawah bisa menggantung SELAMANYA:
// tidak pernah resolve, tidak pernah reject. Efeknya proses pemanggil (mis.
// ronde auto-share) berhenti persis di baris itu tanpa pernah masuk
// catch/finally manapun - lock ronde tidak pernah lepas, promo_logs tidak
// pernah ketambahan baris baru, dan dari luar terlihat seperti "auto share
// macet mentok di putaran yang sama" walau statusnya masih AKTIF.
// CALL_TIMEOUT_MS memaksa pemanggilan seperti itu gagal dengan error yang
// jelas setelah waktu ini, supaya lock/finally tetap jalan dan mekanisme
// reconnect + guardian yang sudah ada bisa langsung ambil alih pemulihan.
const CALL_TIMEOUT_MS = 45 * 1000;

const { TelegramClient } = require('telegram');
const { StringSession } = require('telegram/sessions');

// Berapa lama nganggur (nggak ada pemanggilan method sama sekali)
// sebelum koneksi userbot diputus otomatis buat hemat memori.
const runtimeConfig = require('../constants/runtimeConfig');
let IDLE_DISCONNECT_MS = runtimeConfig.UBOT_IDLE_DISCONNECT_MS;

// ---- ANTI-LEAK / STABILITAS MEMORI --------------------------------------
// GramJS menumpuk state internal (sender, entity cache, buffer, promise
// loop) di SATU objek TelegramClient setiap kali dipakai connect ->
// disconnect berulang-ulang. Untuk proses yang hidup berhari-hari dengan
// ratusan userbot yang terus di-rotasi (checkUserbotStatus, auto-share),
// itulah yang membuat heap naik pelan-pelan sampai OOM. Solusinya:
//  1) Setelah idle-disconnect, objek TelegramClient LAMA di-destroy dan
//     diganti objek BARU dari session string yang sama (auth key tetap
//     dipakai, user tidak perlu login ulang, proxy `client` TIDAK berubah).
//  2) Jumlah handshake connect yang berjalan bersamaan dibatasi, supaya
//     tidak ada lonjakan memori saat banyak userbot dibangunkan sekaligus.
let CONNECT_CONCURRENCY = Math.max(1, runtimeConfig.UBOT_CONNECT_CONCURRENCY);
let connectActive = 0;
const connectWaiters = [];

async function acquireConnectSlot() {
  if (connectActive < CONNECT_CONCURRENCY) {
    connectActive++;
    return;
  }
  await new Promise((resolve) => connectWaiters.push(resolve));
}

function releaseConnectSlot() {
  const next = connectWaiters.shift();
  if (next) {
    next(); // slot langsung dioper ke antrean berikutnya (connectActive tetap)
  } else {
    connectActive = Math.max(0, connectActive - 1);
  }
}

// Diisi oleh index.js (memoryGuard) -> true kalau heap sedang kritis.
// Selama kritis, connect BARU yang tidak urgent ditunda sebentar (maks
// PRESSURE_WAIT_MAX_MS) supaya proses sempat bernapas; tidak pernah di-reject.
let pressureCheck = () => false;
const PRESSURE_WAIT_MAX_MS = 20 * 1000;

function setPressureCheck(fn) {
  if (typeof fn === 'function') pressureCheck = fn;
}

// Berapa kali dicoba ulang kalau connect gagal (mis. jaringan lagi jelek),
// dengan jeda yang makin lama tiap percobaan (backoff).
const CONNECT_MAX_RETRY = 3;
const CONNECT_RETRY_BASE_MS = 1500;
const CONNECT_RETRY_MAX_MS = 15000;
const FAST_CONNECT_TIMEOUT_MS = 12000;

// Circuit breaker: kalau connect gagal beruntun sebanyak ini (di luar
// percobaan internal ensureConnected), client ditandai "dead" dan
// TIDAK akan dicoba connect lagi sampai di-reset manual (createLazyClient
// ulang / relogin). Ini mencegah retry-storm kalau session sudah invalid.
const MAX_CONSECUTIVE_FAILURES = 5;

// Pola pesan error dari GramJS/MTProto yang menandakan session sudah
// TIDAK VALID (bukan sekadar gangguan jaringan sementara) -> begitu
// ketemu salah satu ini, langsung dead tanpa perlu habiskan retry budget.
const FATAL_AUTH_ERROR_PATTERNS = [
  'AUTH_KEY_UNREGISTERED',
  'AUTH_KEY_INVALID',
  'SESSION_REVOKED',
  'SESSION_EXPIRED',
  'USER_DEACTIVATED',
  'USER_DEACTIVATED_BAN',
];

// Pola error yang SIFATNYA SEMENTARA -> jangan pernah dihitung sebagai
// kegagalan permanen walau muncul berkali-kali. FLOOD_WAIT sangat umum
// terjadi di userbot yang sering dipakai (banyak request beruntun), dan
// TIDAK berarti session-nya rusak -> harus di-backoff sesuai durasi yang
// diminta Telegram, bukan didiamkan sampai kena circuit breaker.
const TRANSIENT_ERROR_PATTERNS = [
  'FLOOD_WAIT',
  'TIMEOUT',
  'ECONNRESET',
  'ECONNREFUSED',
  'ETIMEDOUT',
  'ENOTFOUND',
  'EAI_AGAIN',
  'NETWORK',
  'CONNECTION',
  'RPC_MCGET_FAIL',
  'RPC_CALL_FAIL',
  'NO WORKERS RUNNING',
  'WORKER_BUSY_TOO_LONG_RETRY',
  'MSGID_DECREASE_RETRY',
  'INTERDC_',
  'SERVER_ERROR',
  'INTERNAL_SERVER_ERROR',
];

const TRANSIENT_ERROR_CODES = new Set([500, -500, 502, 503, 504]);

function isFatalAuthError(err) {
  const msg = String((err && (err.errorMessage || err.message)) || '').toUpperCase();
  return FATAL_AUTH_ERROR_PATTERNS.some((p) => msg.includes(p));
}

function isTransientError(err) {
  if (err && TRANSIENT_ERROR_CODES.has(Number(err.code))) return true;
  const msg = String((err && (err.errorMessage || err.message)) || '').toUpperCase();
  return TRANSIENT_ERROR_PATTERNS.some((p) => msg.includes(p));
}

// Ambil durasi tunggu (detik) dari pesan FLOOD_WAIT_123, kalau ada.
function getFloodWaitSeconds(err) {
  const msg = String((err && (err.errorMessage || err.message)) || '');
  const match = msg.match(/FLOOD_WAIT_(\d+)/i);
  return match ? parseInt(match[1], 10) : null;
}

// state per ownerId -> meta
const registry = new Map();

// listener eksternal yang dipanggil begitu suatu client dinyatakan dead
const deadListeners = [];

let logger = console; // default; bisa diganti lewat setLogger()

function setLogger(customLogger) {
  if (customLogger && typeof customLogger.info === 'function') {
    logger = customLogger;
  }
}

function log(level, msg) {
  try {
    const fn = logger[level] || logger.info || console.log;
    fn.call(logger, `[lazyUbot] ${msg}`);
  } catch (e) {
    console.log(`[lazyUbot] ${msg}`);
  }
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Bungkus sebuah promise supaya reject dengan error TIMEOUT yang jelas
 * kalau tidak selesai dalam batas waktu tertentu. Promise asli yang
 * menggantung dibiarkan jalan di background (tidak bisa benar-benar
 * dibatalkan di JS), tapi pemanggil TIDAK ikut menunggu - dia dapat
 * error dan bisa lanjut/retry/reconnect segera, alih-alih diam
 * menggantung tanpa batas waktu.
 */
function withCallTimeout(promise, ms, label) {
  let timer;
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => {
      const err = new Error(`TIMEOUT: ${label} tidak merespons dalam ${ms}ms`);
      err.code = 'ETIMEDOUT';
      reject(err);
    }, ms);
    if (timer.unref) timer.unref();
  });
  return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
}

/**
 * Daftarkan fungsi yang dipanggil begitu sebuah userbot dinyatakan mati
 * permanen (session invalid / auth error fatal / kehabisan retry budget).
 * Dipakai supaya modules/index.js bisa update status di DB & notify owner
 * tanpa lazyUbot.js perlu tahu apa-apa soal DB/bot Telegram.
 */
function onDead(fn) {
  if (typeof fn === 'function') deadListeners.push(fn);
}

function notifyDead(ownerId, reason) {
  for (const fn of deadListeners) {
    try {
      fn(ownerId, reason);
    } catch (e) {
      log('error', `onDead listener error untuk ${ownerId}: ${e.message}`);
    }
  }
}

/**
 * Bikin client "lazy" untuk satu owner. Kalau owner ini sudah pernah
 * punya client sebelumnya (misal relogin/redeploy), entry lama
 * dibersihkan dulu supaya nggak ada timer nyangkut di memori.
 */
function createLazyClient(ownerId, sessionString, apiId, apiHash, clientConfig) {
  ownerId = String(ownerId);

  if (registry.has(ownerId)) {
    remove(ownerId);
  }

  const meta = {
    real: new TelegramClient(new StringSession(sessionString), apiId, apiHash, clientConfig),
    sessionString,
    dirty: false, // true = objek real sudah pernah connect sejak dibuat -> layak didaur ulang
    recycling: false,
    pinCount: 0,
    busyCount: 0,
    idleTimer: null,
    connecting: null, // Promise yang sedang berjalan, dipakai semua caller yang tabrakan
    dead: false,
    deadReason: null,
    consecutiveFailures: 0,
    fastFail: false,
  };

  function clearIdleTimer() {
    if (meta.idleTimer) {
      clearTimeout(meta.idleTimer);
      meta.idleTimer = null;
    }
  }

  /**
   * Ganti objek TelegramClient lama dengan yang baru (session sama) supaya
   * seluruh state internal GramJS yang menumpuk ikut terbuang oleh GC.
   * Hanya jalan kalau benar-benar idle (tidak busy/pin/connecting) dan
   * objek lama memang sudah pernah dipakai connect (dirty).
   */
  async function recycleClient() {
    if (meta.dead || meta.recycling || !meta.dirty) return;
    if (meta.pinCount > 0 || meta.busyCount > 0 || meta.connecting) return;
    meta.recycling = true;
    try {
      const old = meta.real;
      try { if (old.connected) await old.disconnect(); } catch (_) {}
      // Re-check: selama await di atas ada pemanggilan baru yang masuk
      if (meta.pinCount > 0 || meta.busyCount > 0 || meta.connecting || meta.dead) return;

      let saved = '';
      try { saved = old.session && typeof old.session.save === 'function' ? old.session.save() : ''; } catch (_) {}
      if (saved) meta.sessionString = saved;

      meta.real = new TelegramClient(new StringSession(meta.sessionString), apiId, apiHash, clientConfig);
      meta.dirty = false;
      try { await old.destroy(); } catch (_) {}
    } catch (e) {
      log('warn', `Daur ulang client ${ownerId} gagal: ${e.message}`);
    } finally {
      meta.recycling = false;
    }
  }

  function scheduleIdleDisconnect() {
    clearIdleTimer();
    if (meta.dead) return;
    if (meta.pinCount > 0 || meta.busyCount > 0) return;

    meta.idleTimer = setTimeout(async () => {
      meta.idleTimer = null;
      if (meta.pinCount > 0 || meta.busyCount > 0) return;
      try {
        if (meta.real.connected) {
          await meta.real.disconnect();
        }
      } catch (e) {
        log('error', `Gagal disconnect userbot ${ownerId}: ${e.message}`);
      }
      await recycleClient();
    }, IDLE_DISCONNECT_MS);

    if (meta.idleTimer.unref) meta.idleTimer.unref();
  }

  function markDead(reason) {
    if (meta.dead) return;
    meta.dead = true;
    meta.deadReason = reason;
    clearIdleTimer();
    log('warn', `Userbot ${ownerId} ditandai DEAD (${reason}) -> berhenti retry otomatis`);
    try {
      if (meta.real.connected) meta.real.disconnect().catch(() => {});
    } catch (e) {}
    notifyDead(ownerId, reason);
  }

  /**
   * Satu-satunya jalur untuk connect. Kalau ada pemanggilan yang
   * tabrakan (dua method dipanggil bersamaan sebelum connect selesai),
   * semuanya menunggu Promise `meta.connecting` YANG SAMA -> tidak ada
   * connect ganda / retry-storm.
   */
  async function ensureConnected(reentryCount = 0) {
    if (meta.dead) {
      throw new Error(`Userbot ${ownerId} sudah dinonaktifkan (${meta.deadReason || 'dead'})`);
    }
    if (meta.real.connected) return;

    if (meta.connecting) {
      await meta.connecting;
      // Re-check: promise yang ditunggu tadi bisa saja punya hasil
      // yang berbeda dari ekspektasi kita (mis. selesai duluan lalu
      // idle-disconnect kepicu sebelum kita lanjut) -> pastikan lagi.
      //
      // BUG FIX (v10.3 - STABILITAS): sebelumnya baris ini memanggil
      // ensureConnected() lagi TANPA batas rekursi dan TANPA delay sama
      // sekali. Kalau real.connected terus-menerus false padahal belum
      // dead (skenario langka tapi mungkin: connect() resolve lalu
      // idle-disconnect kepicu tepat sebelum re-check ini, berulang-ulang
      // karena timing yang selalu pas-pasan), ini jadi tight-loop rekursif
      // yang bisa menghabiskan CPU / stack tanpa pernah berhenti - proses
      // Node bisa macet/lambat drastis. Sekarang dibatasi maksimal 5x
      // percobaan ulang dengan jeda kecil di antaranya; kalau tetap gagal
      // setelah itu, lempar error yang jelas alih-alih diam-diam infinite loop.
      if (!meta.real.connected && !meta.dead) {
        if (reentryCount >= 5) {
          throw new Error(`Userbot ${ownerId} gagal memastikan koneksi setelah beberapa kali percobaan ulang (kemungkinan race condition idle-disconnect)`);
        }
        await new Promise((resolve) => setImmediate(resolve));
        return ensureConnected(reentryCount + 1);
      }
      return;
    }

    meta.connecting = (async () => {
      let lastErr;
      const maxAttempt = meta.fastFail ? 1 : CONNECT_MAX_RETRY;
      for (let attempt = 1; attempt <= maxAttempt; attempt++) {
        try {
          if (!meta.fastFail && meta.pinCount === 0 && attempt === 1) {
            const t0 = Date.now();
            while (pressureCheck() && Date.now() - t0 < PRESSURE_WAIT_MAX_MS) await sleep(1000);
          }
          await acquireConnectSlot();
          try {
            if (meta.fastFail) {
              await withCallTimeout(meta.real.connect(), FAST_CONNECT_TIMEOUT_MS, `${ownerId}.connect`);
            } else {
              await meta.real.connect();
            }
          } finally {
            releaseConnectSlot();
          }
          meta.dirty = true;
          meta.consecutiveFailures = 0;
          return;
        } catch (e) {
          lastErr = e;
          log(isTransientError(e) ? 'warn' : 'error', `Userbot ${ownerId} gagal connect (percobaan ${attempt}): ${e.message}`);

          // Session sudah tidak valid -> tidak perlu retry sama sekali,
          // langsung tandai dead supaya nggak buang-buang waktu/API call.
          if (isFatalAuthError(e)) {
            markDead(e.errorMessage || e.message || 'fatal_auth_error');
            throw e;
          }

          if (meta.fastFail) {
            try {
              if (typeof meta.real.disconnect === 'function') meta.real.disconnect().catch(() => {});
            } catch (_) {}
            break;
          }

          // FLOOD_WAIT / error jaringan sementara -> ini BUKAN tanda
          // session rusak. Tunggu sesuai durasi yang diminta Telegram
          // (kalau ada), dan jangan hitung ini sebagai "consecutive
          // failure" yang bisa mematikan userbot secara permanen.
          if (isTransientError(e)) {
            const floodSeconds = getFloodWaitSeconds(e);
            if (floodSeconds !== null) {
              const waitMs = Math.min((floodSeconds + 1) * 1000, 60 * 1000);
              await sleep(waitMs);
            } else if (attempt < CONNECT_MAX_RETRY) {
              const backoff = Math.min(CONNECT_RETRY_BASE_MS * attempt, CONNECT_RETRY_MAX_MS);
              await sleep(backoff);
            }
            continue;
          }

          if (attempt < CONNECT_MAX_RETRY) {
            const backoff = Math.min(CONNECT_RETRY_BASE_MS * attempt, CONNECT_RETRY_MAX_MS);
            await sleep(backoff);
          }
        }
      }

      // Kehabisan retry budget untuk percobaan kali ini. Error transient
      // (flood wait/jaringan) tidak menyumbang ke circuit breaker supaya
      // userbot yang sehat tidak ditandai dead hanya karena lagi sibuk.
      if (!isTransientError(lastErr)) {
        meta.consecutiveFailures++;
        if (meta.consecutiveFailures >= MAX_CONSECUTIVE_FAILURES) {
          markDead('max_consecutive_connect_failures');
        }
      }

      throw lastErr || new Error('Gagal connect userbot (sebab tidak diketahui)');
    })();

    try {
      await meta.connecting;
    } finally {
      meta.connecting = null;
    }
  }

  // Simpan fungsi-fungsi ini di meta supaya pin()/unpin() dari luar bisa
  // manggil ulang scheduler yang sama persis (bukan duplikat logika).
  meta.clearIdleTimer = clearIdleTimer;
  meta.scheduleIdleDisconnect = scheduleIdleDisconnect;
  meta.markDead = markDead;
  meta.recycleClient = recycleClient;

  const proxy = new Proxy(meta.real, {
    set(target, prop, value) {
      return Reflect.set(meta.real, prop, value);
    },
    has(target, prop) {
      return Reflect.has(meta.real, prop);
    },
    get(target, prop, receiver) {
      const current = meta.real;
      const value = Reflect.get(current, prop, current);

      // Bukan method (properti biasa, mis. .session) -> teruskan apa adanya
      if (typeof value !== 'function') return value;

      if (prop === 'connect') {
        return async function (...args) {
          clearIdleTimer();
          await ensureConnected();
          scheduleIdleDisconnect();
          return true;
        };
      }
      if (prop === 'disconnect') {
        return async function (...args) {
          clearIdleTimer();
          meta.busyCount = 0; // disconnect manual membatalkan semua "busy" yang tercatat
          meta.pinCount = 0; // idem untuk pin, biar gak nyangkut kalau ada logic error di caller
          return value.apply(meta.real, args);
        };
      }

      // Semua method lain: pastikan konek dulu (auto reconnect kalau perlu),
      // baru jalankan method aslinya. Setelah selesai, jadwalkan lagi
      // idle-disconnect kalau memang sudah gak ada yang pakai/pin.
      return async function (...args) {
        if (meta.dead) {
          throw new Error(`Userbot ${ownerId} sudah dinonaktifkan (${meta.deadReason || 'dead'})`);
        }
        clearIdleTimer();
        meta.busyCount++;
        try {
          await ensureConnected();
          const current = meta.real; // snapshot: pastikan method & target dari objek yang sama
          // withCallTimeout: lihat catatan CALL_TIMEOUT_MS di atas - method
          // GramJS asli TIDAK punya batas waktu bawaan, jadi kalau socket
          // diam-diam mati tanpa error, panggilan ini bisa menggantung
          // selamanya dan mengunci pemanggil (mis. ronde auto-share) tanpa
          // pernah masuk catch/finally. Timeout ini memastikan itu selalu
          // berakhir dengan error yang jelas, bukan hang tanpa batas.
          return await withCallTimeout(
            Reflect.get(current, prop, current).apply(current, args),
            CALL_TIMEOUT_MS,
            `${ownerId}.${String(prop)}`
          );
        } catch (e) {
          // Error fatal bisa saja muncul BUKAN dari proses connect (mis.
          // request tiba-tiba ditolak karena session baru saja di-revoke).
          // FLOOD_WAIT/error jaringan sementara TIDAK pernah menandai
          // dead -> itu bukan tanda session rusak, cuma lagi kena limit.
          if (isFatalAuthError(e)) {
            markDead(e.errorMessage || e.message || 'fatal_auth_error');
          } else if (e && e.code === 'ETIMEDOUT') {
            // Panggilan kena CALL_TIMEOUT_MS -> kemungkinan besar socket
            // "zombie" (OS masih anggap connected, remote sudah tidak
            // pernah balas). Paksa real.connected dianggap putus supaya
            // ensureConnected() di pemanggilan BERIKUTNYA benar-benar
            // reconnect, bukan lolos karena connected masih true lalu
            // menggantung lagi di panggilan yang sama persis.
            try {
              if (typeof meta.real.disconnect === 'function') {
                meta.real.disconnect().catch(() => {});
              }
            } catch (_) {}
            log('warn', `Userbot ${ownerId} method ${String(prop)} timeout (${CALL_TIMEOUT_MS}ms) -> koneksi dipaksa reset untuk reconnect berikutnya`);
          }
          throw e;
        } finally {
          meta.busyCount--;
          if (meta.busyCount === 0) scheduleIdleDisconnect();
        }
      };
    },
  });

  meta.proxy = proxy;
  registry.set(ownerId, meta);

  return proxy;
}

/**
 * Kunci koneksi supaya TIDAK di-disconnect otomatis walau lagi idle
 * sesaat di antara pemanggilan method (mis. selama 1 ronde broadcast
 * berjalan). WAJIB dipasangkan dengan unpin() di blok finally, supaya
 * auto-share tidak pernah "lupa" melepas kuncinya kalau terjadi error.
 */
function pin(ownerId) {
  const meta = registry.get(String(ownerId));
  if (!meta) return;
  meta.pinCount++;
  meta.clearIdleTimer();
}

function unpin(ownerId) {
  const meta = registry.get(String(ownerId));
  if (!meta) return;
  meta.pinCount = Math.max(0, meta.pinCount - 1);
  if (meta.pinCount === 0 && meta.busyCount === 0) {
    meta.scheduleIdleDisconnect();
  }
}

/**
 * Cek status koneksi saat ini (mis. buat ditampilkan di menu status).
 */
function isConnected(ownerId) {
  const meta = registry.get(String(ownerId));
  return !!(meta && !meta.dead && meta.real.connected);
}

/**
 * Cek apakah userbot ini sudah ditandai mati permanen (session invalid /
 * kehabisan retry). Berguna sebelum memanggil method supaya kode
 * pemanggil bisa langsung kasih pesan yang jelas ke user, tanpa perlu
 * nunggu exception dulu.
 */
function isDead(ownerId) {
  const meta = registry.get(String(ownerId));
  return !!(meta && meta.dead);
}

function getDeadReason(ownerId) {
  const meta = registry.get(String(ownerId));
  return meta ? meta.deadReason : null;
}

/**
 * Ringkasan status satu userbot dalam satu pemanggilan -> praktis
 * dipakai di menu status/monitoring tanpa harus panggil 3 fungsi terpisah.
 */
function getStatus(ownerId) {
  const meta = registry.get(String(ownerId));
  if (!meta) {
    return { registered: false, connected: false, dead: false, deadReason: null, pinCount: 0, busyCount: 0 };
  }
  return {
    registered: true,
    connected: !!meta.real.connected,
    dead: meta.dead,
    deadReason: meta.deadReason,
    pinCount: meta.pinCount,
    busyCount: meta.busyCount,
  };
}

/**
 * Bersihin state (dipanggil pas userbot logout/dihapus/cleanup)
 * supaya nggak ada timer yang nyangkut nganggur di memori.
 */
function remove(ownerId) {
  ownerId = String(ownerId);
  const meta = registry.get(ownerId);
  if (meta) {
    meta.clearIdleTimer();
    const old = meta.real;
    meta.dead = true; // hentikan semua pemanggilan lewat proxy lama yang mungkin masih dipegang
    meta.deadReason = meta.deadReason || 'removed';
    Promise.resolve()
      .then(() => (old.connected ? old.disconnect() : null))
      .catch(() => {})
      .then(() => old.destroy())
      .catch(() => {});
  }
  registry.delete(ownerId);
}

/**
 * Lepas SEKARANG semua koneksi userbot yang sedang tidak dipakai (tidak
 * pin, tidak busy, tidak sedang connect) dan daur ulang objek clientnya.
 * Dipakai memoryGuard saat heap menekan -> turunkan memori tanpa restart
 * dan tanpa mengganggu auto-share yang sedang jalan (yang pin dilewati).
 * Dikerjakan bertahap supaya tidak menciptakan lonjakan CPU/GC sendiri.
 */
async function releaseIdle(maxPerCall = 200) {
  let released = 0;
  for (const meta of registry.values()) {
    if (released >= maxPerCall) break;
    if (meta.dead || meta.pinCount > 0 || meta.busyCount > 0 || meta.connecting) continue;
    if (!meta.dirty && !meta.real.connected) continue;
    try {
      meta.clearIdleTimer();
      if (meta.real.connected) await meta.real.disconnect();
      await meta.recycleClient();
      released++;
    } catch (_) {}
    if (released % 10 === 0) await new Promise((r) => setImmediate(r));
  }
  return released;
}

function connectStats() {
  let connected = 0;
  for (const meta of registry.values()) if (meta.real.connected) connected++;
  return { registered: registry.size, connected, connecting: connectActive, waiting: connectWaiters.length, limit: CONNECT_CONCURRENCY };
}

/**
 * Ringkasan seluruh registry, berguna buat command debug/monitoring
 * (mis. /status khusus owner bot).
 */
function stats() {
  const out = [];
  for (const [ownerId, meta] of registry.entries()) {
    out.push({
      ownerId,
      connected: !!meta.real.connected,
      pinCount: meta.pinCount,
      busyCount: meta.busyCount,
      dead: meta.dead,
      deadReason: meta.deadReason,
    });
  }
  return out;
}

function setConnectLimit(n) {
  const prev = CONNECT_CONCURRENCY;
  if (Number.isFinite(n) && n >= 1) CONNECT_CONCURRENCY = Math.floor(n);
  return prev;
}

function setFastFail(ownerId, on) {
  const meta = registry.get(String(ownerId));
  if (meta) meta.fastFail = !!on;
}

module.exports = {
  setConnectLimit,
  setFastFail,
  setIdleMs: (ms) => { if (Number.isFinite(ms) && ms > 10000) IDLE_DISCONNECT_MS = ms; },
  createLazyClient,
  pin,
  unpin,
  isConnected,
  isDead,
  getDeadReason,
  getStatus,
  remove,
  setLogger,
  onDead,
  stats,
  releaseIdle,
  connectStats,
  setPressureCheck,
  isFatalAuthError,
  isTransientError,
  getFloodWaitSeconds,
  IDLE_DISCONNECT_MS,
};
