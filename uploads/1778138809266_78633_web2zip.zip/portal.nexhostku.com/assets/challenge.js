// Bot protection disabled - handled by nginx + fail2ban
