// Behavioral Analysis + AI Bot Detection
// Gemini API key di-load dari server, bukan expose di client

const SIGNALS = {
  mouseMovements: [],
  clickTimings: [],
  keyTimings: [],
  scrollEvents: [],
  startTime: Date.now()
};

// Deteksi touch device
const isTouchDevice = navigator.maxTouchPoints > 0 || 'ontouchstart' in window;

// Track touch sebagai pengganti mouse
document.addEventListener('touchstart', e => {
  SIGNALS.mouseMovements.push({ x: e.touches[0].clientX, y: e.touches[0].clientY, t: Date.now() });
});
document.addEventListener('touchmove', e => {
  SIGNALS.mouseMovements.push({ x: e.touches[0].clientX, y: e.touches[0].clientY, t: Date.now() });
  if (SIGNALS.mouseMovements.length > 100) SIGNALS.mouseMovements.shift();
});

// Track mouse (desktop)
document.addEventListener('mousemove', e => {
  SIGNALS.mouseMovements.push({ x: e.clientX, y: e.clientY, t: Date.now() });
  if (SIGNALS.mouseMovements.length > 100) SIGNALS.mouseMovements.shift();
});

// Track klik
document.addEventListener('click', e => {
  SIGNALS.clickTimings.push(Date.now());
});

// Track scroll
document.addEventListener('scroll', () => {
  SIGNALS.scrollEvents.push(Date.now());
});

// Analisis behavioral lokal
function analyzeBehavior() {
  const score = { botScore: 0, reasons: [] };

  // 1. Tidak ada gerakan mouse/touch sama sekali
  if (SIGNALS.mouseMovements.length === 0 && !isTouchDevice) {
    score.botScore += 30;
    score.reasons.push('no_mouse_movement');
  }

  // 2. Gerakan mouse terlalu linear/perfect
  if (SIGNALS.mouseMovements.length > 5) {
    const diffs = [];
    for (let i = 1; i < SIGNALS.mouseMovements.length; i++) {
      const dx = SIGNALS.mouseMovements[i].x - SIGNALS.mouseMovements[i-1].x;
      const dy = SIGNALS.mouseMovements[i].y - SIGNALS.mouseMovements[i-1].y;
      diffs.push(Math.sqrt(dx*dx + dy*dy));
    }
    const avg = diffs.reduce((a,b) => a+b, 0) / diffs.length;
    const variance = diffs.reduce((a,b) => a + Math.pow(b-avg,2), 0) / diffs.length;
    if (variance < 2) {
      score.botScore += 25;
      score.reasons.push('linear_mouse');
    }
  }

  // 3. Klik terlalu cepat / interval sama persis
  if (SIGNALS.clickTimings.length > 2) {
    const intervals = [];
    for (let i = 1; i < SIGNALS.clickTimings.length; i++) {
      intervals.push(SIGNALS.clickTimings[i] - SIGNALS.clickTimings[i-1]);
    }
    const avgInterval = intervals.reduce((a,b) => a+b,0) / intervals.length;
    const allSame = intervals.every(v => Math.abs(v - avgInterval) < 10);
    if (allSame && avgInterval < 200) {
      score.botScore += 35;
      score.reasons.push('robotic_clicks');
    }
  }

  // 4. Tidak ada scroll sama sekali setelah 5 detik
  const elapsed = Date.now() - SIGNALS.startTime;
  if (elapsed > 8000 && SIGNALS.scrollEvents.length === 0 && !isTouchDevice) {
    score.botScore += 10;
    score.reasons.push('no_scroll');
  }

  return score;
}

// Kirim ke server untuk AI analysis
async function submitForAIAnalysis() {
  const behavior = analyzeBehavior();
  const payload = {
    behavior,
    screen: { w: screen.width, h: screen.height, depth: screen.colorDepth },
    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    lang: navigator.language,
    platform: navigator.platform,
    cookieEnabled: navigator.cookieEnabled,
    touchPoints: navigator.maxTouchPoints,
    webdriver: navigator.webdriver || false,
    plugins: navigator.plugins.length,
    elapsed: Date.now() - SIGNALS.startTime
  };

  try {
    const res = await fetch('/api/bot-check.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (data.blocked) {
      window.location.href = '/block?reason=' + encodeURIComponent(data.reason);
    }
  } catch(e) {}
}

// Jalankan analisis setelah 4 detik
setTimeout(submitForAIAnalysis, 8000);
// Re-check tiap 30 detik
setInterval(submitForAIAnalysis, 30000);

// ── BLOCK PAGE LOCKDOWN ──────────────────────────────────────────────────────
(function() {
  if (!window.location.pathname.startsWith('/block')) return;

  // Block back/forward navigation
  history.pushState(null, '', window.location.href);
  window.addEventListener('popstate', function() {
    history.pushState(null, '', window.location.href);
  });

  // Block keyboard shortcuts (F12, Ctrl+L, Alt+F4, dll)
  document.addEventListener('keydown', function(e) {
    if (
      e.key === 'F12' ||
      (e.ctrlKey && ['l','r','w','t','n','u'].includes(e.key.toLowerCase())) ||
      (e.altKey && e.key === 'F4')
    ) {
      e.preventDefault();
      return false;
    }
  });

  // Block right click
  document.addEventListener('contextmenu', function(e) {
    e.preventDefault();
  });

  // Redirect balik ke /block kalau coba pindah halaman
  window.addEventListener('beforeunload', function(e) {
    e.preventDefault();
    e.returnValue = '';
  });

  // Interval cek — kalau user berhasil kabur, redirect balik
  setInterval(function() {
    if (!window.location.pathname.startsWith('/block')) {
      window.location.replace('/block?reason=Akses+diblokir+oleh+sistem');
    }
  }, 500);
})();
