#!/bin/bash
set -e

cd "$(dirname "$0")"

echo "=== JASEB Userbot - Startup ==="

if ! command -v node &> /dev/null; then
  echo "Node.js belum terpasang. Install Node.js 18 LTS atau lebih baru."
  exit 1
fi
echo "Node.js: $(node --version)"

if [ ! -f ".env" ]; then
  echo "File .env belum ada."
  exit 1
fi

if [ ! -d "node_modules" ]; then
  npm install
fi

mkdir -p logs

if command -v pm2 &> /dev/null; then
  PM2_CMD="pm2"
else
  PM2_CMD="npx pm2"
fi

$PM2_CMD start ecosystem.config.js

echo "Perintah: npm run status | npm run logs | npm run stop"
