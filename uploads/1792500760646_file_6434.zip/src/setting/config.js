// ============================================================================
// KONFIGURASI BOT - dibaca dari environment variable (.env), BUKAN hardcoded.
// ----------------------------------------------------------------------------
// Kenapa diubah dari hardcoded ke .env:
//  - File ini sebelumnya berisi BOT_TOKEN, API_HASH, dan PAKASIR_APIKEY asli
//    dalam bentuk teks biasa. Kalau file ini pernah ikut ter-share/ter-commit
//    ke repo publik, semua kredensial itu langsung bocor ke siapa saja yang
//    baca kode-nya.
//  - Dengan .env, nilai asli cuma ada di server (file .env, TIDAK di-commit -
//    lihat .gitignore), sementara .env.example (aman, isinya placeholder)
//    yang ikut ke repo publik.
//
// CARA PAKAI: salin .env.example jadi .env, isi semua nilainya, baru jalankan
// bot. Kalau ada variabel WAJIB yang belum diisi, bot akan berhenti dengan
// pesan error yang jelas saat startup (bukan crash aneh di tengah jalan).
// ============================================================================

const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '../../.env') });

function required(name) {
  const val = process.env[name];
  if (val === undefined || val === '') {
    throw new Error(
      `[config] Environment variable ${name} belum diisi di file .env.\n` +
      `Salin .env.example jadi .env lalu isi ${name} sebelum menjalankan bot.`
    );
  }
  return val;
}

function optional(name, fallback = '') {
  const val = process.env[name];
  return (val === undefined || val === '') ? fallback : val;
}

function requiredInt(name) {
  const raw = required(name);
  const n = parseInt(raw, 10);
  if (Number.isNaN(n)) {
    throw new Error(`[config] Environment variable ${name} harus berupa angka, tapi isinya: "${raw}"`);
  }
  return n;
}

function optionalInt(name, fallback) {
  const raw = process.env[name];
  if (raw === undefined || raw === '') return fallback;
  const n = parseInt(raw, 10);
  return Number.isNaN(n) ? fallback : n;
}

const BOT_TOKEN = required('BOT_TOKEN');
// FITUR: bot kedua khusus notifikasi tiket/keluhan ke owner (lihat
// FITUR /ticket di index.js). Sengaja OPSIONAL - kalau kosong, sistem
// tiket otomatis fallback pakai BOT_TOKEN (bot utama) supaya bot tetap
// jalan normal tanpa perlu setup token kedua dulu.
const TICKET_BOT_TOKEN = optional('TICKET_BOT_TOKEN');
const OWNER_ID = required('OWNER_ID');
const OWNER_USERNAME = optional('OWNER_USERNAME');
const LOG_GROUP = optional('LOG_GROUP');
const NOTIF_CHANNEL_DEPOSIT = optional('NOTIF_CHANNEL_DEPOSIT');
const NOTIF_CHANNEL_PURCHASE = optional('NOTIF_CHANNEL_PURCHASE');
const REQUIRED_CHANNEL = optional('REQUIRED_CHANNEL');
const REQUIRED_GROUP = optional('REQUIRED_GROUP');
const JOIN_CHECK_CHAT_ID = optional('JOIN_CHECK_CHAT_ID');
const JOIN_FOLDER_LINK = optional('JOIN_FOLDER_LINK');
const API_ID = requiredInt('API_ID');
const API_HASH = required('API_HASH');
const WM = optional('WM', 'AutoShare Userbot');
const QRIS_IMAGE = optional('QRIS_IMAGE');
const MENU_VIDEO_URL = optional('MENU_VIDEO_URL');
const MONGODB_URI = required('MONGODB_URI');
const MONGODB_DB_NAME = optional('MONGODB_DB_NAME', 'jaseb');

// Deposit otomatis (Pakasir) sengaja OPSIONAL - kalau slug/apikey kosong,
// fitur deposit otomatis otomatis nonaktif dan bot tetap jalan normal
// dengan deposit manual saja (lihat PAKASIR_ENABLED di modules/index.js).
const PAKASIR_SLUG = optional('PAKASIR_SLUG');
const PAKASIR_APIKEY = optional('PAKASIR_APIKEY');
const PAKASIR_METHOD = optional('PAKASIR_METHOD', 'qris');
const PAKASIR_ADMIN_FEE = optionalInt('PAKASIR_ADMIN_FEE', 200);
const PAKASIR_EXPIRY_MS = 10 * 60 * 1000;
const PAKASIR_POLL_INTERVAL_MS = 15 * 1000;

// Kunci enkripsi untuk data sensitif di database (session_string dkk).
// WAJIB 64 karakter hex (32 byte). Lihat system/cryptoUtil.js untuk pemakaian.
const DB_ENCRYPTION_KEY = required('DB_ENCRYPTION_KEY');
if (!/^[0-9a-fA-F]{64}$/.test(DB_ENCRYPTION_KEY)) {
  throw new Error(
    '[config] DB_ENCRYPTION_KEY harus berupa 64 karakter hex (32 byte).\n' +
    'Generate dengan: node -e "console.log(require(\'crypto\').randomBytes(32).toString(\'hex\'))"'
  );
}

let config = {
  ENABLED: true,
  DURATION_HOURS: 6
};

let maintenanceMode = {
  enabled: false,
  reason: 'Bot sedang dalam perawatan. Mohon kembali lagi nanti.'
};

const menuEffects = [
  "5104841245755180586",
  "5107584321108051014",
  "5159385139981059251",
  "5046509860389126442"
];

const getRandomEffect = () => menuEffects[Math.floor(Math.random() * menuEffects.length)];

const { Logger } = require('telegram/extensions/Logger');
const silentLogger = new Logger('none');

function getTelegramClientConfig() {
  // Tuning ringan untuk banyak akun: retry koneksi, tanpa mengubah perilaku API.
  return {
    connectionRetries: 8,
    requestRetries: 5,
    timeout: 15,
    autoReconnect: true,
    useWSS: false,
    deviceModel: "Userbot Public",
    systemVersion: "iOS 18.01",
    appVersion: "Telegram iOS 11.5",
    baseLogger: silentLogger
  };
}

module.exports = {
  BOT_TOKEN,
  TICKET_BOT_TOKEN,
  OWNER_ID,
  OWNER_USERNAME,
  LOG_GROUP,
  NOTIF_CHANNEL_DEPOSIT,
  NOTIF_CHANNEL_PURCHASE,
  REQUIRED_CHANNEL,
  REQUIRED_GROUP,
  JOIN_CHECK_CHAT_ID,
  JOIN_FOLDER_LINK,
  API_ID,
  API_HASH,
  WM,
  QRIS_IMAGE,
  MENU_VIDEO_URL,
  MONGODB_URI,
  MONGODB_DB_NAME,
  PAKASIR_SLUG,
  PAKASIR_APIKEY,
  PAKASIR_METHOD,
  PAKASIR_ADMIN_FEE,
  PAKASIR_EXPIRY_MS,
  PAKASIR_POLL_INTERVAL_MS,
  DB_ENCRYPTION_KEY,
  menuEffects,
  getRandomEffect,
  config,
  getTelegramClientConfig,
  maintenanceMode
};
