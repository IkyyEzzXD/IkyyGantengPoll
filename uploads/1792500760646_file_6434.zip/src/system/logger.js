const chalk = require('chalk');
const fs = require('fs');
const path = require('path');
const moment = require('moment');

// BUG FIX: LOGS_DIR sebelumnya path relatif ('./database/logs'), yang
// di-resolve terhadap process.cwd() (bisa beda-beda tergantung dari mana
// proses dijalankan, mis. pm2 start dari /root), bukan terhadap lokasi file
// ini. Kalau cwd beda, folder ini nunjuk ke tempat yang salah/gak ada ->
// appendFileSync ENOENT diam-diam (di-catch kosong di writeToFile). Diganti
// absolut berbasis __dirname biar selalu konsisten ke folder project.
const LOGS_DIR = path.join(__dirname, '../../logs');
// BUG FIX: sebelumnya di sini ada `require('../modules/index.js').bot`.
// Itu circular require (index.js require logger.js, logger.js require balik
// index.js) DAN index.js gak pernah punya `module.exports.bot` sama sekali -
// jadi `bot` di logger.js SELALU undefined, bikin sendErrorToOwner() gak
// pernah berhasil kirim notif error ke owner (diam-diam gagal terus, gak
// ada pesan apapun). Sekarang bot instance di-set dari index.js lewat
// setBotInstance() setelah bot beneran dibuat, bukan lewat require balik.
let bot = null;
let ownerId = null;
function setBotInstance(botInstance) {
  bot = botInstance;
}
function setOwnerId(id) {
  ownerId = id;
}

if (!fs.existsSync(LOGS_DIR)) {
  fs.mkdirSync(LOGS_DIR, { recursive: true });
}

function escHtml(v) {
  return String(v === undefined || v === null ? '' : v)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

// Ambil lokasi "file.js:baris:kolom" pertama milik kode project dari stack trace,
// supaya laporan tidak lagi berisi "Lokasi : Unknown".
function extractLocationFromStack(stack) {
  if (!stack) return null;
  const lines = String(stack).split('\n');
  for (const line of lines) {
    if (line.includes('node_modules') || line.includes('node:internal')) continue;
    const m = line.match(/\(?((?:\/|[A-Za-z]:\\)[^()\s]+\.js):(\d+):(\d+)\)?/);
    if (m) return `${path.basename(m[1])}:${m[2]}`;
  }
  return null;
}

const _ownerErrorSeen = new Map();
const OWNER_ERROR_DEDUP_MS = 5 * 60 * 1000;

function shouldSendOwnerError(key) {
  const now = Date.now();
  const rec = _ownerErrorSeen.get(key);
  if (rec && now - rec.at < OWNER_ERROR_DEDUP_MS) {
    rec.count++;
    return false;
  }
  const repeated = rec ? rec.count : 0;
  _ownerErrorSeen.set(key, { at: now, count: 0 });
  if (_ownerErrorSeen.size > 200) {
    const first = _ownerErrorSeen.keys().next().value;
    _ownerErrorSeen.delete(first);
  }
  return { repeated };
}

async function sendErrorToOwner(errorDetails) {
  try {
    // BUG FIX: sebelumnya pakai process.env.OWNER_ID, padahal OWNER_ID cuma
    // ada sebagai konstanta di setting/config.js, BUKAN environment variable
    // -> selalu undefined, notif error ke owner gak pernah kekirim sama
    // sekali (gagal diam-diam). Sekarang di-set dari index.js lewat setOwnerId().
    if (!bot || !ownerId) return;

    const stackText = errorDetails.stack ? String(errorDetails.stack) : '';
    const location = (errorDetails.location && errorDetails.location !== 'Unknown')
      ? errorDetails.location
      : (extractLocationFromStack(stackText) || 'Unknown');

    const dedupKey = `${String(errorDetails.message).slice(0, 120)}|${location}|${stackText.split('\n')[0].slice(0, 120)}`;
    const gate = shouldSendOwnerError(dedupKey);
    if (!gate) return;

    const repeatedNote = gate.repeated > 0
      ? `\n<b>🔁 Berulang</b> : ${gate.repeated}x sejak laporan terakhir`
      : '';

    const message = `
<blockquote>🔥 <b><u>ERROR DETEKSI</u></b></blockquote>
<blockquote>
<b>📝 Pesan</b> : ${escHtml(errorDetails.message)}
<b>📍 Lokasi</b> : <code>${escHtml(location)}</code>
<b>📅 Waktu</b> : ${moment().format('DD/MM/YYYY HH:mm:ss')}${repeatedNote}
${stackText ? `<b>📚 Stack</b> : <code>${escHtml(stackText.substring(0, 500))}</code>` : ''}</blockquote>`;

    try {
      await bot.sendMessage(ownerId, message, { parse_mode: 'HTML' });
    } catch (sendErr) {
      const plain = `🔥 ERROR DETEKSI\n\nPesan : ${errorDetails.message}\nLokasi : ${location}\nWaktu : ${moment().format('DD/MM/YYYY HH:mm:ss')}${stackText ? `\nStack : ${stackText.substring(0, 500)}` : ''}`;
      await bot.sendMessage(ownerId, plain);
    }
  } catch (err) {
    console.error('Gagal kirim error ke owner:', err.message);
  }
}

// BUG FIX: hampir SEMUA pemanggilan logger.error()/warn() di seluruh project
// (index.js dkk) manggilnya kayak console.error(pesan, errorObjectOrStack) —
// argumen kedua langsung berupa Error object / string stack, BUKAN object
// {user, action, error, stack} kayak yang diharapkan fungsi ini. Akibatnya
// data.stack / data.error selalu undefined dan detail error-nya HILANG dari
// console — makanya di log cuma nongol judulnya doang ("message handler
// error (userId=..., text="..."):") tanpa keterangan errornya sama sekali.
// Fungsi ini sekarang normalize dulu: kalau argumen kedua bukan plain object
// biasa (string / Error / apapun), otomatis dibungkus jadi { error, stack }.
function normalizeLogData(raw) {
  if (raw === undefined || raw === null) return {};
  if (raw instanceof Error) {
    return { error: raw.message, stack: raw.stack };
  }
  if (typeof raw === 'string') {
    // String panjang berformat stack trace ("Error: ...\n    at ...") vs pesan pendek biasa.
    return raw.includes('\n') || raw.length > 150 ? { stack: raw } : { error: raw };
  }
  if (typeof raw === 'object') {
    // Object kosong (default {} karena caller cuma kirim 1 argumen) -> anggap "gak ada data tambahan".
    if (Object.keys(raw).length === 0) return {};
    // Kalau ini plain data object beneran (punya salah satu key yang dikenal), pakai apa adanya.
    if ('user' in raw || 'action' in raw || 'error' in raw || 'stack' in raw || 'duration' in raw) {
      return raw;
    }
    // Object lain (misal hasil JSON.parse dsb) — tetap tampilkan sebagai error biar gak hilang.
    try {
      return { error: JSON.stringify(raw) };
    } catch (e) {
      return { error: String(raw) };
    }
  }
  return { error: String(raw) };
}

// BUG FIX (error.log numpuk tanpa batas): helper rotasi generik dipakai
// untuk combined.log DAN error.log (lihat writeToFile) - sebelumnya logic
// rotasi ini cuma inline sekali untuk combined.log saja. Dipisah jadi
// fungsi supaya bisa dipakai ulang tanpa duplikasi kode, prefix beda per
// file (combined_ / error_) supaya backup dari dua log ini tidak
// tercampur saat di-listing/dihapus.
async function rotateLogIfNeeded(filePath, backupPrefix, maxSizeBytes = 5 * 1024 * 1024, maxBackups = 5) {
  try {
    const stats = await fs.promises.stat(filePath);
    if (stats.size <= maxSizeBytes) return;

    const backup = path.join(LOGS_DIR, `${backupPrefix}${Date.now()}.log`);
    await fs.promises.rename(filePath, backup);

    const files = await fs.promises.readdir(LOGS_DIR);
    const backups = files.filter(f => f.startsWith(backupPrefix) && f.endsWith('.log')).sort();
    while (backups.length > maxBackups) {
      const oldest = backups.shift();
      await fs.promises.unlink(path.join(LOGS_DIR, oldest));
    }
  } catch (err) {}
}

// BUG FIX (I/O sinkron di writeToFile - blocking event loop): sebelumnya
// SETIAP pemanggilan logger.info/error/warn/success/debug langsung
// appendFileSync + statSync/readdirSync/renameSync/unlinkSync (lewat
// rotateLogIfNeeded) di call stack yang sama - synchronous, blocking
// seluruh event loop Node.js tiap kali ada log (termasuk saat polling
// Telegram/DB query lain lagi jalan). Makin sering log (mis. saat promosi
// jalan ke ribuan grup), makin sering event loop nge-freeze sesaat.
// Diganti jadi antrian tulis asinkron yang di-batch: entry log ditumpuk
// dulu di memori (push ke array, urutan terjaga karena push selalu FIFO),
// baru ditulis ke disk lewat satu appendFile terbatch tiap FLUSH_INTERVAL_MS
// (atau saat flushLogs() dipanggil manual, mis. graceful shutdown).
let combinedQueue = [];
let errorQueue = [];
let flushTimer = null;
const FLUSH_INTERVAL_MS = 200;

function scheduleFlush() {
  if (flushTimer) return;
  flushTimer = setTimeout(() => {
    flushTimer = null;
    flushLogs().catch(() => {});
  }, FLUSH_INTERVAL_MS);
  if (flushTimer.unref) flushTimer.unref();
}

// Diekspor supaya bisa dipanggil manual (mis. graceful shutdown) untuk
// memastikan semua entry yang masih di antrian benar-benar tertulis ke
// disk sebelum proses keluar.
async function flushLogs() {
  if (combinedQueue.length > 0) {
    const chunk = combinedQueue;
    combinedQueue = [];
    try {
      const combinedLog = path.join(LOGS_DIR, 'combined.log');
      await fs.promises.appendFile(combinedLog, chunk.join(''));
      await rotateLogIfNeeded(combinedLog, 'combined_');
    } catch (err) {}
  }
  if (errorQueue.length > 0) {
    const chunk = errorQueue;
    errorQueue = [];
    try {
      const errorLog = path.join(LOGS_DIR, 'error.log');
      await fs.promises.appendFile(errorLog, chunk.join(''));
      await rotateLogIfNeeded(errorLog, 'error_');
    } catch (err) {}
  }
}

const TRANSIENT_INFRA_RE = /secureConnect|MongoServerSelectionError|MongoNetworkError|MongoNetworkTimeoutError|MongoPoolClearedError|PoolClearedOnNetworkError|MongoWaitQueueTimeoutError|MongoNotConnectedError|MongoTopologyClosedError|server monitor timeout|connection pool .*cleared|must be connected before running operations|topology (is|was) closed|ReplicaSetNoPrimary|getaddrinfo (EAI_AGAIN|ENOTFOUND)|ECONNRESET|ETIMEDOUT|ENETUNREACH|EHOSTUNREACH|ESOCKETTIMEDOUT|EAI_AGAIN|socket hang up|connection \d+ to \S+ timed out|MongoServerError: .*(not primary|node is recovering|interrupted at shutdown)/i;
const _transientSeen = new Map();
const TRANSIENT_CONSOLE_DEDUP_MS = 30 * 1000;

function isTransientInfraError(message, data) {
  const text = String(message || '') + ' ' + String((data && data.error) || '') + ' ' + String((data && data.stack) || '');
  return TRANSIENT_INFRA_RE.test(text);
}

function logTransient(message, data) {
  const key = String(message || '').slice(0, 80);
  const now = Date.now();
  const rec = _transientSeen.get(key);
  if (!rec || now - rec > TRANSIENT_CONSOLE_DEDUP_MS) {
    _transientSeen.set(key, now);
    if (_transientSeen.size > 200) {
      const first = _transientSeen.keys().next().value;
      _transientSeen.delete(first);
    }
    const detail = data && data.error ? ` | ${String(data.error).split('\n')[0].slice(0, 160)}` : '';
    console.log(chalk.hex('#FFA500')(`[${moment().format('HH:mm:ss')}] ⚠️ gangguan koneksi sementara, dicoba ulang otomatis: ${String(message || '').slice(0, 160)}${detail}`));
  }
  logger.writeToFile('WARN', message, data);
}

const LEVEL_STYLE = {
  INFO: chalk.hex('#00CED1'),
  ERROR: chalk.hex('#FF4444'),
  WARN: chalk.hex('#FFA500'),
  SUCCESS: chalk.hex('#00FF88'),
  DEBUG: chalk.hex('#9B59B6'),
};

function consoleLine(level, message, data, withStack) {
  const parts = [`[${moment().format('HH:mm:ss')}] ${level}`, String(message)];
  if (data.user) parts.push(`user=${data.user}`);
  if (data.action) parts.push(`action=${data.action}`);
  if (data.duration) parts.push(`${data.duration}ms`);
  if (data.error) parts.push(`error=${data.error}`);
  if (withStack && data.stack) parts.push(`stack=${String(data.stack).substring(0, 500)}`);
  console.log(LEVEL_STYLE[level](parts.join(' | ')));
}

const logger = {
  info: (message, data = {}) => {
    data = normalizeLogData(data);
    consoleLine('INFO', message, data, false);
    logger.writeToFile('INFO', message, data);
  },
  
  error: (message, data = {}) => {
    data = normalizeLogData(data);
    if (isTransientInfraError(message, data)) {
      logTransient(message, data);
      return;
    }
    consoleLine('ERROR', message, data, true);
    logger.writeToFile('ERROR', message, data);

    // Jangan spam owner untuk error user-facing yang sudah ditangani (format session, OTP, dsb)
    const skipOwnerNotif = /Login dengan session gagal|Format String Session tidak dikenali|SESSION_REVOKED|SESSION_EXPIRED|not a valid string session|OTP gagal|password.*2FA|PHONE_CODE_INVALID|PHONE_CODE_EXPIRED|AUTH_KEY_UNREGISTERED|AUTH_KEY_INVALID|USER_DEACTIVATED|session invalid.*cleaning up/i.test(String(message || ''));
    // BUG FIX (SPAM NOTIF OWNER - "bot was blocked by the user"): sebelumnya
    // tidak ada pengecualian untuk error 403 Telegram saat bot coba kirim
    // pesan ke user yang sudah blok bot / akun dihapus / chat sudah tidak
    // ada. Ini BUKAN bug sistem - ini kondisi normal yang wajar terjadi
    // kapan saja (user block bot). Karena belum ada di skip list, tiap kali
    // user yang sudah blok bot masih memicu handler (pesan lama yang baru
    // diproses, klik tombol lama, dsb), logger.error() tetap kirim notif
    // "🔥 ERROR DETEKSI" ke owner - bisa berkali-kali beruntun untuk user
    // yang sama dalam hitungan detik. Log ke console/file TETAP dicatat
    // seperti biasa (writeToFile di atas tidak ikut diskip); yang diskip
    // cuma notifikasi Telegram ke owner yang isinya cuma noise.
    const combinedForBlockCheck = String(message || '') + ' ' + String(data.error || '') + ' ' + String(data.stack || '');
    const isBlockedOrChatGoneError = /bot was blocked by the user|user is deactivated|chat not found|can'?t initiate conversation with a user|bot can'?t send messages to bots|group chat was upgraded|PEER_ID_INVALID/i.test(combinedForBlockCheck);

    // BUG FIX (notif "POLLING ERROR" numpuk saat gangguan jaringan sesaat):
    // ESOCKETTIMEDOUT/EFATAL/ECONNRESET dkk di polling Telegram itu wajar
    // terjadi dan loop polling dilanjutkan otomatis oleh library (lihat handler
    // polling_error di index.js) - tapi tanpa throttle, tiap kejadian error
    // yang beruntun (bisa 5-10x dalam semenit sebelum berhasil pulih)
    // masing-masing kirim notif Telegram terpisah ke owner, padahal itu
    // satu insiden yang sama dan sudah ditangani otomatis. Throttle: hanya
    // kirim notif "POLLING ERROR" paling cepat sekali per
    // POLLING_ERROR_NOTIF_COOLDOWN_MS - kalau insidennya berkepanjangan,
    // owner tetap dapat kabar berkala (bukan dibungkam total), tapi tidak
    // banjir notifikasi identik untuk satu insiden yang lagi coba pulih
    // sendiri.
    const isPollingError = /^POLLING ERROR/i.test(String(message || ''));
    let skipPollingNotif = false;
    if (isPollingError) {
      const POLLING_ERROR_NOTIF_COOLDOWN_MS = 3 * 60 * 1000; // 3 menit
      const lastSent = logger._lastPollingErrorNotifAt || 0;
      if (Date.now() - lastSent < POLLING_ERROR_NOTIF_COOLDOWN_MS) {
        skipPollingNotif = true;
      } else {
        logger._lastPollingErrorNotifAt = Date.now();
      }
    }

    if (!skipOwnerNotif && !isBlockedOrChatGoneError && !skipPollingNotif) {
      sendErrorToOwner({
        message: message,
        location: data.action || 'Unknown',
        stack: data.stack || data.error,
        user: data.user
      }).catch(() => {});
    }
  },
  
  warn: (message, data = {}) => {
    data = normalizeLogData(data);
    consoleLine('WARN', message, data, false);
    logger.writeToFile('WARN', message, data);
  },
  
  success: (message, data = {}) => {
    data = normalizeLogData(data);
    consoleLine('SUCCESS', message, data, false);
    logger.writeToFile('SUCCESS', message, data);
  },
  
  debug: (message, data = {}) => {
    data = normalizeLogData(data);
    consoleLine('DEBUG', message, data, false);
    logger.writeToFile('DEBUG', message, data);
  },
  
  writeToFile: (level, message, data = {}) => {
    try {
      const timestamp = new Date().toISOString();
      const logEntry = {
        timestamp,
        level,
        message,
        ...data
      };

      // BUG FIX (I/O sinkron - lihat catatan lengkap di atas dekat
      // scheduleFlush/flushLogs): sebelumnya appendFileSync + rotasi sync
      // langsung di sini. Sekarang cuma push ke antrian memori (murah,
      // non-blocking) - penulisan sungguhan di-batch oleh flushLogs().
      const line = JSON.stringify(logEntry) + '\n';
      if (combinedQueue.length > 20000) combinedQueue = combinedQueue.slice(-10000);
      combinedQueue.push(line);
      // error.log tetap dirotasi terpisah dari combined.log (lihat catatan
      // rotateLogIfNeeded) supaya backup dari dua log ini tidak tercampur.
      if (level === 'ERROR') {
        if (errorQueue.length > 5000) errorQueue = errorQueue.slice(-2500);
        errorQueue.push(line);
      }
      scheduleFlush();
    } catch (err) {}
  }
};

module.exports = logger;
module.exports.setBotInstance = setBotInstance;
module.exports.setOwnerId = setOwnerId;
module.exports.isTransientInfraError = isTransientInfraError;
// BUG FIX (flush saat graceful shutdown): dipanggil dari gracefulShutdown()
// di index.js sebelum process.exit(), supaya entry log yang masih nyangkut
// di antrian in-memory tidak hilang saat proses berhenti tiba-tiba.
module.exports.flushLogs = flushLogs;