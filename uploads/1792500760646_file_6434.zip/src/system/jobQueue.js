const { Semaphore } = require('./concurrency');
const runtimeConfig = require('../constants/runtimeConfig');

class JobQueue {
  constructor(opts = {}) {
    this.name = opts.name || 'default';
    this.concurrency = Math.max(1, opts.concurrency || 4);
    this.maxPending = Math.max(this.concurrency, opts.maxPending || 500);
    this.sem = new Semaphore(this.concurrency);
    this.pending = 0;
    this.running = 0;
    this.completed = 0;
    this.failed = 0;
    this.rejected = 0;
  }

  async add(fn, meta = {}) {
    if (this.pending + this.running >= this.maxPending) {
      this.rejected++;
      const err = new Error(`JobQueue[${this.name}] full (pending=${this.pending} running=${this.running} max=${this.maxPending})`);
      err.code = 'QUEUE_FULL';
      throw err;
    }
    this.pending++;
    try {
      await this.sem.acquire();
      this.pending = Math.max(0, this.pending - 1);
      this.running++;
      try {
        const result = await fn(meta);
        this.completed++;
        return result;
      } catch (err) {
        this.failed++;
        throw err;
      } finally {
        this.running = Math.max(0, this.running - 1);
        this.sem.release();
      }
    } catch (err) {
      this.pending = Math.max(0, this.pending - 1);
      throw err;
    }
  }

  get stats() {
    return {
      name: this.name,
      pending: this.pending,
      running: this.running,
      completed: this.completed,
      failed: this.failed,
      rejected: this.rejected,
      concurrency: this.concurrency,
      maxPending: this.maxPending,
    };
  }

  get isBusy() {
    return this.running > 0 || this.pending > 0;
  }
}

const promoQueue = new JobQueue({
  name: 'promo',
  concurrency: runtimeConfig.PROMO_QUEUE_CONCURRENCY,
  maxPending: 300,
});
const sebarQueue = new JobQueue({
  name: 'sebar',
  concurrency: runtimeConfig.SEBAR_QUEUE_CONCURRENCY,
  maxPending: 200,
});
const adminQueue = new JobQueue({
  name: 'admin',
  concurrency: 2,
  maxPending: 50,
});

function allStats() {
  return {
    promo: promoQueue.stats,
    sebar: sebarQueue.stats,
    admin: adminQueue.stats,
  };
}

module.exports = {
  JobQueue,
  promoQueue,
  sebarQueue,
  adminQueue,
  allStats,
};
