// ============================================================================
// ENKRIPSI DATA SENSITIF DI DATABASE (session_string dkk)
// ----------------------------------------------------------------------------
// KENAPA INI ADA:
//  session_string (GramJS StringSession) setara dengan akses penuh ke akun
//  Telegram pemiliknya - siapapun yang punya string itu bisa login sebagai
//  user tersebut tanpa perlu OTP/2FA lagi. Sebelumnya kolom ini tersimpan
//  sebagai teks biasa di database.sqlite. Kalau file database itu bocor
//  (misal lewat backup yang salah kirim, VPS yang diretas, atau file
//  ter-share tanpa sengaja), SEMUA akun Telegram userbot yang terdaftar
//  langsung bisa diambil alih orang lain tanpa perlu password apapun.
//
// CARA KERJA:
//  AES-256-GCM dengan kunci dari DB_ENCRYPTION_KEY (di .env, 32 byte hex).
//  Setiap enkripsi pakai IV (initialization vector) acak baru, jadi hasil
//  enkripsi dari plaintext yang sama akan selalu berbeda tiap kali - ini
//  mencegah orang menebak isi dari pola ciphertext yang berulang.
//  GCM juga menyertakan auth tag, jadi kalau ciphertext diubah/rusak,
//  dekripsi akan gagal dengan jelas (bukan menghasilkan data yang salah
//  tanpa ketahuan).
//
// FORMAT TERSIMPAN (string, aman disimpan di kolom TEXT SQLite):
//   "v1:<iv_hex>:<authtag_hex>:<ciphertext_hex>"
//  Prefix "v1:" sengaja ada supaya kalau suatu saat skema enkripsi berubah
//  (misal ganti algoritma), kode masih bisa membedakan data lama vs baru.
//
// PENTING:
//  - DB_ENCRYPTION_KEY di .env TIDAK BOLEH hilang atau berubah setelah bot
//    berjalan dengan data asli. Kalau hilang, semua session_string yang
//    sudah terenkripsi TIDAK BISA didekripsi lagi - user harus login ulang.
//    -> WAJIB backup file .env secara terpisah dan aman.
//  - Fungsi decrypt() akan melempar Error kalau data rusak/kunci salah -
//    pemanggil WAJIB menangkap error itu (try/catch), jangan biarkan proses
//    crash cuma karena satu baris data lama yang tidak valid.
// ============================================================================

const crypto = require('crypto');

const ALGORITHM = 'aes-256-gcm';
const IV_LENGTH = 12; // rekomendasi NIST untuk GCM (96 bit)
const VERSION_PREFIX = 'v1';

let cachedKey = null;

function getKey() {
  if (cachedKey) return cachedKey;
  const hexKey = require('../setting/config').DB_ENCRYPTION_KEY;
  if (!hexKey || !/^[0-9a-fA-F]{64}$/.test(hexKey)) {
    throw new Error('[cryptoUtil] DB_ENCRYPTION_KEY tidak valid (harus 64 karakter hex / 32 byte).');
  }
  cachedKey = Buffer.from(hexKey, 'hex');
  return cachedKey;
}

/**
 * Enkripsi sebuah string plaintext. Aman dipanggil berulang dengan input
 * yang sama - hasilnya akan selalu berbeda tiap kali (IV acak baru).
 * @param {string} plaintext - teks asli, mis. session_string GramJS
 * @returns {string} ciphertext terformat "v1:iv:authtag:data", aman disimpan di kolom TEXT
 */
function encrypt(plaintext) {
  if (plaintext === null || plaintext === undefined) return plaintext;
  if (typeof plaintext !== 'string') plaintext = String(plaintext);
  if (plaintext === '') return plaintext; // string kosong tidak perlu dienkripsi

  const key = getKey();
  const iv = crypto.randomBytes(IV_LENGTH);
  const cipher = crypto.createCipheriv(ALGORITHM, key, iv);
  const encrypted = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
  const authTag = cipher.getAuthTag();

  return `${VERSION_PREFIX}:${iv.toString('hex')}:${authTag.toString('hex')}:${encrypted.toString('hex')}`;
}

/**
 * Dekripsi string yang sebelumnya dihasilkan oleh encrypt().
 * MELEMPAR ERROR kalau format tidak valid, kunci salah, atau data rusak -
 * pemanggil wajib bungkus dengan try/catch.
 * @param {string} ciphertext - hasil dari encrypt()
 * @returns {string} plaintext asli
 */
function decrypt(ciphertext) {
  if (ciphertext === null || ciphertext === undefined) return ciphertext;
  if (ciphertext === '') return ciphertext;

  if (!isEncrypted(ciphertext)) {
    const err = new Error('[cryptoUtil] Data tidak terenkripsi atau format tidak dikenali.');
    err.code = 'NOT_ENCRYPTED';
    throw err;
  }

  const parts = ciphertext.split(':');
  const [, ivHex, authTagHex, dataHex] = parts;

  // Validasi format SEBELUM Buffer.from/createDecipheriv supaya data korup
  // tidak memicu error OpenSSL yang kurang jelas.
  if (!/^[0-9a-fA-F]+$/.test(ivHex) || ivHex.length !== IV_LENGTH * 2) {
    const err = new Error('[cryptoUtil] IV terenkripsi tidak valid.');
    err.code = 'INVALID_CIPHERTEXT';
    throw err;
  }
  if (!/^[0-9a-fA-F]+$/.test(authTagHex) || authTagHex.length !== 32) {
    const err = new Error('[cryptoUtil] Auth tag terenkripsi tidak valid.');
    err.code = 'INVALID_CIPHERTEXT';
    throw err;
  }
  if (!/^[0-9a-fA-F]*$/.test(dataHex) || dataHex.length % 2 !== 0) {
    const err = new Error('[cryptoUtil] Ciphertext tidak valid/rusak.');
    err.code = 'INVALID_CIPHERTEXT';
    throw err;
  }

  const key = getKey();
  const iv = Buffer.from(ivHex, 'hex');
  const authTag = Buffer.from(authTagHex, 'hex');
  const data = Buffer.from(dataHex, 'hex');

  try {
    const decipher = crypto.createDecipheriv(ALGORITHM, key, iv);
    decipher.setAuthTag(authTag);
    const decrypted = Buffer.concat([decipher.update(data), decipher.final()]);
    return decrypted.toString('utf8');
  } catch (err) {
    // Node/OpenSSL memakai pesan ini saat kunci salah atau ciphertext
    // berubah. Tandai secara eksplisit agar caller bisa menangani tanpa
    // retry/log spam.
    if (/authenticate|auth|bad decrypt|unsupported state/i.test(String(err.message))) {
      const authErr = new Error(
        '[cryptoUtil] Autentikasi dekripsi gagal: kunci DB_ENCRYPTION_KEY tidak cocok atau data terenkripsi rusak.'
      );
      authErr.code = 'AUTH_FAILED';
      authErr.cause = err;
      throw authErr;
    }
    throw err;
  }
}

/**
 * Cek apakah sebuah string sudah dalam format terenkripsi kita.
 * Berguna untuk migrasi data lama (lihat migrateEncryptSessions di
 * modules/index.js) supaya tidak mengenkripsi ulang data yang sudah
 * terenkripsi.
 */
function isEncrypted(value) {
  if (typeof value !== 'string') return false;
  const parts = value.split(':');
  return parts.length === 4 && parts[0] === VERSION_PREFIX;
}

/**
 * Dekripsi yang "aman" - kalau gagal (data lama belum terenkripsi, atau
 * korup), kembalikan nilai aslinya apa adanya alih-alih melempar error.
 * Dipakai di titik baca yang butuh tetap jalan meski ada data lama yang
 * belum sempat termigrasi, TAPI tetap mencatat ke log supaya ketahuan.
 */
function decryptSafe(ciphertext, logger = null) {
  if (ciphertext === null || ciphertext === undefined || ciphertext === '') return ciphertext;

  if (!isEncrypted(ciphertext)) {
    if (logger && typeof logger.warn === 'function') {
      logger.warn('[cryptoUtil] Ditemukan session_string belum terenkripsi (data lama).');
    }
    return ciphertext;
  }

  try {
    return decrypt(ciphertext);
  } catch (err) {
    if (logger && typeof logger.error === 'function') {
      // Jangan cetak ciphertext/session string. Untuk AUTH_FAILED, caller
      // dapat menangani secara khusus dan tidak mengulang log tiap query.
      logger.error(`[cryptoUtil] Gagal dekripsi data [${err.code || 'UNKNOWN'}]: ${err.message}`);
    }
    // PENTING: jangan pernah mengembalikan ciphertext terenkripsi ke
    // GramJS. Itu sebelumnya membuat error berantai dan retry terus-menerus.
    // null menandakan session tidak tersedia, tanpa mengubah DB.
    if (err.code === 'AUTH_FAILED' || err.code === 'INVALID_CIPHERTEXT') {
      return null;
    }
    return ciphertext;
  }
}

module.exports = {
  encrypt,
  decrypt,
  decryptSafe,
  isEncrypted,
};
