const { AsyncLocalStorage } = require('async_hooks');

const MEDIA_CACHE_MAX = 4000;
const PEER_FAIL_TTL_MS = 10 * 60 * 1000;
const PEER_FAIL_MAX = 2000;

const mediaMessages = new Map();
const peerFailures = new Map();

function mediaKey(chatId, messageId) {
  return `${chatId}:${messageId}`;
}

function noteMedia(chatId, messageId) {
  if (chatId == null || messageId == null) return;
  const key = mediaKey(chatId, messageId);
  if (mediaMessages.has(key)) mediaMessages.delete(key);
  mediaMessages.set(key, 1);
  while (mediaMessages.size > MEDIA_CACHE_MAX) {
    const oldest = mediaMessages.keys().next().value;
    if (oldest === undefined) break;
    mediaMessages.delete(oldest);
  }
}

function forgetMedia(chatId, messageId) {
  mediaMessages.delete(mediaKey(chatId, messageId));
}

function isMediaMessage(message) {
  if (!message || typeof message !== 'object') return false;
  return !!(message.photo || message.video || message.animation || message.document ||
    message.audio || message.voice || message.video_note || message.sticker);
}

function noteIfMedia(message) {
  if (!message || !message.chat) return;
  if (isMediaMessage(message)) noteMedia(message.chat.id, message.message_id);
}

function errText(err) {
  return String((err && (err.message || err.description)) || '');
}

function isNoTextError(err) {
  return /there is no text in the message to edit/i.test(errText(err));
}

function isNeedResendError(err) {
  return /caption is too long|MEDIA_CAPTION_TOO_LONG|there is no caption in the message to edit|message can.?t be edited/i.test(errText(err));
}

function toMessageLike(result, chatId, messageId) {
  if (result && typeof result === 'object') {
    if (result.message_id == null) result.message_id = messageId;
    return result;
  }
  return { message_id: messageId, chat: { id: chatId } };
}

function installMediaEditFallback(botInstance, log, stateHolder) {
  if (!botInstance || botInstance.__mediaEditFallback) return;
  const baseEditText = botInstance.editMessageText.bind(botInstance);
  const baseEditCaption = botInstance.editMessageCaption.bind(botInstance);
  const baseSend = botInstance.sendMessage.bind(botInstance);
  const baseDelete = botInstance.deleteMessage.bind(botInstance);

  const syncMenuState = (chatId, oldId, newId, type) => {
    try {
      const map = stateHolder && stateHolder.menuMsgState;
      if (!map || typeof map.get !== 'function') return;
      const key = String(chatId);
      const st = map.get(key);
      if (st && String(st.messageId) === String(oldId)) map.set(key, { messageId: newId, type });
    } catch (_) {}
  };

  const resend = async (text, options, chatId, messageId) => {
    forgetMedia(chatId, messageId);
    try { await baseDelete(chatId, messageId); } catch (_) {}
    const sendOpts = {};
    if (options.parse_mode) sendOpts.parse_mode = options.parse_mode;
    if (options.reply_markup) sendOpts.reply_markup = options.reply_markup;
    sendOpts.disable_web_page_preview = true;
    const sent = await baseSend(chatId, text, sendOpts);
    if (sent && sent.message_id != null) syncMenuState(chatId, messageId, sent.message_id, 'text');
    return sent;
  };

  const viaCaption = async (text, options, chatId, messageId) => {
    const captionOpts = { ...options };
    delete captionOpts.disable_web_page_preview;
    try {
      const res = await baseEditCaption(text, captionOpts);
      noteMedia(chatId, messageId);
      return toMessageLike(res, chatId, messageId);
    } catch (err) {
      if (isNeedResendError(err)) return resend(text, options, chatId, messageId);
      throw err;
    }
  };

  botInstance.editMessageText = async function (text, options = {}) {
    const chatId = options && options.chat_id;
    const messageId = options && options.message_id;
    const addressable = chatId != null && messageId != null;
    if (addressable && mediaMessages.has(mediaKey(chatId, messageId))) {
      return viaCaption(text, options, chatId, messageId);
    }
    try {
      return await baseEditText(text, options);
    } catch (err) {
      if (!addressable || !isNoTextError(err)) throw err;
      noteMedia(chatId, messageId);
      return viaCaption(text, options, chatId, messageId);
    }
  };

  for (const name of ['sendPhoto', 'sendVideo', 'sendAnimation', 'sendDocument', 'sendAudio', 'sendVoice']) {
    const original = botInstance[name];
    if (typeof original !== 'function') continue;
    botInstance[name] = async function (...args) {
      const sent = await original.apply(botInstance, args);
      try { noteIfMedia(sent); } catch (_) {}
      return sent;
    };
  }

  botInstance.__mediaEditFallback = true;
  if (log && typeof log.info === 'function') log.info('[telegramGuards] fallback edit pesan media aktif');
}

const touchStore = new AsyncLocalStorage();

function markTouched() {
  const st = touchStore.getStore();
  if (st) st.touched = true;
}

function installTouchTracking(botInstance) {
  if (!botInstance || botInstance.__touchTracking) return;
  const methods = [
    'sendMessage', 'sendPhoto', 'sendVideo', 'sendAnimation', 'sendDocument', 'sendAudio',
    'sendVoice', 'sendSticker', 'sendMediaGroup', 'editMessageText', 'editMessageCaption',
    'editMessageReplyMarkup', 'editMessageMedia', 'deleteMessage'
  ];
  for (const name of methods) {
    const original = botInstance[name];
    if (typeof original !== 'function') continue;
    botInstance[name] = function (...args) {
      markTouched();
      return original.apply(botInstance, args);
    };
  }
  const originalAnswer = botInstance.answerCallbackQuery;
  if (typeof originalAnswer === 'function') {
    botInstance.answerCallbackQuery = function (...args) {
      const second = args[1];
      if ((typeof second === 'string' && second) || (second && typeof second === 'object' && second.text)) markTouched();
      return originalAnswer.apply(botInstance, args);
    };
  }
  botInstance.__touchTracking = true;
}

function withSilenceGuard(handler, onSilent, log) {
  return async function (callbackQuery) {
    const store = { touched: false };
    try {
      await touchStore.run(store, () => handler(callbackQuery));
    } catch (err) {
      if (log && typeof log.error === 'function') log.error(`callback handler gagal: ${errText(err)}`);
    }
    if (!store.touched) {
      try {
        await onSilent(callbackQuery);
      } catch (err) {
        if (log && typeof log.warn === 'function') log.warn(`fallback tombol diam gagal: ${errText(err)}`);
      }
    }
  };
}

function normalizeTarget(target) {
  const raw = String(target == null ? '' : target).trim();
  if (!raw) return { kind: 'none', value: '' };
  if (raw.toLowerCase() === 'me') return { kind: 'me', value: 'me' };
  if (raw[0] === '@') return { kind: 'username', value: raw.slice(1) };
  if (/^-?\d+$/.test(raw)) {
    const n = Number(raw);
    if (Number.isSafeInteger(n)) return { kind: 'id', value: n, raw };
    return { kind: 'id', value: raw, raw };
  }
  if (/^[A-Za-z][A-Za-z0-9_]{3,}$/.test(raw)) return { kind: 'username', value: raw };
  return { kind: 'unknown', value: raw };
}

function failureKey(ubotId, target) {
  return `${ubotId}|${target}`;
}

function peerRecentlyFailed(ubotId, target) {
  const key = failureKey(ubotId, target);
  const at = peerFailures.get(key);
  if (at === undefined) return false;
  if (Date.now() - at > PEER_FAIL_TTL_MS) {
    peerFailures.delete(key);
    return false;
  }
  return true;
}

function markPeerFailed(ubotId, target) {
  const key = failureKey(ubotId, target);
  if (peerFailures.has(key)) peerFailures.delete(key);
  peerFailures.set(key, Date.now());
  while (peerFailures.size > PEER_FAIL_MAX) {
    const oldest = peerFailures.keys().next().value;
    if (oldest === undefined) break;
    peerFailures.delete(oldest);
  }
}

function clearPeerFailure(ubotId, target) {
  peerFailures.delete(failureKey(ubotId, target));
}

async function resolveUserbotPeer(client, target) {
  const t = normalizeTarget(target);
  if (t.kind === 'none' || t.kind === 'unknown') throw new Error('target notifikasi tidak valid');
  if (t.kind === 'me') return 'me';
  if (t.kind === 'username') return client.getInputEntity(t.value);
  try {
    return await client.getInputEntity(t.value);
  } catch (_) {
    return client.getEntity(t.value);
  }
}

async function sendNotif(options) {
  const { ubot, bot, target, ownerId, plain, html, log } = options;
  const text = plain != null ? plain : html;
  const htmlText = html != null ? html : plain;
  const ubotId = ubot && (ubot.id || ubot.owner_id);
  const t = normalizeTarget(target);

  if (ubot && ubot.client && t.kind !== 'none' && t.kind !== 'unknown' && !peerRecentlyFailed(ubotId, t.raw || t.value)) {
    try {
      const peer = await resolveUserbotPeer(ubot.client, target);
      await ubot.client.sendMessage(peer, { message: text });
      clearPeerFailure(ubotId, t.raw || t.value);
      return 'userbot';
    } catch (err) {
      markPeerFailed(ubotId, t.raw || t.value);
      if (log && typeof log.warn === 'function') {
        log.warn(`Notif via userbot ke ${target} gagal (${errText(err)}), pakai bot API`);
      }
    }
  }

  if (bot && t.kind === 'id' && Number(t.value) > 0) {
    try {
      await bot.sendMessage(t.value, htmlText, { parse_mode: 'HTML' });
      return 'bot-target';
    } catch (_) {
      try {
        await bot.sendMessage(t.value, text);
        return 'bot-target';
      } catch (_) {}
    }
  }

  if (bot && ownerId != null) {
    try {
      await bot.sendMessage(ownerId, htmlText, { parse_mode: 'HTML' });
      return 'bot-owner';
    } catch (_) {
      try {
        await bot.sendMessage(ownerId, text);
        return 'bot-owner';
      } catch (err) {
        if (log && typeof log.error === 'function') log.error(`Notif ke owner ${ownerId} gagal total: ${errText(err)}`);
      }
    }
  }
  return null;
}

module.exports = {
  installMediaEditFallback,
  installTouchTracking,
  markTouched,
  withSilenceGuard,
  noteMedia,
  noteIfMedia,
  isMediaMessage,
  resolveUserbotPeer,
  sendNotif,
  normalizeTarget
};
