// =====================================================================
// SISTEM PAKET FLEKSIBEL + CASHBACK + FIRST-PURCHASE DISCOUNT
// Melengkapi tabel `prices` yang sudah ada (1–5 bulan).
// Durasi tambahan: 1 hari, 3 hari, 7 hari, 90 hari.
// =====================================================================

/**
 * Durasi paket dalam detik + label.
 * months: null artinya bukan berbasis bulan (harian/mingguan).
 * priceKey: kolom di tabel prices (price_1 .. price_5) ATAU key custom.
 */
const FLEX_PACKAGES = [
  { id: '1d',  label: '1 Hari',   seconds: 1 * 86400,        months: null, discountPct: 0  },
  { id: '3d',  label: '3 Hari',   seconds: 3 * 86400,        months: null, discountPct: 5  },
  { id: '7d',  label: '7 Hari',   seconds: 7 * 86400,        months: null, discountPct: 10 },
  { id: '30d', label: '1 Bulan',  seconds: 30 * 86400,       months: 1,    discountPct: 0  },
  { id: '60d', label: '2 Bulan',  seconds: 60 * 86400,       months: 2,    discountPct: 5  },
  { id: '90d', label: '3 Bulan',  seconds: 90 * 86400,       months: 3,    discountPct: 10 },
  { id: '120d',label: '4 Bulan',  seconds: 120 * 86400,      months: 4,    discountPct: 12 },
  { id: '150d',label: '5 Bulan',  seconds: 150 * 86400,      months: 5,    discountPct: 15 },
];

// Harga dasar untuk paket harian (kalau belum ada di DB).
// Dihitung proporsional dari harga 1 bulan.
// price_1 = harga 1 bulan di tabel prices.
function calcFlexPrice(baseMonthPrice, pkg) {
  if (!baseMonthPrice || baseMonthPrice <= 0) baseMonthPrice = 5000;
  if (pkg.months) {
    // pakai harga dari DB (price_N), fallback proporsional
    return Math.round(baseMonthPrice * pkg.months * (1 - (pkg.discountPct || 0) / 100));
  }
  // harian: proporsional dari harga bulanan / 30, + markup kecil biar tidak terlalu murah
  const daily = baseMonthPrice / 30;
  let price = Math.round(daily * (pkg.seconds / 86400));
  // minimal Rp 500
  if (price < 500) price = 500;
  // terapkan diskon paket
  if (pkg.discountPct) {
    price = Math.round(price * (1 - pkg.discountPct / 100));
  }
  return price;
}

/**
 * Ambil daftar paket siap jual untuk type 'wm' | 'nowm' | 'reseller'.
 * pricesRow = hasil SELECT * FROM prices WHERE type = ?
 */
function listPackages(type, pricesRow, options = {}) {
  const {
    firstPurchaseDiscountPct = 20, // diskon tambahan untuk pembelian pertama
    isFirstPurchase = false,
    expiryDiscountPct = 0,         // diskon karena hampir expired
  } = options;

  const base1 = pricesRow?.price_1 || (type === 'nowm' ? 5000 : type === 'reseller' ? 10000 : 3000);
  const base2 = pricesRow?.price_2 || base1 * 2;
  const base3 = pricesRow?.price_3 || base1 * 3;
  const base4 = pricesRow?.price_4 || base1 * 4;
  const base5 = pricesRow?.price_5 || base1 * 5;
  const monthPrices = { 1: base1, 2: base2, 3: base3, 4: base4, 5: base5 };

  return FLEX_PACKAGES.map(pkg => {
    let price;
    if (pkg.months && monthPrices[pkg.months]) {
      // harga dari DB, lalu terapkan discountPct paket (kalau ada)
      price = monthPrices[pkg.months];
      if (pkg.discountPct && pkg.months > 1) {
        // untuk multi-bulan, harga DB sudah final; discountPct hanya info
        // (bisa diabaikan atau dipakai sebagai label "hemat X%")
      }
    } else {
      price = calcFlexPrice(base1, pkg);
    }

    let finalPrice = price;
    let appliedDiscounts = [];

    if (isFirstPurchase && firstPurchaseDiscountPct > 0) {
      const d = Math.floor(finalPrice * firstPurchaseDiscountPct / 100);
      finalPrice -= d;
      appliedDiscounts.push({ type: 'first_purchase', pct: firstPurchaseDiscountPct, amount: d });
    }
    if (expiryDiscountPct > 0) {
      const d = Math.floor(finalPrice * expiryDiscountPct / 100);
      finalPrice -= d;
      appliedDiscounts.push({ type: 'expiry', pct: expiryDiscountPct, amount: d });
    }
    if (finalPrice < 100) finalPrice = 100;

    return {
      id: pkg.id,
      label: pkg.label,
      seconds: pkg.seconds,
      months: pkg.months,
      basePrice: price,
      finalPrice,
      appliedDiscounts,
      type
    };
  });
}

function findPackage(packageId) {
  return FLEX_PACKAGES.find(p => p.id === packageId) || null;
}

/**
 * Reseller tiers.
 * Bronze / Silver / Gold — beda komisi & limit.
 */
const RESELLER_TIERS = {
  bronze: {
    id: 'bronze',
    label: 'Bronze',
    minSales: 0,
    commissionPct: 10,
    maxUserbots: 3,
    color: '🥉'
  },
  silver: {
    id: 'silver',
    label: 'Silver',
    minSales: 20,
    commissionPct: 15,
    maxUserbots: 10,
    color: '🥈'
  },
  gold: {
    id: 'gold',
    label: 'Gold',
    minSales: 50,
    commissionPct: 20,
    maxUserbots: 30,
    color: '🥇'
  }
};

function getResellerTier(salesCount) {
  if (salesCount >= RESELLER_TIERS.gold.minSales) return RESELLER_TIERS.gold;
  if (salesCount >= RESELLER_TIERS.silver.minSales) return RESELLER_TIERS.silver;
  return RESELLER_TIERS.bronze;
}

/**
 * Bundle: userbot paket + produk script dari toko.
 * Diskon bundle default 10%.
 */
function calcBundlePrice(packagePrice, productPrice, bundleDiscountPct = 10) {
  const total = (packagePrice || 0) + (productPrice || 0);
  const discount = Math.floor(total * bundleDiscountPct / 100);
  return {
    total,
    discount,
    finalPrice: Math.max(100, total - discount),
    bundleDiscountPct
  };
}

module.exports = {
  FLEX_PACKAGES,
  listPackages,
  findPackage,
  calcFlexPrice,
  RESELLER_TIERS,
  getResellerTier,
  calcBundlePrice
};
