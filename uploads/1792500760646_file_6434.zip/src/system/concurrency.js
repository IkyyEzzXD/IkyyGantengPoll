/**
 * concurrency.js
 * Kontrol konkurensi global + per-kunci untuk multi-akun.
 * Mencegah lonjakan Promise.all / broadcast serentak yang bikin FLOOD / OOM.
 */

class Semaphore {
  constructor(max) {
    this.max = Math.max(1, max | 0);
    this.active = 0;
    this.queue = [];
  }

  async acquire() {
    if (this.active < this.max) {
      this.active++;
      return;
    }
    await new Promise((resolve) => this.queue.push(resolve));
    this.active++;
  }

  release() {
    this.active = Math.max(0, this.active - 1);
    const next = this.queue.shift();
    if (next) next();
  }

  async run(fn) {
    await this.acquire();
    try {
      return await fn();
    } finally {
      this.release();
    }
  }

  get stats() {
    return { active: this.active, waiting: this.queue.length, max: this.max };
  }
}

/** Map of key -> Semaphore (lazy) */
const keySemaphores = new Map();

const KEY_SEMAPHORE_PRUNE_AT = 2000;

function pruneIdleKeySemaphores() {
  for (const [k, s] of keySemaphores) {
    if (s.active === 0 && s.queue.length === 0) keySemaphores.delete(k);
  }
}

function getKeySemaphore(key, max = 1) {
  const k = String(key);
  let s = keySemaphores.get(k);
  if (!s) {
    if (keySemaphores.size >= KEY_SEMAPHORE_PRUNE_AT) pruneIdleKeySemaphores();
    s = new Semaphore(max);
    keySemaphores.set(k, s);
  }
  return s;
}

/**
 * Jalankan fn dengan batasan: maksimal `limit` task berjalan bersamaan.
 * Item di-process secara streaming (bukan Promise.all semua sekaligus).
 */
async function mapPool(items, limit, worker) {
  const list = Array.isArray(items) ? items : [];
  if (list.length === 0) return [];
  const results = new Array(list.length);
  let idx = 0;
  const workers = [];
  const n = Math.min(limit, list.length);

  async function runOne() {
    while (true) {
      const i = idx++;
      if (i >= list.length) return;
      try {
        results[i] = await worker(list[i], i);
      } catch (err) {
        results[i] = { error: err };
      }
    }
  }

  for (let w = 0; w < n; w++) workers.push(runOne());
  await Promise.all(workers);
  return results;
}

/**
 * Simple mutex per key (max=1). Cocok untuk promoRoundLocks dll.
 */
const locks = new Map();

async function withLock(key, fn) {
  const k = String(key);
  while (locks.get(k)) {
    await locks.get(k);
  }
  let release;
  const p = new Promise((r) => { release = r; });
  locks.set(k, p);
  try {
    return await fn();
  } finally {
    locks.delete(k);
    release();
  }
}

function isLocked(key) {
  return locks.has(String(key));
}

function prune() {
  pruneIdleKeySemaphores();
  if (locks.size > 5000) {
    const keys = [...locks.keys()];
    for (let i = 0; i < keys.length - 2000; i++) locks.delete(keys[i]);
  }
}

module.exports = {
  Semaphore,
  getKeySemaphore,
  mapPool,
  withLock,
  isLocked,
  prune,
};
