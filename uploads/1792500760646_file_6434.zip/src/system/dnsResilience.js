/**
 * dnsResilience.js
 * ------------------------------------------------------------------
 * Penyebab error "getaddrinfo EAI_AGAIN ...mongodb.net / api.telegram.org":
 * DNS resolver VPS gagal sesaat (temporary failure). Node tidak mengulang
 * lookup sendiri, jadi MongoDB (MongoServerSelectionError), Telegram bot
 * dan GramJS langsung gagal walau jaringan sebenarnya hidup lagi sedetik kemudian.
 *
 * Modul ini membungkus dns.lookup (dipakai net.connect -> MongoDB, axios,
 * node-telegram-bot-api, GramJS) dengan urutan:
 *   1) lookup normal (hasil sukses disimpan sebagai "last known good")
 *   2) kalau EAI_AGAIN -> ulang beberapa kali dengan jeda singkat
 *   3) masih gagal -> resolve lewat DNS publik (default 1.1.1.1, 8.8.8.8)
 *   4) masih gagal -> pakai IP terakhir yang pernah berhasil (stale)
 *   5) tetap gagal -> lempar error asli
 * Lookup yang SUKSES tidak pernah diubah / ditimpa cache.
 *
 * Env opsional:
 *   DNS_RESILIENCE=0            matikan modul ini
 *   DNS_RETRY_ATTEMPTS=3        jumlah ulang lookup (default 3)
 *   DNS_RETRY_DELAY_MS=200      jeda dasar antar ulang (x percobaan)
 *   DNS_FALLBACK_SERVERS=1.1.1.1,8.8.8.8   ("" = tanpa fallback resolver)
 *   DNS_FALLBACK_TIMEOUT_MS=2000
 *   DNS_STALE_TTL_MS=21600000   umur maks IP lama yang boleh dipakai (6 jam)
 * ------------------------------------------------------------------
 */
const nodeDns = require('dns');
const net = require('net');

const RETRYABLE = new Set(['EAI_AGAIN']);
const CACHE_MAX = 500;

function install(dns = nodeDns, opts = {}) {
  if (!dns || typeof dns.lookup !== 'function') return false;
  if (dns.lookup.__resilient) return false;

  const env = opts.env || process.env;
  if (env.DNS_RESILIENCE === '0' || env.DNS_RESILIENCE === 'false') return false;

  const attempts = Math.max(0, Number(env.DNS_RETRY_ATTEMPTS === undefined ? 3 : env.DNS_RETRY_ATTEMPTS) || 0);
  const delayMs = Math.max(0, Number(env.DNS_RETRY_DELAY_MS === undefined ? 200 : env.DNS_RETRY_DELAY_MS) || 0);
  const fbTimeout = Math.max(500, Number(env.DNS_FALLBACK_TIMEOUT_MS) || 2000);
  const staleTtl = Math.max(0, Number(env.DNS_STALE_TTL_MS === undefined ? 6 * 3600 * 1000 : env.DNS_STALE_TTL_MS) || 0);
  const fbServers = (env.DNS_FALLBACK_SERVERS === undefined ? '1.1.1.1,8.8.8.8' : env.DNS_FALLBACK_SERVERS)
    .split(',').map((s) => s.trim()).filter(Boolean);
  const log = typeof opts.log === 'function' ? opts.log : () => {};

  const origLookup = dns.lookup;
  const cache = new Map(); // key -> { list, ts }
  let resolver = null;

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  function getResolver() {
    if (resolver || fbServers.length === 0) return resolver;
    try {
      const R = (dns.promises && dns.promises.Resolver) || nodeDns.promises.Resolver;
      resolver = new R({ timeout: fbTimeout, tries: 1 });
      resolver.setServers(fbServers);
    } catch (_) {
      resolver = null;
    }
    return resolver;
  }

  function rawLookup(hostname, o) {
    return new Promise((resolve, reject) => {
      origLookup.call(dns, hostname, Object.assign({}, o, { all: true }), (err, list) => {
        if (err) return reject(err);
        resolve(Array.isArray(list) ? list : []);
      });
    });
  }

  async function fallbackResolve(hostname, family) {
    const r = getResolver();
    if (!r) return [];
    const out = [];
    try {
      if (family !== 6) {
        const a = await r.resolve4(hostname);
        for (const address of a) out.push({ address, family: 4 });
      }
      if ((family === 6 || family === 0) && out.length === 0) {
        const a6 = await r.resolve6(hostname);
        for (const address of a6) out.push({ address, family: 6 });
      }
    } catch (_) {}
    return out;
  }

  function remember(key, list) {
    if (!list.length) return;
    if (cache.size >= CACHE_MAX && !cache.has(key)) cache.delete(cache.keys().next().value);
    cache.set(key, { list, ts: Date.now() });
  }

  async function resolveAll(hostname, o) {
    const family = Number(o.family) || 0;
    const key = `${hostname}|${family}`;
    let lastErr;

    for (let i = 0; i <= attempts; i++) {
      try {
        const list = await rawLookup(hostname, o);
        remember(key, list);
        return list;
      } catch (e) {
        lastErr = e;
        if (!e || !RETRYABLE.has(e.code)) throw e; // ENOTFOUND dll = permanen, jangan diulang
        if (i < attempts) await sleep(delayMs * (i + 1));
      }
    }

    const fresh = await fallbackResolve(hostname, family);
    if (fresh.length) {
      log(`DNS ${hostname}: lookup sistem gagal (${lastErr.code}), pakai resolver publik`);
      remember(key, fresh);
      return fresh;
    }

    const hit = cache.get(key);
    if (hit && Date.now() - hit.ts <= staleTtl) {
      log(`DNS ${hostname}: lookup gagal (${lastErr.code}), pakai IP terakhir yang berhasil`);
      return hit.list;
    }
    throw lastErr;
  }

  function wrapped(hostname, options, callback) {
    if (typeof options === 'function') { callback = options; options = {}; }
    else if (typeof options === 'number') options = { family: options };
    else if (!options || typeof options !== 'object') options = {};

    // IP literal / bukan string / localhost / callback tidak valid -> serahkan ke Node apa adanya
    if (typeof callback !== 'function' || typeof hostname !== 'string' || !hostname ||
        net.isIP(hostname) || hostname === 'localhost') {
      return origLookup.call(dns, hostname, options, callback);
    }

    resolveAll(hostname, options).then(
      (list) => {
        if (options.all) return callback(null, list);
        if (!list.length) {
          const e = new Error(`getaddrinfo ENOTFOUND ${hostname}`);
          e.code = 'ENOTFOUND'; e.hostname = hostname; e.syscall = 'getaddrinfo';
          return callback(e);
        }
        callback(null, list[0].address, list[0].family);
      },
      (err) => callback(err)
    );
  }

  // pertahankan properti bawaan (mis. util.promisify.custom)
  for (const k of Reflect.ownKeys(origLookup)) {
    if (k === 'length' || k === 'name' || k === 'prototype') continue;
    try { Object.defineProperty(wrapped, k, Object.getOwnPropertyDescriptor(origLookup, k)); } catch (_) {}
  }
  wrapped.__resilient = true;
  wrapped.__original = origLookup;
  wrapped.__cache = cache;
  dns.lookup = wrapped;
  return true;
}

module.exports = { install };
