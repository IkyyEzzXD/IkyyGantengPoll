const axios = require('axios');
const https = require('https');

const BASE_URL = 'https://app.pakasir.com';
const REQUEST_TIMEOUT_MS = 12000;
const MAX_ATTEMPTS = 4;
const TOTAL_DEADLINE_MS = 45000;
const BASE_DELAY_MS = 1000;
const MAX_DELAY_MS = 10000;

const NETWORK_ERROR_CODES = new Set([
  'ETIMEDOUT',
  'ESOCKETTIMEDOUT',
  'ECONNABORTED',
  'ENETUNREACH',
  'ECONNRESET',
  'ECONNREFUSED',
  'ENOTFOUND',
  'EAI_AGAIN',
  'EPIPE',
  'EHOSTUNREACH',
  'ERR_SOCKET_CONNECTION_TIMEOUT',
]);

const RETRYABLE_STATUS = new Set([
  408, 425, 429, 500, 502, 503, 504, 520, 521, 522, 523, 524, 525, 526, 527, 530,
]);

const VALID_METHODS = [
  'payment_link',
  'qris',
  'bri_va',
  'bni_va',
  'cimb_niaga_va',
  'permata_va',
  'maybank_va',
  'bnc_va',
  'artha_graha_va',
  'sampoerna_va',
  'atm_bersama_va',
];

const orderIdToTxnId = new Map();
// Pakasir membatasi cek status 1x per 4 detik per transaksi. Tombol "Cek Status" yang
// ditekan bersamaan dengan polling otomatis sebelumnya kena 429 -> hasil cek hilang.
// Hasil 'pending' yang masih segar dipakai ulang; hasil 'completed' tidak pernah di-cache.
const STATUS_MIN_GAP_MS = 3500;
const statusCache = new Map();
const STATUS_CACHE_MAX = 2000;
const inflightCreate = new Map();
const ORDER_MAP_MAX = 5000;

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function errorCode(err) {
  return err && (err.code || (err.cause && err.cause.code));
}

function errorStatus(err) {
  return err && err.response ? err.response.status : null;
}

function isTimeoutError(err) {
  const code = errorCode(err);
  if (code === 'ECONNABORTED' || code === 'ETIMEDOUT' || code === 'ESOCKETTIMEDOUT') return true;
  return /timeout/i.test(String((err && err.message) || ''));
}

function isRetryable(err) {
  const status = errorStatus(err);
  if (status) return RETRYABLE_STATUS.has(status);
  const code = errorCode(err);
  if (code && NETWORK_ERROR_CODES.has(code)) return true;
  if (isTimeoutError(err)) return true;
  const msg = String((err && err.message) || '');
  for (const c of NETWORK_ERROR_CODES) {
    if (msg.includes(c)) return true;
  }
  return /socket hang up|network error|aborted/i.test(msg);
}

function retryAfterMs(err) {
  const headers = err && err.response && err.response.headers;
  const raw = headers && (headers['retry-after'] || headers['Retry-After']);
  if (!raw) return null;
  const seconds = Number(raw);
  if (!Number.isNaN(seconds) && seconds >= 0) return Math.min(seconds * 1000, MAX_DELAY_MS);
  return null;
}

function backoffMs(attempt) {
  const exp = Math.min(BASE_DELAY_MS * 2 ** (attempt - 1), MAX_DELAY_MS);
  return exp + Math.floor(Math.random() * 400);
}

async function withRetry(fn) {
  const startedAt = Date.now();
  let lastErr;

  for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
    try {
      return await fn(attempt);
    } catch (err) {
      lastErr = err;
      if (!isRetryable(err) || attempt === MAX_ATTEMPTS) break;
      const delay = retryAfterMs(err) || backoffMs(attempt);
      if (Date.now() - startedAt + delay + REQUEST_TIMEOUT_MS > TOTAL_DEADLINE_MS) break;
      await sleep(delay);
    }
  }

  throw lastErr;
}

function apiMessageOf(err) {
  const data = err && err.response && err.response.data;
  if (!data) return null;
  if (typeof data === 'string') {
    return /<html|<!doctype/i.test(data) ? null : data.slice(0, 200);
  }
  return data.message || data.error || null;
}

function normalizeError(err) {
  if (!err || !(err.isAxiosError || err.response || errorCode(err))) return err;

  const status = errorStatus(err);
  let normalized;

  if (status && !RETRYABLE_STATUS.has(status)) {
    normalized = new Error(apiMessageOf(err) || `Pakasir menolak permintaan (HTTP ${status})`);
  } else if (isRetryable(err)) {
    const detail = status ? `HTTP ${status}` : (isTimeoutError(err) ? 'timeout' : (errorCode(err) || 'jaringan'));
    normalized = new Error(`Server pembayaran sedang tidak dapat dihubungi (${detail}). Silakan coba lagi beberapa saat.`);
  } else {
    normalized = new Error(apiMessageOf(err) || err.message);
  }

  normalized.status = status || null;
  normalized.code = errorCode(err) || null;
  normalized.transient = isRetryable(err);
  normalized.cause = err;
  return normalized;
}

function rememberTxnId(orderId, txnId, expiredAt) {
  if (!orderId || !txnId) return;
  orderIdToTxnId.delete(orderId);
  orderIdToTxnId.set(orderId, { txnId, expiredAt: expiredAt || null });
  if (orderIdToTxnId.size > ORDER_MAP_MAX) {
    const first = orderIdToTxnId.keys().next().value;
    orderIdToTxnId.delete(first);
  }
}

function buildClient(slug, apiKey) {
  if (!slug || !apiKey) {
    throw new Error('PAKASIR_SLUG dan PAKASIR_APIKEY wajib diisi di config sebelum pakai fitur deposit otomatis.');
  }

  // Dua jalur koneksi: IPv4 saja (default) dan otomatis (IPv4/IPv6). Percobaan ganjil
  // lewat IPv4, genap lewat jalur otomatis. Kalau salah satu jalur dari VPS ke Pakasir
  // lambat/tersendat (penyebab umum "timeout" berulang), percobaan berikutnya otomatis
  // memakai jalur yang lain, bukan mengulang jalur yang sama sampai habis.
  const makeHttp = (family) => axios.create({
    baseURL: BASE_URL,
    timeout: REQUEST_TIMEOUT_MS,
    httpsAgent: new https.Agent({ keepAlive: true, family, maxSockets: 20, keepAliveMsecs: 15000 }),
    headers: {
      'Content-Type': 'application/json',
      Accept: 'application/json',
      'X-Api-Key': apiKey,
    },
  });
  const httpV4 = makeHttp(4);
  const httpAuto = makeHttp(0);
  const httpFor = (attempt) => (attempt % 2 === 1 ? httpV4 : httpAuto);

  async function doCreate(paymentMethod, orderId, numericAmount) {
    const path = `/api/v2/create-transaction/${encodeURIComponent(slug)}/${encodeURIComponent(orderId)}`;
    const res = await withRetry((attempt) => httpFor(attempt).post(path, { method: paymentMethod, amount: numericAmount }));

    const payment = res.data;
    if (!payment || !payment.txn_id) return null;

    rememberTxnId(orderId, payment.txn_id, payment.expired_at);

    const isPaymentLink = paymentMethod === 'payment_link';

    return {
      order_id: orderId,
      txn_id: payment.txn_id,
      amount: payment.amount != null ? payment.amount : numericAmount,
      fee: payment.fee,
      total_payment: payment.total_payment != null ? payment.total_payment : numericAmount,
      payment_method: payment.payment_method || paymentMethod,
      payment_number: payment.qr_string || payment.va_number || '',
      payment_url: isPaymentLink ? payment.payment_link : (payment.payment_link || ''),
      expired_at: payment.expired_at,
      is_sandbox: !!payment.is_sandbox,
    };
  }

  async function createPayment(method, orderId, amount) {
    const paymentMethod = (method || 'qris').toLowerCase();
    if (!VALID_METHODS.includes(paymentMethod)) {
      throw new Error(`Metode pembayaran "${paymentMethod}" tidak valid. Pilihan: ${VALID_METHODS.join(', ')}`);
    }
    if (!orderId) throw new Error('orderId wajib diisi');
    const numericAmount = Math.round(Number(amount));
    if (!numericAmount || numericAmount <= 0) {
      throw new Error('amount harus berupa angka positif');
    }

    const key = `${orderId}:${paymentMethod}:${numericAmount}`;
    if (inflightCreate.has(key)) return inflightCreate.get(key);

    const promise = doCreate(paymentMethod, orderId, numericAmount)
      .catch((err) => {
        throw normalizeError(err);
      })
      .finally(() => {
        inflightCreate.delete(key);
      });

    inflightCreate.set(key, promise);
    return promise;
  }

  async function detailPayment(orderId, amount) {
    if (!orderId) throw new Error('orderId wajib diisi');

    let entry = orderIdToTxnId.get(orderId);
    if (!entry) {
      if (!amount || Number(amount) <= 0) return null;
      try {
        const recreated = await createPayment('qris', orderId, amount);
        if (recreated && recreated.txn_id) entry = orderIdToTxnId.get(orderId);
      } catch (_) {
        entry = null;
      }
      if (!entry) return null;
    }

    const cached = statusCache.get(entry.txnId);
    if (cached && Date.now() - cached.at < STATUS_MIN_GAP_MS) {
      return Object.assign({}, cached.value, { order_id: cached.value.order_id || orderId });
    }

    const path = `/api/v2/transaction-status/${encodeURIComponent(slug)}/${encodeURIComponent(entry.txnId)}`;
    let res;
    try {
      res = await withRetry((attempt) => httpFor(attempt).get(path));
    } catch (err) {
      throw normalizeError(err);
    }

    const tx = res.data;
    if (!tx || !tx.txn_id) return null;

    const value = {
      order_id: tx.order_id || orderId,
      txn_id: tx.txn_id,
      amount: tx.amount,
      total_payment: tx.amount,
      project: slug,
      status: String(tx.status == null ? '' : tx.status).trim().toLowerCase(),
      payment_method: tx.payment_method,
      completed_at: tx.completed_at,
      expired_at: tx.expired_at || entry.expiredAt || null,
    };

    if (value.status === 'pending') {
      statusCache.delete(entry.txnId);
      statusCache.set(entry.txnId, { at: Date.now(), value });
      if (statusCache.size > STATUS_CACHE_MAX) statusCache.delete(statusCache.keys().next().value);
    } else {
      statusCache.delete(entry.txnId);
    }
    return value;
  }

  function knowsOrder(orderId) {
    return orderIdToTxnId.has(orderId);
  }

  async function cancelPayment(orderId, amount) {
    if (!orderId) throw new Error('orderId wajib diisi');

    const entry = orderIdToTxnId.get(orderId);
    if (!entry) return null;

    let res;
    try {
      const path = `/api/v2/cancel-transaction/${encodeURIComponent(slug)}/${encodeURIComponent(entry.txnId)}`;
      res = await withRetry((attempt) => httpFor(attempt).post(path));
    } catch (err) {
      throw normalizeError(err);
    }

    if (res && res.status >= 200 && res.status < 300) {
      return { order_id: orderId, status: 'canceled', success: true };
    }

    return null;
  }

  function adoptOrder(orderId, txnId, expiredAt) {
    if (!orderId || !txnId) return false;
    let iso = null;
    if (expiredAt) {
      const d = new Date(Number(expiredAt) || expiredAt);
      iso = Number.isNaN(d.getTime()) ? null : d.toISOString();
    }
    rememberTxnId(orderId, txnId, iso);
    return true;
  }

  return { createPayment, detailPayment, cancelPayment, adoptOrder, knowsOrder, VALID_METHODS };
}

module.exports = buildClient;
