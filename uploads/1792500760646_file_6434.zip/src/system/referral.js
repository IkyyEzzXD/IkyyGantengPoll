const { createKvDoc } = require('./kvDoc');

const REFERRAL_DOC_ID = 'referral';

const REFERRAL_REWARD = 200;
const REFERRAL_REWARD_L2 = 50;
const REFERRAL_DAILY_CAP = 15;
const REFERRAL_MIN_DEPOSIT = Number(process.env.REFERRAL_MIN_DEPOSIT) > 0
  ? Number(process.env.REFERRAL_MIN_DEPOSIT)
  : 2000;

const CONTEST_REWARDS = [10000, 5000, 2500];

const HOUR_MS = 60 * 60 * 1000;
const DAY_MS = 24 * HOUR_MS;
const PENDING_TTL_MS = 30 * DAY_MS;
const HISTORY_MAX = 2000;
const HISTORY_KEEP = 1000;

const tzHours = process.env.CONTEST_TZ_OFFSET_HOURS !== undefined && process.env.CONTEST_TZ_OFFSET_HOURS !== '' && Number.isFinite(Number(process.env.CONTEST_TZ_OFFSET_HOURS))
  ? Number(process.env.CONTEST_TZ_OFFSET_HOURS)
  : 7;
const CONTEST_TZ_OFFSET_MS = tzHours * HOUR_MS;

function rewardMode() {
  return String(process.env.REFERRAL_REWARD_MODE || 'deposit').trim().toLowerCase() === 'start'
    ? 'start'
    : 'deposit';
}

function monthKeyOf(ts) {
  const n = Number(ts);
  if (!Number.isFinite(n) || n <= 0) return null;
  const d = new Date(n + CONTEST_TZ_OFFSET_MS);
  if (Number.isNaN(d.getTime())) return null;
  return d.toISOString().slice(0, 7);
}

function currentMonthKey() {
  return monthKeyOf(Date.now());
}

function createData() {
  return {
    referredBy: {},
    pendingCode: {},
    pendingAt: {},
    everStarted: {},
    stats: {},
    history: [],
    customCodes: {},
    userCustomCode: {},
    contest: {},
    failedPayouts: {}
  };
}

function isPlainObject(v) {
  return !!v && typeof v === 'object' && !Array.isArray(v);
}

function normalize(payload) {
  const out = Object.assign(createData(), isPlainObject(payload) ? payload : {});
  const template = createData();
  for (const key of Object.keys(template)) {
    if (Array.isArray(template[key])) {
      if (!Array.isArray(out[key])) out[key] = [];
    } else if (!isPlainObject(out[key])) {
      out[key] = {};
    }
  }
  for (const entry of Object.values(out.referredBy)) {
    if (entry && entry.status === 'closed' && entry.closedReason === 'daily_cap') {
      entry.status = 'pending';
      delete entry.closedReason;
    }
  }
  return out;
}

function addStats(target, source) {
  target.count = (target.count || 0) + (source.count || 0);
  target.totalReward = (target.totalReward || 0) + (source.totalReward || 0);
  target.countL2 = (target.countL2 || 0) + (source.countL2 || 0);
  target.totalRewardL2 = (target.totalRewardL2 || 0) + (source.totalRewardL2 || 0);
}

function mergeOverlay(base, mem) {
  const maps = ['referredBy', 'everStarted', 'customCodes', 'userCustomCode', 'pendingCode', 'pendingAt', 'failedPayouts'];
  for (const key of maps) {
    for (const [k, v] of Object.entries(mem[key] || {})) {
      if (base[key][k] === undefined) base[key][k] = v;
    }
  }
  for (const uid of Object.keys(base.pendingCode)) {
    if (base.referredBy[uid]) {
      delete base.pendingCode[uid];
      delete base.pendingAt[uid];
    }
  }
  for (const [uid, s] of Object.entries(mem.stats || {})) {
    if (!base.stats[uid]) base.stats[uid] = { count: 0, totalReward: 0, countL2: 0, totalRewardL2: 0 };
    addStats(base.stats[uid], s || {});
  }
  const seen = new Set(base.history.map((h) => h && `${h.user}|${h.at}`));
  for (const h of mem.history || []) {
    if (h && !seen.has(`${h.user}|${h.at}`)) base.history.push(h);
  }
  base.history.sort((a, b) => (Number(a && a.at) || 0) - (Number(b && b.at) || 0));
  for (const [mk, c] of Object.entries(mem.contest || {})) {
    if (!base.contest[mk]) base.contest[mk] = { scores: {}, rewardsPaid: false };
    const t = base.contest[mk];
    if (c && c.rewardsPaid) t.rewardsPaid = true;
    if (c && c.paidUsers) t.paidUsers = Object.assign({}, c.paidUsers, t.paidUsers || {});
  }
  return base;
}

let lastPrune = 0;

function pruneStale() {
  const now = Date.now();
  if (now - lastPrune < HOUR_MS) return;
  lastPrune = now;
  const data = store.data;
  for (const uid of Object.keys(data.pendingCode)) {
    const at = Number(data.pendingAt[uid]) || 0;
    if (at && now - at > PENDING_TTL_MS) {
      delete data.pendingCode[uid];
      delete data.pendingAt[uid];
    }
  }
  for (const uid of Object.keys(data.pendingAt)) {
    if (!data.pendingCode[uid]) delete data.pendingAt[uid];
  }
}

const store = createKvDoc({
  id: REFERRAL_DOC_ID,
  label: 'referral',
  create: createData,
  normalize,
  merge: mergeOverlay,
  afterLoad: () => ensureContestMonth(currentMonthKey())
});

const data = store.data;

function load() {
  store.load();
}

function save() {
  pruneStale();
  store.markDirty();
}

function ensureContestMonth(mk) {
  if (!mk) return;
  if (!data.contest[mk]) {
    data.contest[mk] = { scores: {}, rewardsPaid: false };
    store.markDirty();
  }
}

let rankCache = null;

function buildIndex() {
  const rev = store.revision();
  if (rankCache && rankCache.rev === rev) return rankCache;
  const months = {};
  const totals = {};
  for (const entry of Object.values(data.referredBy)) {
    if (!entry || !entry.by) continue;
    const by = String(entry.by);
    const mk = monthKeyOf(entry.at);
    if (mk) {
      if (!months[mk]) months[mk] = {};
      months[mk][by] = (months[mk][by] || 0) + 1;
    }
    if (!totals[by]) totals[by] = { total: 0, pending: 0 };
    totals[by].total += 1;
    if (!entry.rewarded && entry.status !== 'closed') totals[by].pending += 1;
  }
  rankCache = { rev, months, totals };
  return rankCache;
}

function contestScores(mk) {
  const derived = buildIndex().months[mk] || {};
  const legacy = (data.contest[mk] && data.contest[mk].scores) || {};
  const out = {};
  for (const [uid, n] of Object.entries(legacy)) out[uid] = Number(n) || 0;
  for (const [uid, n] of Object.entries(derived)) out[uid] = Math.max(out[uid] || 0, n);
  return out;
}

function rankScores(scores, limit) {
  const list = Object.entries(scores || {})
    .map(([uid, score]) => ({ userId: uid, score: Number(score) || 0 }))
    .filter((e) => e.score > 0)
    .sort((a, b) => (b.score - a.score) || (a.userId < b.userId ? -1 : a.userId > b.userId ? 1 : 0));
  return Number.isFinite(limit) ? list.slice(0, limit) : list;
}

function markStarted(userId) {
  load();
  userId = String(userId);
  if (!data.everStarted[userId]) {
    data.everStarted[userId] = Date.now();
    save();
  }
}

function hasStartedBefore(userId) {
  load();
  return !!data.everStarted[String(userId)];
}

function setPendingCode(userId, referrerId) {
  load();
  userId = String(userId);
  referrerId = String(referrerId || '').trim();
  if (!referrerId || referrerId === userId) return false;
  if (data.pendingCode[userId]) return false;
  if (data.referredBy[userId]) return false;
  if (data.everStarted[userId]) return false;
  data.pendingCode[userId] = referrerId;
  data.pendingAt[userId] = Date.now();
  save();
  return true;
}

function getPendingCode(userId) {
  load();
  return data.pendingCode[String(userId)] || null;
}

function clearPendingCode(userId) {
  load();
  userId = String(userId);
  if (data.pendingCode[userId] || data.pendingAt[userId]) {
    delete data.pendingCode[userId];
    delete data.pendingAt[userId];
    save();
  }
}

function getReferrerOf(userId) {
  load();
  const entry = data.referredBy[String(userId)];
  return entry ? entry.by : null;
}

function isAlreadyRewarded(userId) {
  load();
  const entry = data.referredBy[String(userId)];
  return !!(entry && entry.rewarded);
}

function recentPaidCount(referrerId) {
  const dayAgo = Date.now() - DAY_MS;
  let n = 0;
  for (let i = data.history.length - 1; i >= 0; i--) {
    const h = data.history[i];
    if (!h) continue;
    if (Number(h.at) < dayAgo) break;
    if (String(h.referrer) === referrerId) n++;
  }
  return n;
}

function payout(newUserId, referrerId, entry) {
  if (recentPaidCount(referrerId) >= REFERRAL_DAILY_CAP) {
    return { ok: false, reason: 'daily_cap' };
  }

  entry.rewarded = true;
  entry.status = 'rewarded';
  entry.rewardedAt = Date.now();

  if (!data.stats[referrerId]) {
    data.stats[referrerId] = { count: 0, totalReward: 0, countL2: 0, totalRewardL2: 0 };
  }
  data.stats[referrerId].count += 1;
  data.stats[referrerId].totalReward += REFERRAL_REWARD;

  let l2Referrer = null;
  let l2Reward = 0;
  const parent = data.referredBy[referrerId];
  if (parent && parent.by && String(parent.by) !== newUserId && String(parent.by) !== referrerId) {
    l2Referrer = String(parent.by);
    l2Reward = REFERRAL_REWARD_L2;
    if (!data.stats[l2Referrer]) {
      data.stats[l2Referrer] = { count: 0, totalReward: 0, countL2: 0, totalRewardL2: 0 };
    }
    data.stats[l2Referrer].countL2 = (data.stats[l2Referrer].countL2 || 0) + 1;
    data.stats[l2Referrer].totalRewardL2 = (data.stats[l2Referrer].totalRewardL2 || 0) + l2Reward;
  }

  data.history.push({
    referrer: referrerId,
    user: newUserId,
    reward: REFERRAL_REWARD,
    l2Referrer: l2Referrer || null,
    l2Reward: l2Reward || 0,
    at: Date.now()
  });
  if (data.history.length > HISTORY_MAX) {
    data.history = data.history.slice(-HISTORY_KEEP);
  }

  delete data.pendingCode[newUserId];
  delete data.pendingAt[newUserId];

  save();
  return {
    ok: true,
    reward: REFERRAL_REWARD,
    l2Referrer,
    l2Reward,
    viaDeposit: true
  };
}

function registerReferral(newUserId, referrerId) {
  load();
  newUserId = String(newUserId);
  referrerId = String(referrerId || '').trim();

  if (!referrerId) {
    return { ok: false, reason: 'no_referrer' };
  }

  if (referrerId === newUserId) {
    clearPendingCode(newUserId);
    return { ok: false, reason: 'self_referral' };
  }

  if (hasStartedBefore(newUserId)) {
    clearPendingCode(newUserId);
    return { ok: false, reason: 'already_started_before' };
  }

  if (data.referredBy[newUserId]) {
    clearPendingCode(newUserId);
    return { ok: false, reason: 'already_referred' };
  }

  const now = Date.now();
  const entry = {
    by: referrerId,
    at: now,
    rewarded: false,
    status: 'pending'
  };
  data.referredBy[newUserId] = entry;
  delete data.pendingCode[newUserId];
  delete data.pendingAt[newUserId];
  ensureContestMonth(monthKeyOf(now));
  save();

  if (rewardMode() === 'start') {
    const paid = payout(newUserId, referrerId, entry);
    if (paid.ok) {
      paid.viaDeposit = false;
      paid.counted = true;
      return paid;
    }
  }

  return { ok: true, pending: true, counted: true, reward: 0, l2Referrer: null, l2Reward: 0 };
}

function settleReferral(userId, depositAmount) {
  load();
  userId = String(userId);
  const entry = data.referredBy[userId];
  if (!entry || entry.rewarded || entry.status === 'closed') {
    return { ok: false, reason: 'nothing_pending' };
  }
  if (!(Number(depositAmount) >= REFERRAL_MIN_DEPOSIT)) {
    return { ok: false, reason: 'below_min_deposit' };
  }
  return payout(userId, String(entry.by), entry);
}

function recordPayoutFailure(userId, job) {
  load();
  data.failedPayouts[String(userId)] = Object.assign({}, job, { at: Date.now() });
  save();
}

function clearPayoutFailure(userId) {
  load();
  userId = String(userId);
  if (data.failedPayouts[userId]) {
    delete data.failedPayouts[userId];
    save();
  }
}

function getFailedPayouts() {
  load();
  return Object.entries(data.failedPayouts).map(([user, job]) => Object.assign({ user }, job));
}

function getPendingCount(referrerId) {
  load();
  const t = buildIndex().totals[String(referrerId)];
  return t ? t.pending : 0;
}

function getInviteCount(referrerId) {
  load();
  const t = buildIndex().totals[String(referrerId)];
  return t ? { total: t.total, pending: t.pending } : { total: 0, pending: 0 };
}

function getStats(userId) {
  load();
  const s = data.stats[String(userId)];
  return s
    ? {
        count: s.count || 0,
        totalReward: s.totalReward || 0,
        countL2: s.countL2 || 0,
        totalRewardL2: s.totalRewardL2 || 0
      }
    : { count: 0, totalReward: 0, countL2: 0, totalRewardL2: 0 };
}

function getHistoryOf(userId, limit = 10) {
  load();
  userId = String(userId);
  return data.history
    .filter((h) => h && (String(h.referrer) === userId || String(h.l2Referrer) === userId))
    .slice(-limit)
    .reverse();
}

function getTotalStats() {
  load();
  const totalUsers = Object.keys(data.referredBy).length;
  const totalReward = Object.values(data.stats).reduce(
    (sum, s) => sum + ((s && s.totalReward) || 0) + ((s && s.totalRewardL2) || 0),
    0
  );
  return { totalReferred: totalUsers, totalReward };
}

function setCustomCode(userId, code) {
  load();
  userId = String(userId);
  code = String(code || '').trim().toLowerCase().replace(/[^a-z0-9_]/g, '');
  if (code.length < 3 || code.length > 16) {
    return { ok: false, reason: 'Kode harus 3–16 karakter (huruf/angka/_)' };
  }
  if (/^\d+$/.test(code)) {
    return { ok: false, reason: 'Kode tidak boleh murni angka (biar tidak bentrok dengan user ID)' };
  }
  if (data.customCodes[code] && data.customCodes[code] !== userId) {
    return { ok: false, reason: 'Kode sudah dipakai orang lain' };
  }
  const old = data.userCustomCode[userId];
  if (old && data.customCodes[old] === userId) {
    delete data.customCodes[old];
  }
  data.customCodes[code] = userId;
  data.userCustomCode[userId] = code;
  save();
  return { ok: true, code };
}

function getCustomCode(userId) {
  load();
  return data.userCustomCode[String(userId)] || null;
}

function resolveReferrerFromPayload(payload) {
  load();
  const raw = String(payload || '').replace(/^ref_/i, '').trim();
  if (!raw) return null;
  const custom = data.customCodes[raw.toLowerCase()];
  if (custom) return String(custom);
  if (/^\d+$/.test(raw)) return raw;
  return null;
}

function getContestLeaderboard(limit = 10) {
  load();
  const monthKey = currentMonthKey();
  const entries = rankScores(contestScores(monthKey), limit);
  const c = data.contest[monthKey];
  return {
    monthKey,
    entries,
    rewardsPaid: !!(c && c.rewardsPaid),
    rewards: CONTEST_REWARDS
  };
}

function getContestStanding(userId) {
  load();
  const uid = String(userId);
  const ranked = rankScores(contestScores(currentMonthKey()));
  const idx = ranked.findIndex((e) => e.userId === uid);
  if (idx < 0) return { rank: null, score: 0, total: ranked.length };
  return { rank: idx + 1, score: ranked[idx].score, total: ranked.length };
}

function getUnpaidContestMonths() {
  load();
  const currentKey = currentMonthKey();
  const out = [];
  for (const mk of Object.keys(data.contest).sort()) {
    if (mk >= currentKey) continue;
    const c = data.contest[mk];
    if (!c || c.rewardsPaid) continue;
    const winners = rankScores(contestScores(mk), CONTEST_REWARDS.length).map((e, i) => ({
      userId: e.userId,
      score: e.score,
      rank: i + 1,
      amount: CONTEST_REWARDS[i],
      paid: !!(c.paidUsers && c.paidUsers[e.userId])
    }));
    out.push({ monthKey: mk, winners });
  }
  return out;
}

function recordContestPayout(monthKey, userId, amount) {
  load();
  const c = data.contest[monthKey];
  if (!c) return false;
  if (!c.paidUsers) c.paidUsers = {};
  c.paidUsers[String(userId)] = amount;
  store.markDirty();
  return true;
}

function markContestRewardsPaid(monthKey) {
  load();
  if (data.contest[monthKey]) {
    data.contest[monthKey].rewardsPaid = true;
    store.markDirty();
  }
}

async function reloadFromMongo() {
  await store.reload();
}

async function flush() {
  await store.flush();
}

load();

module.exports = {
  reloadFromMongo,
  flush,

  REFERRAL_REWARD,
  REFERRAL_REWARD_L2,
  REFERRAL_DAILY_CAP,
  REFERRAL_MIN_DEPOSIT,
  CONTEST_REWARDS,
  monthKeyOf,
  currentMonthKey,
  markStarted,
  hasStartedBefore,
  setPendingCode,
  getPendingCode,
  clearPendingCode,
  getReferrerOf,
  isAlreadyRewarded,
  registerReferral,
  settleReferral,
  recordPayoutFailure,
  clearPayoutFailure,
  getFailedPayouts,
  getPendingCount,
  getInviteCount,
  rewardMode,
  getStats,
  getHistoryOf,
  getTotalStats,
  setCustomCode,
  getCustomCode,
  resolveReferrerFromPayload,
  getContestLeaderboard,
  getContestStanding,
  getUnpaidContestMonths,
  recordContestPayout,
  markContestRewardsPaid
};
