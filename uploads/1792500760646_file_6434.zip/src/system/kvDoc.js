const mongoAdapter = require('../storage/mongoAdapter');

const COLLECTION = 'kv_store';
const SAVE_DEBOUNCE_MS = 150;
const MAX_BACKOFF_MS = 30000;

function createKvDoc(options) {
  const { id, label, create, normalize, merge, afterLoad } = options;
  const data = create();

  let dbLoaded = false;
  let loading = null;
  let nextLoadAt = 0;
  let loadFails = 0;
  let touchedBeforeLoad = false;

  let dirty = false;
  let saving = null;
  let saveTimer = null;
  let saveFails = 0;
  let revision = 0;

  function adopt(next) {
    for (const key of Object.keys(data)) delete data[key];
    Object.assign(data, next);
  }

  function requestLoad(force) {
    if (loading) return loading;
    if (dbLoaded && !force) return null;
    if (!force && Date.now() < nextLoadAt) return null;
    loading = (async () => {
      await null;
      try {
        const db = mongoAdapter.getDatabase();
        if (!db) {
          nextLoadAt = Date.now() + 1000;
          return;
        }
        const doc = await db.collection(COLLECTION).findOne({ _id: id });
        const fromDb = normalize(doc && doc.payload);
        if (dbLoaded) {
          adopt(fromDb);
        } else if (touchedBeforeLoad) {
          adopt(merge(fromDb, data));
          dirty = true;
        } else {
          adopt(fromDb);
        }
        dbLoaded = true;
        touchedBeforeLoad = false;
        loadFails = 0;
        revision++;
        if (typeof afterLoad === 'function') afterLoad(data);
        if (dirty) scheduleSave(0);
      } catch (e) {
        loadFails++;
        nextLoadAt = Date.now() + Math.min(MAX_BACKOFF_MS, 1000 * 2 ** Math.min(loadFails, 5));
        console.error(`[${label}] load gagal:`, e && e.message ? e.message : e);
      } finally {
        loading = null;
      }
    })();
    return loading;
  }

  function load() {
    if (dbLoaded) return;
    const p = requestLoad(false);
    if (p) p.catch(() => {});
  }

  function persist() {
    if (saving) return saving;
    if (!dbLoaded || !dirty) return Promise.resolve();
    saving = (async () => {
      await null;
      dirty = false;
      try {
        const db = mongoAdapter.getDatabase();
        if (!db) throw new Error('database belum siap');
        await db.collection(COLLECTION).updateOne(
          { _id: id },
          { $set: { payload: data, updatedAt: Date.now() } },
          { upsert: true }
        );
        saveFails = 0;
      } catch (e) {
        dirty = true;
        saveFails++;
        console.error(`[${label}] save gagal:`, e && e.message ? e.message : e);
      } finally {
        saving = null;
      }
    })();
    return saving;
  }

  async function runSave() {
    saveTimer = null;
    try {
      if (!dbLoaded) {
        const p = requestLoad(false);
        if (p) await p;
      }
      if (dbLoaded) await persist();
    } catch (_) {}
    if (dirty && !saveTimer) {
      let wait;
      if (!dbLoaded) wait = Math.max(1000, nextLoadAt - Date.now());
      else if (saveFails > 0) wait = Math.min(MAX_BACKOFF_MS, 2000 * 2 ** Math.min(saveFails, 4));
      else wait = SAVE_DEBOUNCE_MS;
      scheduleSave(wait);
    }
  }

  function scheduleSave(delay) {
    if (saveTimer) return;
    saveTimer = setTimeout(runSave, delay);
    if (typeof saveTimer.unref === 'function') saveTimer.unref();
  }

  function markDirty() {
    dirty = true;
    revision++;
    if (!dbLoaded) touchedBeforeLoad = true;
    scheduleSave(SAVE_DEBOUNCE_MS);
  }

  async function flush() {
    if (saveTimer) {
      clearTimeout(saveTimer);
      saveTimer = null;
    }
    if (!dbLoaded) {
      const p = requestLoad(dirty);
      if (p) await p;
    }
    for (let i = 0; i < 3 && dirty && dbLoaded; i++) await persist();
  }

  async function reload() {
    if (loading) await loading.catch(() => {});
    if (dbLoaded) await flush();
    const p = requestLoad(true);
    if (p) await p;
  }

  return {
    data,
    load,
    markDirty,
    flush,
    reload,
    isLoaded: () => dbLoaded,
    revision: () => revision
  };
}

module.exports = { createKvDoc };
