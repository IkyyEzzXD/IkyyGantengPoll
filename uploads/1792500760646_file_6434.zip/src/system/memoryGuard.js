/**
 * memoryGuard.js
 * ------------------------------------------------------------------
 * Penjaga memori BERTAHAP — tanpa pernah me-restart / mematikan proses.
 *
 * Cara kerja (dipanggil tiap siklus compactMemoryIfHigh -> tick()):
 *   normal   (< 60% heap)  : tidak ada tindakan.
 *   elevated (>= 60%)      : buang cache kadaluarsa + cache DB.
 *   high     (>= 75%)      : + lepas semua koneksi userbot yang idle
 *                            (client GramJS didaur ulang) + GC.
 *   critical (>= 88%)      : + flag "pressure" menyala -> connect userbot
 *                            baru yang tidak urgent ditahan sebentar
 *                            (maks 20 dtk, tidak pernah di-reject) sampai
 *                            heap turun. Auto-share yang sedang jalan
 *                            TIDAK disentuh.
 *   Memori native (RSS) ikut dipantau: buffer GramJS/Mongo tidak muncul di
 *   heap JS, jadi RSS >= 85% RAM dihitung "critical" juga.
 *
 * Deteksi leak: tiap LEAK_SAMPLE_MS dicatat heap "retained" (setelah GC).
 * Kalau naik terus beberapa sampel berturut-turut, dicatat WARN beserta
 * ukuran struktur utama (describe()) supaya sumber leak mudah dilacak.
 * ------------------------------------------------------------------
 */

const v8 = require('v8');
const os = require('os');

const LEVELS = ['normal', 'elevated', 'high', 'critical'];

const DEFAULTS = {
  elevatedRatio: 0.60,
  highRatio: 0.75,
  criticalRatio: 0.88,
  rssCriticalRatio: 0.85,
  actionCooldownMs: 60 * 1000,
  logCooldownMs: 5 * 60 * 1000,
  leakSampleMs: 10 * 60 * 1000,
  leakSamplesNeeded: 6,
  leakMinGrowthMb: 40,
};

function mb(n) {
  return Math.round(n / 1048576);
}

function memoryCeilingBytes() {
  try {
    if (typeof process.constrainedMemory === 'function') {
      const c = process.constrainedMemory();
      if (c && Number.isFinite(c) && c > 0 && c < os.totalmem()) return c;
    }
  } catch (_) {}
  return os.totalmem();
}

function create(opts = {}) {
  const cfg = Object.assign({}, DEFAULTS, opts.config || {});
  const logger = opts.logger || console;
  const hooks = {
    cleanup: opts.cleanup || (() => {}), // buang state kadaluarsa
    clearCaches: opts.clearCaches || (() => {}), // lepas cache besar
    releaseIdle: opts.releaseIdle || (async () => 0), // lepas koneksi idle
    describe: opts.describe || (() => ({})), // ukuran struktur utama (log leak)
  };

  let level = 'normal';
  let pressure = false;
  let lastActionAt = 0;
  let lastLogAt = 0;
  let busy = false;
  let lastLeakSampleAt = 0;
  const retainedSamples = [];

  function readLevel() {
    const heap = v8.getHeapStatistics();
    const heapRatio = heap.used_heap_size / heap.heap_size_limit;
    let rssRatio = 0;
    try { rssRatio = process.memoryUsage().rss / memoryCeilingBytes(); } catch (_) {}

    let lv = 'normal';
    if (heapRatio >= cfg.criticalRatio || rssRatio >= cfg.rssCriticalRatio) lv = 'critical';
    else if (heapRatio >= cfg.highRatio) lv = 'high';
    else if (heapRatio >= cfg.elevatedRatio) lv = 'elevated';
    return { lv, heapRatio, rssRatio, heap };
  }

  function runGc() {
    try { if (typeof global.gc === 'function') global.gc(); } catch (_) {}
  }

  async function act(lv, snap) {
    if (busy) return;
    busy = true;
    try {
      const before = snap.heap.used_heap_size;
      try { hooks.cleanup(); } catch (e) { warn(`cleanup gagal: ${e.message}`); }

      let released = 0;
      if (lv === 'high' || lv === 'critical') {
        try { hooks.clearCaches(); } catch (e) { warn(`clearCaches gagal: ${e.message}`); }
        try { released = await hooks.releaseIdle(); } catch (e) { warn(`releaseIdle gagal: ${e.message}`); }
        runGc();
      }

      const after = v8.getHeapStatistics().used_heap_size;
      if (Date.now() - lastLogAt > cfg.logCooldownMs) {
        lastLogAt = Date.now();
        warn(
          `Tekanan memori [${lv}] heap ${mb(before)}MB -> ${mb(after)}MB ` +
          `(limit ${mb(snap.heap.heap_size_limit)}MB), rss ${mb(process.memoryUsage().rss)}MB, ` +
          `koneksi idle dilepas ${released}`
        );
      }
    } finally {
      busy = false;
    }
  }

  function warn(msg) {
    try { (logger.warn || logger.info || console.log).call(logger, `[memoryGuard] ${msg}`); } catch (_) {}
  }

  function sampleLeak() {
    const now = Date.now();
    if (now - lastLeakSampleAt < cfg.leakSampleMs) return;
    lastLeakSampleAt = now;
    runGc();
    // heap JS + memori eksternal (Buffer/ArrayBuffer GramJS & Mongo tidak masuk heap JS)
    const hs = v8.getHeapStatistics();
    const retained = hs.used_heap_size + (hs.external_memory || 0);
    retainedSamples.push(retained);
    if (retainedSamples.length > cfg.leakSamplesNeeded) retainedSamples.shift();
    if (retainedSamples.length < cfg.leakSamplesNeeded) return;

    let rising = true;
    for (let i = 1; i < retainedSamples.length; i++) {
      if (retainedSamples[i] <= retainedSamples[i - 1]) { rising = false; break; }
    }
    const growth = retainedSamples[retainedSamples.length - 1] - retainedSamples[0];
    if (rising && growth >= cfg.leakMinGrowthMb * 1048576) {
      let detail = '';
      try { detail = JSON.stringify(hooks.describe()); } catch (_) {}
      warn(
        `Indikasi LEAK: heap+eksternal setelah GC naik terus ${mb(growth)}MB dalam ` +
        `${Math.round((cfg.leakSamplesNeeded * cfg.leakSampleMs) / 60000)} menit ` +
        `(sekarang ${mb(retained)}MB). Struktur: ${detail}`
      );
      retainedSamples.length = 0;
    }
  }

  /** Dipanggil periodik. Ringan; tindakan berat dijalankan async. */
  function tick() {
    const snap = readLevel();
    const prev = level;
    level = snap.lv;

    // Histeresis: pressure baru padam kalau sudah turun di bawah "high".
    if (level === 'critical') pressure = true;
    else if (level === 'normal' || level === 'elevated') pressure = false;

    if (level !== 'normal' && Date.now() - lastActionAt >= cfg.actionCooldownMs) {
      lastActionAt = Date.now();
      act(level, snap).catch(() => {});
    } else if (level === 'normal' && prev !== 'normal') {
      warn('Memori kembali normal');
    }

    try { sampleLeak(); } catch (_) {}
    return level;
  }

  return {
    tick,
    getLevel: () => level,
    isUnderPressure: () => pressure,
    levels: LEVELS,
  };
}

module.exports = { create, DEFAULTS };
