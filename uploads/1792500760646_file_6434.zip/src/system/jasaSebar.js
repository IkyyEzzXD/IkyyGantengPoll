/**
 * Modul Jasa Sebar (sender milik bot + pool grup otomatis)
 * --------------------------------------------------------
 * - Owner /addsender → bot scan semua grup di akun sender, simpan ke pool.
 * - User beli paket: hari + jumlah grup + basic/pro + jumlah sender.
 * - Harga basis: 1 hari · 10 grup · basic · 2 sender = Rp 3.000
 * - Setelah bayar: sistem assign grup dari pool, bagi merata antar sender
 *   (sisa ganjil boleh ke salah satu sender).
 * - User HANYA atur pesan + lihat status/log share. Tidak pilih grup sendiri.
 * - Default: share tiap 3 jam, delay 5 detik antar grup.
 */

const JASA_CONFIG = {
  BASE_PRICE: 2500,
  BASE_DAYS: 1,
  BASE_GROUPS: 10,
  BASE_SENDERS: 2,
  PRO_MULTIPLIER: 1.5,
  MIN_DAYS: 1,
  MAX_DAYS: 30,
  MIN_GROUPS: 5,
  MAX_GROUPS: 200,
  MIN_SENDERS: 1,
  MAX_SENDERS: 10,
  MIN_PRICE: 1000,
  DEFAULT_JEDA_MINUTES: 180,
  MIN_JEDA_MINUTES: 180,
  SLOT_GAP_SEC: 300,
  DEFAULT_DELAY_MS: 8000,
  STEP_DAYS: 1,
  STEP_GROUPS: 5,
  STEP_SENDERS: 1,
  MANDATORY_GROUP_ID: '-1004438526460',
  MANDATORY_GROUP_USERNAME: 'senderjaseb',
};

function isMandatoryGroup(g) {
  if (!g) return false;
  if (String(g.group_id || '') === JASA_CONFIG.MANDATORY_GROUP_ID) return true;
  const u = String(g.group_username || '').replace(/^@/, '').trim().toLowerCase();
  return u === JASA_CONFIG.MANDATORY_GROUP_USERNAME;
}

function calculatePrice({ access, days, groups, senders }) {
  const d = Math.max(JASA_CONFIG.MIN_DAYS, Math.min(JASA_CONFIG.MAX_DAYS, Number(days) || 1));
  const g = Math.max(JASA_CONFIG.MIN_GROUPS, Math.min(JASA_CONFIG.MAX_GROUPS, Number(groups) || 10));
  const s = Math.max(JASA_CONFIG.MIN_SENDERS, Math.min(JASA_CONFIG.MAX_SENDERS, Number(senders) || 2));
  const accessMult = access === 'pro' ? JASA_CONFIG.PRO_MULTIPLIER : 1;

  let raw =
    JASA_CONFIG.BASE_PRICE *
    (d / JASA_CONFIG.BASE_DAYS) *
    (g / JASA_CONFIG.BASE_GROUPS) *
    (s / JASA_CONFIG.BASE_SENDERS) *
    accessMult;

  let price = Math.round(raw / 100) * 100;
  if (price < JASA_CONFIG.MIN_PRICE) price = JASA_CONFIG.MIN_PRICE;
  return price;
}

async function initJasaTables(db) {
  await db.exec(`
    CREATE TABLE IF NOT EXISTS jasa_senders (
      sender_id TEXT PRIMARY KEY,
      phone TEXT,
      session_string TEXT NOT NULL,
      status TEXT DEFAULT 'AKTIF' CHECK(status IN ('AKTIF','OFF','ERROR')),
      groups_count INTEGER DEFAULT 0,
      created_at INTEGER,
      last_used_at INTEGER,
      last_scan_at INTEGER,
      note TEXT
    );

    CREATE TABLE IF NOT EXISTS jasa_sender_groups (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sender_id TEXT NOT NULL,
      group_id TEXT NOT NULL,
      group_username TEXT,
      group_title TEXT,
      access_hash TEXT,
      status TEXT DEFAULT 'aktif' CHECK(status IN ('aktif','blacklist','error','busy')),
      created_at INTEGER,
      UNIQUE(sender_id, group_id),
      FOREIGN KEY (sender_id) REFERENCES jasa_senders(sender_id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS jasa_orders (
      order_id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      access_type TEXT NOT NULL CHECK(access_type IN ('basic','pro')),
      days INTEGER NOT NULL,
      groups_count INTEGER NOT NULL,
      senders_count INTEGER NOT NULL,
      price INTEGER NOT NULL,
      status TEXT DEFAULT 'pending' CHECK(status IN ('pending','paid','active','paused','finished','cancelled','expired')),
      pakasir_order_id TEXT,
      started_at INTEGER,
      expires_at INTEGER,
      created_at INTEGER,
      updated_at INTEGER,
      message_type TEXT,
      message_content TEXT,
      message_file_id TEXT,
      message_caption TEXT,
      message_from_chat TEXT,
      message_from_chat_hash TEXT,
      message_from_chat_username TEXT,
      message_forward_id INTEGER,
      media_path TEXT,
      jeda_minutes INTEGER DEFAULT 180,
      delay_ms INTEGER DEFAULT 5000,
      next_run_at INTEGER,
      total_rounds INTEGER DEFAULT 0,
      last_round_at INTEGER,
      last_success INTEGER DEFAULT 0,
      last_failed INTEGER DEFAULT 0,
      round_in_progress INTEGER
    );

    CREATE TABLE IF NOT EXISTS jasa_order_groups (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id TEXT NOT NULL,
      sender_id TEXT NOT NULL,
      group_id TEXT NOT NULL,
      group_username TEXT,
      group_title TEXT,
      status TEXT DEFAULT 'aktif' CHECK(status IN ('aktif','blacklist','error')),
      created_at INTEGER,
      last_sent_round INTEGER,
      last_sent_at INTEGER,
      last_sent_status TEXT,
      UNIQUE(order_id, sender_id, group_id),
      FOREIGN KEY (order_id) REFERENCES jasa_orders(order_id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS jasa_order_senders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id TEXT NOT NULL,
      sender_id TEXT NOT NULL,
      assigned_at INTEGER,
      groups_assigned INTEGER DEFAULT 0,
      UNIQUE(order_id, sender_id),
      FOREIGN KEY (order_id) REFERENCES jasa_orders(order_id) ON DELETE CASCADE,
      FOREIGN KEY (sender_id) REFERENCES jasa_senders(sender_id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS jasa_share_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id TEXT NOT NULL,
      round_number INTEGER,
      success INTEGER DEFAULT 0,
      failed INTEGER DEFAULT 0,
      detail TEXT,
      started_at INTEGER,
      finished_at INTEGER,
      FOREIGN KEY (order_id) REFERENCES jasa_orders(order_id) ON DELETE CASCADE
    );

    CREATE INDEX IF NOT EXISTS idx_jasa_orders_user ON jasa_orders(user_id);
    CREATE INDEX IF NOT EXISTS idx_jasa_orders_status ON jasa_orders(status);
    CREATE INDEX IF NOT EXISTS idx_jasa_orders_next_run ON jasa_orders(next_run_at);
    CREATE INDEX IF NOT EXISTS idx_jasa_sender_groups_sender ON jasa_sender_groups(sender_id);
    CREATE INDEX IF NOT EXISTS idx_jasa_order_groups_order ON jasa_order_groups(order_id);
    CREATE INDEX IF NOT EXISTS idx_jasa_logs_order ON jasa_share_logs(order_id);
  `);

  // Migrasi kolom jika tabel lama sudah ada
  try {
    const cols = await db.all(`PRAGMA table_info(jasa_senders)`);
    const names = (cols || []).map((c) => c.name);
    if (!names.includes('groups_count')) {
      await db.run(`ALTER TABLE jasa_senders ADD COLUMN groups_count INTEGER DEFAULT 0`);
    }
    if (!names.includes('last_scan_at')) {
      await db.run(`ALTER TABLE jasa_senders ADD COLUMN last_scan_at INTEGER`);
    }
  } catch (e) {}

  try {
    const cols2 = await db.all(`PRAGMA table_info(jasa_orders)`);
    const n2 = (cols2 || []).map((c) => c.name);
    if (!n2.includes('last_success')) {
      await db.run(`ALTER TABLE jasa_orders ADD COLUMN last_success INTEGER DEFAULT 0`);
    }
    if (!n2.includes('last_failed')) {
      await db.run(`ALTER TABLE jasa_orders ADD COLUMN last_failed INTEGER DEFAULT 0`);
    }
  } catch (e) {}

  try {
    const cols3 = await db.all(`PRAGMA table_info(jasa_order_groups)`);
    const n3 = (cols3 || []).map((c) => c.name);
    if (!n3.includes('sender_id')) {
      // Tabel lama tanpa sender_id — biarkan; insert baru selalu isi sender_id
      await db.run(`ALTER TABLE jasa_order_groups ADD COLUMN sender_id TEXT`);
    }
    // FITUR BARU (tahan-restart auto share): catat per-grup, round keberapa
    // terakhir grup ini kebagian share + waktu + statusnya. Sebelumnya progres
    // share HANYA disimpan di memori selama satu round jalan (variabel success/
    // failed di executeJasaRound) dan baru ditulis ke DB setelah SEMUA grup
    // selesai diproses. Kalau bot restart di tengah round (mis. grup ke-30 dari
    // 50), seluruh progres round itu hilang tanpa jejak - tidak ada cara tahu
    // grup mana yang sudah/belum kebagian. Dengan 3 kolom ini, tiap grup
    // ditandai LANGSUNG setelah dikirim (bukan nunggu round selesai), jadi
    // kalau restart di tengah jalan, round yang sama bisa dilanjutkan persis
    // dari grup yang belum kebagian - tidak diulang dari nol, tidak dobel
    // kirim ke grup yang sudah kebagian.
    if (!n3.includes('last_sent_round')) {
      await db.run(`ALTER TABLE jasa_order_groups ADD COLUMN last_sent_round INTEGER`);
    }
    if (!n3.includes('last_sent_at')) {
      await db.run(`ALTER TABLE jasa_order_groups ADD COLUMN last_sent_at INTEGER`);
    }
    if (!n3.includes('last_sent_status')) {
      await db.run(`ALTER TABLE jasa_order_groups ADD COLUMN last_sent_status TEXT`);
    }
  } catch (e) {}

  try {
    const cols4 = await db.all(`PRAGMA table_info(jasa_orders)`);
    const n4 = (cols4 || []).map((c) => c.name);
    // FITUR BARU (tahan-restart auto share): penanda "round nomor X sedang
    // berjalan" untuk order ini. NULL = tidak ada round yang sedang jalan
    // (idle, menunggu next_run_at). Diisi di AWAL round (sebelum loop kirim
    // ke grup dimulai) dan di-NULL-kan lagi setelah round itu benar-benar
    // selesai semua grup. Kalau bot restart sementara kolom ini masih terisi
    // (tidak sempat di-NULL-kan), itu tandanya round itu terputus di tengah
    // jalan - dipakai saat startup untuk memutuskan lanjutkan round yang sama
    // (bukan mulai round baru / bukan nunggu next_run_at lagi).
    if (!n4.includes('round_in_progress')) {
      await db.run(`ALTER TABLE jasa_orders ADD COLUMN round_in_progress INTEGER`);
    }
  } catch (e) {}
}

function formatOrderSummary({ access, days, groups, senders, price }) {
  const accessLabel = access === 'pro' ? 'Pro (Forward)' : 'Basic (Copy)';
  const s = Number(senders) || 1;
  const g = Number(groups) || 0;
  const slots = g * s;
  return (
    `<b>Akses</b> : <code>${accessLabel}</code>\n` +
    `<b>Durasi</b> : <code>${days} hari</code>\n` +
    `<b>Grup / sender</b> : <code>${g} grup</code> (tiap sender kirim ke ${g} grup)\n` +
    `<b>Sender</b> : <code>${s} akun</code>\n` +
    `<b>Total slot share</b> : <code>${slots}</code> (${s}×${g})\n` +
    `<b>Total harga</b> : <code><b>Rp ${Number(price).toLocaleString('id-ID')}</b></code>`
  );
}


/**
 * Ambil sender aktif, urut last_used (paling lama dipakai dulu).
 * @param {number} count - jumlah sender yang diminta
 * @param {number} [minFreeGroups=1] - minimal grup free per sender (opsional filter)
 */
async function getAvailableSenders(db, count, minFreeGroups = 1) {
  const rows = await db.all(
    `SELECT * FROM jasa_senders WHERE status = 'AKTIF' ORDER BY COALESCE(last_used_at, 0) ASC`
  );
  if (!rows || rows.length === 0) return [];

  // BUG FIX: sama seperti getSenderFreeCaps() - jangan pakai kolom statis
  // jasa_senders.groups_count (tidak berkurang saat grup di-blacklist),
  // hitung total dari pool aktif sebenarnya.
  const activeCountRows = await db.all(
    `SELECT sender_id, COUNT(*) AS c FROM jasa_sender_groups WHERE status = 'aktif' GROUP BY sender_id`
  );
  const activeCountMap = {};
  for (const r of activeCountRows || []) activeCountMap[r.sender_id] = r.c;

  // Hitung free groups per sender (pool - busy di order aktif)
  const busyRows = await db.all(
    `SELECT og.sender_id, og.group_id FROM jasa_order_groups og
     JOIN jasa_orders o ON o.order_id = og.order_id
     WHERE o.status IN ('active','paused','paid') AND og.status = 'aktif'`
  );
  const busyCount = {};
  for (const r of busyRows || []) {
    busyCount[r.sender_id] = (busyCount[r.sender_id] || 0) + 1;
  }

  const enriched = [];
  for (const s of rows) {
    const total = activeCountMap[s.sender_id] || 0;
    if (total <= 0) continue;
    const busy = busyCount[s.sender_id] || 0;
    const free = Math.max(0, total - busy);
    enriched.push({ ...s, groups_count: total, free_groups: free });
  }

  // Prioritas: cukup free dulu, lalu last_used
  enriched.sort((a, b) => {
    const aOk = a.free_groups >= minFreeGroups ? 1 : 0;
    const bOk = b.free_groups >= minFreeGroups ? 1 : 0;
    if (bOk !== aOk) return bOk - aOk;
    return (a.last_used_at || 0) - (b.last_used_at || 0);
  });

  return enriched.slice(0, count);
}

async function getPoolGroupCapacity(db) {
  const row = await db.get(
    `SELECT COUNT(*) AS c FROM jasa_sender_groups sg
     JOIN jasa_senders s ON s.sender_id = sg.sender_id
     WHERE s.status = 'AKTIF' AND sg.status = 'aktif'`
  );
  return (row && row.c) || 0;
}

/**
 * Hitung free groups per sender aktif.
 * @returns {Array<{sender_id, phone, groups_count, free_groups}>}
 */
async function getSenderFreeCaps(db) {
  const senders = await db.all(
    `SELECT * FROM jasa_senders WHERE status = 'AKTIF' ORDER BY COALESCE(last_used_at, 0) ASC`
  );
  // BUG FIX (auto share ga work / grup banned dipakai lagi): sebelumnya
  // "total" kapasitas sender diambil dari kolom statis jasa_senders.groups_count
  // (hasil scan terakhir), yang TIDAK berkurang saat sebagian grup di sender
  // itu belakangan ditandai 'blacklist'/'error' (mis. karena USER_BANNED_IN_CHANNEL).
  // Akibatnya kapasitas selalu dianggap lebih besar dari yang sebenarnya
  // available, dan grup yang sudah terbukti gagal permanen tetap dihitung
  // sebagai slot valid. Fix: hitung total dari POOL AKTIF sebenarnya
  // (jasa_sender_groups WHERE status = 'aktif'), bukan kolom statis.
  const activeCountRows = await db.all(
    `SELECT sender_id, COUNT(*) AS c FROM jasa_sender_groups WHERE status = 'aktif' GROUP BY sender_id`
  );
  const activeCountMap = {};
  for (const r of activeCountRows || []) activeCountMap[r.sender_id] = r.c;

  const busyRows = await db.all(
    `SELECT og.sender_id, COUNT(*) AS c FROM jasa_order_groups og
     JOIN jasa_orders o ON o.order_id = og.order_id
     WHERE o.status IN ('active','paused','paid') AND og.status = 'aktif'
     GROUP BY og.sender_id`
  );
  const busyMap = {};
  for (const r of busyRows || []) busyMap[r.sender_id] = r.c;

  return (senders || []).map((s) => {
    const total = activeCountMap[s.sender_id] || 0;
    const busy = busyMap[s.sender_id] || 0;
    return {
      sender_id: s.sender_id,
      phone: s.phone,
      groups_count: total,
      free_groups: Math.max(0, total - busy),
      last_used_at: s.last_used_at,
    };
  });
}

/**
 * Cek kapasitas untuk order: SETIAP sender harus punya minimal `groups` free.
 * Jika tidak semua sender punya cukup, hitung maxGroups yang feasible =
 * min(free) di antara sender terpilih (yang free > 0), dan saran penyesuaian.
 *
 * Return:
 *  {
 *    ok: boolean,
 *    senders: [...],          // sender terpilih
 *    requestedGroups: number,
 *    effectiveGroups: number, // bisa < requested jika auto-reduce
 *    totalSlots: number,      // effectiveGroups * senders.length (total kiriman)
 *    price: number,           // harga pakai effectiveGroups
 *    detail: string
 *  }
 */
async function planOrderCapacity(db, { access, days, groups, senders }) {
  const wantSenders = Math.max(1, Number(senders) || 1);
  const wantGroups = Math.max(1, Number(groups) || 10);

  const caps = await getSenderFreeCaps(db);
  if (caps.length < wantSenders) {
    return {
      ok: false,
      senders: [],
      requestedGroups: wantGroups,
      effectiveGroups: 0,
      totalSlots: 0,
      price: 0,
      detail: `Sender aktif hanya ${caps.length}, butuh ${wantSenders}. Tambah/refresh sender dulu.`,
    };
  }

  // Ambil sender dengan free terbanyak dulu agar order besar lebih mungkin
  const sorted = [...caps].sort((a, b) => b.free_groups - a.free_groups || (a.last_used_at || 0) - (b.last_used_at || 0));
  const picked = sorted.slice(0, wantSenders);

  // Tiap sender harus kirim ke `groups` grup → effective = min free di antara picked
  const minFree = Math.min(...picked.map((p) => p.free_groups));
  if (minFree <= 0) {
    return {
      ok: false,
      senders: picked,
      requestedGroups: wantGroups,
      effectiveGroups: 0,
      totalSlots: 0,
      price: 0,
      detail: `Semua/sebagian sender tidak punya grup free. Jalankan /refreshsender atau tunggu order lain selesai.`,
    };
  }

  const effectiveGroups = Math.min(wantGroups, minFree);
  const totalSlots = effectiveGroups * picked.length;
  const price = calculatePrice({
    access,
    days,
    groups: effectiveGroups,
    senders: wantSenders,
  });

  let detail = '';
  if (effectiveGroups < wantGroups) {
    detail =
      `Kapasitas terbatas: diminta ${wantGroups} grup/sender, ` +
      `tersedia min ${minFree} free → disesuaikan jadi ${effectiveGroups} grup/sender ` +
      `(total ${totalSlots} slot share). Harga menyesuaikan.`;
  } else {
    detail =
      `OK: ${wantSenders} sender × ${effectiveGroups} grup = ${totalSlots} slot share.`;
  }

  return {
    ok: effectiveGroups > 0,
    senders: picked,
    requestedGroups: wantGroups,
    effectiveGroups,
    totalSlots,
    price,
    reduced: effectiveGroups < wantGroups,
    detail,
    perSender: picked.map((p) => ({
      sender_id: p.sender_id,
      free: p.free_groups,
      will_use: effectiveGroups,
    })),
  };
}

/**
 * Assign grup: SETIAP sender mendapat `groupsNeeded` grup dari pool-nya sendiri.
 * Contoh order 10 grup + 2 sender → sender A 10 grup, sender B 10 grup (bukan 5+5).
 */
async function assignGroupsToOrder(db, orderId, senders, groupsNeeded) {
  const now = Math.floor(Date.now() / 1000);
  let assignedTotal = 0;

  const busyRows = await db.all(
    `SELECT og.sender_id, og.group_id FROM jasa_order_groups og
     JOIN jasa_orders o ON o.order_id = og.order_id
     WHERE o.status IN ('active','paused','paid') AND o.order_id != ? AND og.status = 'aktif'`,
    orderId
  );
  const busyKey = new Set((busyRows || []).map((r) => `${r.sender_id}::${r.group_id}`));

  for (const sender of senders) {
    const need = groupsNeeded;
    if (need <= 0) continue;

    const pool = await db.all(
      `SELECT * FROM jasa_sender_groups
       WHERE sender_id = ? AND status = 'aktif'
       ORDER BY id ASC`,
      sender.sender_id
    );

    const free = (pool || []).filter((g) => !busyKey.has(`${sender.sender_id}::${g.group_id}`));
    const take = free.slice(0, need);

    for (const g of take) {
      await db.run(
        `INSERT OR IGNORE INTO jasa_order_groups
         (order_id, sender_id, group_id, group_username, group_title, status, created_at)
         VALUES (?, ?, ?, ?, ?, 'aktif', ?)`,
        orderId,
        sender.sender_id,
        g.group_id,
        g.group_username || null,
        g.group_title || null,
        now
      );
      assignedTotal++;
    }

    await db.run(
      `INSERT OR REPLACE INTO jasa_order_senders (order_id, sender_id, assigned_at, groups_assigned)
       VALUES (?, ?, ?, ?)`,
      orderId,
      sender.sender_id,
      now,
      take.length
    );
    await db.run(`UPDATE jasa_senders SET last_used_at = ? WHERE sender_id = ?`, now, sender.sender_id);
  }

  return assignedTotal;
}

function jedaSecOf(order) {
  const min = Math.max(JASA_CONFIG.MIN_JEDA_MINUTES, Number(order && order.jeda_minutes) || JASA_CONFIG.DEFAULT_JEDA_MINUTES);
  return min * 60;
}

function earliestNextRun(order) {
  const last = Number(order && order.last_round_at) || 0;
  return last > 0 ? last + jedaSecOf(order) : 0;
}

function estimateRoundSec(order) {
  const delaySec = Math.max(8, (Number(order && order.delay_ms) || JASA_CONFIG.DEFAULT_DELAY_MS) / 1000) + 2;
  return Math.ceil((Number(order && order.groups_count) || 10) * delaySec + 90);
}

async function computeSafeNextRun(db, orderId, preferredStartTs, opts = {}) {
  const gap = JASA_CONFIG.SLOT_GAP_SEC;
  const me = await db.get(`SELECT * FROM jasa_orders WHERE order_id = ?`, orderId);
  let candidate = preferredStartTs || Math.floor(Date.now() / 1000) + 60;
  if (me) candidate = Math.max(candidate, earliestNextRun(me));
  const myDur = me ? estimateRoundSec(me) : 600;

  const others = await db.all(
    `SELECT * FROM jasa_orders
     WHERE status = 'active' AND order_id != ? AND next_run_at IS NOT NULL`,
    orderId
  );
  const mySenders = await db.all(`SELECT sender_id FROM jasa_order_senders WHERE order_id = ?`, orderId);
  const myIds = new Set((mySenders || []).map((r) => String(r.sender_id)));
  if (myIds.size === 0 || !others || others.length === 0) return candidate;

  const windows = [];
  for (const o of others) {
    if (opts.onlyIds && !opts.onlyIds.has(o.order_id)) continue;
    const their = await db.all(`SELECT sender_id FROM jasa_order_senders WHERE order_id = ?`, o.order_id);
    if (!(their || []).some((r) => myIds.has(String(r.sender_id)))) continue;
    windows.push({ start: o.next_run_at, end: o.next_run_at + estimateRoundSec(o) + gap });
  }
  windows.sort((x, y) => x.start - y.start);

  for (let i = 0; i < 500; i++) {
    const hit = windows.find((w) => candidate < w.end && candidate + myDur + gap > w.start);
    if (!hit) break;
    candidate = hit.end;
  }
  return candidate;
}

async function rebalanceSchedules(db) {
  const now = Math.floor(Date.now() / 1000);
  const rows = await db.all(
    `SELECT * FROM jasa_orders WHERE status = 'active' AND round_in_progress IS NULL AND next_run_at IS NOT NULL ORDER BY next_run_at ASC`
  );
  let moved = 0;
  const processed = new Set();
  const running = await db.all(`SELECT order_id FROM jasa_orders WHERE status = 'active' AND round_in_progress IS NOT NULL`);
  for (const r of running || []) processed.add(r.order_id);
  for (const o of rows || []) {
    const preferred = Math.max(o.next_run_at, earliestNextRun(o), now + 30);
    const next = await computeSafeNextRun(db, o.order_id, preferred, { onlyIds: processed });
    processed.add(o.order_id);
    if (next !== o.next_run_at) {
      await db.run(`UPDATE jasa_orders SET next_run_at = ?, updated_at = ? WHERE order_id = ?`, next, now, o.order_id);
      moved++;
    }
  }
  return moved;
}

async function activateOrder(db, orderId) {
  const order = await db.get(`SELECT * FROM jasa_orders WHERE order_id = ?`, orderId);
  if (!order) throw new Error('Order tidak ditemukan');
  if (order.status === 'active') return order;

  // Tiap sender kirim ke groups_count grup (bukan split).
  // expected total rows di jasa_order_groups = groups_count * senders_count
  const plan = await planOrderCapacity(db, {
    access: order.access_type,
    days: order.days,
    groups: order.groups_count,
    senders: order.senders_count,
  });
  if (!plan.ok || !plan.senders.length) {
    throw new Error(plan.detail || 'Kapasitas sender/grup tidak cukup');
  }

  // Jangan ubah groups_count / price. Jumlah pesanan yang di-ACC harus tetap
  // sesuai yang dipesan. Assign sebanyak yang free sekarang; sisanya diisi
  // kemudian oleh healOrder saat slot tersedia.
  const groupsNeeded = Math.min(Number(order.groups_count) || 0, plan.effectiveGroups);
  const assigned = await assignGroupsToOrder(db, orderId, plan.senders, groupsNeeded);
  if (assigned <= 0) {
    throw new Error(
      `Grup free tidak cukup (ter-assign 0). ` +
      `Tiap sender butuh ${order.groups_count} grup. Refresh sender atau tunggu slot kosong.`
    );
  }

  const now = Math.floor(Date.now() / 1000);
  const expiresAt = now + order.days * 86400;
  const nextRun = await computeSafeNextRun(db, orderId, now + 120);

  await db.run(
    `UPDATE jasa_orders SET
      status = 'active',
      started_at = ?,
      expires_at = ?,
      next_run_at = ?,
      jeda_minutes = COALESCE(jeda_minutes, ?),
      delay_ms = COALESCE(delay_ms, ?),
      updated_at = ?
     WHERE order_id = ?`,
    now,
    expiresAt,
    nextRun,
    JASA_CONFIG.DEFAULT_JEDA_MINUTES,
    JASA_CONFIG.DEFAULT_DELAY_MS,
    now,
    orderId
  );

  return await db.get(`SELECT * FROM jasa_orders WHERE order_id = ?`, orderId);
}

async function createPendingOrder(db, userId, { access, days, groups, senders, price }) {
  const orderId = `JASA-${Date.now()}-${userId}`;
  const now = Math.floor(Date.now() / 1000);
  await db.run(
    `INSERT INTO jasa_orders (
      order_id, user_id, access_type, days, groups_count, senders_count, price,
      status, created_at, updated_at, jeda_minutes, delay_ms
    ) VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?, ?, ?)`,
    orderId,
    String(userId),
    access === 'pro' ? 'pro' : 'basic',
    days,
    groups,
    senders,
    price,
    now,
    now,
    JASA_CONFIG.DEFAULT_JEDA_MINUTES,
    JASA_CONFIG.DEFAULT_DELAY_MS
  );
  return orderId;
}

async function markPaidAndActivate(db, orderId, pakasirOrderId) {
  const now = Math.floor(Date.now() / 1000);
  await db.run(
    `UPDATE jasa_orders SET status = 'paid', pakasir_order_id = ?, updated_at = ? WHERE order_id = ? AND status = 'pending'`,
    pakasirOrderId || null,
    now,
    orderId
  );
  return activateOrder(db, orderId);
}

async function getUserOrders(db, userId, limit = 10) {
  return db.all(
    `SELECT * FROM jasa_orders WHERE user_id = ? ORDER BY created_at DESC LIMIT ?`,
    String(userId),
    limit
  );
}

async function getActiveOrders(db) {
  return db.all(`SELECT * FROM jasa_orders WHERE status = 'active'`);
}

async function getUserActiveOrder(db, userId) {
  return db.get(
    `SELECT * FROM jasa_orders WHERE user_id = ? AND status IN ('active','paused','paid') ORDER BY created_at DESC LIMIT 1`,
    String(userId)
  );
}

/**
 * Tandai order jasa yang lewat expires_at → finished/expired.
 * Bebaskan slot grup (hapus assign) supaya sender bisa dipakai order lain.
 * Return daftar order yang baru di-expire (untuk notifikasi).
 */
async function expireDueOrders(db) {
  const now = Math.floor(Date.now() / 1000);
  const due = await db.all(
    `SELECT * FROM jasa_orders
     WHERE status IN ('active','paused','paid')
       AND expires_at IS NOT NULL
       AND expires_at <= ?`,
    now
  );
  if (!due || due.length === 0) return [];

  for (const o of due) {
    await db.run(
      `UPDATE jasa_orders SET status = 'expired', next_run_at = NULL, updated_at = ? WHERE order_id = ?`,
      now,
      o.order_id
    );
    // Bebaskan grup assign (slot sender free lagi)
    try {
      await db.run(`DELETE FROM jasa_order_groups WHERE order_id = ?`, o.order_id);
      await db.run(`DELETE FROM jasa_order_senders WHERE order_id = ?`, o.order_id);
    } catch (e) {}
  }
  return due;
}

async function addShareLog(db, orderId, roundNumber, success, failed, detail) {
  const now = Math.floor(Date.now() / 1000);
  await db.run(
    `INSERT INTO jasa_share_logs (order_id, round_number, success, failed, detail, started_at, finished_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    orderId,
    roundNumber,
    success,
    failed,
    detail || null,
    now,
    now
  );
}

async function getShareLogs(db, orderId, limit = 10) {
  return db.all(
    `SELECT * FROM jasa_share_logs WHERE order_id = ? ORDER BY id DESC LIMIT ?`,
    orderId,
    limit
  );
}

/**
 * Simpan hasil scan dialog grup milik sender.
 * @param {Array<{group_id, group_username?, group_title?, access_hash?}>} groups
 */
async function saveSenderGroups(db, senderId, groups) {
  const now = Math.floor(Date.now() / 1000);
  groups = (groups || []).filter((g) => !isMandatoryGroup(g));
  await db.run(`DELETE FROM jasa_sender_groups WHERE sender_id = ?`, senderId);
  for (const g of groups) {
    await db.run(
      `INSERT OR IGNORE INTO jasa_sender_groups
       (sender_id, group_id, group_username, group_title, access_hash, status, created_at)
       VALUES (?, ?, ?, ?, ?, 'aktif', ?)`,
      senderId,
      String(g.group_id),
      g.group_username || null,
      g.group_title || null,
      g.access_hash != null ? String(g.access_hash) : null,
      now
    );
  }
  await db.run(
    `UPDATE jasa_senders SET groups_count = ?, last_scan_at = ? WHERE sender_id = ?`,
    groups.length,
    now,
    senderId
  );
  return groups.length;
}

/**
 * BUG FIX (order "paid" nyangkut selamanya): activateOrder() di atas bisa
 * gagal kalau pas order dibayar/diterima owner, ternyata kapasitas sender
 * (grup free per sender) udah abis kepake order lain di antara waktu order
 * dibuat & waktu dibayar (race yang wajar terjadi kalau ada beberapa order
 * jalan bersamaan). Sebelumnya kalau ini kejadian: uang customer udah
 * diterima/ditandai 'paid', tapi order-nya gak pernah jadi 'active' -
 * customer nunggu tanpa kepastian, dan satu-satunya jalan keluar adalah
 * owner ngurus manual satu-satu.
 * Fungsi ini dipanggil berkala (lihat pemanggilannya di checkExpired /
 * index.js, tiap 30 detik) - nyari semua order yang nyangkut di status
 * 'paid' dan coba aktivasi ulang. Begitu sender lain selesai/expired dan
 * slotnya kebuka, order yang nyangkut ini otomatis lanjut aktif sendiri
 * tanpa perlu campur tangan owner atau customer complain dulu.
 * Return: array order yang BERHASIL diaktifkan barusan (buat dikirimin
 * notifikasi "udah aktif" ke usernya oleh pemanggil).
 */
async function retryStuckPaidOrders(db) {
  const stuck = await db.all(`SELECT * FROM jasa_orders WHERE status = 'paid'`);
  const activated = [];
  for (const order of stuck || []) {
    try {
      const result = await activateOrder(db, order.order_id);
      if (result && result.status === 'active') {
        activated.push(result);
      }
    } catch (e) {
      // Masih belum ada slot free - biarin, dicoba lagi otomatis di siklus
      // berikutnya (30 detik lagi). Sengaja TIDAK di-log sebagai error di
      // sini supaya gak spam - pemanggil (checkExpired) yang atur logging.
    }
  }
  return activated;
}

/**
 * FITUR BARU (tahan-restart auto share): dipanggil SEKALI saat bot startup,
 * SEBELUM worker jasa sebar mulai jalan tiap menit (lihat startJasaSebarWorker
 * di index.js). Mencari semua order yang round_in_progress-nya masih terisi -
 * artinya round itu ketahuan terputus (bot mati/restart) di tengah proses
 * kirim ke grup, bukan selesai normal.
 *
 * Untuk tiap order begitu, next_run_at di-set ke "sekarang" supaya worker
 * tick berikutnya (maksimal 60 detik lagi) langsung mengambil order ini dan
 * executeJasaRound melanjutkan round yang sama (grup yang last_sent_round-nya
 * sudah sama dengan round_in_progress dilewati, sisanya lanjut dikirim -
 * lihat executeJasaRound di index.js).
 *
 * Return: array order yang round-nya terdeteksi terputus (untuk di-log).
 */
async function recoverInterruptedRounds(db) {
  const now = Math.floor(Date.now() / 1000);
  const interrupted = await db.all(
    `SELECT * FROM jasa_orders WHERE status = 'active' AND round_in_progress IS NOT NULL`
  );
  if (!interrupted || interrupted.length === 0) return [];

  for (const o of interrupted) {
    await db.run(
      `UPDATE jasa_orders SET next_run_at = ?, updated_at = ? WHERE order_id = ?`,
      now, now, o.order_id
    );
  }
  return interrupted;
}

async function freeGroupsForSender(db, senderId) {
  const pool = await db.all(
    `SELECT * FROM jasa_sender_groups WHERE sender_id = ? AND status = 'aktif' ORDER BY id ASC`,
    senderId
  );
  const busy = await db.all(
    `SELECT og.group_id FROM jasa_order_groups og
     JOIN jasa_orders o ON o.order_id = og.order_id
     WHERE og.sender_id = ? AND og.status = 'aktif' AND o.status IN ('active','paused','paid')`,
    senderId
  );
  const busySet = new Set((busy || []).map((r) => String(r.group_id)));
  return (pool || []).filter((g) => !busySet.has(String(g.group_id)));
}

async function countActiveOrderGroups(db, orderId, senderId) {
  const row = await db.get(
    `SELECT COUNT(*) AS c FROM jasa_order_groups WHERE order_id = ? AND sender_id = ? AND status = 'aktif'`,
    orderId, senderId
  );
  return (row && row.c) || 0;
}

async function syncAssignedCount(db, orderId, senderId) {
  const c = await countActiveOrderGroups(db, orderId, senderId);
  await db.run(
    `UPDATE jasa_order_senders SET groups_assigned = ? WHERE order_id = ? AND sender_id = ?`,
    c, orderId, senderId
  );
  return c;
}

async function fillSenderGroups(db, orderId, senderId, need) {
  if (need <= 0) return 0;
  const now = Math.floor(Date.now() / 1000);
  const free = await freeGroupsForSender(db, senderId);
  let n = 0;
  for (const g of free.slice(0, need)) {
    await db.run(
      `INSERT OR IGNORE INTO jasa_order_groups
       (order_id, sender_id, group_id, group_username, group_title, status, created_at)
       VALUES (?, ?, ?, ?, ?, 'aktif', ?)`,
      orderId, senderId, String(g.group_id), g.group_username || null, g.group_title || null, now
    );
    n++;
  }
  if (n > 0) await syncAssignedCount(db, orderId, senderId);
  return n;
}

async function takeReplacementGroup(db, orderId, senderId) {
  const free = await freeGroupsForSender(db, senderId);
  const g = free[0];
  if (!g) return null;
  const now = Math.floor(Date.now() / 1000);
  await db.run(
    `INSERT OR IGNORE INTO jasa_order_groups
     (order_id, sender_id, group_id, group_username, group_title, status, created_at)
     VALUES (?, ?, ?, ?, ?, 'aktif', ?)`,
    orderId, senderId, String(g.group_id), g.group_username || null, g.group_title || null, now
  );
  await syncAssignedCount(db, orderId, senderId);
  return {
    order_id: orderId,
    sender_id: senderId,
    group_id: String(g.group_id),
    group_username: g.group_username || null,
    group_title: g.group_title || null,
    access_hash: g.access_hash || null,
    id: null,
  };
}

async function getOrderSenders(db, orderId) {
  const rows = await db.all(
    `SELECT s.* FROM jasa_order_senders os
     JOIN jasa_senders s ON s.sender_id = os.sender_id
     WHERE os.order_id = ?`,
    orderId
  );
  return rows || [];
}

async function getSenderBatch(db, orderId, senderId) {
  const rows = await db.all(
    `SELECT og.*, sg.access_hash AS access_hash
     FROM jasa_order_groups og
     LEFT JOIN jasa_sender_groups sg ON sg.sender_id = og.sender_id AND sg.group_id = og.group_id
     WHERE og.order_id = ? AND og.sender_id = ? AND og.status = 'aktif'
     ORDER BY og.id ASC`,
    orderId, senderId
  );
  return rows || [];
}

async function replaceSender(db, orderId, badSenderId, need) {
  const current = await getOrderSenders(db, orderId);
  const taken = new Set(current.map((s) => s.sender_id));
  const caps = await getSenderFreeCaps(db);
  const candidates = caps
    .filter((c) => !taken.has(c.sender_id) && c.free_groups > 0)
    .sort((a, b) => b.free_groups - a.free_groups || (a.last_used_at || 0) - (b.last_used_at || 0));
  if (candidates.length === 0) return null;
  const pick = candidates.find((c) => c.free_groups >= need) || candidates[0];
  const take = Math.min(need, pick.free_groups);
  const now = Math.floor(Date.now() / 1000);

  await db.run(`DELETE FROM jasa_order_groups WHERE order_id = ? AND sender_id = ?`, orderId, badSenderId);
  await db.run(`DELETE FROM jasa_order_senders WHERE order_id = ? AND sender_id = ?`, orderId, badSenderId);
  await db.run(
    `INSERT OR REPLACE INTO jasa_order_senders (order_id, sender_id, assigned_at, groups_assigned)
     VALUES (?, ?, ?, 0)`,
    orderId, pick.sender_id, now
  );
  const assigned = await fillSenderGroups(db, orderId, pick.sender_id, take);
  await db.run(`UPDATE jasa_senders SET last_used_at = ? WHERE sender_id = ?`, now, pick.sender_id);
  if (assigned <= 0) {
    await db.run(`DELETE FROM jasa_order_senders WHERE order_id = ? AND sender_id = ?`, orderId, pick.sender_id);
    return null;
  }
  return { sender_id: pick.sender_id, assigned };
}

async function addMissingSenders(db, order) {
  const current = await getOrderSenders(db, order.order_id);
  const missing = (order.senders_count || 1) - current.filter((s) => s.status === 'AKTIF').length;
  if (missing <= 0) return 0;
  let added = 0;
  for (let i = 0; i < missing; i++) {
    const r = await replaceSender(db, order.order_id, '__none__', order.groups_count);
    if (!r) break;
    added++;
  }
  return added;
}

async function healOrder(db, order) {
  const result = { replaced: [], short: [] };
  const senders = await getOrderSenders(db, order.order_id);
  for (const s of senders) {
    if (s.status !== 'AKTIF') {
      const r = await replaceSender(db, order.order_id, s.sender_id, order.groups_count);
      if (r) result.replaced.push({ from: s.sender_id, to: r.sender_id });
      continue;
    }
    await db.run(
      `DELETE FROM jasa_order_groups WHERE order_id = ? AND sender_id = ? AND status != 'aktif'`,
      order.order_id, s.sender_id
    );
    const have = await countActiveOrderGroups(db, order.order_id, s.sender_id);
    if (have < order.groups_count) {
      await fillSenderGroups(db, order.order_id, s.sender_id, order.groups_count - have);
      const after = await syncAssignedCount(db, order.order_id, s.sender_id);
      if (after < order.groups_count) result.short.push(s.sender_id);
    }
  }
  const added = await addMissingSenders(db, order);
  if (added > 0) result.added = added;
  return result;
}

async function markGroupBad(db, orderId, senderId, groupId) {
  await db.run(
    `UPDATE jasa_order_groups SET status = 'error' WHERE order_id = ? AND sender_id = ? AND group_id = ?`,
    orderId, senderId, String(groupId)
  );
  await db.run(
    `UPDATE jasa_sender_groups SET status = 'blacklist' WHERE sender_id = ? AND group_id = ?`,
    senderId, String(groupId)
  );
}

async function markGroupResult(db, orderId, senderId, groupId, roundNum, ok) {
  const now = Math.floor(Date.now() / 1000);
  await db.run(
    `UPDATE jasa_order_groups SET last_sent_round = ?, last_sent_at = ?, last_sent_status = ?
     WHERE order_id = ? AND sender_id = ? AND group_id = ?`,
    roundNum, now, ok ? 'ok' : 'error', orderId, senderId, String(groupId)
  );
}

async function editOrderAccess(db, orderId, target) {
  const order = await db.get(`SELECT * FROM jasa_orders WHERE order_id = ?`, orderId);
  if (!order) throw new Error('Order tidak ditemukan');
  if (!['active', 'paused'].includes(order.status)) throw new Error('Hanya order aktif atau dijeda yang bisa diedit');
  if (order.round_in_progress) throw new Error('Order sedang share, coba lagi beberapa menit lagi');

  const now = Math.floor(Date.now() / 1000);
  const days = parseInt(target.days, 10);
  const groups = parseInt(target.groups, 10);
  const senders = parseInt(target.senders, 10);
  if (!Number.isFinite(days) || days < JASA_CONFIG.MIN_DAYS || days > JASA_CONFIG.MAX_DAYS) {
    throw new Error(`Hari harus ${JASA_CONFIG.MIN_DAYS}-${JASA_CONFIG.MAX_DAYS}`);
  }
  if (!Number.isFinite(groups) || groups < JASA_CONFIG.MIN_GROUPS || groups > JASA_CONFIG.MAX_GROUPS) {
    throw new Error(`Grup harus ${JASA_CONFIG.MIN_GROUPS}-${JASA_CONFIG.MAX_GROUPS}`);
  }
  if (!Number.isFinite(senders) || senders < JASA_CONFIG.MIN_SENDERS || senders > JASA_CONFIG.MAX_SENDERS) {
    throw new Error(`Sender harus ${JASA_CONFIG.MIN_SENDERS}-${JASA_CONFIG.MAX_SENDERS}`);
  }

  const startedAt = Number(order.started_at) || now;
  const newExpires = startedAt + days * 86400;
  if (newExpires <= now) {
    const ran = Math.ceil((now - startedAt) / 86400);
    throw new Error(`Hari terlalu kecil, order sudah berjalan ${ran} hari`);
  }

  const caps = await getSenderFreeCaps(db);
  const ownRows = await db.all(
    `SELECT sender_id, COUNT(*) AS c FROM jasa_order_groups WHERE order_id = ? AND status = 'aktif' GROUP BY sender_id`,
    orderId
  );
  const ownMap = {};
  for (const r of ownRows || []) ownMap[String(r.sender_id)] = r.c;

  const availMap = {};
  for (const c of caps) {
    availMap[String(c.sender_id)] = c.free_groups + (ownMap[String(c.sender_id)] || 0);
  }

  const orderSenderRows = await db.all(`SELECT sender_id FROM jasa_order_senders WHERE order_id = ?`, orderId);
  const currentActive = (orderSenderRows || [])
    .map((r) => String(r.sender_id))
    .filter((sid) => Object.prototype.hasOwnProperty.call(availMap, sid))
    .sort((a, b) => (ownMap[b] || 0) - (ownMap[a] || 0));
  const currentInactive = (orderSenderRows || [])
    .map((r) => String(r.sender_id))
    .filter((sid) => !Object.prototype.hasOwnProperty.call(availMap, sid));

  const keep = currentActive.slice(0, senders);
  const drop = currentActive.slice(senders);
  const needNew = senders - keep.length;

  const candidates = caps
    .map((c) => String(c.sender_id))
    .filter((sid) => !currentActive.includes(sid) && !currentInactive.includes(sid))
    .sort((a, b) => availMap[b] - availMap[a]);

  const chosen = keep.concat(candidates.slice(0, needNew));
  if (chosen.length < senders) {
    throw new Error(`Sender aktif yang tersedia hanya ${chosen.length}, butuh ${senders}`);
  }
  const maxGroups = Math.min(...chosen.map((sid) => availMap[sid]));
  if (maxGroups < groups) {
    throw new Error(`Kapasitas tidak cukup. Dengan ${senders} sender, maksimal ${maxGroups} grup per sender`);
  }
  const add = chosen.slice(keep.length);

  for (const sid of drop) {
    await db.run(`DELETE FROM jasa_order_groups WHERE order_id = ? AND sender_id = ?`, orderId, sid);
    await db.run(`DELETE FROM jasa_order_senders WHERE order_id = ? AND sender_id = ?`, orderId, sid);
  }

  for (const sid of keep) {
    const have = ownMap[sid] || 0;
    if (have > groups) {
      const extra = await db.all(
        `SELECT group_id FROM jasa_order_groups WHERE order_id = ? AND sender_id = ? AND status = 'aktif' ORDER BY created_at DESC, rowid DESC LIMIT ?`,
        orderId, sid, have - groups
      );
      for (const g of extra || []) {
        await db.run(`DELETE FROM jasa_order_groups WHERE order_id = ? AND sender_id = ? AND group_id = ?`, orderId, sid, g.group_id);
      }
    } else if (have < groups) {
      await fillSenderGroups(db, orderId, sid, groups - have);
    }
    await syncAssignedCount(db, orderId, sid);
  }

  if (add.length > 0) {
    await assignGroupsToOrder(db, orderId, add.map((sid) => ({ sender_id: sid })), groups);
  }

  await db.run(
    `UPDATE jasa_orders SET days = ?, groups_count = ?, senders_count = ?, expires_at = ?, updated_at = ? WHERE order_id = ?`,
    days, groups, senders, newExpires, now, orderId
  );

  try {
    await addShareLog(
      db, orderId, order.total_rounds || 0, 0, 0,
      `EDIT OWNER ${order.days}h/${order.groups_count}g/${order.senders_count}s -> ${days}h/${groups}g/${senders}s`
    );
  } catch (e) {}

  return {
    before: { days: order.days, groups: order.groups_count, senders: order.senders_count, expires_at: order.expires_at },
    after: { days, groups, senders, expires_at: newExpires },
  };
}

async function grantOrderAccess(db, userId, opts) {
  const access = opts.access === 'pro' ? 'pro' : 'basic';
  const days = parseInt(opts.days, 10);
  const groups = parseInt(opts.groups, 10);
  const senders = parseInt(opts.senders, 10);
  if (!Number.isFinite(days) || days < JASA_CONFIG.MIN_DAYS || days > JASA_CONFIG.MAX_DAYS) {
    throw new Error(`Hari harus ${JASA_CONFIG.MIN_DAYS}-${JASA_CONFIG.MAX_DAYS}`);
  }
  if (!Number.isFinite(groups) || groups < JASA_CONFIG.MIN_GROUPS || groups > JASA_CONFIG.MAX_GROUPS) {
    throw new Error(`Grup harus ${JASA_CONFIG.MIN_GROUPS}-${JASA_CONFIG.MAX_GROUPS}`);
  }
  if (!Number.isFinite(senders) || senders < JASA_CONFIG.MIN_SENDERS || senders > JASA_CONFIG.MAX_SENDERS) {
    throw new Error(`Sender harus ${JASA_CONFIG.MIN_SENDERS}-${JASA_CONFIG.MAX_SENDERS}`);
  }

  const plan = await planOrderCapacity(db, { access, days, groups, senders });
  if (!plan.ok) throw new Error(plan.detail || 'Kapasitas sender tidak cukup');
  if (plan.effectiveGroups < groups) {
    throw new Error(`Kapasitas tidak cukup. Dengan ${senders} sender, maksimal ${plan.effectiveGroups} grup per sender`);
  }

  const orderId = await createPendingOrder(db, userId, { access, days, groups, senders, price: 0 });
  try {
    return await markPaidAndActivate(db, orderId, 'OWNER-GRANT');
  } catch (err) {
    await db.run(
      `UPDATE jasa_orders SET status = 'cancelled', updated_at = ? WHERE order_id = ?`,
      Math.floor(Date.now() / 1000), orderId
    );
    throw err;
  }
}

async function scheduleOrderNow(db, orderId, delaySec = 20) {
  const now = Math.floor(Date.now() / 1000);
  const order = await db.get(`SELECT * FROM jasa_orders WHERE order_id = ? AND status = 'active'`, orderId);
  if (!order) return;
  const floor = earliestNextRun(order);
  if (floor > 0) {
    if (!order.next_run_at || order.next_run_at < floor) {
      await db.run(`UPDATE jasa_orders SET next_run_at = ?, updated_at = ? WHERE order_id = ?`, floor, now, orderId);
    }
    return;
  }
  const next = await computeSafeNextRun(db, orderId, now + delaySec);
  await db.run(
    `UPDATE jasa_orders SET next_run_at = ?, updated_at = ? WHERE order_id = ? AND status = 'active'`,
    next, now, orderId
  );
}

module.exports = {
  JASA_CONFIG,
  calculatePrice,
  initJasaTables,
  formatOrderSummary,
  getAvailableSenders,
  getPoolGroupCapacity,
  getSenderFreeCaps,
  planOrderCapacity,
  assignGroupsToOrder,
  computeSafeNextRun,
  activateOrder,
  createPendingOrder,
  markPaidAndActivate,
  getUserOrders,
  getActiveOrders,
  getUserActiveOrder,
  expireDueOrders,
  retryStuckPaidOrders,
  addShareLog,
  getShareLogs,
  saveSenderGroups,
  isMandatoryGroup,
  recoverInterruptedRounds,
  freeGroupsForSender,
  fillSenderGroups,
  takeReplacementGroup,
  getOrderSenders,
  getSenderBatch,
  replaceSender,
  healOrder,
  markGroupBad,
  markGroupResult,
  scheduleOrderNow,
  syncAssignedCount,
  editOrderAccess,
  grantOrderAccess,
  jedaSecOf,
  earliestNextRun,
  estimateRoundSec,
  rebalanceSchedules,
};
