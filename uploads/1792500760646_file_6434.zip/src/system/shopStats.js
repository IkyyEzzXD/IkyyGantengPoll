const mongoAdapter = require('../storage/mongoAdapter');

const DOC_ID = 'shop_stats';
const FIELDS = ['ordersCompleted', 'incomeTotal', 'depositTotal'];
const FLUSH_DELAY_MS = 50;

const data = { ordersCompleted: 0, incomeTotal: 0, depositTotal: 0 };
let pending = { ordersCompleted: 0, incomeTotal: 0, depositTotal: 0 };
let inflight = { ordersCompleted: 0, incomeTotal: 0, depositTotal: 0 };

let loaded = false;
let loading = null;
let flushTimer = null;
let flushing = null;

function zero() {
  return { ordersCompleted: 0, incomeTotal: 0, depositTotal: 0 };
}

function toNum(v) {
  if (typeof v === 'number') return Number.isFinite(v) ? v : 0;
  const cleaned = String(v == null ? '' : v).replace(/[^\d-]/g, '');
  const n = parseInt(cleaned, 10);
  return Number.isFinite(n) ? n : 0;
}

function hasDelta(d) {
  return FIELDS.some((f) => d[f] !== 0);
}

async function flushNow() {
  if (flushing) return flushing;
  if (!hasDelta(pending)) return;
  flushing = (async () => {
    const batch = pending;
    pending = zero();
    inflight = batch;
    try {
      const db = mongoAdapter.getDatabase();
      if (!db) throw new Error('database belum siap');
      const $inc = {};
      for (const f of FIELDS) if (batch[f] !== 0) $inc[f] = batch[f];
      await db.collection('kv_store').updateOne(
        { _id: DOC_ID },
        { $inc, $set: { updatedAt: Date.now() } },
        { upsert: true }
      );
      inflight = zero();
    } catch (e) {
      for (const f of FIELDS) pending[f] += batch[f];
      inflight = zero();
      console.error('[shopStats] save gagal:', e.message);
      scheduleFlush(2000);
    } finally {
      flushing = null;
    }
  })();
  return flushing;
}

function scheduleFlush(delay = FLUSH_DELAY_MS) {
  if (flushTimer) return;
  flushTimer = setTimeout(() => {
    flushTimer = null;
    flushNow().catch(() => {});
  }, delay);
  if (typeof flushTimer.unref === 'function') flushTimer.unref();
}

async function loadAsync() {
  if (loading) return loading;
  loading = (async () => {
    try {
      if (flushing) await flushing.catch(() => {});
      const db = mongoAdapter.getDatabase();
      if (!db) return;
      const doc = await db.collection('kv_store').findOne({ _id: DOC_ID });
      for (const f of FIELDS) {
        data[f] = Math.max(0, toNum(doc && doc[f])) + pending[f] + inflight[f];
      }
      loaded = true;
    } catch (e) {
      console.error('[shopStats] load gagal:', e.message);
    } finally {
      loading = null;
    }
  })();
  return loading;
}

function ensureLoaded() {
  if (loaded || loading) return;
  loadAsync().catch(() => {});
}

function add(field, amount) {
  ensureLoaded();
  data[field] += amount;
  pending[field] += amount;
  scheduleFlush();
}

function recordOrderCompleted() {
  add('ordersCompleted', 1);
}

function recordIncome(amount) {
  const n = toNum(amount);
  if (n <= 0) return;
  add('incomeTotal', n);
}

function recordDeposit(amount) {
  const n = toNum(amount);
  if (n <= 0) return;
  add('depositTotal', n);
}

function getStats() {
  ensureLoaded();
  return {
    ordersCompleted: data.ordersCompleted,
    incomeTotal: data.incomeTotal,
    depositTotal: data.depositTotal
  };
}

function rebuildFromTransactions(transactions) {
  ensureLoaded();
  if (!Array.isArray(transactions)) return getStats();
  let income = 0;
  let orders = 0;
  let deposit = 0;
  for (const t of transactions) {
    if (!t) continue;
    const details = String(t.details || '');
    const amount = toNum(t.amount);
    if (t.type === 'DEPOSIT') {
      if (/^(deposit_manual|deposit_otomatis_pakasir)$/.test(details)) deposit += amount;
    } else if (t.type === 'PURCHASE') {
      if (/^(purchase_|product_|product:|auto_renew_)/.test(details)) {
        orders += 1;
        income += amount;
      }
    }
  }
  let changed = false;
  if (loaded) {
    if (income > data.incomeTotal) { pending.incomeTotal += income - data.incomeTotal; data.incomeTotal = income; changed = true; }
    if (orders > data.ordersCompleted) { pending.ordersCompleted += orders - data.ordersCompleted; data.ordersCompleted = orders; changed = true; }
    if (deposit > data.depositTotal) { pending.depositTotal += deposit - data.depositTotal; data.depositTotal = deposit; changed = true; }
    if (changed) scheduleFlush();
  }
  return getStats();
}

async function initFromMongo() {
  await loadAsync();
}

async function flush() {
  if (flushTimer) {
    clearTimeout(flushTimer);
    flushTimer = null;
  }
  await flushNow();
}

module.exports = {
  recordOrderCompleted,
  recordIncome,
  recordDeposit,
  rebuildFromTransactions,
  getStats,
  initFromMongo,
  flush
};
