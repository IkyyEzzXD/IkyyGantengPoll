const fs = require('fs');

const RETRY_AFTER_MAX_MS = 15000;
const RETRY_AFTER_DEFAULT_MS = 1000;
const MAX_429_ATTEMPTS = 3;

const LOCK_CACHE_TTL_MS = 8000;
const LOCK_CACHE_MAX_ENTRIES = 20000;

function extractRetryAfterMs(err) {
  if (!err) return null;
  const candidates = [
    err.response && err.response.body && err.response.body.parameters && err.response.body.parameters.retry_after,
    err.parameters && err.parameters.retry_after,
    err.error && err.error.parameters && err.error.parameters.retry_after,
  ];
  for (const c of candidates) {
    const n = Number(c);
    if (Number.isFinite(n) && n > 0) return Math.min(n * 1000, RETRY_AFTER_MAX_MS);
  }
  const text = `${(err && err.message) || ''} ${(err && err.description) || ''}`;
  const m = /retry after (\d+)/i.exec(text);
  if (m) return Math.min(Number(m[1]) * 1000, RETRY_AFTER_MAX_MS);
  if (/too many requests|\b429\b/i.test(text)) return RETRY_AFTER_DEFAULT_MS;
  const code = (err.response && err.response.statusCode) || err.statusCode;
  if (Number(code) === 429) return RETRY_AFTER_DEFAULT_MS;
  return null;
}

function wrapFloodRetry(bot, methodNames) {
  for (const name of methodNames) {
    const original = bot[name];
    if (typeof original !== 'function') continue;
    bot[name] = async function (...args) {
      let lastErr;
      for (let attempt = 1; attempt <= MAX_429_ATTEMPTS; attempt++) {
        try {
          return await original.apply(bot, args);
        } catch (err) {
          lastErr = err;
          const waitMs = extractRetryAfterMs(err);
          if (waitMs === null || attempt >= MAX_429_ATTEMPTS) throw err;
          await new Promise((r) => setTimeout(r, waitMs + Math.floor(Math.random() * 150)));
        }
      }
      throw lastErr;
    };
  }
}

const lockCache = new Map();

function lockCacheGet(userId) {
  const e = lockCache.get(String(userId));
  if (!e) return undefined;
  if (Date.now() - e.ts > LOCK_CACHE_TTL_MS) {
    lockCache.delete(String(userId));
    return undefined;
  }
  return e.value;
}

function lockCacheSet(userId, value) {
  const k = String(userId);
  if (lockCache.size >= LOCK_CACHE_MAX_ENTRIES) {
    const oldest = lockCache.keys().next().value;
    if (oldest !== undefined) lockCache.delete(oldest);
  }
  lockCache.set(k, { value, ts: Date.now() });
}

function lockCacheInvalidate(userId) {
  lockCache.delete(String(userId));
}

function lockCacheClear() {
  lockCache.clear();
}

function watchSettingsWrites(db) {
  if (!db || db.__stabilityWatched) return db;
  const originalRun = db.run.bind(db);
  db.run = async function (sql, ...params) {
    const result = await originalRun(sql, ...params);
    try {
      const text = typeof sql === 'string' ? sql : '';
      if (/\bsettings\b/i.test(text) && /\b(update|insert|delete|replace)\b/i.test(text)) {
        const flat = params.length === 1 && Array.isArray(params[0]) ? params[0] : params;
        const last = flat[flat.length - 1];
        if (last !== undefined && last !== null && /owner_id\s*=\s*\?\s*$/i.test(text.trim().replace(/;$/, ''))) {
          lockCacheInvalidate(last);
        } else {
          lockCacheClear();
        }
      }
    } catch (_) {
      lockCacheClear();
    }
    return result;
  };
  db.__stabilityWatched = true;
  return db;
}

function writeJsonAtomic(filePath, data) {
  const tmp = `${filePath}.${process.pid}.tmp`;
  try {
    fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
    fs.renameSync(tmp, filePath);
  } catch (err) {
    try { fs.unlinkSync(tmp); } catch (_) {}
    throw err;
  }
}

function stats() {
  return {
    lockCache: lockCache.size,
  };
}

module.exports = {
  extractRetryAfterMs,
  wrapFloodRetry,
  lockCacheGet,
  lockCacheSet,
  lockCacheInvalidate,
  lockCacheClear,
  watchSettingsWrites,
  writeJsonAtomic,
  stats,
};
