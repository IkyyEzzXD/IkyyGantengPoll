// =====================================================================
// SISTEM RETENSI — streak, misi harian/mingguan, auto-renew, leaderboard,
// notifikasi expiry pintar, first-purchase discount tracking.
// Data disimpan di database/retention.json (pola JSON file, konsisten
// dengan referral.json / produk_balance.json).
// =====================================================================

const { createKvDoc } = require('./kvDoc');

const RETENTION_DOC_ID = 'retention';

// --- Konfigurasi (mudah diubah) ---
// Hadiah saldo (streak/misi/leaderboard) dikurangi ~30% dari nilai sebelumnya.
// Hadiah referral (REFERRAL_REWARD / CONTEST di referral.js) TIDAK diubah.
const CONFIG = {
  // Streak
  STREAK_REWARD_SALDO: 350,           // reward tiap hari streak (Rp) — was 500
  STREAK_BONUS_7DAY: 2100,            // bonus ekstra saat streak 7 hari — was 3000
  STREAK_BONUS_30DAY: 10500,          // bonus ekstra saat streak 30 hari — was 15000
  STREAK_RESET_HOURS: 36,             // jika tidak aktif > 36 jam, streak reset

  // Misi harian
  DAILY_MISSIONS: [
    { id: 'share_1',   label: 'Jalankan 1x promosi',          target: 1,  reward: 210  }, // was 300
    { id: 'share_3',   label: 'Jalankan 3x promosi',          target: 3,  reward: 700  }, // was 1000
    { id: 'deposit_1', label: 'Deposit minimal Rp 5.000',     target: 1,  reward: 350  }, // was 500
  ],
  // Misi mingguan
  WEEKLY_MISSIONS: [
    { id: 'share_10',  label: 'Jalankan 10x promosi minggu ini', target: 10, reward: 3500 }, // was 5000
    { id: 'invite_2',  label: 'Invite 2 teman sukses',           target: 2,  reward: 2100 }, // was 3000
  ],

  // Expiry reminder
  EXPIRY_REMIND_HOURS: [72, 24, 6],   // kirim notif di sisa jam ini
  EXPIRY_DISCOUNT_PCT: 15,            // diskon % kalau perpanjang sebelum expired
  EXPIRY_DISCOUNT_WINDOW_HOURS: 72,   // window diskon sebelum expired

  // Auto-renew
  AUTO_RENEW_MIN_SALDO: 1000,         // minimal saldo untuk auto-renew jalan

  // Leaderboard
  LEADERBOARD_TOP: 10,
  LEADERBOARD_REWARD: [3500, 2100, 1050], // hadiah top 1-3 (saldo) — was [5000, 3000, 1500]
};

function defaultData() {
  return {
    // streaks[userId] = { count, lastActiveAt, lastRewardAt, totalRewards }
    streaks: {},
    // missions[userId] = { daily: { date, progress:{}, claimed:{} }, weekly: { week, progress:{}, claimed:{} } }
    missions: {},
    // autoRenew[userId] = { enabled: bool, packageType: 'wm'|'nowm', durationMonths: number }
    autoRenew: {},
    // expiryNotified[userId] = { [hours]: timestamp }  // biar tidak spam
    expiryNotified: {},
    // firstPurchase[userId] = true  // sudah pernah beli paket
    firstPurchase: {},
    // promoRuns[userId] = { daily: {date, count}, weekly: {week, count}, total: number }
    promoRuns: {},
    // leaderboardWeek = { weekKey, scores: {userId: score}, rewardsPaid: bool }
    leaderboardWeek: { weekKey: '', scores: {}, rewardsPaid: false },
    leaderboardHistory: {},
    // depositCashbackLog: [{userId, amount, cashback, at}]
    depositCashbackLog: [],
  };
}

function isPlainObject(v) {
  return !!v && typeof v === 'object' && !Array.isArray(v);
}

function normalizeData(payload) {
  const out = Object.assign(defaultData(), isPlainObject(payload) ? payload : {});
  const template = defaultData();
  for (const key of Object.keys(template)) {
    if (Array.isArray(template[key])) {
      if (!Array.isArray(out[key])) out[key] = [];
    } else if (!isPlainObject(out[key])) {
      out[key] = template[key];
    }
  }
  return out;
}

function mergeOverlay(base, mem) {
  for (const [key, value] of Object.entries(mem)) {
    if (key === 'leaderboardWeek') {
      const b = base.leaderboardWeek;
      if (b && value && b.weekKey === value.weekKey) {
        if (!b.scores) b.scores = {};
        for (const [uid, n] of Object.entries(value.scores || {})) {
          b.scores[uid] = (Number(b.scores[uid]) || 0) + (Number(n) || 0);
        }
      }
      continue;
    }
    if (Array.isArray(value)) {
      if (!Array.isArray(base[key])) base[key] = [];
      base[key] = base[key].concat(value);
      continue;
    }
    if (isPlainObject(value)) {
      if (!isPlainObject(base[key])) base[key] = {};
      for (const [k, v] of Object.entries(value)) {
        if (base[key][k] === undefined) base[key][k] = v;
      }
    }
  }
  return base;
}

const store = createKvDoc({
  id: RETENTION_DOC_ID,
  label: 'retention',
  create: defaultData,
  normalize: normalizeData,
  merge: mergeOverlay
});

const data = store.data;

function load() {
  store.load();
}

function save() {
  store.markDirty();
}

load();

// ---------- helpers tanggal ----------
function todayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function weekKey() {
  const d = new Date();
  // ISO week roughly: year + week number
  const oneJan = new Date(d.getFullYear(), 0, 1);
  const week = Math.ceil((((d - oneJan) / 86400000) + oneJan.getDay() + 1) / 7);
  return `${d.getFullYear()}-W${String(week).padStart(2, '0')}`;
}

function hoursUntil(tsSeconds) {
  if (!tsSeconds) return null;
  return (tsSeconds * 1000 - Date.now()) / 3600000;
}

// ---------- STREAK ----------
function recordActivity(userId) {
  load();
  userId = String(userId);
  const now = Date.now();
  let s = data.streaks[userId];
  if (!s) {
    s = { count: 0, lastActiveAt: 0, lastRewardAt: 0, totalRewards: 0 };
    data.streaks[userId] = s;
  }

  const hoursSince = s.lastActiveAt ? (now - s.lastActiveAt) / 3600000 : 999;
  if (hoursSince > CONFIG.STREAK_RESET_HOURS) {
    s.count = 0;
  }

  // Hanya naikkan streak 1x per hari kalender
  const lastDay = s.lastActiveAt ? new Date(s.lastActiveAt).toDateString() : '';
  const today = new Date(now).toDateString();
  let rewarded = 0;
  if (lastDay !== today) {
    s.count += 1;
    s.lastActiveAt = now;

    // reward harian
    rewarded = CONFIG.STREAK_REWARD_SALDO;
    if (s.count === 7) rewarded += CONFIG.STREAK_BONUS_7DAY;
    if (s.count === 30) rewarded += CONFIG.STREAK_BONUS_30DAY;
    s.lastRewardAt = now;
    s.totalRewards = (s.totalRewards || 0) + rewarded;
  } else {
    s.lastActiveAt = now;
  }

  save();
  return { streak: s.count, reward: rewarded };
}

function getStreak(userId) {
  load();
  const s = data.streaks[String(userId)];
  if (!s) return { count: 0, lastActiveAt: 0, totalRewards: 0 };
  // cek apakah sudah reset
  const hoursSince = s.lastActiveAt ? (Date.now() - s.lastActiveAt) / 3600000 : 999;
  if (hoursSince > CONFIG.STREAK_RESET_HOURS) {
    return { count: 0, lastActiveAt: s.lastActiveAt, totalRewards: s.totalRewards || 0 };
  }
  return { count: s.count || 0, lastActiveAt: s.lastActiveAt, totalRewards: s.totalRewards || 0 };
}

// ---------- PROMO RUNS (untuk misi + leaderboard) ----------
function recordPromoRun(userId) {
  load();
  userId = String(userId);
  const day = todayKey();
  const week = weekKey();
  if (!data.promoRuns[userId]) {
    data.promoRuns[userId] = { daily: { date: day, count: 0 }, weekly: { week, count: 0 }, total: 0 };
  }
  const pr = data.promoRuns[userId];
  if (pr.daily.date !== day) pr.daily = { date: day, count: 0 };
  if (pr.weekly.week !== week) pr.weekly = { week, count: 0 };
  pr.daily.count += 1;
  pr.weekly.count += 1;
  pr.total = (pr.total || 0) + 1;

  _rollLeaderboardWeek(week);
  data.leaderboardWeek.scores[userId] = (data.leaderboardWeek.scores[userId] || 0) + 1;

  // progress misi
  _bumpMission(userId, 'share_1', 1);
  _bumpMission(userId, 'share_3', 1);
  _bumpMission(userId, 'share_10', 1);

  save();
  return pr;
}

function recordDeposit(userId, amount) {
  load();
  userId = String(userId);
  if (amount >= 5000) {
    _bumpMission(userId, 'deposit_1', 1);
  }
  save();
}

function recordInviteSuccess(userId) {
  load();
  _bumpMission(String(userId), 'invite_2', 1);
  save();
}

function _bumpMission(userId, missionId, by = 1) {
  if (!data.missions[userId]) {
    data.missions[userId] = {
      daily: { date: todayKey(), progress: {}, claimed: {} },
      weekly: { week: weekKey(), progress: {}, claimed: {} }
    };
  }
  const m = data.missions[userId];
  const day = todayKey();
  const week = weekKey();
  if (m.daily.date !== day) m.daily = { date: day, progress: {}, claimed: {} };
  if (m.weekly.week !== week) m.weekly = { week, progress: {}, claimed: {} };

  const isDaily = CONFIG.DAILY_MISSIONS.some(x => x.id === missionId);
  const bucket = isDaily ? m.daily : m.weekly;
  bucket.progress[missionId] = (bucket.progress[missionId] || 0) + by;
}

function getMissions(userId) {
  load();
  userId = String(userId);
  if (!data.missions[userId]) {
    data.missions[userId] = {
      daily: { date: todayKey(), progress: {}, claimed: {} },
      weekly: { week: weekKey(), progress: {}, claimed: {} }
    };
    save();
  }
  const m = data.missions[userId];
  const day = todayKey();
  const week = weekKey();
  if (m.daily.date !== day) m.daily = { date: day, progress: {}, claimed: {} };
  if (m.weekly.week !== week) m.weekly = { week, progress: {}, claimed: {} };

  const daily = CONFIG.DAILY_MISSIONS.map(ms => ({
    ...ms,
    progress: m.daily.progress[ms.id] || 0,
    claimed: !!m.daily.claimed[ms.id],
    done: (m.daily.progress[ms.id] || 0) >= ms.target
  }));
  const weekly = CONFIG.WEEKLY_MISSIONS.map(ms => ({
    ...ms,
    progress: m.weekly.progress[ms.id] || 0,
    claimed: !!m.weekly.claimed[ms.id],
    done: (m.weekly.progress[ms.id] || 0) >= ms.target
  }));
  return { daily, weekly };
}

/** Claim misi. Return { ok, reward, message } */
function claimMission(userId, missionId) {
  load();
  userId = String(userId);
  const all = [...CONFIG.DAILY_MISSIONS, ...CONFIG.WEEKLY_MISSIONS];
  const ms = all.find(x => x.id === missionId);
  if (!ms) return { ok: false, reward: 0, message: 'Misi tidak ditemukan' };

  const m = data.missions[userId];
  if (!m) return { ok: false, reward: 0, message: 'Belum ada progress' };

  const isDaily = CONFIG.DAILY_MISSIONS.some(x => x.id === missionId);
  const bucket = isDaily ? m.daily : m.weekly;
  const day = todayKey();
  const week = weekKey();
  if (isDaily && bucket.date !== day) return { ok: false, reward: 0, message: 'Misi harian sudah reset' };
  if (!isDaily && bucket.week !== week) return { ok: false, reward: 0, message: 'Misi mingguan sudah reset' };

  if (bucket.claimed[missionId]) return { ok: false, reward: 0, message: 'Sudah diklaim' };
  if ((bucket.progress[missionId] || 0) < ms.target) return { ok: false, reward: 0, message: 'Target belum tercapai' };

  bucket.claimed[missionId] = true;
  save();
  return { ok: true, reward: ms.reward, message: `Klaim berhasil +Rp ${ms.reward.toLocaleString('id-ID')}` };
}

function unclaimMission(userId, missionId) {
  load();
  const m = data.missions[String(userId)];
  if (!m) return false;
  const isDaily = CONFIG.DAILY_MISSIONS.some(x => x.id === missionId);
  const bucket = isDaily ? m.daily : m.weekly;
  if (!bucket || !bucket.claimed || !bucket.claimed[missionId]) return false;
  delete bucket.claimed[missionId];
  save();
  return true;
}

// ---------- AUTO-RENEW ----------
function setAutoRenew(userId, enabled, packageType = 'wm', durationMonths = 1) {
  load();
  userId = String(userId);
  data.autoRenew[userId] = {
    enabled: !!enabled,
    packageType: packageType === 'nowm' ? 'nowm' : 'wm',
    durationMonths: Math.max(1, Math.min(5, Number(durationMonths) || 1)),
    updatedAt: Date.now()
  };
  save();
  return data.autoRenew[userId];
}

function getAutoRenew(userId) {
  load();
  return data.autoRenew[String(userId)] || { enabled: false, packageType: 'wm', durationMonths: 1 };
}

function getAllAutoRenewEnabled() {
  load();
  return Object.entries(data.autoRenew)
    .filter(([, v]) => v && v.enabled)
    .map(([uid, v]) => ({ userId: uid, ...v }));
}

// ---------- EXPIRY NOTIFY ----------
function shouldNotifyExpiry(userId, expiredTsSeconds) {
  load();
  userId = String(userId);
  const hoursLeft = hoursUntil(expiredTsSeconds);
  if (hoursLeft === null || hoursLeft < 0) return null;

  if (!data.expiryNotified[userId]) data.expiryNotified[userId] = {};

  for (const h of CONFIG.EXPIRY_REMIND_HOURS) {
    // window: antara h dan h-1 jam (supaya tidak miss)
    if (hoursLeft <= h && hoursLeft > h - 1) {
      if (data.expiryNotified[userId][String(h)]) continue;
      data.expiryNotified[userId][String(h)] = Date.now();
      save();
      return { hours: h, hoursLeft, discountPct: CONFIG.EXPIRY_DISCOUNT_PCT };
    }
  }
  return null;
}

// Pemberitahuan "saldo kurang untuk auto-renew": cukup SEKALI per tanggal habis,
// supaya job 30-menitan tidak mengirim pesan berulang.
function shouldNotifyAutoRenewFail(userId, expiredTsSeconds) {
  load();
  userId = String(userId);
  if (!data.autoRenewFailNotified) data.autoRenewFailNotified = {};
  const key = String(expiredTsSeconds);
  if (data.autoRenewFailNotified[userId] === key) return false;
  data.autoRenewFailNotified[userId] = key;
  save();
  return true;
}

function clearExpiryNotified(userId) {
  load();
  delete data.expiryNotified[String(userId)];
  save();
}

function getExpiryDiscount(userId, expiredTsSeconds) {
  const hoursLeft = hoursUntil(expiredTsSeconds);
  if (hoursLeft === null || hoursLeft < 0) return 0;
  if (hoursLeft <= CONFIG.EXPIRY_DISCOUNT_WINDOW_HOURS) {
    return CONFIG.EXPIRY_DISCOUNT_PCT;
  }
  return 0;
}

// ---------- FIRST PURCHASE ----------
function hasFirstPurchase(userId) {
  load();
  return !!data.firstPurchase[String(userId)];
}

function markFirstPurchase(userId) {
  load();
  data.firstPurchase[String(userId)] = true;
  save();
}

// Dipakai saat pembelian dibatalkan (rollback) supaya diskon pembelian pertama
// tidak hangus gara-gara pembelian yang akhirnya gagal.
function clearFirstPurchase(userId) {
  load();
  if (data.firstPurchase[String(userId)]) {
    delete data.firstPurchase[String(userId)];
    save();
  }
}

// ---------- LEADERBOARD ----------
const LEADERBOARD_HISTORY_KEEP = 8;

function _rollLeaderboardWeek(week) {
  const cur = data.leaderboardWeek;
  if (cur && cur.weekKey === week) return false;
  if (cur && cur.weekKey && Object.keys(cur.scores || {}).length > 0) {
    if (!data.leaderboardHistory) data.leaderboardHistory = {};
    data.leaderboardHistory[cur.weekKey] = {
      scores: cur.scores,
      rewardsPaid: !!cur.rewardsPaid,
      paidUsers: cur.paidUsers || {},
    };
    const keys = Object.keys(data.leaderboardHistory).sort();
    while (keys.length > LEADERBOARD_HISTORY_KEEP) delete data.leaderboardHistory[keys.shift()];
  }
  data.leaderboardWeek = { weekKey: week, scores: {}, rewardsPaid: false, paidUsers: {} };
  return true;
}

function _rankScores(scores, limit) {
  return Object.entries(scores || {})
    .map(([uid, score]) => ({ userId: uid, score: Number(score) || 0 }))
    .filter((e) => e.score > 0)
    .sort((a, b) => (b.score - a.score) || (a.userId < b.userId ? -1 : a.userId > b.userId ? 1 : 0))
    .slice(0, limit);
}

function getLeaderboard(limit = CONFIG.LEADERBOARD_TOP) {
  load();
  const week = weekKey();
  if (_rollLeaderboardWeek(week)) save();
  const entries = _rankScores(data.leaderboardWeek.scores, limit);
  return { weekKey: week, entries, rewardsPaid: !!data.leaderboardWeek.rewardsPaid };
}

function getUnpaidLeaderboardWeeks() {
  load();
  if (_rollLeaderboardWeek(weekKey())) save();
  const out = [];
  const history = data.leaderboardHistory || {};
  for (const wk of Object.keys(history).sort()) {
    const h = history[wk];
    if (!h || h.rewardsPaid) continue;
    const winners = _rankScores(h.scores, CONFIG.LEADERBOARD_REWARD.length).map((e, i) => ({
      userId: e.userId,
      score: e.score,
      rank: i + 1,
      amount: CONFIG.LEADERBOARD_REWARD[i],
      paid: !!(h.paidUsers && h.paidUsers[e.userId]),
    }));
    out.push({ weekKey: wk, winners });
  }
  return out;
}

function recordLeaderboardPayout(wk, userId, amount) {
  load();
  const h = data.leaderboardHistory && data.leaderboardHistory[wk];
  if (!h) return false;
  if (!h.paidUsers) h.paidUsers = {};
  h.paidUsers[String(userId)] = amount;
  save();
  return true;
}

function markLeaderboardRewardsPaid(wk) {
  load();
  if (wk && data.leaderboardHistory && data.leaderboardHistory[wk]) {
    data.leaderboardHistory[wk].rewardsPaid = true;
  } else if (!wk || data.leaderboardWeek.weekKey === wk) {
    data.leaderboardWeek.rewardsPaid = true;
  }
  save();
}

// ---------- CASHBACK LOG ----------
function logCashback(userId, amount, cashback) {
  load();
  data.depositCashbackLog.push({
    userId: String(userId),
    amount,
    cashback,
    at: Date.now()
  });
  if (data.depositCashbackLog.length > 500) {
    data.depositCashbackLog = data.depositCashbackLog.slice(-300);
  }
  save();
}

function getCashbackConfig() {
  // threshold → persen cashback
  return [
    { min: 100000, pct: 10 },
    { min: 50000,  pct: 5 },
    { min: 20000,  pct: 3 },
  ];
}

function calcCashback(amount) {
  const rules = getCashbackConfig();
  for (const r of rules) {
    if (amount >= r.min) return Math.floor(amount * r.pct / 100);
  }
  return 0;
}

async function reloadFromMongo() {
  await store.reload();
}

async function flush() {
  await store.flush();
}

module.exports = {
  reloadFromMongo,
  flush,

  CONFIG,
  recordActivity,
  getStreak,
  recordPromoRun,
  recordDeposit,
  recordInviteSuccess,
  getMissions,
  claimMission,
  unclaimMission,
  setAutoRenew,
  getAutoRenew,
  getAllAutoRenewEnabled,
  shouldNotifyExpiry,
  clearExpiryNotified,
  shouldNotifyAutoRenewFail,
  getExpiryDiscount,
  hasFirstPurchase,
  markFirstPurchase,
  clearFirstPurchase,
  getLeaderboard,
  getUnpaidLeaderboardWeeks,
  recordLeaderboardPayout,
  markLeaderboardRewardsPaid,
  logCashback,
  calcCashback,
  getCashbackConfig,
  todayKey,
  weekKey,
};
