const { Api, TelegramClient } = require('telegram');
const { StringSession } = require('telegram/sessions');
const jasaSebar = require('./jasaSebar');
const senderScheduler = require('./senderScheduler');

const GROUP_ID = jasaSebar.JASA_CONFIG.MANDATORY_GROUP_ID;
const GROUP_USERNAME = jasaSebar.JASA_CONFIG.MANDATORY_GROUP_USERNAME;
const GROUP_CHANNEL_ID = GROUP_ID.replace(/^-100/, '');
const MEMBER_CACHE_TTL_MS = 6 * 3600 * 1000;
const MEMBER_CACHE_MAX = 2000;

const memberCache = new Map();

function errText(err) {
  return String((err && (err.errorMessage || err.message)) || err || 'unknown');
}

function describeError(raw) {
  const m = String(raw || '').toUpperCase();
  const flood = m.match(/FLOOD_WAIT_(\d+)/) || m.match(/A WAIT OF (\d+) SECONDS/);
  if (flood) return `limit join ${flood[1]} detik`;
  if (m.includes('USER_BANNED_IN_CHANNEL')) return 'akun diblokir di grup';
  if (m.includes('CHANNELS_TOO_MUCH')) return 'akun sudah join terlalu banyak grup';
  if (m.includes('INVITE_REQUEST_SENT')) return 'menunggu persetujuan admin grup';
  if (m.includes('GROUP_MISMATCH')) return 'username tidak cocok dengan id grup';
  if (m.includes('USERNAME_NOT_OCCUPIED') || m.includes('USERNAME_INVALID') || m.includes('CHANNEL_INVALID')) return 'grup tidak ditemukan';
  if (m.includes('AUTH_KEY') || m.includes('SESSION_REVOKED') || m.includes('SESSION_EXPIRED') || m.includes('USER_DEACTIVATED')) return 'sesi sender tidak valid';
  if (m.includes('TIMEOUT')) return 'koneksi timeout';
  return String(raw || 'error').replace(/\s+/g, ' ').slice(0, 60);
}

function pruneCache() {
  if (memberCache.size <= MEMBER_CACHE_MAX) return;
  const cutoff = Date.now() - MEMBER_CACHE_TTL_MS;
  for (const [key, at] of memberCache) {
    if (at < cutoff) memberCache.delete(key);
  }
  if (memberCache.size > MEMBER_CACHE_MAX) memberCache.clear();
}

async function resolvePeer(client) {
  const peer = await client.getInputEntity(GROUP_USERNAME);
  if (!peer || String(peer.channelId) !== GROUP_CHANNEL_ID) {
    throw new Error('GROUP_MISMATCH');
  }
  return peer;
}

async function isMember(client, peer) {
  try {
    const res = await client.invoke(new Api.channels.GetParticipant({ channel: peer, participant: 'me' }));
    const part = res && res.participant;
    const cls = part && part.className;
    if (cls === 'ChannelParticipantLeft') return false;
    if (cls === 'ChannelParticipantBanned') return !part.left;
    return true;
  } catch (err) {
    if (errText(err).toUpperCase().includes('USER_NOT_PARTICIPANT')) return false;
    throw err;
  }
}

async function ensureMember(client, senderId, opts = {}) {
  const key = String(senderId);
  if (!opts.force) {
    const at = memberCache.get(key);
    if (at && Date.now() - at < MEMBER_CACHE_TTL_MS) return { ok: true, joined: false };
  }
  try {
    const peer = await resolvePeer(client);
    if (await isMember(client, peer)) {
      memberCache.set(key, Date.now());
      pruneCache();
      return { ok: true, joined: false };
    }
    try {
      await client.invoke(new Api.channels.JoinChannel({ channel: peer }));
    } catch (err) {
      if (!errText(err).toUpperCase().includes('USER_ALREADY_PARTICIPANT')) throw err;
    }
    memberCache.set(key, Date.now());
    pruneCache();
    return { ok: true, joined: true };
  } catch (err) {
    memberCache.delete(key);
    return { ok: false, joined: false, reason: describeError(errText(err)) };
  }
}

async function ensureForSession(senderId, sessionString, opts = {}) {
  const config = require('../setting/config');
  return senderScheduler.withSenderLock(String(senderId), async () => {
    let client = null;
    try {
      client = new TelegramClient(new StringSession(sessionString), config.API_ID, config.API_HASH, config.getTelegramClientConfig());
      await client.connect();
      return await ensureMember(client, senderId, { force: opts.force !== false });
    } catch (err) {
      return { ok: false, joined: false, reason: describeError(errText(err)) };
    } finally {
      if (client) {
        try { await client.disconnect(); } catch (e) {}
      }
    }
  });
}

function forget(senderId) {
  memberCache.delete(String(senderId));
}

function describe(result) {
  if (!result) return '';
  if (result.ok && result.joined) return `✅ Join @${GROUP_USERNAME} berhasil`;
  if (result.ok) return `✅ Sudah di @${GROUP_USERNAME}`;
  return `⚠️ Gagal join @${GROUP_USERNAME}: ${result.reason}`;
}

module.exports = {
  GROUP_ID,
  GROUP_USERNAME,
  resolvePeer,
  ensureMember,
  ensureForSession,
  forget,
  describe,
};
