/**
 * accountManager.js
 * Pengelola akun userbot secara terpusat.
 * Tujuan: isolasi per-akun (satu akun bermasalah tidak menular),
 * health-check, cleanup, dan batas beban.
 */

const lazyUbot = require('./lazyUbot');
const { mapPool, withLock } = require('./concurrency');

/** Referensi ke array userbots di index (di-set saat boot). */
let userbotsRef = null;
let logger = console;

function setUserbotsRef(arr) {
  userbotsRef = arr;
}

function setLogger(l) {
  logger = l || console;
  if (lazyUbot.setLogger) lazyUbot.setLogger(l);
}

function list() {
  return userbotsRef || [];
}

function findByOwner(ownerId) {
  const id = String(ownerId);
  return list().find((u) => String(u.owner_id) === id) || null;
}

function findByUbotId(ubotId) {
  const id = String(ubotId);
  return list().find((u) => String(u.id) === id || String(u.ubot_id) === id) || null;
}

/**
 * Jalankan fn hanya untuk satu owner, dengan lock.
 * Mencegah dua operasi berat (promo + sync grup) tabrakan di akun yang sama.
 */
async function withAccountLock(ownerId, fn) {
  return withLock(`acct:${ownerId}`, fn);
}

/**
 * Health snapshot satu akun.
 */
function healthOf(ownerId) {
  const ub = findByOwner(ownerId);
  if (!ub) return { exists: false };
  const st = lazyUbot.getStatus(String(ownerId)) || {};
  return {
    exists: true,
    ownerId: String(ownerId),
    status: ub.status,
    connected: !!st.connected,
    pinned: (st.pinCount || 0) > 0,
    dead: !!st.dead,
    deadReason: st.deadReason || null,
    phone: ub.phone || null,
  };
}

/**
 * Health semua akun aktif (dengan batas paralel biar tidak spike).
 */
async function healthAll(limit = 20) {
  const actives = list().filter((u) => u.status === 'AKTIF');
  return mapPool(actives, limit, async (ub) => healthOf(ub.owner_id));
}

/**
 * Disconnect idle / dead accounts secara aman (bulk).
 * Tidak menyentuh akun yang sedang di-pin (promo jalan).
 */
async function cleanupIdle(limit = 10) {
  const actives = list().filter((u) => u.status === 'AKTIF');
  let cleaned = 0;
  await mapPool(actives, limit, async (ub) => {
    const ownerId = String(ub.owner_id);
    if (lazyUbot.isDead(ownerId)) {
      try {
        lazyUbot.remove(ownerId);
        cleaned++;
      } catch (_) {}
      return;
    }
    // biarkan idle timer di lazyUbot yang memutus; di sini hanya bersihkan yang dead
  });
  return cleaned;
}

/**
 * Statistik ringkas untuk monitoring.
 */
function stats() {
  const all = list();
  const aktif = all.filter((u) => u.status === 'AKTIF').length;
  const lazyStats = lazyUbot.stats ? lazyUbot.stats() : [];
  const connected = lazyStats.filter((s) => s.connected).length;
  const dead = lazyStats.filter((s) => s.dead).length;
  const pinned = lazyStats.filter((s) => (s.pinCount || 0) > 0).length;
  return {
    totalInMemory: all.length,
    aktif,
    connected,
    dead,
    pinned,
  };
}

module.exports = {
  setUserbotsRef,
  setLogger,
  list,
  findByOwner,
  findByUbotId,
  withAccountLock,
  healthOf,
  healthAll,
  cleanupIdle,
  stats,
};
