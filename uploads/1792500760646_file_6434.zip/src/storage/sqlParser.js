const CLAUSE_WORDS = new Set([
  'WHERE', 'JOIN', 'LEFT', 'INNER', 'CROSS', 'OUTER', 'ORDER', 'GROUP', 'LIMIT', 'ON', 'UNION',
  'HAVING', 'SET', 'VALUES', 'FROM', 'AS', 'AND', 'OR', 'NOT', 'OFFSET', 'DO', 'SELECT'
]);

const AGG_FUNCS = new Set(['COUNT', 'SUM', 'AVG', 'MIN', 'MAX', 'TOTAL', 'GROUP_CONCAT']);

function tokenize(sql) {
  const out = [];
  const n = sql.length;
  let i = 0;
  while (i < n) {
    const c = sql[i];
    if (c === ' ' || c === '\n' || c === '\t' || c === '\r') {
      i++;
      continue;
    }
    if (c === '-' && sql[i + 1] === '-') {
      while (i < n && sql[i] !== '\n') i++;
      continue;
    }
    if (c === '/' && sql[i + 1] === '*') {
      const end = sql.indexOf('*/', i + 2);
      i = end < 0 ? n : end + 2;
      continue;
    }
    const start = i;
    if (c === "'" || c === '"') {
      let s = '';
      i++;
      while (i < n) {
        if (sql[i] === c) {
          if (sql[i + 1] === c) {
            s += c;
            i += 2;
            continue;
          }
          break;
        }
        s += sql[i++];
      }
      i++;
      out.push({ k: 'str', v: s, s: start, e: i });
      continue;
    }
    if (c === '`' || c === '[') {
      const close = c === '`' ? '`' : ']';
      const end = sql.indexOf(close, i + 1);
      const stop = end < 0 ? n : end;
      out.push({ k: 'id', v: sql.slice(i + 1, stop), u: sql.slice(i + 1, stop).toUpperCase(), s: start, e: stop + 1, quoted: true });
      i = stop + 1;
      continue;
    }
    if ((c >= '0' && c <= '9') || (c === '.' && sql[i + 1] >= '0' && sql[i + 1] <= '9')) {
      let j = i;
      while (j < n && ((sql[j] >= '0' && sql[j] <= '9') || sql[j] === '.')) j++;
      if ((sql[j] === 'e' || sql[j] === 'E') && /[0-9+-]/.test(sql[j + 1] || '')) {
        j += 2;
        while (j < n && sql[j] >= '0' && sql[j] <= '9') j++;
      }
      out.push({ k: 'num', v: Number(sql.slice(i, j)), s: start, e: j });
      i = j;
      continue;
    }
    if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c === '_') {
      let j = i + 1;
      while (j < n && /[A-Za-z0-9_$]/.test(sql[j])) j++;
      const v = sql.slice(i, j);
      out.push({ k: 'id', v, u: v.toUpperCase(), s: start, e: j });
      i = j;
      continue;
    }
    if (c === '?') {
      i++;
      while (i < n && sql[i] >= '0' && sql[i] <= '9') i++;
      out.push({ k: 'param', s: start, e: i });
      continue;
    }
    const two = sql.slice(i, i + 2);
    if (two === '<=' || two === '>=' || two === '<>' || two === '!=' || two === '||' || two === '==') {
      out.push({ k: 'op', v: two === '==' ? '=' : two === '<>' ? '!=' : two, s: start, e: i + 2 });
      i += 2;
      continue;
    }
    if ('=<>+-*/%(),.;'.includes(c)) {
      out.push({ k: 'op', v: c, s: start, e: i + 1 });
      i++;
      continue;
    }
    throw new Error(`SQL tidak dikenali di posisi ${i}: ${sql.slice(i, i + 20)}`);
  }
  return out;
}

class Parser {
  constructor(sql, tokens) {
    this.sql = sql;
    this.t = tokens || tokenize(sql);
    this.p = 0;
    this.paramCount = 0;
  }

  peek(o = 0) {
    return this.t[this.p + o];
  }

  next() {
    return this.t[this.p++];
  }

  eof() {
    return this.p >= this.t.length;
  }

  isKw(word, o = 0) {
    const tk = this.t[this.p + o];
    return !!tk && tk.k === 'id' && !tk.quoted && tk.u === word;
  }

  isOp(v, o = 0) {
    const tk = this.t[this.p + o];
    return !!tk && tk.k === 'op' && tk.v === v;
  }

  acceptKw(word) {
    if (this.isKw(word)) {
      this.p++;
      return true;
    }
    return false;
  }

  acceptOp(v) {
    if (this.isOp(v)) {
      this.p++;
      return true;
    }
    return false;
  }

  expectKw(word) {
    if (!this.acceptKw(word)) throw new Error(`SQL: diharapkan ${word} di dekat "${this.near()}"`);
  }

  expectOp(v) {
    if (!this.acceptOp(v)) throw new Error(`SQL: diharapkan '${v}' di dekat "${this.near()}"`);
  }

  near() {
    const tk = this.t[this.p] || this.t[this.t.length - 1];
    return tk ? this.sql.slice(tk.s, tk.s + 30) : '';
  }

  ident() {
    const tk = this.next();
    if (!tk || tk.k !== 'id') throw new Error(`SQL: identifier diharapkan di dekat "${this.near()}"`);
    return tk.v;
  }

  parseStatement() {
    const tk = this.peek();
    if (!tk || tk.k !== 'id') throw new Error('SQL kosong');
    switch (tk.u) {
      case 'SELECT': return this.parseCompound();
      case 'INSERT':
      case 'REPLACE': return this.parseInsert();
      case 'UPDATE': return this.parseUpdate();
      case 'DELETE': return this.parseDelete();
      default: throw new Error(`SQL tidak didukung: ${tk.v}`);
    }
  }

  parseCompound() {
    const first = this.parseSelect();
    const parts = [first];
    let all = false;
    while (this.isKw('UNION')) {
      this.next();
      if (this.acceptKw('ALL')) all = true;
      parts.push(this.parseSelect());
    }
    if (parts.length === 1) return first;
    return { type: 'union', parts, all };
  }

  parseSelect() {
    this.expectKw('SELECT');
    const node = {
      type: 'select', distinct: false, cols: [], from: null, joins: [],
      where: null, groupBy: [], having: null, orderBy: [], limit: null, offset: null
    };
    if (this.acceptKw('DISTINCT')) node.distinct = true;
    else this.acceptKw('ALL');
    for (;;) {
      node.cols.push(this.parseSelectCol());
      if (!this.acceptOp(',')) break;
    }
    if (this.acceptKw('FROM')) {
      node.from = this.parseTableRef();
      for (;;) {
        let jt = null;
        if (this.isKw('LEFT')) {
          this.next();
          this.acceptKw('OUTER');
          this.expectKw('JOIN');
          jt = 'left';
        } else if (this.isKw('INNER')) {
          this.next();
          this.expectKw('JOIN');
          jt = 'inner';
        } else if (this.isKw('CROSS')) {
          this.next();
          this.expectKw('JOIN');
          jt = 'inner';
        } else if (this.isKw('JOIN')) {
          this.next();
          jt = 'inner';
        } else if (this.isOp(',')) {
          this.next();
          jt = 'inner';
        }
        if (!jt) break;
        const ref = this.parseTableRef();
        let on = null;
        if (this.acceptKw('ON')) on = this.parseExpr();
        node.joins.push({ type: jt, table: ref.table, alias: ref.alias, on });
      }
    }
    if (this.acceptKw('WHERE')) node.where = this.parseExpr();
    if (this.isKw('GROUP')) {
      this.next();
      this.expectKw('BY');
      for (;;) {
        node.groupBy.push(this.parseExpr());
        if (!this.acceptOp(',')) break;
      }
    }
    if (this.acceptKw('HAVING')) node.having = this.parseExpr();
    if (this.isKw('ORDER')) {
      this.next();
      this.expectKw('BY');
      for (;;) {
        const expr = this.parseExpr();
        let dir = 'asc';
        if (this.acceptKw('DESC')) dir = 'desc';
        else this.acceptKw('ASC');
        node.orderBy.push({ expr, dir });
        if (!this.acceptOp(',')) break;
      }
    }
    if (this.acceptKw('LIMIT')) {
      node.limit = this.parseExpr();
      if (this.acceptKw('OFFSET')) node.offset = this.parseExpr();
      else if (this.acceptOp(',')) {
        node.offset = node.limit;
        node.limit = this.parseExpr();
      }
    }
    return node;
  }

  parseTableRef() {
    const table = this.ident();
    let alias = table;
    if (this.acceptKw('AS')) alias = this.ident();
    else {
      const tk = this.peek();
      if (tk && tk.k === 'id' && (tk.quoted || !CLAUSE_WORDS.has(tk.u))) alias = this.ident();
    }
    return { table, alias };
  }

  parseSelectCol() {
    if (this.isOp('*')) {
      this.next();
      return { star: true, alias: null };
    }
    const a = this.peek();
    if (a && a.k === 'id' && this.isOp('.', 1) && this.isOp('*', 2)) {
      this.p += 3;
      return { star: true, table: a.v, alias: null };
    }
    const startTok = this.peek();
    const expr = this.parseExpr();
    const endTok = this.t[this.p - 1];
    const text = this.sql.slice(startTok.s, endTok.e);
    let alias = null;
    if (this.acceptKw('AS')) {
      const tk = this.next();
      alias = tk.v;
    } else {
      const tk = this.peek();
      if (tk && (tk.k === 'id' || tk.k === 'str') && !(tk.k === 'id' && !tk.quoted && CLAUSE_WORDS.has(tk.u))) {
        this.next();
        alias = tk.v;
      }
    }
    return { expr, alias, text };
  }

  parseInsert() {
    const first = this.next();
    const node = {
      type: 'insert', table: null, cols: [], rows: [], orReplace: false, orIgnore: false,
      conflict: null, select: null
    };
    if (first.u === 'REPLACE') node.orReplace = true;
    else if (this.acceptKw('OR')) {
      if (this.acceptKw('REPLACE')) node.orReplace = true;
      else if (this.acceptKw('IGNORE')) node.orIgnore = true;
      else this.next();
    }
    this.expectKw('INTO');
    node.table = this.ident();
    if (this.acceptOp('(')) {
      for (;;) {
        node.cols.push(this.ident());
        if (!this.acceptOp(',')) break;
      }
      this.expectOp(')');
    }
    if (this.isKw('SELECT')) {
      node.select = this.parseCompound();
    } else {
      this.expectKw('VALUES');
      for (;;) {
        this.expectOp('(');
        const row = [];
        for (;;) {
          row.push(this.parseExpr());
          if (!this.acceptOp(',')) break;
        }
        this.expectOp(')');
        node.rows.push(row);
        if (!this.acceptOp(',')) break;
      }
    }
    if (this.isKw('ON') && this.isKw('CONFLICT', 1)) {
      this.p += 2;
      const cols = [];
      if (this.acceptOp('(')) {
        for (;;) {
          cols.push(this.ident());
          if (!this.acceptOp(',')) break;
        }
        this.expectOp(')');
      }
      this.expectKw('DO');
      if (this.acceptKw('NOTHING')) {
        node.conflict = { cols, action: 'nothing' };
      } else {
        this.expectKw('UPDATE');
        this.expectKw('SET');
        const sets = this.parseAssignments();
        node.conflict = { cols, action: 'update', sets };
      }
    }
    return node;
  }

  parseAssignments() {
    const sets = [];
    for (;;) {
      let col = this.ident();
      if (this.acceptOp('.')) col = this.ident();
      this.expectOp('=');
      sets.push({ col, expr: this.parseExpr() });
      if (!this.acceptOp(',')) break;
    }
    return sets;
  }

  parseUpdate() {
    this.expectKw('UPDATE');
    if (this.acceptKw('OR')) this.next();
    const table = this.ident();
    this.expectKw('SET');
    const sets = this.parseAssignments();
    let where = null;
    if (this.acceptKw('WHERE')) where = this.parseExpr();
    return { type: 'update', table, sets, where };
  }

  parseDelete() {
    this.expectKw('DELETE');
    this.expectKw('FROM');
    const table = this.ident();
    let where = null;
    if (this.acceptKw('WHERE')) where = this.parseExpr();
    return { type: 'delete', table, where };
  }

  parseExpr() {
    return this.parseOr();
  }

  parseOr() {
    let left = this.parseAnd();
    while (this.acceptKw('OR')) left = { type: 'or', l: left, r: this.parseAnd() };
    return left;
  }

  parseAnd() {
    let left = this.parseNot();
    while (this.acceptKw('AND')) left = { type: 'and', l: left, r: this.parseNot() };
    return left;
  }

  parseNot() {
    if (this.isKw('NOT') && !this.isKw('EXISTS', 1)) {
      this.next();
      return { type: 'not', e: this.parseNot() };
    }
    return this.parseComparison();
  }

  parseComparison() {
    let left = this.parseAdditive();
    for (;;) {
      if (this.isKw('IS')) {
        this.next();
        const neg = this.acceptKw('NOT');
        this.expectKw('NULL');
        left = { type: 'isnull', e: left, neg };
        continue;
      }
      let neg = false;
      let save = this.p;
      if (this.isKw('NOT')) {
        this.next();
        neg = true;
      }
      if (this.acceptKw('IN')) {
        this.expectOp('(');
        if (this.isKw('SELECT')) {
          const sub = this.parseCompound();
          this.expectOp(')');
          left = { type: 'in', e: left, sub, neg };
        } else {
          const list = [];
          if (!this.isOp(')')) {
            for (;;) {
              list.push(this.parseExpr());
              if (!this.acceptOp(',')) break;
            }
          }
          this.expectOp(')');
          left = { type: 'in', e: left, list, neg };
        }
        continue;
      }
      if (this.acceptKw('LIKE')) {
        const pattern = this.parseAdditive();
        if (this.acceptKw('ESCAPE')) this.parseAdditive();
        left = { type: 'like', e: left, pattern, neg };
        continue;
      }
      if (this.acceptKw('BETWEEN')) {
        const lo = this.parseAdditive();
        this.expectKw('AND');
        const hi = this.parseAdditive();
        left = { type: 'between', e: left, lo, hi, neg };
        continue;
      }
      if (neg) this.p = save;
      const tk = this.peek();
      if (tk && tk.k === 'op' && ['=', '!=', '<', '<=', '>', '>='].includes(tk.v)) {
        this.next();
        const right = this.parseAdditive();
        left = { type: 'cmp', op: tk.v, l: left, r: right };
        continue;
      }
      break;
    }
    return left;
  }

  parseAdditive() {
    let left = this.parseMul();
    for (;;) {
      const tk = this.peek();
      if (tk && tk.k === 'op' && (tk.v === '+' || tk.v === '-' || tk.v === '||')) {
        this.next();
        left = { type: 'bin', op: tk.v, l: left, r: this.parseMul() };
      } else break;
    }
    return left;
  }

  parseMul() {
    let left = this.parseUnary();
    for (;;) {
      const tk = this.peek();
      if (tk && tk.k === 'op' && (tk.v === '*' || tk.v === '/' || tk.v === '%')) {
        this.next();
        left = { type: 'bin', op: tk.v, l: left, r: this.parseUnary() };
      } else break;
    }
    return left;
  }

  parseUnary() {
    if (this.isOp('-')) {
      this.next();
      return { type: 'neg', e: this.parseUnary() };
    }
    if (this.isOp('+')) {
      this.next();
      return this.parseUnary();
    }
    return this.parsePrimary();
  }

  parsePrimary() {
    const tk = this.next();
    if (!tk) throw new Error('SQL: ekspresi tidak lengkap');
    if (tk.k === 'num') return { type: 'lit', v: tk.v };
    if (tk.k === 'str') return { type: 'lit', v: tk.v };
    if (tk.k === 'param') return { type: 'param', idx: this.paramCount++ };
    if (tk.k === 'op' && tk.v === '(') {
      if (this.isKw('SELECT')) {
        const sub = this.parseCompound();
        this.expectOp(')');
        return { type: 'subq', sub };
      }
      const e = this.parseExpr();
      this.expectOp(')');
      return e;
    }
    if (tk.k === 'id') {
      if (!tk.quoted) {
        if (tk.u === 'NULL') return { type: 'lit', v: null };
        if (tk.u === 'TRUE') return { type: 'lit', v: 1 };
        if (tk.u === 'FALSE') return { type: 'lit', v: 0 };
        if (tk.u === 'EXISTS' || (tk.u === 'NOT' && this.isKw('EXISTS'))) {
          const neg = tk.u === 'NOT';
          if (neg) this.next();
          this.expectOp('(');
          const sub = this.parseCompound();
          this.expectOp(')');
          return { type: 'exists', sub, neg };
        }
        if (tk.u === 'CASE') return this.parseCase();
        if (tk.u === 'CAST' && this.isOp('(')) {
          this.next();
          const e = this.parseExpr();
          this.expectKw('AS');
          const typ = this.ident().toUpperCase();
          this.expectOp(')');
          return { type: 'cast', e, to: typ };
        }
      }
      if (this.isOp('(') && !tk.quoted) {
        this.next();
        const name = tk.u;
        const node = { type: 'fn', name, args: [], distinct: false, star: false };
        if (this.acceptKw('DISTINCT')) node.distinct = true;
        if (this.isOp('*')) {
          this.next();
          node.star = true;
        } else if (!this.isOp(')')) {
          for (;;) {
            node.args.push(this.parseExpr());
            if (!this.acceptOp(',')) break;
          }
        }
        this.expectOp(')');
        return node;
      }
      if (this.isOp('.') && this.peek(1) && this.peek(1).k === 'id') {
        this.next();
        const col = this.next();
        return { type: 'col', table: tk.v, name: col.v };
      }
      return { type: 'col', table: null, name: tk.v };
    }
    throw new Error(`SQL: token tak terduga "${this.sql.slice(tk.s, tk.s + 20)}"`);
  }

  parseCase() {
    const node = { type: 'case', base: null, whens: [], else: null };
    if (!this.isKw('WHEN')) node.base = this.parseExpr();
    while (this.acceptKw('WHEN')) {
      const cond = this.parseExpr();
      this.expectKw('THEN');
      node.whens.push({ cond, then: this.parseExpr() });
    }
    if (this.acceptKw('ELSE')) node.else = this.parseExpr();
    this.expectKw('END');
    return node;
  }
}

function parseSql(sql) {
  const parser = new Parser(sql);
  const ast = parser.parseStatement();
  while (parser.acceptOp(';')) {}
  if (!parser.eof()) throw new Error(`SQL: sisa token tak terduga di dekat "${parser.near()}"`);
  return ast;
}

function affinityOf(typeText) {
  const t = String(typeText || '').toUpperCase();
  if (t.includes('INT')) return 'INTEGER';
  if (t.includes('CHAR') || t.includes('CLOB') || t.includes('TEXT')) return 'TEXT';
  if (t.includes('BLOB') || t === '') return 'NONE';
  if (t.includes('REAL') || t.includes('FLOA') || t.includes('DOUB')) return 'REAL';
  return 'NUMERIC';
}

const COL_CONSTRAINT_WORDS = new Set([
  'PRIMARY', 'NOT', 'NULL', 'DEFAULT', 'UNIQUE', 'CHECK', 'REFERENCES', 'COLLATE', 'AUTOINCREMENT', 'GENERATED', 'CONSTRAINT'
]);

function skipBalanced(tokens, i) {
  let depth = 0;
  let j = i;
  while (j < tokens.length) {
    if (tokens[j].k === 'op' && tokens[j].v === '(') depth++;
    else if (tokens[j].k === 'op' && tokens[j].v === ')') {
      depth--;
      if (depth === 0) return j + 1;
    }
    j++;
  }
  return j;
}

function parseColumnDef(sql, tokens) {
  const name = tokens[0].v;
  let i = 1;
  const typeParts = [];
  while (i < tokens.length && !(tokens[i].k === 'id' && !tokens[i].quoted && COL_CONSTRAINT_WORDS.has(tokens[i].u))) {
    if (tokens[i].k === 'op' && tokens[i].v === '(') {
      i = skipBalanced(tokens, i);
      continue;
    }
    typeParts.push(tokens[i].v);
    i++;
  }
  const type = typeParts.join(' ');
  const col = { name, type, affinity: affinityOf(type), def: undefined, pk: false, unique: false, auto: false };
  while (i < tokens.length) {
    const tk = tokens[i];
    const u = tk.k === 'id' ? tk.u : '';
    if (u === 'PRIMARY') {
      col.pk = true;
      i += 2;
    } else if (u === 'AUTOINCREMENT') {
      col.auto = true;
      i++;
    } else if (u === 'UNIQUE') {
      col.unique = true;
      i++;
    } else if (u === 'NOT') {
      i += 2;
    } else if (u === 'NULL') {
      i++;
    } else if (u === 'DEFAULT') {
      i++;
      const dt = tokens[i];
      if (dt && dt.k === 'op' && dt.v === '(') {
        const end = skipBalanced(tokens, i);
        const text = sql.slice(tokens[i].s + 1, tokens[end - 1].s);
        col.def = { expr: text };
        i = end;
      } else if (dt && dt.k === 'op' && dt.v === '-' && tokens[i + 1] && tokens[i + 1].k === 'num') {
        col.def = { value: -tokens[i + 1].v };
        i += 2;
      } else if (dt) {
        if (dt.k === 'num' || dt.k === 'str') col.def = { value: dt.v };
        else if (dt.k === 'id' && dt.u === 'NULL') col.def = { value: null };
        else if (dt.k === 'id' && (dt.u === 'CURRENT_TIMESTAMP' || dt.u === 'CURRENT_DATE' || dt.u === 'CURRENT_TIME')) col.def = { expr: dt.u };
        i++;
      }
    } else if (u === 'CHECK') {
      i = skipBalanced(tokens, i + 1);
    } else if (u === 'REFERENCES') {
      i += 2;
      if (tokens[i] && tokens[i].k === 'op' && tokens[i].v === '(') i = skipBalanced(tokens, i);
      while (tokens[i] && tokens[i].k === 'id' && (tokens[i].u === 'ON' || tokens[i].u === 'DELETE' || tokens[i].u === 'UPDATE' || tokens[i].u === 'CASCADE' || tokens[i].u === 'SET' || tokens[i].u === 'NO' || tokens[i].u === 'ACTION' || tokens[i].u === 'RESTRICT')) {
        i++;
        if (tokens[i - 1].u === 'SET' && tokens[i]) i++;
      }
    } else if (u === 'COLLATE') {
      i += 2;
    } else if (u === 'CONSTRAINT') {
      i += 2;
    } else {
      i++;
    }
  }
  return col;
}

function splitTopLevel(tokens, from, to) {
  const groups = [];
  let cur = [];
  let depth = 0;
  for (let i = from; i < to; i++) {
    const tk = tokens[i];
    if (tk.k === 'op' && tk.v === '(') depth++;
    if (tk.k === 'op' && tk.v === ')') depth--;
    if (tk.k === 'op' && tk.v === ',' && depth === 0) {
      groups.push(cur);
      cur = [];
      continue;
    }
    cur.push(tk);
  }
  if (cur.length) groups.push(cur);
  return groups;
}

function identList(tokens) {
  const out = [];
  for (const tk of tokens) {
    if (tk.k === 'id' && !(tk.u === 'ASC' || tk.u === 'DESC' || tk.u === 'COLLATE' || tk.u === 'NOCASE')) out.push(tk.v);
  }
  return out;
}

function parseDdl(sql) {
  const tokens = tokenize(sql);
  if (!tokens.length || tokens[0].k !== 'id') return null;
  const first = tokens[0].u;
  if (first === 'CREATE') {
    let i = 1;
    let unique = false;
    if (tokens[i] && tokens[i].u === 'TEMP') i++;
    if (tokens[i] && tokens[i].u === 'UNIQUE') {
      unique = true;
      i++;
    }
    const kind = tokens[i] && tokens[i].u;
    i++;
    if (tokens[i] && tokens[i].u === 'IF') i += 3;
    if (kind === 'TABLE') {
      const table = tokens[i].v;
      i++;
      if (!(tokens[i] && tokens[i].k === 'op' && tokens[i].v === '(')) return { kind: 'ignore' };
      const end = skipBalanced(tokens, i);
      const groups = splitTopLevel(tokens, i + 1, end - 1);
      const schema = { name: table, cols: new Map(), order: [], pk: [], uniques: [], indexes: [] };
      for (const g of groups) {
        if (!g.length) continue;
        let head = g[0];
        let body = g;
        if (head.k === 'id' && head.u === 'CONSTRAINT') {
          body = g.slice(2);
          head = body[0];
        }
        const hu = head && head.k === 'id' && !head.quoted ? head.u : '';
        if (hu === 'PRIMARY') {
          const open = body.findIndex(t => t.k === 'op' && t.v === '(');
          schema.pk = identList(body.slice(open + 1));
        } else if (hu === 'UNIQUE') {
          const open = body.findIndex(t => t.k === 'op' && t.v === '(');
          schema.uniques.push(identList(body.slice(open + 1)));
        } else if (hu === 'FOREIGN' || hu === 'CHECK') {
          continue;
        } else {
          const col = parseColumnDef(sql, g);
          schema.cols.set(col.name, col);
          schema.order.push(col.name);
          if (col.pk) schema.pk = [col.name];
          if (col.unique) schema.uniques.push([col.name]);
        }
      }
      return { kind: 'table', schema };
    }
    if (kind === 'INDEX') {
      const name = tokens[i].v;
      i++;
      if (!(tokens[i] && tokens[i].u === 'ON')) return { kind: 'ignore' };
      i++;
      const table = tokens[i].v;
      i++;
      const end = skipBalanced(tokens, i);
      const cols = identList(tokens.slice(i + 1, end - 1));
      return { kind: 'index', name, table, cols, unique };
    }
    return { kind: 'ignore' };
  }
  if (first === 'ALTER') {
    if (!(tokens[1] && tokens[1].u === 'TABLE')) return { kind: 'ignore' };
    const table = tokens[2].v;
    if (tokens[3] && tokens[3].u === 'ADD') {
      let i = 4;
      if (tokens[i] && tokens[i].u === 'COLUMN') i++;
      const col = parseColumnDef(sql, tokens.slice(i));
      return { kind: 'addcolumn', table, col };
    }
    return { kind: 'ignore' };
  }
  if (first === 'PRAGMA') {
    const m = /^\s*PRAGMA\s+table_info\s*\(\s*[`"']?(\w+)[`"']?\s*\)/i.exec(sql);
    if (m) return { kind: 'tableinfo', table: m[1] };
    return { kind: 'ignore' };
  }
  if (['BEGIN', 'COMMIT', 'ROLLBACK', 'END', 'DROP', 'VACUUM', 'ANALYZE', 'REINDEX', 'SAVEPOINT', 'RELEASE'].includes(first)) {
    return { kind: 'ignore' };
  }
  return null;
}

function splitStatements(sql) {
  const tokens = tokenize(sql);
  const out = [];
  let from = 0;
  for (let i = 0; i < tokens.length; i++) {
    if (tokens[i].k === 'op' && tokens[i].v === ';') {
      if (i > from) out.push(sql.slice(tokens[from].s, tokens[i - 1].e));
      from = i + 1;
    }
  }
  if (from < tokens.length) out.push(sql.slice(tokens[from].s, tokens[tokens.length - 1].e));
  return out;
}

module.exports = {
  Parser,
  tokenize,
  parseSql,
  parseDdl,
  splitStatements,
  affinityOf,
  AGG_FUNCS
};
