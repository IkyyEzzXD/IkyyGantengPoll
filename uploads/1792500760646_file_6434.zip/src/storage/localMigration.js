const fs = require('fs');
const os = require('os');
const path = require('path');

const KV_FILES = {
  list_access: 'list_access',
  users: 'users_file',
  users_file: 'users_file',
  produk_balance: 'produk_balance',
  produk_transactions: 'produk_transactions',
  produk_baru: 'produk_baru',
  order_baru: 'order_baru',
  referral: 'referral',
  retention: 'retention',
  shop_stats: 'shop_stats'
};

const MARKER_ID = 'local_migration';
// Naikkan angka ini kalau logika migrasi berubah dan semua file perlu diperiksa ulang.
// v2: data JSON sekarang DIGABUNG (bukan dilewati) dan shop_stats memakai nilai terbesar.
// v3: tabel yang belum dikenal bot / kolom yang tidak ada di MongoDB TIDAK lagi dibuang diam-diam
//     (diarsipkan ke kv_store), dan file state lama diimpor bila belum ada di MongoDB.
const MARKER_VERSION = 3;
const IGNORED_JSON = new Set(['promosi_state', 'promo_state', 'auto_restart']);
const IGNORED_DIRS = new Set(['backups', 'logs']);
const SIDECAR = /\.(sqlite3?|db)-(wal|shm|journal)$/i;
const BATCH_SIZE = 500;
const PARALLEL = 20;
const SAFE_NAME = /^[A-Za-z_][A-Za-z0-9_]*$/;
const ARCHIVE_MAX_ROWS = 20000;
const ARCHIVE_MAX_BYTES = 12 * 1024 * 1024;
// File state lama: sekarang disimpan bot di kv_store (promo_state / auto_restore_state).
// Hanya diimpor kalau dokumennya BELUM ADA sama sekali di MongoDB, supaya state lama
// tidak menghidupkan lagi promosi/broadcast yang sudah berhenti.
const STATE_FILES = { state: 'promo_state', auto_restore_state: 'auto_restore_state' };

function noopLogger() {
  return { info() {}, warn() {}, error() {} };
}

function parseLoose(text) {
  const t = String(text).replace(/^\uFEFF/, '').trim();
  try {
    return JSON.parse(t);
  } catch (_) {}
  const stripped = t.replace(/^(?:module\.exports|exports\.\w+|(?:const|let|var)\s+\w+)\s*=\s*/, '').replace(/;\s*$/, '');
  return JSON.parse(stripped);
}

function fingerprint(file) {
  const st = fs.statSync(file);
  return `${st.size}:${Math.floor(st.mtimeMs)}`;
}

function copyToTemp(file) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'jaseb-migrasi-'));
  const dest = path.join(dir, path.basename(file));
  fs.copyFileSync(file, dest);
  for (const ext of ['-wal', '-shm']) {
    const side = file + ext;
    if (fs.existsSync(side)) fs.copyFileSync(side, dest + ext);
  }
  return { dir, dest };
}

function cleanupTemp(dir) {
  try { fs.rmSync(dir, { recursive: true, force: true }); } catch (_) {}
}

function wrapSync(handle) {
  return {
    async all(sql, params = []) {
      return handle.prepare(sql).all(...params);
    },
    async close() {
      try { handle.close(); } catch (_) {}
    }
  };
}

async function openSqlite(file) {
  try {
    const { DatabaseSync } = require('node:sqlite');
    return wrapSync(new DatabaseSync(file));
  } catch (_) {}
  try {
    const Database = require('better-sqlite3');
    return wrapSync(new Database(file, { fileMustExist: true }));
  } catch (_) {}
  try {
    const sqlite3 = require('sqlite3');
    const handle = await new Promise((resolve, reject) => {
      const d = new sqlite3.Database(file, sqlite3.OPEN_READWRITE, err => (err ? reject(err) : resolve(d)));
    });
    return {
      all(sql, params = []) {
        return new Promise((resolve, reject) => handle.all(sql, params, (e, rows) => (e ? reject(e) : resolve(rows))));
      },
      close() {
        return new Promise(resolve => handle.close(() => resolve()));
      }
    };
  } catch (_) {}
  return null;
}

function normalizeValue(v) {
  if (v === undefined) return null;
  if (typeof v === 'bigint') return Number(v);
  return v;
}

function isEmptyPayload(doc, id) {
  if (!doc) return true;
  if (id === 'shop_stats') {
    return !Number(doc.ordersCompleted) && !Number(doc.incomeTotal);
  }
  const p = doc.payload;
  if (p === undefined || p === null) return true;
  if (Array.isArray(p)) return p.length === 0;
  if (typeof p === 'object') return Object.keys(p).length === 0;
  return false;
}

function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function itemKey(x) {
  if (x !== null && typeof x === 'object') {
    for (const f of ['id', 'order_id', 'orderId', 'user_id', 'userId', 'txn_id']) {
      if (x[f] !== undefined && x[f] !== null) return `${f}:${x[f]}`;
    }
    try { return `j:${JSON.stringify(x)}`; } catch (_) { return `o:${String(x)}`; }
  }
  return `p:${typeof x}:${String(x)}`;
}

// Gabungkan data file lama ke data yang sudah ada di MongoDB tanpa menimpa:
// array -> tambahkan item yang belum ada, objek -> tambahkan kunci yang belum ada.
function mergePayload(base, extra) {
  if (Array.isArray(base) && Array.isArray(extra)) {
    const seen = new Set(base.map(itemKey));
    const out = base.slice();
    for (const item of extra) {
      const k = itemKey(item);
      if (!seen.has(k)) {
        seen.add(k);
        out.push(item);
      }
    }
    return out;
  }
  if (isPlainObject(base) && isPlainObject(extra)) {
    const out = Object.assign({}, base);
    for (const [k, v] of Object.entries(extra)) {
      if (!(k in out)) out[k] = v;
      else if ((isPlainObject(out[k]) && isPlainObject(v)) || (Array.isArray(out[k]) && Array.isArray(v))) out[k] = mergePayload(out[k], v);
    }
    return out;
  }
  return base;
}

function bulkDocs(engine, table, cols, rows) {
  return rows.map(row => {
    const doc = {};
    for (const c of cols) doc[c] = engine.coerce(table, c, normalizeValue(row[c]));
    return doc;
  });
}

async function bulkInsert(col, docs) {
  try {
    const r = await col.insertMany(docs, { ordered: false });
    return { inserted: r && r.insertedCount !== undefined ? r.insertedCount : docs.length, skipped: 0, failed: 0, error: null };
  } catch (e) {
    const writeErrors = Array.isArray(e.writeErrors) ? e.writeErrors : (e.writeErrors ? [e.writeErrors] : []);
    if (!writeErrors.length) throw e;
    const dup = writeErrors.filter(w => (w.code || (w.err && w.err.code)) === 11000).length;
    const other = writeErrors.length - dup;
    const inserted = e.insertedCount !== undefined ? e.insertedCount : (e.result && e.result.insertedCount) || (docs.length - writeErrors.length);
    return { inserted, skipped: dup, failed: other, error: other ? (writeErrors[0].errmsg || e.message) : null };
  }
}

// Simpan baris tabel/kolom yang tidak punya tempat di skema MongoDB ke kv_store
// supaya tidak hilang saat folder database dihapus.
async function archiveToKv(kv, id, rows, log, label) {
  if (!kv) return false;
  if (rows.length > ARCHIVE_MAX_ROWS) {
    log.error(`Migrasi: ${label} berisi ${rows.length} baris, terlalu besar untuk diarsipkan otomatis`);
    return false;
  }
  const payload = rows.map(r => {
    const o = {};
    for (const [k, v] of Object.entries(r)) o[k] = normalizeValue(v);
    return o;
  });
  let size = 0;
  try { size = Buffer.byteLength(JSON.stringify(payload)); } catch (_) { size = Infinity; }
  if (size > ARCHIVE_MAX_BYTES) {
    log.error(`Migrasi: ${label} berukuran ${(size / 1048576).toFixed(1)} MB, terlalu besar untuk diarsipkan otomatis`);
    return false;
  }
  await kv.updateOne({ _id: id }, { $set: { payload, updatedAt: Date.now() } }, { upsert: true });
  return true;
}

async function migrateTable(db, rawDb, engine, src, table, log, kv) {
  const destInfo = await db.all(`PRAGMA table_info(${table})`);
  if (!destInfo.length) {
    const cntRow = await src.all(`SELECT COUNT(*) AS c FROM "${table}"`);
    const cnt = cntRow && cntRow[0] ? Number(cntRow[0].c) : 0;
    if (cnt === 0) {
      log.info(`Migrasi: tabel "${table}" tidak dikenal bot dan kosong, dilewati`);
      return { table, inserted: 0, skipped: 0, failed: 0, ignoredTable: true };
    }
    const allRows = await src.all(`SELECT * FROM "${table}"`);
    const ok = await archiveToKv(kv, `legacy_table_${table}`, allRows, log, `tabel "${table}"`);
    if (ok) {
      log.warn(`Migrasi: tabel "${table}" tidak dikenal bot, ${cnt} baris diarsipkan ke kv_store/legacy_table_${table}`);
      return { table, inserted: 0, skipped: 0, failed: 0, ignoredTable: true, archived: cnt };
    }
    log.error(`Migrasi: tabel "${table}" tidak dikenal bot dan gagal diarsipkan`);
    return { table, inserted: 0, skipped: 0, failed: cnt, ignoredTable: true };
  }
  const srcInfo = await src.all(`PRAGMA table_info("${table}")`);
  const srcCols = new Set(srcInfo.map(c => c.name));
  const cols = destInfo.map(c => c.name).filter(n => srcCols.has(n) && SAFE_NAME.test(n));
  if (!cols.length) return { table, inserted: 0, skipped: 0, failed: 0, ignoredTable: true };

  // Kolom di file lama yang tidak ada di skema MongoDB: arsipkan kalau ada isinya.
  const destNames = new Set(destInfo.map(c => c.name));
  const dropped = srcInfo.map(c => c.name).filter(n => !destNames.has(n) && SAFE_NAME.test(n));
  let droppedFailed = 0;
  for (const col of dropped) {
    try {
      const nn = await src.all(`SELECT COUNT(*) AS c FROM "${table}" WHERE "${col}" IS NOT NULL`);
      const n = nn && nn[0] ? Number(nn[0].c) : 0;
      if (n === 0) continue;
      const keyCols = srcInfo.filter(c => Number(c.pk) > 0).map(c => c.name);
      const keySel = keyCols.length ? keyCols.map(k => `"${k}"`).join(', ') : 'rowid AS rowid';
      const rows = await src.all(`SELECT ${keySel}, "${col}" FROM "${table}" WHERE "${col}" IS NOT NULL`);
      const ok = await archiveToKv(kv, `legacy_col_${table}_${col}`, rows, log, `kolom "${table}.${col}"`);
      if (ok) log.warn(`Migrasi: kolom "${table}.${col}" tidak ada di skema MongoDB, ${n} nilai diarsipkan ke kv_store/legacy_col_${table}_${col}`);
      else droppedFailed += n;
    } catch (e) {
      log.warn(`Migrasi: gagal memeriksa kolom "${table}.${col}": ${e.message}`);
    }
  }

  const existing = await db.get(`SELECT COUNT(*) AS c FROM ${table}`);
  const destCount = existing ? Number(existing.c) : 0;
  const hasPk = destInfo.some(c => Number(c.pk) > 0);
  if (!hasPk && destCount > 0) {
    log.info(`Migrasi: tabel "${table}" sudah berisi data di MongoDB, dilewati`);
    return { table, inserted: 0, skipped: 0, failed: 0, ignoredTable: true };
  }

  const totalRow = await src.all(`SELECT COUNT(*) AS c FROM "${table}"`);
  const total = totalRow && totalRow[0] ? Number(totalRow[0].c) : 0;
  let nativeCol = null;
  if (engine && destCount === 0) {
    try {
      const c = engine.col(table);
      if (c && typeof c.insertMany === 'function') nativeCol = c;
    } catch (_) {}
  }

  // Tabel sudah berisi data tapi punya kunci primer tunggal: ambil dulu kunci yang sudah ada,
  // lalu masukkan HANYA baris yang belum ada secara massal (jauh lebih cepat daripada satu-satu).
  let existingKeys = null;
  let pkName = null;
  if (!nativeCol && engine && destCount > 0) {
    const pkCols = destInfo.filter(c => Number(c.pk) > 0).map(c => c.name);
    if (pkCols.length === 1 && cols.includes(pkCols[0]) && SAFE_NAME.test(pkCols[0])) {
      try {
        const c = engine.col(table);
        if (c && typeof c.insertMany === 'function') {
          const keyRows = await db.all(`SELECT ${pkCols[0]} AS k FROM ${table}`);
          existingKeys = new Set(keyRows.map(r => String(r.k)));
          pkName = pkCols[0];
          nativeCol = c;
        }
      } catch (_) { nativeCol = null; existingKeys = null; }
    }
  }

  const sql = `INSERT OR IGNORE INTO ${table} (${cols.join(', ')}) VALUES (${cols.map(() => '?').join(', ')})`;
  const hasId = cols.includes('id');
  let inserted = 0;
  let skipped = 0;
  let failed = 0;
  let maxId = 0;
  let firstError = null;
  let processed = 0;
  let lastReport = 0;
  const batchSize = nativeCol ? 1000 : BATCH_SIZE;

  for (let offset = 0; ; offset += batchSize) {
    const rows = await src.all(`SELECT * FROM "${table}" LIMIT ${batchSize} OFFSET ${offset}`);
    if (!rows.length) break;
    if (hasId) {
      for (const row of rows) {
        if (typeof row.id === 'number' && row.id > maxId) maxId = row.id;
      }
    }
    if (nativeCol) {
      try {
        let batch = rows;
        if (existingKeys) {
          batch = [];
          for (const row of rows) {
            const k = String(row[pkName]);
            if (existingKeys.has(k)) { skipped++; continue; }
            existingKeys.add(k);
            batch.push(row);
          }
        }
        if (!batch.length) { processed += rows.length; if (rows.length < batchSize) break; continue; }
        const r = await bulkInsert(nativeCol, bulkDocs(engine, table, cols, batch));
        inserted += r.inserted;
        skipped += r.skipped;
        failed += r.failed;
        if (r.error && !firstError) firstError = r.error;
      } catch (e) {
        failed += rows.length;
        if (!firstError) firstError = e.message;
      }
    } else {
      for (let i = 0; i < rows.length; i += PARALLEL) {
        const slice = rows.slice(i, i + PARALLEL);
        const results = await Promise.allSettled(slice.map(row => db.run(sql, cols.map(c => normalizeValue(row[c])))));
        for (const r of results) {
          if (r.status === 'fulfilled') {
            if (r.value && r.value.changes === 0) skipped++;
            else inserted++;
          } else {
            failed++;
            if (!firstError) firstError = r.reason && r.reason.message ? r.reason.message : String(r.reason);
          }
        }
      }
    }
    processed += rows.length;
    if (processed - lastReport >= 5000) {
      lastReport = processed;
      log.info(`Migrasi: ${table} ${processed}/${total} baris...`);
    }
    if (rows.length < batchSize) break;
  }

  if (nativeCol && engine && inserted > 0) {
    try { engine.bump(table); } catch (_) {}
  }
  if (hasId && maxId > 0 && rawDb) {
    try {
      await rawDb.collection('_counters').updateOne({ _id: table }, { $max: { seq: maxId } }, { upsert: true });
    } catch (e) {
      log.warn(`Migrasi: gagal memperbarui counter "${table}": ${e.message}`);
    }
  }
  failed += droppedFailed;
  if (failed > 0) log.warn(`Migrasi: tabel "${table}" ${failed} baris gagal (contoh: ${firstError})`);
  return { table, inserted, skipped, failed };
}

async function migrateSqliteFile(db, engine, file, log, kv) {
  const { dir, dest } = copyToTemp(file);
  let src = null;
  try {
    src = await openSqlite(dest);
    if (!src) {
      log.warn(`Migrasi: ${path.basename(file)} ditemukan tapi modul SQLite tidak tersedia. Gunakan Node.js 22.5 atau lebih baru, atau jalankan: npm install better-sqlite3`);
      return false;
    }
    let tables = (await src.all("SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'"))
      .map(t => t.name)
      .filter(n => SAFE_NAME.test(n));
    // Mode pemulihan: MIGRATE_ONLY_TABLES=jasa_orders,jasa_senders -> hanya tabel itu yang diproses.
    const only = String(process.env.MIGRATE_ONLY_TABLES || '').split(',').map(x => x.trim()).filter(Boolean);
    if (only.length) {
      tables = tables.filter(t => only.includes(t));
      log.warn(`Migrasi: mode pemulihan, hanya tabel: ${tables.join(', ') || '(tidak ada yang cocok)'}`);
    }
    let rawDb = null;
    try { rawDb = db.rawDb; } catch (_) {}
    let total = 0;
    let anyFailed = false;
    for (const table of tables) {
      try {
        const r = await migrateTable(db, rawDb, engine, src, table, log, kv);
        total += r.inserted;
        if (r.failed > 0) anyFailed = true;
        if (!r.ignoredTable) {
          // Verifikasi: jumlah baris di MongoDB harus >= jumlah baris di file lama.
          const srcRow = await src.all(`SELECT COUNT(*) AS c FROM "${table}"`);
          const dstRow = await db.get(`SELECT COUNT(*) AS c FROM ${table}`);
          const srcCount = srcRow && srcRow[0] ? Number(srcRow[0].c) : 0;
          const dstCount = dstRow ? Number(dstRow.c) : 0;
          if (dstCount < srcCount) {
            anyFailed = true;
            log.error(`Migrasi: verifikasi tabel "${table}" GAGAL (file lama ${srcCount} baris, MongoDB ${dstCount} baris)`);
          }
        }
        if (r.inserted > 0 || r.failed > 0) {
          log.info(`Migrasi: ${table} -> ${r.inserted} baris masuk, ${r.skipped} sudah ada, ${r.failed} gagal`);
        }
      } catch (e) {
        anyFailed = true;
        log.error(`Migrasi: tabel "${table}" gagal: ${e.message}`);
      }
    }
    log.info(`Migrasi ${path.basename(file)} selesai: ${total} baris dipindahkan ke MongoDB`);
    return !anyFailed;
  } catch (e) {
    log.error(`Migrasi ${path.basename(file)} gagal: ${e.message}`);
    return false;
  } finally {
    if (src) await src.close();
    cleanupTemp(dir);
  }
}

async function migrateJsonFile(kv, file, id, log) {
  let parsed;
  try {
    parsed = parseLoose(fs.readFileSync(file, 'utf8'));
  } catch (e) {
    log.warn(`Migrasi: ${path.basename(file)} bukan JSON valid (${e.message}), dilewati`);
    return false;
  }
  if (parsed === null || parsed === undefined) return true;
  const existing = await kv.findOne({ _id: id });
  if (id === 'shop_stats') {
    // Ambil nilai TERBESAR supaya angka pesanan/penghasilan tidak pernah turun.
    const ex = existing || {};
    const orders = Math.max(Number(ex.ordersCompleted) || 0, Number(parsed.ordersCompleted) || 0);
    const income = Math.max(Number(ex.incomeTotal) || 0, Number(parsed.incomeTotal) || 0);
    await kv.updateOne(
      { _id: id },
      { $set: { ordersCompleted: orders, incomeTotal: income, updatedAt: Date.now() } },
      { upsert: true }
    );
    log.info(`Migrasi: ${path.basename(file)} -> kv_store/${id} (pesanan ${orders}, penghasilan ${income})`);
    return true;
  }
  if (isEmptyPayload(existing, id)) {
    await kv.updateOne({ _id: id }, { $set: { payload: parsed, updatedAt: Date.now() } }, { upsert: true });
  } else {
    const merged = mergePayload(existing.payload, parsed);
    if (JSON.stringify(merged) === JSON.stringify(existing.payload)) {
      log.info(`Migrasi: ${path.basename(file)} sudah lengkap di MongoDB (${id})`);
      return true;
    }
    await kv.updateOne({ _id: id }, { $set: { payload: merged, updatedAt: Date.now() } }, { upsert: true });
    log.info(`Migrasi: ${path.basename(file)} digabung ke kv_store/${id} (data yang kurang ditambahkan)`);
    return true;
  }
  log.info(`Migrasi: ${path.basename(file)} -> kv_store/${id}`);
  return true;
}

async function importStateFile(kv, file, id, log) {
  let parsed;
  try {
    parsed = parseLoose(fs.readFileSync(file, 'utf8'));
  } catch (e) {
    log.warn(`Migrasi: ${path.basename(file)} bukan JSON valid (${e.message}), dilewati`);
    return true;
  }
  const existing = await kv.findOne({ _id: id });
  if (existing) {
    log.info(`Migrasi: ${path.basename(file)} dilewati, state ${id} sudah ada di MongoDB (state lama tidak dihidupkan lagi)`);
    return true;
  }
  if (parsed === null || parsed === undefined) return true;
  await kv.updateOne({ _id: id }, { $set: { payload: parsed, updatedAt: Date.now() } }, { upsert: true });
  log.info(`Migrasi: ${path.basename(file)} -> kv_store/${id} (state belum ada di MongoDB)`);
  return true;
}

function classify(databaseDir) {
  const result = { sqlite: [], json: [], state: [], ignored: [], backups: [], unknown: [], hasMedia: false };
  for (const entry of fs.readdirSync(databaseDir, { withFileTypes: true })) {
    const name = entry.name;
    // File/folder tersembunyi (mis. .orphan_fk_heal_done, .total_sent_sync_done,
    // .trial_used_reset_done) hanyalah penanda internal versi lama, bukan data.
    if (name.startsWith('.')) {
      result.ignored.push(name);
      continue;
    }
    if (entry.isDirectory()) {
      if (name === 'media') result.hasMedia = true;
      else if (IGNORED_DIRS.has(name)) result.ignored.push(name + '/');
      else result.unknown.push(name + '/');
      continue;
    }
    if (!entry.isFile()) continue;
    const base = name.replace(/\.(json|js)$/i, '').toLowerCase();
    if (SIDECAR.test(name)) result.ignored.push(name);
    else if (/^backup_/i.test(name)) result.backups.push(name);
    else if (/\.(sqlite3?|db)$/i.test(name)) result.sqlite.push(name);
    else if (/\.(json|js)$/i.test(name) && KV_FILES[base]) result.json.push(name);
    else if (/\.(json|js)$/i.test(name) && STATE_FILES[base]) result.state.push(name);
    else if (/\.(json|js)$/i.test(name) && IGNORED_JSON.has(base)) result.ignored.push(name);
    else result.unknown.push(name);
  }
  return result;
}

function hasLocalDatabase(databaseDir) {
  try {
    return !!databaseDir && fs.existsSync(databaseDir);
  } catch (_) {
    return false;
  }
}

async function migrateLocalDatabase({ db, mongoAdapter, mediaStore, logger, databaseDir }) {
  const log = logger || noopLogger();
  try {
    if (!db || !mongoAdapter || !databaseDir || !fs.existsSync(databaseDir)) return { migrated: 0 };
    const found = classify(databaseDir);
    const mediaDir = path.join(databaseDir, 'media');
    const mediaFiles = found.hasMedia && mediaStore ? mediaStore.listFiles(mediaDir) : [];
    const hasContent = found.sqlite.length || found.json.length || found.state.length || mediaFiles.length || found.backups.length || found.ignored.length;
    if (!hasContent && !found.unknown.length) {
      try { fs.rmSync(databaseDir, { recursive: true, force: true }); } catch (_) {}
      return { migrated: 0 };
    }

    const mdb = mongoAdapter.getDatabase();
    if (!mdb) return { migrated: 0 };
    const engineRef = typeof mongoAdapter.getEngine === 'function' ? mongoAdapter.getEngine() : null;
    const kv = mdb.collection('kv_store');
    const marker = await kv.findOne({ _id: MARKER_ID });
    const sameVersion = !!(marker && marker.payload && marker.payload.version === MARKER_VERSION);
    const done = Object.assign({}, sameVersion ? marker.payload.files : {});
    if (!sameVersion && marker) log.info('Migrasi: logika migrasi diperbarui, semua file diperiksa ulang untuk melengkapi data yang kurang');
    let changed = false;
    let migrated = 0;
    let incomplete = false;

    const totalSteps = found.sqlite.length + found.json.length + found.state.length + (mediaFiles.length ? 1 : 0);
    let step = 0;
    log.info(`Migrasi: ${totalSteps} langkah (sqlite ${found.sqlite.length}, json ${found.json.length}, state ${found.state.length}, media ${mediaFiles.length ? 'ya' : 'tidak'}), dikerjakan satu per satu`);

    found.sqlite.sort((a, b) => fs.statSync(path.join(databaseDir, a)).mtimeMs - fs.statSync(path.join(databaseDir, b)).mtimeMs);

    for (const name of found.sqlite) {
      const file = path.join(databaseDir, name);
      const fp = fingerprint(file);
      step++;
      if (done[name] === fp) {
        log.info(`Migrasi [${step}/${totalSteps}]: ${name} sudah pernah dipindahkan, dilewati`);
        continue;
      }
      log.info(`Migrasi [${step}/${totalSteps}]: memindahkan ${name} ke MongoDB...`);
      if (await migrateSqliteFile(db, engineRef, file, log, kv)) {
        done[name] = fp;
        changed = true;
        migrated++;
      } else {
        incomplete = true;
      }
    }

    // Mode pemulihan tabel (MIGRATE_ONLY_TABLES): file JSON & state tidak disentuh.
    const recoveryOnly = String(process.env.MIGRATE_ONLY_TABLES || '').trim() !== '';
    if (recoveryOnly) log.warn('Migrasi: mode pemulihan tabel aktif, file JSON/state/media dilewati');

    for (const name of (recoveryOnly ? [] : found.json)) {
      const file = path.join(databaseDir, name);
      const fp = fingerprint(file);
      step++;
      if (done[name] === fp) {
        log.info(`Migrasi [${step}/${totalSteps}]: ${name} sudah pernah dipindahkan, dilewati`);
        continue;
      }
      const id = KV_FILES[name.replace(/\.(json|js)$/i, '').toLowerCase()];
      try {
        if (await migrateJsonFile(kv, file, id, log)) {
          done[name] = fp;
          changed = true;
          migrated++;
        } else {
          incomplete = true;
        }
      } catch (e) {
        incomplete = true;
        log.error(`Migrasi ${name} gagal: ${e.message}`);
      }
    }

    for (const name of (recoveryOnly ? [] : found.state)) {
      const file = path.join(databaseDir, name);
      const fp = fingerprint(file);
      step++;
      if (done[name] === fp) {
        log.info(`Migrasi [${step}/${totalSteps}]: ${name} sudah diperiksa, dilewati`);
        continue;
      }
      const id = STATE_FILES[name.replace(/\.(json|js)$/i, '').toLowerCase()];
      try {
        await importStateFile(kv, file, id, log);
        done[name] = fp;
        changed = true;
        migrated++;
      } catch (e) {
        incomplete = true;
        log.error(`Migrasi ${name} gagal: ${e.message}`);
      }
    }

    if (mediaFiles.length && !recoveryOnly) {
      step++;
      log.info(`Migrasi [${step}/${totalSteps}]: memindahkan ${mediaFiles.length} file media ke MongoDB...`);
      const r = await mediaStore.importDir(mediaDir);
      log.info(`Migrasi media: ${r.uploaded} diunggah, ${r.skipped} sudah ada, ${r.failed} gagal`);
      if (r.failed !== 0) incomplete = true;
      migrated += r.uploaded;
    }

    if (changed) {
      await kv.updateOne({ _id: MARKER_ID }, { $set: { payload: { version: MARKER_VERSION, files: done }, updatedAt: Date.now() } }, { upsert: true });
    }

    if (found.unknown.length) {
      incomplete = true;
      log.warn(`Migrasi: folder database tidak dihapus karena ada file yang tidak dikenali: ${found.unknown.join(', ')}`);
    }
    if (incomplete) {
      log.warn('Migrasi belum lengkap, folder database dibiarkan. Perbaiki penyebabnya lalu jalankan ulang bot.');
      return { migrated, incomplete: true };
    }

    log.info('Migrasi: semua langkah selesai & terverifikasi, menghapus folder database lama...');
    try {
      fs.rmSync(databaseDir, { recursive: true, force: true });
    } catch (e) {
      log.error(`Migrasi: gagal menghapus folder database: ${e.message}`);
      return { migrated };
    }
    if (fs.existsSync(databaseDir)) {
      log.error('Migrasi: folder database masih ada setelah dihapus');
      return { migrated };
    }
    log.info('Migrasi selesai, folder database lama dihapus');
    return { migrated };
  } catch (e) {
    log.error(`Migrasi database lokal ke MongoDB gagal: ${e && e.message ? e.message : e}`);
    return { migrated: 0, incomplete: true, error: e };
  }
}

module.exports = { migrateLocalDatabase, hasLocalDatabase };
