const { Parser, parseSql, parseDdl, splitStatements, AGG_FUNCS } = require('./sqlParser');

const SEQ_TABLES = new Set([
  'admin_controls', 'messages', 'groups', 'blacklist_groups', 'blacklist_users',
  'payments', 'prices', 'premium_wm', 'premium_no_wm', 'reseller_list',
  'reseller_added', 'tokens', 'promo_logs', 'activity_logs', 'temp_payments',
  'tickets', 'ticket_messages', 'jasa_senders', 'jasa_orders', 'jasa_order_groups',
  'jasa_order_senders'
]);

const AUTO_INDEX_COLUMNS = ['owner_id', 'user_id', 'order_id', 'sender_id', 'ubot_id', 'reseller_id', 'token'];

const CACHE_TTL_MS = Number(process.env.MONGODB_READ_CACHE_TTL_MS || 10000);
const CACHE_MAX_ENTRIES = 3000;
const CACHE_MAX_ROWS = 200;
const CACHE_TOTAL_ROWS = 20000;
const PARSE_CACHE_MAX = 1500;
const OP_MAX_TIME_MS = 30000;
const RETRY_BUDGET_MS = Number(process.env.MONGODB_RETRY_BUDGET_MS || 30000);
const NEVER_SENT_NAMES = new Set(['MongoServerSelectionError', 'MongoPoolClearedError', 'MongoWaitQueueTimeoutError']);
const TRANSIENT_NAMES = new Set(['MongoNetworkError', 'MongoNetworkTimeoutError', 'PoolClearedOnNetworkError', 'MongoTopologyClosedError']);
const NETWORK_MSG = /secureConnect|server monitor timeout|connection pool .*cleared|interrupted due to|ECONNRESET|ETIMEDOUT|ECONNREFUSED|ENOTFOUND|EAI_AGAIN|ENETUNREACH|EHOSTUNREACH|EPIPE|socket hang up|topology (is|was) closed|ReplicaSetNoPrimary|no primary/i;
const NEVER = { _id: { $in: [] } };
const VOLATILE_COLUMNS = new Set(['last_used', 'last_active']);
const NOT_CONST = Symbol('not-const');

let mongoLib = null;
let client = null;
let database = null;
let counters = null;
let engine = null;
let wrappedDb = null;
let pingTimer = null;
let sweepTimer = null;
let closing = false;
let reviving = null;
let connParams = null;

const connState = { healthy: false, failures: 0, lastError: null, since: Date.now() };

function lib() {
  if (!mongoLib) mongoLib = require('mongodb');
  return mongoLib;
}

function log(level, message) {
  try {
    const logger = require('../system/logger.js');
    if (logger && typeof logger[level] === 'function') {
      logger[level](message);
      return;
    }
  } catch (_) {}
  const out = level === 'error' ? console.error : console.log;
  out(`[mongo:${level}] ${message}`);
}

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

function errText(e) {
  return String((e && e.message) || e);
}

function isNotConnected(e) {
  return !!e && (e.name === 'MongoNotConnectedError' || /must be connected before running operations/i.test(String(e.message || '')));
}

function isTransient(e, forWrite) {
  if (!e) return false;
  const name = e.name || '';
  const code = e.code;
  if (NEVER_SENT_NAMES.has(name)) return true;
  if (forWrite === true) return false;
  if (TRANSIENT_NAMES.has(name)) return true;
  if ([6, 7, 89, 91, 189, 9001, 10107, 11600, 11602, 13435, 13436].includes(code)) return true;
  if (typeof e.hasErrorLabel === 'function' && (e.hasErrorLabel('RetryableWriteError') || e.hasErrorLabel('TransientTransactionError'))) return true;
  return NETWORK_MSG.test(String(e.message || ''));
}

async function withRetry(fn, forWrite) {
  const started = Date.now();
  let last;
  let revived = false;
  for (let i = 0; ; i++) {
    try {
      return await fn();
    } catch (e) {
      last = e;
      if (isNotConnected(e) && !revived && !closing && connParams) {
        revived = true;
        await revive();
        continue;
      }
      if (closing || !isTransient(e, forWrite)) throw e;
      const elapsed = Date.now() - started;
      if (elapsed >= RETRY_BUDGET_MS) throw last;
      const wait = Math.min(250 * Math.pow(2, Math.min(i, 4)), 3000) + Math.floor(Math.random() * 150);
      await sleep(Math.min(wait, RETRY_BUDGET_MS - elapsed));
    }
  }
}

function constraintError(e, table) {
  const err = new Error(`UNIQUE constraint failed: ${table}`);
  err.code = 'SQLITE_CONSTRAINT';
  err.errno = 19;
  err.cause = e;
  return err;
}

function isDup(e) {
  return !!e && (e.code === 11000 || e.code === 11001);
}

function toObjectId(v) {
  try {
    const { ObjectId } = lib();
    if (v instanceof ObjectId) return v;
    if (typeof v === 'string' && /^[0-9a-fA-F]{24}$/.test(v)) return new ObjectId(v);
  } catch (_) {}
  return v;
}

function norm(v) {
  if (v === null || v === undefined) return v;
  if (v instanceof Date) return v.getTime();
  if (typeof v === 'object' && typeof v.toHexString === 'function') return v.toHexString();
  if (typeof v === 'bigint') return Number(v);
  return v;
}

function cmpVals(a, b) {
  a = norm(a);
  b = norm(b);
  if (typeof a === 'boolean') a = a ? 1 : 0;
  if (typeof b === 'boolean') b = b ? 1 : 0;
  const ta = typeof a;
  const tb = typeof b;
  if (ta === tb) return a < b ? -1 : a > b ? 1 : 0;
  if (ta === 'number' && tb === 'string') {
    const nb = Number(b);
    if (b.trim() !== '' && !Number.isNaN(nb)) return a < nb ? -1 : a > nb ? 1 : 0;
    return -1;
  }
  if (ta === 'string' && tb === 'number') {
    const na = Number(a);
    if (a.trim() !== '' && !Number.isNaN(na)) return na < b ? -1 : na > b ? 1 : 0;
    return 1;
  }
  const sa = String(a);
  const sb = String(b);
  return sa < sb ? -1 : sa > sb ? 1 : 0;
}

function sortCmp(a, b) {
  const an = a === null || a === undefined;
  const bn = b === null || b === undefined;
  if (an && bn) return 0;
  if (an) return -1;
  if (bn) return 1;
  return cmpVals(a, b);
}

function truthy(v) {
  if (v === null || v === undefined) return false;
  if (v === true) return true;
  if (typeof v === 'number') return v !== 0;
  if (typeof v === 'string') {
    const n = Number(v);
    return v.trim() !== '' && !Number.isNaN(n) && n !== 0;
  }
  return !!v;
}

function escapeRegex(s) {
  return String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function likeSource(pattern) {
  let out = '^';
  for (const ch of String(pattern)) {
    if (ch === '%') out += '[\\s\\S]*';
    else if (ch === '_') out += '[\\s\\S]';
    else out += escapeRegex(ch);
  }
  return out + '$';
}

function coerceByAffinity(affinity, v) {
  if (v === null || v === undefined) return v;
  if (affinity === 'TEXT') {
    if (typeof v === 'number' || typeof v === 'bigint' || typeof v === 'boolean') return String(v);
    return v;
  }
  if (affinity === 'INTEGER' || affinity === 'REAL' || affinity === 'NUMERIC') {
    if (typeof v === 'string' && v.trim() !== '') {
      const n = Number(v);
      if (!Number.isNaN(n)) return n;
    }
    if (typeof v === 'boolean') return v ? 1 : 0;
  }
  return v;
}

function walk(node, fn) {
  if (!node || typeof node !== 'object') return;
  if (Array.isArray(node)) {
    for (const n of node) walk(n, fn);
    return;
  }
  if (fn(node) === false) return;
  for (const k of Object.keys(node)) {
    const v = node[k];
    if (v && typeof v === 'object') walk(v, fn);
  }
}

function isAggFn(node) {
  if (!node || node.type !== 'fn') return false;
  if (node.name === 'MIN' || node.name === 'MAX') return node.args.length === 1;
  return AGG_FUNCS.has(node.name);
}

function hasAgg(node) {
  let found = false;
  walk(node, n => {
    if (n.type === 'select' || n.type === 'union') return false;
    if (isAggFn(n)) found = true;
    return !found;
  });
  return found;
}

function splitAnd(node, out = []) {
  if (!node) return out;
  if (node.type === 'and') {
    splitAnd(node.l, out);
    splitAnd(node.r, out);
  } else out.push(node);
  return out;
}

function joinAnd(list) {
  if (!list.length) return null;
  return list.reduce((a, b) => ({ type: 'and', l: a, r: b }));
}

function andFilters(list) {
  const f = list.filter(Boolean);
  if (!f.length) return {};
  if (f.length === 1) return f[0];
  return { $and: f };
}

class Engine {
  constructor(db, countersCol) {
    this.db = db;
    this.counters = countersCol;
    this.schemas = new Map();
    this.versions = new Map();
    this.cache = new Map();
    this.cacheRows = 0;
    this.inflight = new Map();
    this.parsed = new Map();
    this.tablesMemo = new WeakMap();
    this.seeded = new Set();
    this.indexed = new Set();
    this.pendingIndexes = [];
    this.stat = { hits: 0, misses: 0, coalesced: 0, reads: 0, writes: 0 };
  }

  col(name) {
    return this.db.collection(name);
  }

  parse(sql) {
    let ast = this.parsed.get(sql);
    if (ast) return ast;
    ast = parseSql(sql);
    if (this.parsed.size >= PARSE_CACHE_MAX) this.parsed.delete(this.parsed.keys().next().value);
    this.parsed.set(sql, ast);
    return ast;
  }

  schemaOf(table) {
    return this.schemas.get(String(table).toLowerCase()) || null;
  }

  colInfo(table, name) {
    const s = this.schemaOf(table);
    return s ? s.cols.get(name) || null : null;
  }

  coerce(table, name, v) {
    const c = this.colInfo(table, name);
    return c ? coerceByAffinity(c.affinity, v) : v;
  }

  version(table) {
    return this.versions.get(String(table).toLowerCase()) || 0;
  }

  bump(table) {
    const k = String(table).toLowerCase();
    this.versions.set(k, (this.versions.get(k) || 0) + 1);
  }

  tablesOf(ast) {
    let t = this.tablesMemo.get(ast);
    if (t) return t;
    const set = new Set();
    walk(ast, n => {
      if (n.type === 'select' && n.from) {
        set.add(n.from.table.toLowerCase());
        for (const j of n.joins) set.add(j.table.toLowerCase());
      }
    });
    t = Array.from(set);
    this.tablesMemo.set(ast, t);
    return t;
  }

  snapshot(tables) {
    return tables.map(t => this.version(t));
  }

  registerTable(schema) {
    const key = schema.name.toLowerCase();
    const existing = this.schemas.get(key);
    if (existing) {
      for (const [n, c] of schema.cols) {
        if (!existing.cols.has(n)) {
          existing.cols.set(n, c);
          existing.order.push(n);
        }
      }
      if (!existing.pk.length) existing.pk = schema.pk;
      for (const u of schema.uniques) {
        if (!existing.uniques.some(x => x.join() === u.join())) existing.uniques.push(u);
      }
      schema = existing;
    } else {
      this.schemas.set(key, schema);
    }
    schema.autoId = null;
    if (schema.pk.length === 1) {
      const c = schema.cols.get(schema.pk[0]);
      if (c && /^INTEGER$/i.test(c.type.trim())) schema.autoId = c.name;
    }
    return schema;
  }

  planIndexes(schema) {
    const plans = [];
    const lead = new Set();
    const addPlan = (cols, unique) => {
      const key = `${schema.name}:${unique ? 'u' : 'i'}:${cols.join(',')}`;
      lead.add(cols[0]);
      if (this.indexed.has(key)) return;
      this.indexed.add(key);
      plans.push({ table: schema.name, cols, unique });
    };
    if (schema.pk.length) addPlan(schema.pk, true);
    for (const u of schema.uniques) addPlan(u, true);
    for (const ix of schema.indexes) addPlan(ix.cols, ix.unique);
    for (const c of AUTO_INDEX_COLUMNS) {
      if (schema.cols.has(c) && !lead.has(c)) addPlan([c], false);
    }
    return plans;
  }

  async buildIndexes(plans) {
    await Promise.all(plans.map(async p => {
      const keys = {};
      for (const c of p.cols) keys[c] = 1;
      const opts = { name: `jx_${p.cols.join('_')}${p.unique ? '_u' : ''}`, background: true };
      if (p.unique) {
        opts.unique = true;
        const pf = {};
        for (const c of p.cols) pf[c] = { $type: ['string', 'int', 'long', 'double', 'decimal', 'date', 'bool', 'objectId'] };
        opts.partialFilterExpression = pf;
      }
      try {
        await withRetry(() => this.col(p.table).createIndex(keys, opts), true);
      } catch (e) {
        log('warn', `createIndex ${p.table}(${p.cols.join(',')}) dilewati: ${errText(e)}`);
      }
    }));
  }

  refreshDefaults(schema) {
    schema.defaultCols = [];
    for (const c of schema.cols.values()) {
      if (c.def && Object.prototype.hasOwnProperty.call(c.def, 'value') && c.def.value !== null && c.def.value !== undefined) {
        schema.defaultCols.push({ name: c.name, value: coerceByAffinity(c.affinity, c.def.value) });
      }
    }
  }

  fillRow(table, doc, projection) {
    const s = this.schemaOf(table);
    if (!s || !s.defaultCols) return doc;
    for (const c of s.defaultCols) {
      if (doc[c.name] === undefined && (!projection || projection[c.name])) doc[c.name] = c.value;
    }
    return doc;
  }

  defaultOf(table, name) {
    const c = this.colInfo(table, name);
    if (c && c.def && Object.prototype.hasOwnProperty.call(c.def, 'value') && c.def.value !== null) {
      return coerceByAffinity(c.affinity, c.def.value);
    }
    return undefined;
  }

  newEnv(params, sel) {
    const env = {
      params: params || [],
      now: Date.now(),
      aliases: [],
      byAlias: new Map(),
      group: null,
      excluded: null
    };
    if (sel && sel.from) {
      const add = (alias, table) => {
        const a = alias.toLowerCase();
        env.aliases.push(a);
        env.byAlias.set(a, table);
      };
      add(sel.from.alias, sel.from.table);
      for (const j of sel.joins) add(j.alias, j.table);
    }
    return env;
  }

  colOwner(node, env) {
    if (node.table) return node.table.toLowerCase();
    if (env.aliases.length <= 1) return env.aliases[0];
    for (const a of env.aliases) {
      if (this.colInfo(env.byAlias.get(a), node.name)) return a;
    }
    return env.aliases[0];
  }

  evalNode(node, ctx, env) {
    switch (node.type) {
      case 'lit': return node.v;
      case 'param': {
        const v = env.params[node.idx];
        return v === undefined ? null : v;
      }
      case 'col': {
        if (node.table && node.table.toLowerCase() === 'excluded' && env.excluded) {
          const v = env.excluded[node.name];
          return v === undefined ? null : v;
        }
        const alias = this.colOwner(node, env);
        const doc = ctx ? ctx[alias] : null;
        if (!doc) return null;
        if (node.name.toLowerCase() === 'rowid' && doc.rowid === undefined) return doc._id;
        const v = doc[node.name];
        return v === undefined ? null : v;
      }
      case 'neg': {
        const v = this.evalNode(node.e, ctx, env);
        return v === null ? null : -Number(v);
      }
      case 'bin': {
        const a = this.evalNode(node.l, ctx, env);
        const b = this.evalNode(node.r, ctx, env);
        if (a === null || b === null || a === undefined || b === undefined) return null;
        switch (node.op) {
          case '+': return Number(a) + Number(b);
          case '-': return Number(a) - Number(b);
          case '*': return Number(a) * Number(b);
          case '/': return Number(b) === 0 ? null : Number(a) / Number(b);
          case '%': return Number(b) === 0 ? null : Number(a) % Number(b);
          case '||': return String(a) + String(b);
          default: return null;
        }
      }
      case 'cmp': {
        const a = this.evalNode(node.l, ctx, env);
        const b = this.evalNode(node.r, ctx, env);
        if (a === null || b === null || a === undefined || b === undefined) return null;
        return this.compare(node.op, a, b) ? 1 : 0;
      }
      case 'and': {
        const a = this.evalNode(node.l, ctx, env);
        if (a !== null && !truthy(a)) return 0;
        const b = this.evalNode(node.r, ctx, env);
        if (b !== null && !truthy(b)) return 0;
        if (a === null || b === null) return null;
        return 1;
      }
      case 'or': {
        const a = this.evalNode(node.l, ctx, env);
        if (a !== null && truthy(a)) return 1;
        const b = this.evalNode(node.r, ctx, env);
        if (b !== null && truthy(b)) return 1;
        if (a === null || b === null) return null;
        return 0;
      }
      case 'not': {
        const v = this.evalNode(node.e, ctx, env);
        return v === null ? null : truthy(v) ? 0 : 1;
      }
      case 'isnull': {
        const v = this.evalNode(node.e, ctx, env);
        const isN = v === null || v === undefined;
        return (node.neg ? !isN : isN) ? 1 : 0;
      }
      case 'in': {
        const v = this.evalNode(node.e, ctx, env);
        if (v === null || v === undefined) return null;
        const vals = node.vals || node.list.map(x => this.evalNode(x, ctx, env));
        let found = false;
        let sawNull = false;
        for (const x of vals) {
          if (x === null || x === undefined) sawNull = true;
          else if (cmpVals(v, x) === 0) {
            found = true;
            break;
          }
        }
        if (found) return node.neg ? 0 : 1;
        if (sawNull) return null;
        return node.neg ? 1 : 0;
      }
      case 'like': {
        const v = this.evalNode(node.e, ctx, env);
        const p = this.evalNode(node.pattern, ctx, env);
        if (v === null || p === null || v === undefined || p === undefined) return null;
        const hit = new RegExp(likeSource(p), 'i').test(String(v));
        return (node.neg ? !hit : hit) ? 1 : 0;
      }
      case 'between': {
        const v = this.evalNode(node.e, ctx, env);
        const lo = this.evalNode(node.lo, ctx, env);
        const hi = this.evalNode(node.hi, ctx, env);
        if (v === null || lo === null || hi === null) return null;
        const hit = cmpVals(v, lo) >= 0 && cmpVals(v, hi) <= 0;
        return (node.neg ? !hit : hit) ? 1 : 0;
      }
      case 'existsSet': {
        const v = this.evalNode(node.outer, ctx, env);
        const hit = v !== null && v !== undefined && node.set.has(String(norm(v)));
        return (node.neg ? !hit : hit) ? 1 : 0;
      }
      case 'cast': {
        const v = this.evalNode(node.e, ctx, env);
        if (v === null) return null;
        if (node.to.includes('INT')) return Math.trunc(Number(v)) || 0;
        if (node.to.includes('REAL') || node.to.includes('NUM') || node.to.includes('FLOA') || node.to.includes('DOUB')) return Number(v) || 0;
        return String(v);
      }
      case 'case': {
        const base = node.base ? this.evalNode(node.base, ctx, env) : undefined;
        for (const w of node.whens) {
          const c = this.evalNode(w.cond, ctx, env);
          const ok = node.base ? (base !== null && c !== null && cmpVals(base, c) === 0) : truthy(c);
          if (ok) return this.evalNode(w.then, ctx, env);
        }
        return node.else ? this.evalNode(node.else, ctx, env) : null;
      }
      case 'fn': return this.evalFn(node, ctx, env);
      default:
        throw new Error(`Ekspresi SQL tidak didukung: ${node.type}`);
    }
  }

  compare(op, a, b) {
    const c = cmpVals(a, b);
    switch (op) {
      case '=': return c === 0;
      case '!=': return c !== 0;
      case '<': return c < 0;
      case '<=': return c <= 0;
      case '>': return c > 0;
      case '>=': return c >= 0;
      default: return false;
    }
  }

  evalFn(node, ctx, env) {
    if (isAggFn(node)) {
      if (!env.group) throw new Error(`Fungsi agregat ${node.name} dipakai di luar agregasi`);
      return this.computeAgg(node, env);
    }
    const name = node.name;
    const args = node.args.map(a => this.evalNode(a, ctx, env));
    switch (name) {
      case 'LOWER': return args[0] === null ? null : String(args[0]).toLowerCase();
      case 'UPPER': return args[0] === null ? null : String(args[0]).toUpperCase();
      case 'COALESCE':
      case 'IFNULL': {
        for (const a of args) if (a !== null && a !== undefined) return a;
        return null;
      }
      case 'NULLIF': return args[0] !== null && args[1] !== null && cmpVals(args[0], args[1]) === 0 ? null : args[0];
      case 'MAX':
      case 'MIN': {
        if (args.some(a => a === null || a === undefined)) return null;
        let best = args[0];
        for (const a of args) {
          const c = cmpVals(a, best);
          if ((name === 'MAX' && c > 0) || (name === 'MIN' && c < 0)) best = a;
        }
        return best;
      }
      case 'ABS': return args[0] === null ? null : Math.abs(Number(args[0]));
      case 'ROUND': return args[0] === null ? null : Number(Number(args[0]).toFixed(args[1] ? Number(args[1]) : 0));
      case 'LENGTH': return args[0] === null ? null : String(args[0]).length;
      case 'TRIM': return args[0] === null ? null : String(args[0]).trim();
      case 'SUBSTR':
      case 'SUBSTRING': {
        if (args[0] === null) return null;
        const s = String(args[0]);
        let start = Number(args[1]) || 1;
        start = start > 0 ? start - 1 : Math.max(0, s.length + start);
        return args[2] === undefined || args[2] === null ? s.slice(start) : s.substr(start, Number(args[2]));
      }
      case 'STRFTIME': {
        if (String(args[0]) === '%s') return Math.floor(env.now / 1000);
        throw new Error('strftime hanya mendukung format %s');
      }
      case 'UNIXEPOCH': return Math.floor(env.now / 1000);
      default:
        throw new Error(`Fungsi SQL tidak didukung: ${name}`);
    }
  }

  computeAgg(node, env) {
    const rows = env.group;
    const child = Object.assign({}, env, { group: null });
    if (node.name === 'COUNT' && (node.star || !node.args.length)) return rows.length;
    const vals = [];
    const seen = node.distinct ? new Set() : null;
    for (const r of rows) {
      const v = this.evalNode(node.args[0], r, child);
      if (v === null || v === undefined) continue;
      if (seen) {
        const k = String(norm(v));
        if (seen.has(k)) continue;
        seen.add(k);
      }
      vals.push(v);
    }
    switch (node.name) {
      case 'COUNT': return vals.length;
      case 'SUM': return vals.length ? vals.reduce((a, b) => a + Number(b), 0) : null;
      case 'TOTAL': return vals.reduce((a, b) => a + Number(b), 0);
      case 'AVG': return vals.length ? vals.reduce((a, b) => a + Number(b), 0) / vals.length : null;
      case 'MIN': return vals.length ? vals.reduce((a, b) => (cmpVals(a, b) <= 0 ? a : b)) : null;
      case 'MAX': return vals.length ? vals.reduce((a, b) => (cmpVals(a, b) >= 0 ? a : b)) : null;
      case 'GROUP_CONCAT': return vals.length ? vals.map(String).join(',') : null;
      default: return null;
    }
  }

  isConst(node) {
    let ok = true;
    walk(node, n => {
      if (n.type === 'col' || n.type === 'select' || n.type === 'union' || n.type === 'subq' || n.type === 'exists' || n.type === 'existsSet' || isAggFn(n)) ok = false;
      return ok;
    });
    return ok;
  }

  constOf(node, env) {
    if (!this.isConst(node)) return NOT_CONST;
    try {
      return this.evalNode(node, {}, env);
    } catch (_) {
      return NOT_CONST;
    }
  }

  asCol(node, owner, env) {
    if (!node || node.type !== 'col') return null;
    if (node.table && node.table.toLowerCase() === 'excluded') return null;
    return this.colOwner(node, env) === owner ? node : null;
  }

  fieldOf(node) {
    return node.name.toLowerCase() === 'rowid' ? '_id' : node.name;
  }

  valueFor(node, owner, env, v) {
    if (node.name.toLowerCase() === 'rowid') return toObjectId(v);
    return this.coerce(env.byAlias.get(owner), node.name, v);
  }

  missingMatches(owner, env, node, pred) {
    const d = this.defaultOf(env.byAlias.get(owner), node.name);
    return d !== undefined && pred(d);
  }

  pushFilter(node, owner, env) {
    switch (node.type) {
      case 'and': {
        const a = this.pushFilter(node.l, owner, env);
        const b = this.pushFilter(node.r, owner, env);
        if (!a || !b) return null;
        return { $and: [a, b] };
      }
      case 'or': {
        const a = this.pushFilter(node.l, owner, env);
        const b = this.pushFilter(node.r, owner, env);
        if (!a || !b) return null;
        return { $or: [a, b] };
      }
      case 'not': {
        const a = this.pushFilter(node.e, owner, env);
        return a ? { $nor: [a] } : null;
      }
      case 'cmp': return this.pushCmp(node, owner, env);
      case 'isnull': {
        const c = this.asCol(node.e, owner, env);
        if (!c) return null;
        const f = this.fieldOf(c);
        const hasDef = this.defaultOf(env.byAlias.get(owner), c.name) !== undefined;
        if (!node.neg) return hasDef ? { [f]: { $type: 'null' } } : { [f]: null };
        return hasDef ? { $or: [{ [f]: { $ne: null } }, { [f]: { $exists: false } }] } : { [f]: { $ne: null } };
      }
      case 'in': {
        const c = this.asCol(node.e, owner, env);
        if (!c) return null;
        let vals;
        if (node.vals) vals = node.vals;
        else {
          vals = [];
          for (const x of node.list) {
            const v = this.constOf(x, env);
            if (v === NOT_CONST) return null;
            vals.push(v);
          }
        }
        const f = this.fieldOf(c);
        const clean = vals.filter(v => v !== null && v !== undefined).map(v => this.valueFor(c, owner, env, v));
        if (!node.neg) {
          if (!clean.length) return NEVER;
          const base = { [f]: { $in: clean } };
          if (this.missingMatches(owner, env, c, d => clean.some(x => cmpVals(d, x) === 0))) return { $or: [base, { [f]: { $exists: false } }] };
          return base;
        }
        if (vals.length !== clean.length) return NEVER;
        const base = { [f]: { $nin: clean.concat([null]) } };
        if (this.missingMatches(owner, env, c, d => !clean.some(x => cmpVals(d, x) === 0))) return { $or: [base, { [f]: { $exists: false } }] };
        return base;
      }
      case 'like': {
        const c = this.asCol(node.e, owner, env);
        if (!c) return null;
        const p = this.constOf(node.pattern, env);
        if (p === NOT_CONST) return null;
        if (p === null) return NEVER;
        const f = this.fieldOf(c);
        if (!node.neg) return { [f]: { $regex: likeSource(p), $options: 'i' } };
        return { $and: [{ [f]: { $ne: null } }, { [f]: { $not: new RegExp(likeSource(p), 'i') } }] };
      }
      case 'between': {
        const c = this.asCol(node.e, owner, env);
        if (!c) return null;
        const lo = this.constOf(node.lo, env);
        const hi = this.constOf(node.hi, env);
        if (lo === NOT_CONST || hi === NOT_CONST) return null;
        if (lo === null || hi === null) return NEVER;
        const f = this.fieldOf(c);
        const base = { [f]: { $gte: this.valueFor(c, owner, env, lo), $lte: this.valueFor(c, owner, env, hi) } };
        return node.neg ? { $nor: [base] } : base;
      }
      default: return null;
    }
  }

  lowerCol(node, owner, env) {
    if (node && node.type === 'fn' && node.name === 'LOWER' && node.args.length === 1) return this.asCol(node.args[0], owner, env);
    return null;
  }

  lowerConst(node, env) {
    if (node && node.type === 'fn' && node.name === 'LOWER' && node.args.length === 1) {
      const v = this.constOf(node.args[0], env);
      return v === NOT_CONST ? NOT_CONST : v === null ? null : String(v).toLowerCase();
    }
    const v = this.constOf(node, env);
    return v === NOT_CONST ? NOT_CONST : v === null ? null : typeof v === 'string' ? v.toLowerCase() : NOT_CONST;
  }

  pushCmp(node, owner, env) {
    let op = node.op;
    let c = this.asCol(node.l, owner, env);
    let other = node.r;
    if (!c) {
      c = this.asCol(node.r, owner, env);
      other = node.l;
      if (c) op = { '<': '>', '<=': '>=', '>': '<', '>=': '<=', '=': '=', '!=': '!=' }[op];
    }
    if (c) {
      const v = this.constOf(other, env);
      if (v === NOT_CONST) return null;
      if (v === null || v === undefined) return NEVER;
      const f = this.fieldOf(c);
      const val = this.valueFor(c, owner, env, v);
      let base;
      if (op === '=') base = { [f]: val };
      else if (op === '!=') base = { [f]: { $nin: [val, null] } };
      else base = { [f]: { [{ '<': '$lt', '<=': '$lte', '>': '$gt', '>=': '$gte' }[op]]: val } };
      if (this.missingMatches(owner, env, c, d => this.compare(op, d, val))) return { $or: [base, { [f]: { $exists: false } }] };
      return base;
    }
    if (op === '=') {
      let lc = this.lowerCol(node.l, owner, env);
      let oth = node.r;
      if (!lc) {
        lc = this.lowerCol(node.r, owner, env);
        oth = node.l;
      }
      if (lc) {
        const v = this.lowerConst(oth, env);
        if (v === NOT_CONST) return null;
        if (v === null) return NEVER;
        return { [this.fieldOf(lc)]: { $regex: `^${escapeRegex(v)}$`, $options: 'i' } };
      }
    }
    return null;
  }

  aliasesOf(node, env) {
    const set = new Set();
    walk(node, n => {
      if (n.type === 'col' && !(n.table && n.table.toLowerCase() === 'excluded')) set.add(this.colOwner(n, env));
      if (n.type === 'select' || n.type === 'union') return false;
      return true;
    });
    return set;
  }

  async resolveSubs(node, env) {
    if (!node || typeof node !== 'object') return node;
    if (Array.isArray(node)) {
      const out = [];
      for (const n of node) out.push(await this.resolveSubs(n, env));
      return out;
    }
    if (node.type === 'select' || node.type === 'union') return node;
    if (node.type === 'in' && node.sub) {
      const rows = await this.execSelectAst(node.sub, env.params);
      const vals = rows.map(r => r[Object.keys(r)[0]]);
      return { type: 'in', e: await this.resolveSubs(node.e, env), vals, neg: node.neg };
    }
    if (node.type === 'subq') {
      const rows = await this.execSelectAst(node.sub, env.params);
      const first = rows[0];
      return { type: 'lit', v: first ? first[Object.keys(first)[0]] : null };
    }
    if (node.type === 'exists') return this.resolveExists(node, env);
    const out = {};
    for (const k of Object.keys(node)) {
      const v = node[k];
      out[k] = v && typeof v === 'object' ? await this.resolveSubs(v, env) : v;
    }
    return out;
  }

  async resolveExists(node, env) {
    const sub = node.sub;
    const constant = async () => {
      const rows = await this.execSelectAst(sub, env.params);
      return { type: 'lit', v: (rows.length > 0) !== node.neg ? 1 : 0 };
    };
    if (sub.type !== 'select' || !sub.from) return constant();
    const subAlias = sub.from.alias.toLowerCase();
    const conj = splitAnd(sub.where);
    let corr = null;
    const rest = [];
    for (const c of conj) {
      if (!corr && c.type === 'cmp' && c.op === '=' && c.l.type === 'col' && c.r.type === 'col') {
        const lOwn = c.l.table ? c.l.table.toLowerCase() : subAlias;
        const rOwn = c.r.table ? c.r.table.toLowerCase() : subAlias;
        if (lOwn === subAlias && rOwn !== subAlias) {
          corr = { subCol: c.l, outer: c.r };
          continue;
        }
        if (rOwn === subAlias && lOwn !== subAlias) {
          corr = { subCol: c.r, outer: c.l };
          continue;
        }
      }
      rest.push(c);
    }
    if (!corr) return constant();
    const subAst = Object.assign({}, sub, {
      cols: [{ expr: { type: 'col', table: null, name: corr.subCol.name }, alias: 'k', text: 'k' }],
      where: joinAnd(rest),
      distinct: true,
      orderBy: [],
      limit: null,
      offset: null
    });
    const rows = await this.execSelectAst(subAst, env.params);
    const set = new Set();
    for (const r of rows) if (r.k !== null && r.k !== undefined) set.add(String(norm(r.k)));
    return { type: 'existsSet', neg: node.neg, outer: corr.outer, set };
  }

  collectRefs(ast, env) {
    const refs = new Map();
    const star = new Set();
    for (const c of ast.cols) {
      if (c.star) {
        if (c.table) star.add(c.table.toLowerCase());
        else for (const a of env.aliases) star.add(a);
      }
    }
    const visit = n => {
      walk(n, x => {
        if (x.type === 'col' && !(x.table && x.table.toLowerCase() === 'excluded')) {
          const a = this.colOwner(x, env);
          if (!refs.has(a)) refs.set(a, new Set());
          refs.get(a).add(x.name);
        }
        if (x.type === 'select' || x.type === 'union') return false;
        return true;
      });
    };
    for (const c of ast.cols) if (c.expr) visit(c.expr);
    visit(ast.where);
    visit(ast.groupBy);
    visit(ast.having);
    for (const o of ast.orderBy) visit(o.expr);
    for (const j of ast.joins) visit(j.on);
    return { refs, star };
  }

  projectionFor(alias, info) {
    if (info.star.has(alias)) return null;
    const set = info.refs.get(alias);
    const p = { _id: 1 };
    if (set) {
      for (const n of set) {
        if (n.toLowerCase() !== 'rowid') p[n] = 1;
      }
    }
    return p;
  }

  async execSelectAst(ast, params, opts = {}) {
    if (ast.type === 'union') {
      let rows = [];
      for (const p of ast.parts) rows = rows.concat(await this.execSelectAst(p, params));
      if (!ast.all) {
        const seen = new Set();
        rows = rows.filter(r => {
          const k = JSON.stringify(r);
          if (seen.has(k)) return false;
          seen.add(k);
          return true;
        });
      }
      return rows;
    }
    const env = this.newEnv(params, ast);
    if (!ast.from) {
      const out = {};
      for (const c of ast.cols) {
        if (!c.star) out[c.alias || c.text] = this.evalNode(c.expr, {}, env);
      }
      return [out];
    }
    const sel = Object.assign({}, ast);
    sel.where = await this.resolveSubs(ast.where, env);
    sel.having = await this.resolveSubs(ast.having, env);
    sel.joins = [];
    for (const j of ast.joins) sel.joins.push(Object.assign({}, j, { on: await this.resolveSubs(j.on, env) }));

    const info = this.collectRefs(sel, env);
    const base = env.aliases[0];
    const aggregated = sel.cols.some(c => c.expr && hasAgg(c.expr)) || sel.groupBy.length > 0 || !!(sel.having && hasAgg(sel.having));
    const residual = [];
    const pushed = new Map();
    const allowPush = alias => {
      if (alias === base) return true;
      const j = sel.joins[env.aliases.indexOf(alias) - 1];
      return !!j && j.type === 'inner';
    };
    for (const c of splitAnd(sel.where)) {
      const owners = this.aliasesOf(c, env);
      let done = false;
      if (owners.size <= 1) {
        const owner = owners.size === 1 ? Array.from(owners)[0] : base;
        if (allowPush(owner)) {
          const f = this.pushFilter(c, owner, env);
          if (f) {
            if (!pushed.has(owner)) pushed.set(owner, []);
            pushed.get(owner).push(f);
            done = true;
          }
        }
      }
      if (!done) residual.push(c);
    }

    const baseTable = env.byAlias.get(base);
    const flat = sel.joins.length === 0 && residual.length === 0;
    const simple = flat && !aggregated;
    const canPushOrder = simple && !sel.distinct && sel.orderBy.every(o => o.expr.type === 'col' && this.colOwner(o.expr, env) === base);
    const needsAll = !simple || sel.distinct || (sel.orderBy.length > 0 && !canPushOrder);

    let limit = null;
    let offset = 0;
    if (sel.limit) {
      const lv = this.evalNode(sel.limit, {}, env);
      limit = lv === null || lv === undefined || Number(lv) < 0 ? null : Number(lv);
    }
    if (sel.offset) offset = Math.max(0, Number(this.evalNode(sel.offset, {}, env)) || 0);
    if (opts.first && !aggregated) limit = limit === null ? 1 : Math.min(limit, 1);

    const baseFilter = andFilters(pushed.get(base) || []);
    const first = sel.cols[0];

    if (flat && sel.cols.length === 1 && first.expr && first.expr.type === 'fn' && first.expr.name === 'COUNT' &&
      !first.expr.distinct && (first.expr.star || !first.expr.args.length) && !sel.groupBy.length && !sel.having && !sel.distinct) {
      const n = await withRetry(() => this.col(baseTable).countDocuments(baseFilter, { maxTimeMS: OP_MAX_TIME_MS }), false);
      return [{ [first.alias || first.text]: n }];
    }

    const proj = this.projectionFor(base, info);
    const fetchOpts = { maxTimeMS: OP_MAX_TIME_MS };
    if (proj) fetchOpts.projection = proj;
    const fetchBase = async () => {
      let cursor = this.col(baseTable).find(baseFilter, fetchOpts);
      if (!needsAll) {
        if (sel.orderBy.length) {
          const sort = {};
          for (const o of sel.orderBy) sort[this.fieldOf(o.expr)] = o.dir === 'desc' ? -1 : 1;
          cursor = cursor.sort(sort);
        }
        if (offset) cursor = cursor.skip(offset);
        if (limit !== null) cursor = cursor.limit(limit);
      }
      return cursor.toArray();
    };
    const docs = await withRetry(fetchBase, false);
    for (const d of docs) this.fillRow(baseTable, d, proj);
    let rows = docs.map(d => ({ [base]: d }));

    for (let ji = 0; ji < sel.joins.length; ji++) {
      const j = sel.joins[ji];
      const alias = env.aliases[ji + 1];
      const table = env.byAlias.get(alias);
      const prior = new Set(env.aliases.slice(0, ji + 1));
      const joinFilters = pushed.get(alias) ? pushed.get(alias).slice() : [];
      const onResidual = [];
      let key = null;
      for (const c of splitAnd(j.on)) {
        if (!key && c.type === 'cmp' && c.op === '=' && c.l.type === 'col' && c.r.type === 'col') {
          const lo = this.colOwner(c.l, env);
          const ro = this.colOwner(c.r, env);
          if (lo === alias && prior.has(ro)) {
            key = { right: c.l, left: c.r };
            continue;
          }
          if (ro === alias && prior.has(lo)) {
            key = { right: c.r, left: c.l };
            continue;
          }
        }
        const owners = this.aliasesOf(c, env);
        if (owners.size === 1 && owners.has(alias)) {
          const f = this.pushFilter(c, alias, env);
          if (f) {
            joinFilters.push(f);
            continue;
          }
        }
        onResidual.push(c);
      }
      const jOpts = { maxTimeMS: OP_MAX_TIME_MS };
      const jproj = this.projectionFor(alias, info);
      if (jproj) jOpts.projection = jproj;
      let rightDocs;
      if (key) {
        const keys = new Map();
        for (const r of rows) {
          const v = this.evalNode(key.left, r, env);
          if (v !== null && v !== undefined) keys.set(String(norm(v)), v);
        }
        const rf = joinFilters.slice();
        if (keys.size <= 5000) {
          const vals = [];
          for (const v of keys.values()) {
            const cv = this.valueFor(key.right, alias, env, v);
            vals.push(cv);
            if (cv !== v) vals.push(v);
          }
          rf.push({ [this.fieldOf(key.right)]: { $in: vals } });
        }
        rightDocs = keys.size ? await withRetry(() => this.col(table).find(andFilters(rf), jOpts).toArray(), false) : [];
      } else {
        rightDocs = await withRetry(() => this.col(table).find(andFilters(joinFilters), jOpts).toArray(), false);
      }
      for (const d of rightDocs) this.fillRow(table, d, jproj);
      const index = new Map();
      if (key) {
        for (const d of rightDocs) {
          const rv = key.right.name.toLowerCase() === 'rowid' ? d._id : d[key.right.name];
          if (rv === null || rv === undefined) continue;
          const k = String(norm(rv));
          if (!index.has(k)) index.set(k, []);
          index.get(k).push(d);
        }
      }
      const next = [];
      for (const r of rows) {
        let cands;
        if (key) {
          const lv = this.evalNode(key.left, r, env);
          cands = lv === null || lv === undefined ? [] : index.get(String(norm(lv))) || [];
        } else cands = rightDocs;
        let matched = false;
        for (const d of cands) {
          const ctx = Object.assign({}, r, { [alias]: d });
          let ok = true;
          for (const c of onResidual) {
            if (!truthy(this.evalNode(c, ctx, env))) {
              ok = false;
              break;
            }
          }
          if (ok) {
            matched = true;
            next.push(ctx);
          }
        }
        if (!matched && j.type === 'left') next.push(Object.assign({}, r, { [alias]: null }));
      }
      rows = next;
    }

    if (residual.length) {
      rows = rows.filter(r => {
        for (const c of residual) if (!truthy(this.evalNode(c, r, env))) return false;
        return true;
      });
    }

    const colName = c => c.alias || (c.expr.type === 'col' ? c.expr.name : c.text);
    const buildOut = (ctx, groupRows) => {
      const out = {};
      const e2 = groupRows ? Object.assign({}, env, { group: groupRows }) : env;
      for (const c of sel.cols) {
        if (c.star) {
          const targets = c.table ? [c.table.toLowerCase()] : env.aliases;
          for (const a of targets) {
            const d = ctx[a];
            if (!d) continue;
            for (const k of Object.keys(d)) if (k !== '_id') out[k] = d[k];
          }
          continue;
        }
        const v = this.evalNode(c.expr, ctx, e2);
        out[colName(c)] = v === undefined ? null : v;
      }
      return out;
    };
    const orderExprs = sel.orderBy.map(o => {
      let expr = o.expr;
      if (expr.type === 'col' && !expr.table) {
        const hit = sel.cols.find(c => c.alias && c.alias.toLowerCase() === expr.name.toLowerCase());
        if (hit) expr = hit.expr;
      } else if (expr.type === 'lit' && typeof expr.v === 'number') {
        const hit = sel.cols[expr.v - 1];
        if (hit && hit.expr) expr = hit.expr;
      }
      return { expr, dir: o.dir };
    });

    let entries;
    if (aggregated) {
      const groups = new Map();
      if (!sel.groupBy.length) groups.set('', rows);
      else {
        for (const r of rows) {
          const k = JSON.stringify(sel.groupBy.map(g => norm(this.evalNode(g, r, env))));
          if (!groups.has(k)) groups.set(k, []);
          groups.get(k).push(r);
        }
      }
      entries = [];
      for (const g of groups.values()) {
        const ctx = g[0] || {};
        if (sel.having && !truthy(this.evalNode(sel.having, ctx, Object.assign({}, env, { group: g })))) continue;
        entries.push({ ctx, group: g, out: buildOut(ctx, g) });
      }
    } else {
      entries = rows.map(r => ({ ctx: r, group: null, out: null }));
    }

    if (orderExprs.length && needsAll) {
      for (const en of entries) {
        const e2 = en.group ? Object.assign({}, env, { group: en.group }) : env;
        en.keys = orderExprs.map(o => this.evalNode(o.expr, en.ctx, e2));
      }
      entries.sort((a, b) => {
        for (let i = 0; i < orderExprs.length; i++) {
          const c = sortCmp(a.keys[i], b.keys[i]);
          if (c !== 0) return orderExprs[i].dir === 'desc' ? -c : c;
        }
        return 0;
      });
    }

    let result = entries.map(en => en.out || buildOut(en.ctx, null));
    if (sel.distinct) {
      const seen = new Set();
      result = result.filter(r => {
        const k = JSON.stringify(r);
        if (seen.has(k)) return false;
        seen.add(k);
        return true;
      });
    }
    if (needsAll) {
      if (offset) result = result.slice(offset);
      if (limit !== null) result = result.slice(0, limit);
    }
    return result;
  }

  cacheKey(sql, params, first) {
    return `${first ? 1 : 0}|${sql}|${JSON.stringify(params, (k, v) => (typeof v === 'bigint' ? Number(v) : v))}`;
  }

  cloneRows(rows) {
    return rows.map(r => Object.assign({}, r));
  }

  async select(sql, params, first) {
    const ast = this.parse(sql);
    if (ast.type !== 'select' && ast.type !== 'union') throw new Error('Bukan SELECT');
    this.stat.reads++;
    const tables = this.tablesOf(ast);
    const key = this.cacheKey(sql, params, first);
    const snap = this.snapshot(tables);
    const same = other => other.every((v, i) => v === snap[i]);
    const hit = this.cache.get(key);
    if (hit) {
      if (Date.now() - hit.ts < CACHE_TTL_MS && same(hit.snap)) {
        this.stat.hits++;
        return this.cloneRows(hit.rows);
      }
      this.evict(key);
    }
    const pending = this.inflight.get(key);
    if (pending && same(pending.snap)) {
      this.stat.coalesced++;
      return this.cloneRows(await pending.promise);
    }
    this.stat.misses++;
    const promise = this.execSelectAst(ast, params, { first });
    const entry = { promise, snap };
    this.inflight.set(key, entry);
    try {
      const rows = await promise;
      if (rows.length <= CACHE_MAX_ROWS && same(this.snapshot(tables))) this.store(key, rows, snap);
      return this.cloneRows(rows);
    } finally {
      if (this.inflight.get(key) === entry) this.inflight.delete(key);
    }
  }

  evict(key) {
    const v = this.cache.get(key);
    if (!v) return;
    this.cacheRows -= v.rows.length;
    this.cache.delete(key);
  }

  store(key, rows, snap) {
    this.evict(key);
    while (this.cache.size >= CACHE_MAX_ENTRIES || this.cacheRows + rows.length > CACHE_TOTAL_ROWS) {
      const oldest = this.cache.keys().next().value;
      if (oldest === undefined) break;
      this.evict(oldest);
    }
    this.cache.set(key, { rows: this.cloneRows(rows), ts: Date.now(), snap });
    this.cacheRows += rows.length;
  }

  clearCache() {
    this.cache.clear();
    this.cacheRows = 0;
    this.parsed.clear();
  }

  sweep() {
    const now = Date.now();
    for (const [k, v] of this.cache) if (now - v.ts >= CACHE_TTL_MS) this.evict(k);
  }

  async nextSeq(table) {
    const name = String(table).toLowerCase();
    if (!this.seeded.has(name)) {
      const schema = this.schemaOf(name);
      const idCol = (schema && schema.autoId) || 'id';
      let max = 0;
      try {
        const top = await this.col(table).find({ [idCol]: { $type: 'number' } }, { projection: { [idCol]: 1 } }).sort({ [idCol]: -1 }).limit(1).toArray();
        if (top[0] && Number.isFinite(Number(top[0][idCol]))) max = Number(top[0][idCol]);
      } catch (e) {
        log('warn', `seed counter ${table}: ${errText(e)}`);
      }
      await withRetry(() => this.counters.updateOne({ _id: table }, { $max: { seq: max } }, { upsert: true }), true);
      this.seeded.add(name);
    }
    const res = await withRetry(() => this.counters.findOneAndUpdate({ _id: table }, { $inc: { seq: 1 } }, { upsert: true, returnDocument: 'after' }), true);
    const doc = res && res.seq === undefined && res.value ? res.value : res;
    return doc && doc.seq ? doc.seq : 1;
  }

  evalDefault(def, env) {
    if (!def) return undefined;
    if (Object.prototype.hasOwnProperty.call(def, 'value')) return def.value;
    if (def.expr) {
      if (/^CURRENT_/i.test(def.expr)) return Math.floor(Date.now() / 1000);
      try {
        return this.evalNode(new Parser(def.expr).parseExpr(), {}, env);
      } catch (_) {
        return undefined;
      }
    }
    return undefined;
  }

  keyFor(schema, doc, conflictCols, skipPk) {
    const candidates = [];
    if (conflictCols && conflictCols.length) candidates.push(conflictCols);
    if (schema) {
      if (schema.pk.length && !(skipPk && schema.autoId && schema.pk.length === 1)) candidates.push(schema.pk);
      for (const u of schema.uniques) candidates.push(u);
    }
    for (const cols of candidates) {
      if (cols.every(c => doc[c] !== undefined && doc[c] !== null)) {
        const f = {};
        for (const c of cols) f[c] = doc[c];
        return f;
      }
    }
    return null;
  }

  async execInsert(ast, params) {
    const table = ast.table;
    const schema = this.schemaOf(table);
    const env = this.newEnv(params, null);
    let cols = ast.cols;
    const valueRows = [];
    if (ast.select) {
      const sel = await this.execSelectAst(ast.select, params);
      for (const r of sel) {
        const keys = Object.keys(r);
        const useCols = cols.length ? cols : keys;
        const o = {};
        useCols.forEach((c, i) => { o[c] = r[cols.length ? keys[i] : c]; });
        valueRows.push(o);
      }
    } else {
      if (!cols.length && schema) cols = schema.order;
      for (const r of ast.rows) {
        const o = {};
        cols.forEach((c, i) => { o[c] = r[i] ? this.evalNode(r[i], {}, env) : null; });
        valueRows.push(o);
      }
    }
    let changes = 0;
    let lastID = 0;
    for (const raw of valueRows) {
      const doc = {};
      for (const k of Object.keys(raw)) {
        if (raw[k] !== undefined) doc[k] = this.coerce(table, k, raw[k]);
      }
      if (schema) {
        for (const c of schema.cols.values()) {
          if (doc[c.name] === undefined && c.def) {
            const dv = this.evalDefault(c.def, env);
            if (dv !== undefined && dv !== null) doc[c.name] = coerceByAffinity(c.affinity, dv);
          }
        }
      }
      const idCol = schema ? schema.autoId : (SEQ_TABLES.has(table) ? 'id' : null);
      let autoGen = false;
      if (idCol && (doc[idCol] === undefined || doc[idCol] === null)) {
        doc[idCol] = await this.nextSeq(table);
        autoGen = true;
      }
      const n = await this.insertDoc(ast, schema, table, doc, env, autoGen);
      changes += n;
      if (idCol && n) lastID = Number(doc[idCol]) || 0;
    }
    this.bump(table);
    return { changes, lastID };
  }

  async insertDoc(ast, schema, table, doc, env, autoGen) {
    const col = this.col(table);
    const conflict = ast.conflict;
    const key = this.keyFor(schema, doc, conflict && conflict.cols, autoGen);
    if (ast.orReplace && key) {
      await withRetry(() => col.replaceOne(key, doc, { upsert: true }), true);
      return 1;
    }
    if ((ast.orIgnore || (conflict && conflict.action === 'nothing')) && key) {
      try {
        const r = await withRetry(() => col.updateOne(key, { $setOnInsert: doc }, { upsert: true }), true);
        return r && r.upsertedCount ? 1 : 0;
      } catch (e) {
        if (!isDup(e)) throw e;
        return 0;
      }
    }
    if (conflict && conflict.action === 'update' && key) {
      const alias = table.toLowerCase();
      const e2 = Object.assign({}, env, { excluded: doc, aliases: [alias], byAlias: new Map([[alias, table]]) });
      const doUpdate = async () => {
        const existing = await withRetry(() => col.findOne(key), false);
        if (!existing) return false;
        const $set = {};
        for (const s of conflict.sets) $set[s.col] = this.coerce(table, s.col, this.evalNode(s.expr, { [alias]: existing }, e2));
        await withRetry(() => col.updateOne({ _id: existing._id }, { $set }), true);
        return true;
      };
      if (await doUpdate()) return 1;
      try {
        await withRetry(() => col.insertOne(doc), true);
      } catch (e) {
        if (!isDup(e)) throw e;
        await doUpdate();
      }
      return 1;
    }
    try {
      await withRetry(() => col.insertOne(doc), true);
      return 1;
    } catch (e) {
      if (!isDup(e)) throw e;
      if (ast.orIgnore) return 0;
      if (ast.orReplace && key) {
        await withRetry(() => col.replaceOne(key, doc, { upsert: true }), true);
        return 1;
      }
      throw constraintError(e, table);
    }
  }

  async whereFilter(table, whereNode, params) {
    const alias = table.toLowerCase();
    const env = this.newEnv(params, { from: { table, alias }, joins: [] });
    const resolved = await this.resolveSubs(whereNode, env);
    const filters = [];
    const residual = [];
    for (const c of splitAnd(resolved)) {
      const f = this.pushFilter(c, alias, env);
      if (f) filters.push(f);
      else residual.push(c);
    }
    return { env, filter: andFilters(filters), residual };
  }

  async matchedDocs(table, filter, residual, env) {
    const docs = await withRetry(() => this.col(table).find(filter, { maxTimeMS: OP_MAX_TIME_MS }).toArray(), false);
    const alias = table.toLowerCase();
    const out = [];
    for (const d of docs) {
      this.fillRow(table, d, null);
      if (residual.every(c => truthy(this.evalNode(c, { [alias]: d }, env)))) out.push(d);
    }
    return out;
  }

  async execUpdate(ast, params) {
    const table = ast.table;
    const alias = table.toLowerCase();
    const { env, filter, residual } = await this.whereFilter(table, ast.where, params);
    const sets = [];
    for (const s of ast.sets) sets.push({ col: s.col, expr: await this.resolveSubs(s.expr, env) });
    const $set = {};
    const $inc = {};
    let perDoc = residual.length > 0;
    if (!perDoc) {
      for (const s of sets) {
        const e = s.expr;
        const v = this.constOf(e, env);
        if (v !== NOT_CONST) {
          $set[s.col] = this.coerce(table, s.col, v);
          continue;
        }
        if (e.type === 'bin' && (e.op === '+' || e.op === '-') && e.l.type === 'col' && e.l.name.toLowerCase() === s.col.toLowerCase() && !e.l.table) {
          const by = this.constOf(e.r, env);
          if (by !== NOT_CONST && by !== null && Number.isFinite(Number(by))) {
            $inc[s.col] = e.op === '+' ? Number(by) : -Number(by);
            continue;
          }
        }
        perDoc = true;
        break;
      }
    }
    let changes = 0;
    if (!perDoc) {
      const update = {};
      if (Object.keys($set).length) update.$set = $set;
      if (Object.keys($inc).length) update.$inc = $inc;
      if (!Object.keys(update).length) return { changes: 0, lastID: 0 };
      const r = await withRetry(() => this.col(table).updateMany(filter, update), $inc && Object.keys($inc).length ? true : 'idem');
      changes = r.matchedCount;
    } else {
      const docs = await this.matchedDocs(table, filter, residual, env);
      const ops = docs.map(d => {
        const set = {};
        for (const s of sets) set[s.col] = this.coerce(table, s.col, this.evalNode(s.expr, { [alias]: d }, env));
        return { updateOne: { filter: { _id: d._id }, update: { $set: set } } };
      });
      for (let i = 0; i < ops.length; i += 500) {
        await withRetry(() => this.col(table).bulkWrite(ops.slice(i, i + 500), { ordered: false }), true);
      }
      changes = ops.length;
    }
    if (!ast.sets.every(x => VOLATILE_COLUMNS.has(String(x.col).toLowerCase()))) this.bump(table);
    return { changes, lastID: 0 };
  }

  async execDelete(ast, params) {
    const table = ast.table;
    const { env, filter, residual } = await this.whereFilter(table, ast.where, params);
    let changes = 0;
    if (!residual.length) {
      const r = await withRetry(() => this.col(table).deleteMany(filter), true);
      changes = r.deletedCount;
    } else {
      const docs = await this.matchedDocs(table, filter, residual, env);
      for (let i = 0; i < docs.length; i += 1000) {
        const ids = docs.slice(i, i + 1000).map(d => d._id);
        const r = await withRetry(() => this.col(table).deleteMany({ _id: { $in: ids } }), true);
        changes += r.deletedCount;
      }
    }
    this.bump(table);
    return { changes, lastID: 0 };
  }

  async execDdl(stmt) {
    const ddl = parseDdl(stmt);
    if (!ddl) return false;
    if (ddl.kind === 'table') {
      const schema = this.registerTable(ddl.schema);
      this.refreshDefaults(schema);
      this.pendingIndexes.push(...this.planIndexes(schema));
    } else if (ddl.kind === 'index') {
      const schema = this.schemaOf(ddl.table);
      if (schema) {
        schema.indexes.push({ cols: ddl.cols, unique: ddl.unique });
        this.pendingIndexes.push(...this.planIndexes(schema));
      } else {
        this.pendingIndexes.push({ table: ddl.table, cols: ddl.cols, unique: ddl.unique });
      }
    } else if (ddl.kind === 'addcolumn') {
      const schema = this.schemaOf(ddl.table);
      if (schema) {
        if (!schema.cols.has(ddl.col.name)) {
          schema.cols.set(ddl.col.name, ddl.col);
          schema.order.push(ddl.col.name);
        }
        this.refreshDefaults(schema);
        this.bump(ddl.table);
      }
    }
    return true;
  }

  async flushIndexes() {
    if (!this.pendingIndexes.length) return;
    const plans = this.pendingIndexes;
    this.pendingIndexes = [];
    await this.buildIndexes(plans);
  }

  async tableInfo(table) {
    const schema = this.schemaOf(table);
    if (schema) {
      return schema.order.map((name, i) => {
        const c = schema.cols.get(name);
        return { cid: i, name, type: c.type || '', notnull: 0, dflt_value: null, pk: schema.pk.includes(name) ? 1 : 0 };
      });
    }
    const sample = await withRetry(() => this.col(table).findOne({}), false);
    if (!sample) return [];
    return Object.keys(sample).filter(k => k !== '_id').map((name, i) => ({ cid: i, name, type: '', notnull: 0, dflt_value: null, pk: 0 }));
  }
}

function flattenParams(params) {
  if (params.length === 1 && Array.isArray(params[0])) return params[0];
  return params;
}

function buildAdapter(eng) {
  const adapter = {
    async get(sql, ...params) {
      const rows = await adapter.query(sql, flattenParams(params), true);
      return rows[0] || undefined;
    },

    async all(sql, ...params) {
      return adapter.query(sql, flattenParams(params), false);
    },

    async query(sql, params, first) {
      const text = String(sql || '');
      if (/^\s*PRAGMA/i.test(text)) {
        const ddl = parseDdl(text);
        return ddl && ddl.kind === 'tableinfo' ? eng.tableInfo(ddl.table) : [];
      }
      return eng.select(text, params, first);
    },

    async run(sql, ...params) {
      const text = String(sql || '');
      if (await eng.execDdl(text)) {
        await eng.flushIndexes();
        return { changes: 0, lastID: 0 };
      }
      const p = flattenParams(params);
      const ast = eng.parse(text);
      eng.stat.writes++;
      switch (ast.type) {
        case 'insert': return eng.execInsert(ast, p);
        case 'update': return eng.execUpdate(ast, p);
        case 'delete': return eng.execDelete(ast, p);
        default: throw new Error('run() hanya untuk INSERT/UPDATE/DELETE/DDL');
      }
    },

    async exec(sql) {
      for (const stmt of splitStatements(String(sql))) {
        if (await eng.execDdl(stmt)) continue;
        await adapter.run(stmt);
      }
      await eng.flushIndexes();
    },

    async close() {
      await closeAll();
    },

    collection(name) {
      return wrappedDb.collection(name);
    },

    get rawDb() {
      return database;
    },

    stats() {
      return Object.assign({ cacheEntries: eng.cache.size, inflight: eng.inflight.size, parsed: eng.parsed.size }, eng.stat);
    },

    clearCache() {
      eng.clearCache();
    },

    invalidate(table) {
      if (table) eng.bump(table);
      else for (const t of eng.schemas.keys()) eng.bump(t);
    }
  };
  return adapter;
}

const kvQueue = new Map();
const kvActive = new Set();

function kvUpdate(col, filter, update, opts) {
  const id = filter && filter._id;
  const mergeable = id !== undefined && update && update.$set && Object.keys(update).length === 1;
  if (!mergeable) return withRetry(() => col.updateOne(filter, update, opts), true);
  let q = kvQueue.get(id);
  if (!q) {
    q = { running: false, next: null };
    kvQueue.set(id, q);
  }
  return new Promise((resolve, reject) => {
    if (q.next) {
      q.next.update = update;
      q.next.opts = opts;
      q.next.waiters.push({ resolve, reject });
    } else {
      q.next = { filter, update, opts, waiters: [{ resolve, reject }] };
    }
    kvPump(id, q, col);
  });
}

async function kvPump(id, q, col) {
  if (q.running || !q.next) return;
  q.running = true;
  const job = q.next;
  q.next = null;
  const token = {};
  kvActive.add(token);
  try {
    const r = await withRetry(() => col.updateOne(job.filter, job.update, job.opts), 'idem');
    for (const w of job.waiters) w.resolve(r);
  } catch (e) {
    for (const w of job.waiters) w.reject(e);
  }
  kvActive.delete(token);
  q.running = false;
  if (q.next) kvPump(id, q, col);
  else kvQueue.delete(id);
}

async function drainKv(timeoutMs) {
  const end = Date.now() + timeoutMs;
  while ((kvActive.size || kvQueue.size) && Date.now() < end) await sleep(25);
}

function wrapCollection(name) {
  const raw = database.collection(name);
  return {
    raw,
    findOne: (f, o) => withRetry(() => raw.findOne(f, Object.assign({ maxTimeMS: OP_MAX_TIME_MS }, o || {})), false),
    find: (f, o) => raw.find(f, o),
    updateOne: (f, u, o) => (name === 'kv_store' ? kvUpdate(raw, f, u, o) : withRetry(() => raw.updateOne(f, u, o), true)),
    updateMany: (f, u, o) => withRetry(() => raw.updateMany(f, u, o), true),
    insertOne: (d, o) => withRetry(() => raw.insertOne(d, o), true),
    replaceOne: (f, d, o) => withRetry(() => raw.replaceOne(f, d, o), true),
    deleteOne: (f, o) => withRetry(() => raw.deleteOne(f, o), true),
    deleteMany: (f, o) => withRetry(() => raw.deleteMany(f, o), true),
    countDocuments: (f, o) => withRetry(() => raw.countDocuments(f || {}, Object.assign({ maxTimeMS: OP_MAX_TIME_MS }, o || {})), false),
    createIndex: (k, o) => withRetry(() => raw.createIndex(k, o), true),
    bulkWrite: (ops, o) => withRetry(() => raw.bulkWrite(ops, o), true)
  };
}

function setHealth(ok, err) {
  if (ok) {
    if (!connState.healthy) {
      log('info', `MongoDB tersambung (${connState.failures} kegagalan beruntun sebelumnya)`);
      connState.since = Date.now();
    }
    connState.healthy = true;
    connState.failures = 0;
    connState.lastError = null;
    return;
  }
  connState.failures++;
  connState.lastError = errText(err);
  if (connState.healthy || connState.failures === 1) {
    log('warn', `MongoDB bermasalah: ${connState.lastError}`);
    connState.since = Date.now();
  } else if (connState.failures % 20 === 0) {
    log('warn', `MongoDB masih bermasalah (${connState.failures}x): ${connState.lastError}`);
  }
  connState.healthy = false;
}

function buildClient(uri) {
  const { MongoClient } = lib();
  const base = {
    maxPoolSize: Number(process.env.MONGODB_POOL_MAX || 30),
    minPoolSize: Number(process.env.MONGODB_POOL_MIN || 2),
    maxIdleTimeMS: 5 * 60 * 1000,
    serverSelectionTimeoutMS: Number(process.env.MONGODB_SELECTION_TIMEOUT_MS || 15000),
    connectTimeoutMS: Number(process.env.MONGODB_CONNECT_TIMEOUT_MS || 20000),
    socketTimeoutMS: 90000,
    waitQueueTimeoutMS: 20000,
    heartbeatFrequencyMS: 10000,
    keepAliveInitialDelay: 15000,
    retryReads: true,
    retryWrites: true
  };
  const extra = {};
  const family = Number(process.env.MONGODB_IP_FAMILY === undefined ? 4 : process.env.MONGODB_IP_FAMILY);
  if (family === 4 || family === 6) extra.family = family;
  extra.serverMonitoringMode = process.env.MONGODB_MONITOR_MODE || 'poll';
  let next;
  try {
    next = new MongoClient(uri, Object.assign({}, base, extra));
  } catch (_) {
    next = new MongoClient(uri, base);
  }
  next.on('error', e => setHealth(false, e));
  next.on('serverHeartbeatFailed', e => setHealth(false, e && e.failure ? e.failure : 'heartbeat gagal'));
  next.on('serverHeartbeatSucceeded', () => setHealth(true));
  return next;
}

function revive(force) {
  if (closing || !connParams) return Promise.reject(new Error('MongoDB sudah ditutup'));
  if (reviving) return reviving;
  reviving = (async () => {
    const { uri, dbName } = connParams;
    const old = client;
    if (old && !force) {
      try {
        await old.connect();
        await old.db(dbName).command({ ping: 1 });
        setHealth(true);
        return;
      } catch (_) {}
    }
    const next = buildClient(uri);
    try {
      await next.connect();
      await next.db(dbName).command({ ping: 1 });
    } catch (e) {
      next.close().catch(() => {});
      throw e;
    }
    client = next;
    database = next.db(dbName);
    counters = database.collection('_counters');
    if (engine) {
      engine.db = database;
      engine.counters = counters;
    }
    if (wrappedDb) wrappedDb.raw = database;
    setHealth(true);
    if (old && old !== next) old.close().catch(() => {});
  })().finally(() => {
    reviving = null;
  });
  return reviving;
}

async function closeAll(permanent = true) {
  if (permanent) closing = true;
  if (pingTimer) clearInterval(pingTimer);
  if (sweepTimer) clearInterval(sweepTimer);
  pingTimer = null;
  sweepTimer = null;
  await drainKv(4000);
  const c = client;
  client = null;
  database = null;
  counters = null;
  engine = null;
  wrappedDb = null;
  connState.healthy = false;
  if (c) {
    try {
      await c.close();
    } catch (_) {}
  }
}

async function connect(uri, dbName) {
  if (client) await closeAll(false);
  closing = false;
  connParams = { uri, dbName };
  const maxAttempts = Number(process.env.MONGODB_CONNECT_MAX_ATTEMPTS || 0);
  const next = buildClient(uri);
  let attempt = 0;
  for (;;) {
    attempt++;
    try {
      await next.connect();
      await next.db(dbName).command({ ping: 1 });
      break;
    } catch (e) {
      setHealth(false, e);
      if (maxAttempts && attempt >= maxAttempts) throw e;
      const wait = Math.min(1000 * Math.pow(2, Math.min(attempt, 4)), 15000);
      log('warn', `Koneksi MongoDB gagal (percobaan ${attempt}): ${errText(e)}. Ulang dalam ${Math.round(wait / 1000)} dtk`);
      await sleep(wait);
    }
  }
  client = next;
  database = client.db(dbName);
  counters = database.collection('_counters');
  setHealth(true);
  engine = new Engine(database, counters);
  wrappedDb = { collection: name => wrapCollection(name), raw: database };
  pingTimer = setInterval(async () => {
    if (!database || closing) return;
    try {
      await database.command({ ping: 1, maxTimeMS: 8000 });
      setHealth(true);
    } catch (e) {
      setHealth(false, e);
      if (isNotConnected(e)) revive().catch(() => {});
      else if (connState.failures >= 9 && connState.failures % 9 === 0) revive(true).catch(() => {});
    }
  }, 20000);
  sweepTimer = setInterval(() => {
    if (engine) engine.sweep();
  }, 15000);
  if (typeof pingTimer.unref === 'function') pingTimer.unref();
  if (typeof sweepTimer.unref === 'function') sweepTimer.unref();
  return buildAdapter(engine);
}

async function dataSizeMB() {
  if (!database) return null;
  try {
    const s = await database.command({ dbStats: 1, scale: 1024 * 1024 });
    return Number(s.dataSize || 0);
  } catch (_) {
    return null;
  }
}

function createEngine(fakeDb) {
  const fakeCounters = fakeDb.collection('_counters');
  const eng = new Engine(fakeDb, fakeCounters);
  database = fakeDb;
  counters = fakeCounters;
  wrappedDb = { collection: name => ({ raw: fakeDb.collection(name) }), raw: fakeDb };
  engine = eng;
  return { adapter: buildAdapter(eng), engine: eng };
}

module.exports = {
  connect,
  createEngine,
  getClient: () => client,
  getDatabase: () => wrappedDb,
  getEngine: () => engine,
  isHealthy: () => connState.healthy,
  health: () => Object.assign({}, connState),
  dataSizeMB,
  drainKv,
  close: () => closeAll(true)
};
