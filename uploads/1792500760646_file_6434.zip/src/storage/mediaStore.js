const fs = require('fs');
const path = require('path');
const { pipeline } = require('stream/promises');

let bucket = null;
let mediaDir = null;
let logFn = null;

function log(level, message) {
  if (logFn && typeof logFn[level] === 'function') logFn[level](message);
}

function init(rawDb, dir, options = {}) {
  mediaDir = dir;
  logFn = options.logger || null;
  if (options.bucket) {
    bucket = options.bucket;
    return true;
  }
  try {
    const { GridFSBucket } = require('mongodb');
    bucket = new GridFSBucket(rawDb, { bucketName: 'media' });
    return true;
  } catch (e) {
    bucket = null;
    log('error', `mediaStore: GridFS tidak bisa diinisialisasi: ${e.message}`);
    return false;
  }
}

function safeKey(key) {
  if (!key) return null;
  const parts = String(key).split('/').filter(Boolean);
  if (!parts.length || parts.some(p => p === '..' || p === '.')) return null;
  return parts.join('/');
}

function keyFor(filePath) {
  if (!filePath) return null;
  const normalized = String(filePath).replace(/\\/g, '/');
  if (mediaDir) {
    const rel = path.relative(path.resolve(mediaDir), path.resolve(filePath)).replace(/\\/g, '/');
    if (rel && !rel.startsWith('..') && !path.isAbsolute(rel)) return safeKey(rel);
  }
  const idx = normalized.lastIndexOf('/media/');
  if (idx >= 0) return safeKey(normalized.slice(idx + 7));
  return null;
}

async function exists(key) {
  const found = await bucket.find({ filename: key }).limit(1).toArray();
  return found.length > 0;
}

async function upload(key, filePath, meta) {
  const old = await bucket.find({ filename: key }).toArray();
  for (const f of old) {
    try { await bucket.delete(f._id); } catch (_) {}
  }
  await pipeline(fs.createReadStream(filePath), bucket.openUploadStream(key, { metadata: meta || {} }));
}

async function saveFile(filePath, meta) {
  if (!bucket) return false;
  const key = keyFor(filePath);
  if (!key || key.split('/')[0] === 'tmp') return false;
  try {
    await upload(key, filePath, meta);
    return true;
  } catch (e) {
    log('error', `mediaStore: gagal menyimpan ${key}: ${e.message}`);
    return false;
  }
}

async function ensureLocal(mediaPath) {
  if (!mediaPath) return null;
  try {
    if (fs.existsSync(mediaPath)) return mediaPath;
  } catch (_) {}
  if (!bucket || !mediaDir) return null;
  const key = keyFor(mediaPath);
  if (!key) return null;
  const dest = path.join(mediaDir, ...key.split('/'));
  try {
    if (fs.existsSync(dest)) return dest;
    if (!(await exists(key))) return null;
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    await pipeline(bucket.openDownloadStreamByName(key), fs.createWriteStream(dest));
    return dest;
  } catch (e) {
    log('error', `mediaStore: gagal memuat ${key}: ${e.message}`);
    try { fs.unlinkSync(dest); } catch (_) {}
    return null;
  }
}

function walk(dir, base, out) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      if (dir === base && entry.name === 'tmp') continue;
      walk(full, base, out);
    } else if (entry.isFile()) {
      out.push(full);
    }
  }
}

function listFiles(dir) {
  const out = [];
  if (dir && fs.existsSync(dir)) walk(dir, dir, out);
  return out;
}

async function importDir(dir) {
  const result = { uploaded: 0, skipped: 0, failed: 0 };
  if (!bucket) {
    result.failed = -1;
    return result;
  }
  for (const file of listFiles(dir)) {
    const key = safeKey(path.relative(dir, file).replace(/\\/g, '/'));
    if (!key) {
      result.failed++;
      continue;
    }
    try {
      if (await exists(key)) {
        result.skipped++;
        continue;
      }
      await upload(key, file, { imported: true });
      result.uploaded++;
    } catch (e) {
      result.failed++;
      log('error', `mediaStore: gagal impor ${key}: ${e.message}`);
    }
  }
  return result;
}

module.exports = { init, saveFile, ensureLocal, importDir, listFiles, keyFor };
