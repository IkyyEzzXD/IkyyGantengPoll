function createProdukService(deps) {
  const { mongoAdapter, logger } = deps;
  let produkBalance = {};
  let produkTransactions = [];

  async function loadProdukBalance() {
    try {
      const mdb = mongoAdapter.getDatabase();
      if (mdb) {
        const doc = await mdb.collection('kv_store').findOne({ _id: 'produk_balance' });
        produkBalance = (doc && doc.payload && typeof doc.payload === 'object') ? doc.payload : {};
      } else {
        produkBalance = produkBalance || {};
      }
    } catch (error) {
      logger.error('loadProdukBalance error:', error);
      produkBalance = {};
    }
  }

  async function saveProdukBalance() {
    try {
      const mdb = mongoAdapter.getDatabase();
      if (!mdb) return;
      await mdb.collection('kv_store').updateOne(
        { _id: 'produk_balance' },
        { $set: { payload: produkBalance, updatedAt: Date.now() } },
        { upsert: true }
      );
    } catch (error) {
      logger.error('saveProdukBalance error:', error);
    }
  }

  async function loadProdukTransactions() {
    try {
      const mdb = mongoAdapter.getDatabase();
      if (mdb) {
        const doc = await mdb.collection('kv_store').findOne({ _id: 'produk_transactions' });
        produkTransactions = (doc && Array.isArray(doc.payload)) ? doc.payload : [];
      } else {
        produkTransactions = produkTransactions || [];
      }
    } catch (error) {
      logger.error('loadProdukTransactions error:', error);
      produkTransactions = [];
    }
  }

  async function saveProdukTransactions() {
    try {
      const mdb = mongoAdapter.getDatabase();
      if (!mdb) return;
      await mdb.collection('kv_store').updateOne(
        { _id: 'produk_transactions' },
        { $set: { payload: produkTransactions, updatedAt: Date.now() } },
        { upsert: true }
      );
    } catch (error) {
      logger.error('saveProdukTransactions error:', error);
    }
  }

  function getProdukBalance(userId) {
    return produkBalance[userId] || 0;
  }

  async function updateProdukBalance(userId, amount, isAdd, orderId = null, details = '') {
    try {
      if (!Number.isSafeInteger(amount) || amount <= 0) {
        logger.warn(`updateProdukBalance rejected invalid amount for user ${userId}: ${amount}`);
        return false;
      }
      if (
        isAdd &&
        orderId &&
        /^deposit_/.test(String(details)) &&
        produkTransactions.some(
          (t) => t.type === 'DEPOSIT' && t.order_id === orderId && t.details === details
        )
      ) {
        logger.warn(`updateProdukBalance: deposit ${orderId} sudah tercatat, kredit ganda dicegah`);
        return true;
      }
      if (!produkBalance[userId]) produkBalance[userId] = 0;
      const oldBalance = produkBalance[userId];
      if (isAdd) {
        produkBalance[userId] += amount;
      } else {
        if (produkBalance[userId] >= amount) {
          produkBalance[userId] -= amount;
        } else {
          return false;
        }
      }
      await saveProdukBalance();
      produkTransactions.push({
        user_id: userId,
        type: isAdd ? 'DEPOSIT' : 'PURCHASE',
        amount,
        old_balance: oldBalance,
        new_balance: produkBalance[userId],
        order_id: orderId,
        details,
        timestamp: Date.now(),
      });
      if (produkTransactions.length > 1000) {
        produkTransactions = produkTransactions.slice(-500);
      }
      await saveProdukTransactions();
      return true;
    } catch (error) {
      logger.error('updateProdukBalance error:', error);
      return false;
    }
  }

  async function produkBaruCekSaldo(userId) {
    return getProdukBalance(userId);
  }

  async function produkBaruKurangiSaldo(userId, amount) {
    return updateProdukBalance(userId, amount, false);
  }

  async function getProdukUserTransactions(userId, limit = 20) {
    const userTransactions = produkTransactions.filter((t) => t.user_id === userId);
    return userTransactions.reverse().slice(0, limit);
  }

  function getBalanceMap() {
    return produkBalance;
  }

  function getTransactions() {
    return produkTransactions;
  }

  function setBalanceMap(m) {
    produkBalance = m && typeof m === 'object' ? m : {};
  }

  function setTransactions(arr) {
    produkTransactions = Array.isArray(arr) ? arr : [];
  }

  let produkBaruData = [];

  async function produkBaruLoad() {
    try {
      const mdb = mongoAdapter.getDatabase();
      if (mdb) {
        const doc = await mdb.collection('kv_store').findOne({ _id: 'produk_baru' });
        produkBaruData = doc && Array.isArray(doc.payload) ? doc.payload : [];
      } else {
        produkBaruData = produkBaruData || [];
      }
    } catch (e) {
      logger.error('Error loading products:', e);
      produkBaruData = [];
    }
    return produkBaruData;
  }

  async function produkBaruSave() {
    try {
      const mdb = mongoAdapter.getDatabase();
      if (!mdb) return;
      await mdb.collection('kv_store').updateOne(
        { _id: 'produk_baru' },
        { $set: { payload: produkBaruData, updatedAt: Date.now() } },
        { upsert: true }
      );
    } catch (e) {
      logger.error('Error saving products:', e);
    }
  }

  async function produkBaruLoadOrders() {
    try {
      const mdb = mongoAdapter.getDatabase();
      if (!mdb) return [];
      const doc = await mdb.collection('kv_store').findOne({ _id: 'order_baru' });
      return doc && Array.isArray(doc.payload) ? doc.payload : [];
    } catch (e) {
      return [];
    }
  }

  async function produkBaruSaveOrders(orders) {
    try {
      const mdb = mongoAdapter.getDatabase();
      if (!mdb) return;
      await mdb.collection('kv_store').updateOne(
        { _id: 'order_baru' },
        { $set: { payload: orders, updatedAt: Date.now() } },
        { upsert: true }
      );
    } catch (e) {
      logger.error('produkBaruSaveOrders error:', e);
    }
  }

  function produkBaruAdd(product) {
    const newId =
      produkBaruData.length > 0 ? Math.max(...produkBaruData.map((p) => p.id)) + 1 : 1;
    produkBaruData.push({
      id: newId,
      ...product,
      sold: 0,
      is_active: 1,
      created_at: Date.now(),
      updated_at: Date.now(),
    });
    produkBaruSave();
    return newId;
  }

  function produkBaruUpdate(id, updates) {
    const index = produkBaruData.findIndex((p) => p.id === id);
    if (index !== -1) {
      produkBaruData[index] = {
        ...produkBaruData[index],
        ...updates,
        updated_at: Date.now(),
      };
      produkBaruSave();
      return true;
    }
    return false;
  }

  function produkBaruDelete(id) {
    produkBaruData = produkBaruData.filter((p) => p.id !== id);
    produkBaruSave();
  }

  function produkBaruUpdateStock(id, qty) {
    if (!Number.isSafeInteger(qty) || qty <= 0) return false;
    const index = produkBaruData.findIndex((p) => p.id === id);
    if (
      index !== -1 &&
      Number.isSafeInteger(produkBaruData[index].stock) &&
      produkBaruData[index].stock >= qty
    ) {
      produkBaruData[index].stock -= qty;
      produkBaruData[index].sold = (produkBaruData[index].sold || 0) + qty;
      produkBaruSave();
      return true;
    }
    return false;
  }

  function produkBaruRestoreStock(id, qty) {
    if (!Number.isSafeInteger(qty) || qty <= 0) return false;
    const index = produkBaruData.findIndex((p) => p.id === id);
    if (index === -1) return false;
    produkBaruData[index].stock = (Number(produkBaruData[index].stock) || 0) + qty;
    produkBaruData[index].sold = Math.max(
      0,
      (Number(produkBaruData[index].sold) || 0) - qty
    );
    produkBaruSave();
    return true;
  }

  function getProdukBaruData() {
    return produkBaruData;
  }

  function setProdukBaruData(arr) {
    produkBaruData = Array.isArray(arr) ? arr : [];
  }

  return {
    loadProdukBalance,
    saveProdukBalance,
    loadProdukTransactions,
    saveProdukTransactions,
    getProdukBalance,
    updateProdukBalance,
    produkBaruCekSaldo,
    produkBaruKurangiSaldo,
    getProdukUserTransactions,
    getBalanceMap,
    getTransactions,
    setBalanceMap,
    setTransactions,
    produkBaruLoad,
    produkBaruSave,
    produkBaruLoadOrders,
    produkBaruSaveOrders,
    produkBaruAdd,
    produkBaruUpdate,
    produkBaruDelete,
    produkBaruUpdateStock,
    produkBaruRestoreStock,
    getProdukBaruData,
    setProdukBaruData,
  };
}

module.exports = { createProdukService };
