const path = require('path');
const fs = require('fs');
const os = require('os');

function createMediaService(deps) {
  const { getBot, mediaStore, logger, mediaDir } = deps;
  const MEDIA_DIR = mediaDir || path.join(os.tmpdir(), 'jaseb_media');
  let _qrisBufferPromise = null;

  function pathExists(p) {
    return fs.promises.access(p).then(() => true, () => false);
  }

  function getQrisBufferCached(qrisImagePath) {
    if (_qrisBufferPromise) return _qrisBufferPromise;
    _qrisBufferPromise = (async () => {
      try {
        if (!qrisImagePath) return null;
        if (await pathExists(qrisImagePath)) {
          return await fs.promises.readFile(qrisImagePath);
        }
      } catch (_) {}
      return null;
    })();
    return _qrisBufferPromise;
  }

  async function downloadAndSaveMedia(fileId, ownerId, localId, type) {
    try {
      if (!fileId) return null;
      const bot = getBot();
      const userMediaDir = path.join(MEDIA_DIR, String(ownerId));
      await fs.promises.mkdir(userMediaDir, { recursive: true });
      const extMap = {
        photo: '.jpg',
        video: '.mp4',
        document: '',
        audio: '.mp3',
        voice: '.ogg',
        sticker: '.webp',
        animation: '.mp4',
      };
      const ext = extMap[type] || '';
      const destName = `msg_${localId}_${Date.now()}${ext}`;
      const destPath = path.join(userMediaDir, destName);
      const downloaded = await bot.downloadFile(fileId, userMediaDir);
      if (downloaded && (await pathExists(downloaded))) {
        if (path.resolve(downloaded) !== path.resolve(destPath)) {
          try {
            await fs.promises.rename(downloaded, destPath);
            await mediaStore.saveFile(destPath, { ownerId: String(ownerId), type });
            return destPath;
          } catch (e) {
            await mediaStore.saveFile(downloaded, { ownerId: String(ownerId), type });
            return downloaded;
          }
        }
        await mediaStore.saveFile(downloaded, { ownerId: String(ownerId), type });
        return downloaded;
      }
      return null;
    } catch (err) {
      logger.error(`downloadAndSaveMedia error: ${err.message}`);
      return null;
    }
  }

  async function resolveMediaForSend(selectedMessage) {
    if (!selectedMessage) return null;
    if (selectedMessage.local_path && (await pathExists(selectedMessage.local_path))) {
      return selectedMessage.local_path;
    }
    if (selectedMessage.file_id && selectedMessage.owner_id) {
      const p = await downloadAndSaveMedia(
        selectedMessage.file_id,
        selectedMessage.owner_id,
        selectedMessage.id || Date.now(),
        selectedMessage.type || 'document'
      );
      if (p) {
        selectedMessage.local_path = p;
        return p;
      }
    }
    return selectedMessage.file_id || null;
  }

  return {
    getQrisBufferCached,
    downloadAndSaveMedia,
    resolveMediaForSend,
    pathExists,
    MEDIA_DIR,
  };
}

module.exports = { createMediaService };
