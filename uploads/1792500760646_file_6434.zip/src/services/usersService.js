function createUsersService(deps) {
  const { mongoAdapter, logger, getDb } = deps;
  let _usersFileCache = null;
  let _usersFileSaveTimer = null;

  async function loadUsersFileFromMongo() {
    try {
      const mdb = mongoAdapter.getDatabase();
      if (!mdb) {
        _usersFileCache = _usersFileCache || [];
        return _usersFileCache;
      }
      const doc = await mdb.collection('kv_store').findOne({ _id: 'users_file' });
      _usersFileCache = (doc && Array.isArray(doc.payload)) ? doc.payload : [];
    } catch (error) {
      logger.error('loadUsersFile error:', error);
      _usersFileCache = _usersFileCache || [];
    }
    return _usersFileCache;
  }

  function loadUsersFile() {
    if (_usersFileCache !== null) return _usersFileCache;
    _usersFileCache = [];
    loadUsersFileFromMongo().catch(() => {});
    return _usersFileCache;
  }

  async function writeUsersFileNow() {
    try {
      const mdb = mongoAdapter.getDatabase();
      if (!mdb || !Array.isArray(_usersFileCache)) return;
      await mdb.collection('kv_store').updateOne(
        { _id: 'users_file' },
        { $set: { payload: _usersFileCache, updatedAt: Date.now() } },
        { upsert: true }
      );
    } catch (e) {
      logger.error('saveUsersFile error:', e);
    }
  }

  async function flushUsersFile() {
    if (!_usersFileSaveTimer) return;
    clearTimeout(_usersFileSaveTimer);
    _usersFileSaveTimer = null;
    await writeUsersFileNow();
  }

  function saveUsersFile(list) {
    try {
      _usersFileCache = list;
      if (_usersFileSaveTimer) return true;
      _usersFileSaveTimer = setTimeout(() => {
        _usersFileSaveTimer = null;
        writeUsersFileNow();
      }, 5000);
      return true;
    } catch (error) {
      logger.error('saveUsersFile error:', error);
      return false;
    }
  }

  function trackUserToFile(userId, username = '', fullName = '') {
    try {
      const list = loadUsersFile();
      const idx = list.findIndex((u) => u.id === userId);
      const entry = {
        id: userId,
        username: username || '',
        full_name: fullName || '',
        last_seen: Math.floor(Date.now() / 1000),
      };
      if (idx === -1) {
        entry.first_seen = entry.last_seen;
        list.push(entry);
      } else {
        entry.first_seen = list[idx].first_seen || entry.last_seen;
        list[idx] = entry;
      }
      saveUsersFile(list);
    } catch (error) {
      logger.error('trackUserToFile error:', error);
    }
  }

  async function getAllKnownUserIds() {
    const idSet = new Set();
    try {
      const db = getDb();
      const rows = await db.all('SELECT user_id FROM users');
      for (const r of rows || []) idSet.add(String(r.user_id));
    } catch (error) {
      logger.warn(`getAllKnownUserIds: gagal baca users: ${error.message}`);
    }
    try {
      const fileUsers = loadUsersFile();
      for (const u of fileUsers) idSet.add(String(u.id));
    } catch (error) {
      logger.error('getAllKnownUserIds: gagal baca dari users.js:', error);
    }
    try {
      const db = getDb();
      const blocked = await db.all('SELECT user_id FROM broadcast_blocked');
      for (const b of blocked || []) idSet.delete(String(b.user_id));
    } catch (error) {
      logger.warn(`getAllKnownUserIds: gagal baca broadcast_blocked: ${error.message}`);
    }
    return Array.from(idSet);
  }

  async function removeUserFromBroadcastList(userId, reason = 'blocked') {
    const uid = String(userId);
    let removedFromFile = false;
    try {
      const list = loadUsersFile();
      const next = list.filter((u) => String(u.id) !== uid);
      if (next.length !== list.length) {
        saveUsersFile(next);
        removedFromFile = true;
      }
    } catch (e) {
      logger.warn(`removeUserFromBroadcastList file ${uid}: ${e.message}`);
    }
    try {
      const db = getDb();
      await db.run(
        'INSERT OR REPLACE INTO broadcast_blocked (user_id, reason, blocked_at) VALUES (?, ?, ?)',
        uid,
        reason,
        Math.floor(Date.now() / 1000)
      );
    } catch (e) {
      logger.warn(`removeUserFromBroadcastList sql ${uid}: ${e.message}`);
    }
    return removedFromFile;
  }

  async function unmarkBroadcastBlocked(userId) {
    try {
      const db = getDb();
      await db.run('DELETE FROM broadcast_blocked WHERE user_id = ?', String(userId));
    } catch (_) {}
  }

  return {
    loadUsersFileFromMongo,
    loadUsersFile,
    writeUsersFileNow,
    flushUsersFile,
    saveUsersFile,
    trackUserToFile,
    getAllKnownUserIds,
    removeUserFromBroadcastList,
    unmarkBroadcastBlocked,
  };
}

module.exports = { createUsersService };
