const DEFAULT_TTL_MS = 5 * 60 * 1000;
const MAX_ENTRIES_PER_MAP = 5000;
const CLEAN_INTERVAL_MS = 45 * 1000;

class TtlMap {
  constructor(opts = {}) {
    this._map = new Map();
    this.ttlMs = opts.ttlMs || DEFAULT_TTL_MS;
    this.maxSize = opts.maxSize || MAX_ENTRIES_PER_MAP;
    this.name = opts.name || 'ttlmap';
  }

  set(key, value, ttlMs) {
    const k = String(key);
    const exp = Date.now() + (Number.isFinite(ttlMs) ? ttlMs : this.ttlMs);
    if (this._map.size >= this.maxSize && !this._map.has(k)) {
      this._evictOldest(Math.ceil(this.maxSize * 0.1));
    }
    this._map.set(k, { v: value, exp });
  }

  get(key) {
    const k = String(key);
    const rec = this._map.get(k);
    if (!rec) return undefined;
    if (Date.now() > rec.exp) {
      this._map.delete(k);
      return undefined;
    }
    return rec.v;
  }

  has(key) {
    return this.get(key) !== undefined;
  }

  delete(key) {
    return this._map.delete(String(key));
  }

  clear() {
    this._map.clear();
  }

  get size() {
    return this._map.size;
  }

  keys() {
    return this._map.keys();
  }

  entries() {
    const out = [];
    const now = Date.now();
    for (const [k, rec] of this._map) {
      if (now <= rec.exp) out.push([k, rec.v]);
      else this._map.delete(k);
    }
    return out;
  }

  prune() {
    const now = Date.now();
    let removed = 0;
    for (const [k, rec] of this._map) {
      if (now > rec.exp) {
        this._map.delete(k);
        removed++;
      }
    }
    if (this._map.size > this.maxSize) {
      removed += this._evictOldest(this._map.size - this.maxSize);
    }
    return removed;
  }

  _evictOldest(count) {
    let n = 0;
    for (const k of this._map.keys()) {
      if (n >= count) break;
      this._map.delete(k);
      n++;
    }
    return n;
  }

  toJSON() {
    return { name: this.name, size: this._map.size, max: this.maxSize };
  }
}

class StateManager {
  constructor() {
    this.chatSessions = new TtlMap({ name: 'chatSessions', ttlMs: 30 * 60 * 1000, maxSize: 8000 });
    this.promosiProgress = new Map();
    this.promoRoundLocks = new Map();
    this.waitingForGiveUserId = new TtlMap({ name: 'waitingForGiveUserId' });
    this.userExtendData = new TtlMap({ name: 'userExtendData' });
    this.waitingForAddBulk = new TtlMap({ name: 'waitingForAddBulk' });
    this.produkBaruUserCart = new TtlMap({ name: 'produkBaruUserCart', ttlMs: 60 * 60 * 1000 });
    this.produkBaruCurrentPage = new TtlMap({ name: 'produkBaruCurrentPage', ttlMs: 30 * 60 * 1000 });
    this.produkBaruWaitingCustomDeposit = new TtlMap({ name: 'produkBaruWaitingCustomDeposit' });
    this.produkBaruDepositAmount = new TtlMap({ name: 'produkBaruDepositAmount' });
    this.userPayments = new TtlMap({ name: 'userPayments', ttlMs: 2 * 60 * 60 * 1000, maxSize: 3000 });
    this.pendingNotifCooldown = new TtlMap({ name: 'pendingNotifCooldown', ttlMs: 10 * 60 * 1000, maxSize: 2000 });
    this.pendingManualPayments = new TtlMap({ name: 'pendingManualPayments', ttlMs: 2 * 60 * 60 * 1000, maxSize: 2000 });
    this.referralInFlight = new Set();
    this.answeredCallbackIds = new TtlMap({ name: 'answeredCallbackIds', ttlMs: 60 * 1000, maxSize: 10000 });
    this.menuLockNotifCooldown = new TtlMap({ name: 'menuLockNotifCooldown', ttlMs: 30 * 1000, maxSize: 2000 });
    this.userRoleCache = new TtlMap({ name: 'userRoleCache', ttlMs: 700, maxSize: 5000 });
    this.userRoleInFlight = new Map();
    this.ubotTouchAt = new TtlMap({ name: 'ubotTouchAt', ttlMs: 30 * 60 * 1000, maxSize: 5000 });
    this.adminOwnersCache = new TtlMap({ name: 'adminOwnersCache', ttlMs: 5 * 60 * 1000, maxSize: 500 });
    this.joinRefreshInFlight = new Map();
    this.joinErrorUntil = new TtlMap({ name: 'joinErrorUntil', ttlMs: 15 * 60 * 1000, maxSize: 3000 });
    this.startVerifyInFlight = new Set();
    this.userNameCache = new TtlMap({ name: 'userNameCache', ttlMs: 10 * 60 * 1000, maxSize: 8000 });
    this.jasaPurging = new Set();
    this.lockNoticeAt = new TtlMap({ name: 'lockNoticeAt', ttlMs: 60 * 1000, maxSize: 2000 });
    this.restartUbotInFlight = new Set();
    this.guardianRetryPending = new Set();
    this.ubotLastStatusCheck = new TtlMap({ name: 'ubotLastStatusCheck', ttlMs: 10 * 60 * 1000, maxSize: 5000 });
    this.jasaRescanAt = new TtlMap({ name: 'jasaRescanAt', ttlMs: 30 * 60 * 1000, maxSize: 3000 });
    this.jasaMandatorySent = new TtlMap({ name: 'jasaMandatorySent', ttlMs: 24 * 60 * 60 * 1000, maxSize: 3000 });
    this.jasaNoticeAt = new TtlMap({ name: 'jasaNoticeAt', ttlMs: 5 * 60 * 1000, maxSize: 3000 });
    this.pakasirWarnAt = new TtlMap({ name: 'pakasirWarnAt', ttlMs: 30 * 60 * 1000, maxSize: 500 });
    this.lateCheckedAt = new TtlMap({ name: 'lateCheckedAt', ttlMs: 60 * 60 * 1000, maxSize: 2000 });
    this.statsOrders = new TtlMap({ name: 'statsOrders', ttlMs: 24 * 60 * 60 * 1000, maxSize: 5000 });
    this.statsDeposits = new Set();
    this._timer = null;
  }

  start() {
    if (this._timer) return;
    this._timer = setInterval(() => {
      try { this.pruneAll(); } catch (_) {}
    }, CLEAN_INTERVAL_MS);
    if (this._timer.unref) this._timer.unref();
  }

  stop() {
    if (this._timer) {
      clearInterval(this._timer);
      this._timer = null;
    }
  }

  pruneAll() {
    let total = 0;
    for (const k of Object.keys(this)) {
      const v = this[k];
      if (v && typeof v.prune === 'function') {
        total += v.prune() || 0;
      }
    }
    this._pruneSet(this.referralInFlight, 2000);
    this._pruneSet(this.startVerifyInFlight, 500);
    this._pruneSet(this.jasaPurging, 500);
    this._pruneSet(this.restartUbotInFlight, 200);
    this._pruneSet(this.guardianRetryPending, 500);
    this._pruneMap(this.promosiProgress, 3000);
    this._pruneMap(this.promoRoundLocks, 3000);
    this._pruneMap(this.userRoleInFlight, 2000);
    this._pruneMap(this.joinRefreshInFlight, 2000);
    if (this.statsDeposits.size > 10000) {
      const arr = [...this.statsDeposits];
      this.statsDeposits.clear();
      for (let i = Math.max(0, arr.length - 5000); i < arr.length; i++) this.statsDeposits.add(arr[i]);
    }
    return total;
  }

  _pruneSet(s, max) {
    if (s.size > max) {
      const arr = [...s];
      s.clear();
      for (let i = Math.max(0, arr.length - Math.floor(max * 0.7)); i < arr.length; i++) s.add(arr[i]);
    }
  }

  _pruneMap(m, max) {
    if (m.size > max) {
      const keys = [...m.keys()];
      const drop = keys.length - Math.floor(max * 0.7);
      for (let i = 0; i < drop; i++) m.delete(keys[i]);
    }
  }

  describe() {
    const out = {};
    for (const k of Object.keys(this)) {
      const v = this[k];
      if (v && typeof v.size === 'number') out[k] = v.size;
      else if (v && typeof v.toJSON === 'function') out[k] = v.toJSON();
    }
    return out;
  }

  clearExpiredWaiting() {
    return this.pruneAll();
  }
}

const state = new StateManager();

module.exports = {
  state,
  StateManager,
  TtlMap,
  DEFAULT_TTL_MS,
};
