function createAccessService(deps) {
  const { mongoAdapter, logger, getDb } = deps;
  let _listAccessCache = null;
  let _listAccessSaveTimer = null;
  const roleCaches = deps.roleCaches || { clear: () => {} };

  async function loadListAccessFromMongo() {
    try {
      const mdb = mongoAdapter.getDatabase();
      if (!mdb) {
        _listAccessCache = _listAccessCache || [];
        return _listAccessCache;
      }
      const doc = await mdb.collection('kv_store').findOne({ _id: 'list_access' });
      _listAccessCache = (doc && Array.isArray(doc.payload)) ? doc.payload : [];
    } catch (error) {
      logger.error('loadListAccess error:', error);
      _listAccessCache = _listAccessCache || [];
    }
    return _listAccessCache;
  }

  function loadListAccess() {
    if (_listAccessCache !== null) return _listAccessCache;
    _listAccessCache = [];
    loadListAccessFromMongo().catch(() => {});
    return _listAccessCache;
  }

  function saveListAccess(accessList) {
    try {
      _listAccessCache = accessList;
      try { roleCaches.clear(); } catch (_) {}
      if (_listAccessSaveTimer) clearTimeout(_listAccessSaveTimer);
      _listAccessSaveTimer = setTimeout(async () => {
        _listAccessSaveTimer = null;
        try {
          const mdb = mongoAdapter.getDatabase();
          if (!mdb) return;
          await mdb.collection('kv_store').updateOne(
            { _id: 'list_access' },
            { $set: { payload: accessList, updatedAt: Date.now() } },
            { upsert: true }
          );
        } catch (e) {
          logger.error('saveListAccess error:', e);
        }
      }, 50);
      return true;
    } catch (error) {
      logger.error('saveListAccess error:', error);
      return false;
    }
  }

  function findAccessByUserId(userId, accessList = null) {
    if (!accessList) accessList = loadListAccess();
    return accessList.find((item) => item.id === userId);
  }

  function findActiveAccessByUserId(userId, accessList = null) {
    if (!accessList) accessList = loadListAccess();
    const now = Math.floor(Date.now() / 1000);
    const activeAccess = accessList.filter((item) => item.id === userId && item.expired_at > now);
    if (activeAccess.length === 0) return null;
    if (activeAccess.length === 1) return activeAccess[0];
    const priority = { reseller: 4, pro: 3, basic: 2, trial: 1 };
    activeAccess.sort((a, b) => (priority[b.role] || 0) - (priority[a.role] || 0));
    return activeAccess[0];
  }

  function addAccess(userId, duration, role, accessList = null) {
    if (!accessList) accessList = loadListAccess();
    const now = Math.floor(Date.now() / 1000);
    let expiredAt;
    let durationText = duration;
    if (duration === 'lifetime') {
      expiredAt = now + 100 * 365 * 24 * 3600;
      durationText = 'lifetime';
    } else if (typeof duration === 'number') {
      expiredAt = now + duration;
      durationText = `${Math.round(duration / 86400)}d`;
    } else {
      const days = parseInt(String(duration).replace(/d/i, ''), 10) || 30;
      expiredAt = now + days * 86400;
      durationText = `${days}d`;
    }
    const existing = accessList.find((item) => item.id === userId);
    if (existing) {
      existing.duration = durationText;
      existing.role = role;
      existing.expired_at = expiredAt;
      existing.updated_at = now;
    } else {
      accessList.push({
        id: userId,
        duration: durationText,
        role,
        expired_at: expiredAt,
        added_at: now,
        updated_at: now,
      });
    }
    saveListAccess(accessList);
    return accessList;
  }

  function removeAccess(userId, accessList = null) {
    if (!accessList) accessList = loadListAccess();
    const filtered = accessList.filter((item) => item.id !== userId);
    if (filtered.length !== accessList.length) {
      saveListAccess(filtered);
      return filtered;
    }
    return accessList;
  }

  function cleanupUserAccess(userId) {
    const accessList = loadListAccess();
    const userAccess = accessList.filter((item) => item.id === userId);
    if (userAccess.length <= 1) return accessList;
    const now = Math.floor(Date.now() / 1000);
    const priority = { reseller: 4, pro: 3, basic: 2, trial: 1 };
    userAccess.sort((a, b) => (priority[b.role] || 0) - (priority[a.role] || 0));
    const bestAccess = userAccess.find((item) => item.expired_at > now) || userAccess[0];
    const filtered = accessList.filter((item) => item.id !== userId);
    filtered.push(bestAccess);
    saveListAccess(filtered);
    return filtered;
  }

  function isUserHasAccess(userId, role = null, accessList = null) {
    if (!accessList) accessList = loadListAccess();
    const now = Math.floor(Date.now() / 1000);
    const active = accessList.filter((item) => item.id === userId && item.expired_at > now);
    if (active.length === 0) return false;
    if (role) return active.some((item) => item.role === role);
    return true;
  }

  function getAccessInfo(userId, accessList = null) {
    if (!accessList) accessList = loadListAccess();
    const now = Math.floor(Date.now() / 1000);
    return accessList.find((item) => item.id === userId && item.expired_at > now);
  }

  function getCache() {
    return _listAccessCache;
  }

  function setCache(list) {
    _listAccessCache = list;
  }

  return {
    loadListAccessFromMongo,
    loadListAccess,
    saveListAccess,
    findAccessByUserId,
    findActiveAccessByUserId,
    addAccess,
    removeAccess,
    cleanupUserAccess,
    isUserHasAccess,
    getAccessInfo,
    getCache,
    setCache,
  };
}

module.exports = { createAccessService };
