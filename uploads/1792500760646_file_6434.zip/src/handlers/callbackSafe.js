function createCallbackSafe(deps) {
  const { getBot, getTicketBot, logger } = deps;

  async function safeAnswerCallbackQuery(callbackQuery, text, showAlert) {
    const bot = getBot();
    try {
      if (text && typeof text === 'object' && !Array.isArray(text)) {
        await bot.answerCallbackQuery(callbackQuery.id, text);
      } else if (typeof text === 'string') {
        await bot.answerCallbackQuery(callbackQuery.id, {
          text: String(text).replace(/<[^>]+>/g, '').slice(0, 200),
          show_alert: !!showAlert,
        });
      } else {
        await bot.answerCallbackQuery(callbackQuery.id);
      }
      return true;
    } catch (err) {
      let fallbackText = null;
      if (typeof text === 'string') fallbackText = text;
      else if (text && typeof text === 'object' && typeof text.text === 'string') fallbackText = text.text;
      if (fallbackText) {
        try {
          const chatId =
            callbackQuery.message &&
            callbackQuery.message.chat &&
            callbackQuery.message.chat.id;
          if (chatId) {
            const plainText = fallbackText.replace(/<[^>]+>/g, '');
            await bot.sendMessage(chatId, plainText);
          }
        } catch (e) {}
      }
      return false;
    }
  }

  async function safeAnswerCallbackQueryTicket(callbackQuery, text, showAlert) {
    const ticketBot = getTicketBot();
    try {
      await ticketBot.answerCallbackQuery(callbackQuery.id, text, showAlert);
      return true;
    } catch (err) {
      let fallbackText = null;
      if (typeof text === 'string') fallbackText = text;
      else if (text && typeof text === 'object' && typeof text.text === 'string') {
        fallbackText = text.text;
      }
      if (fallbackText) {
        try {
          const chatId =
            callbackQuery.message &&
            callbackQuery.message.chat &&
            callbackQuery.message.chat.id;
          if (chatId) {
            const plainText = fallbackText.replace(/<[^>]+>/g, '');
            await ticketBot.sendMessage(chatId, plainText);
          }
        } catch (e) {}
      }
      return false;
    }
  }

  return {
    safeAnswerCallbackQuery,
    safeAnswerCallbackQueryTicket,
  };
}

module.exports = { createCallbackSafe };
