function registerBotEvents(deps) {
  const {
    bot,
    telegramGuards,
    logger,
    onCallbackQuery,
    onCallbackSilence,
    onMessage,
    onPhoto,
    onChatMember,
    onPollingError,
    onWebhookError,
    onError,
  } = deps;

  if (typeof onCallbackQuery === 'function') {
    bot.on(
      'callback_query',
      telegramGuards.withSilenceGuard(onCallbackQuery, onCallbackSilence, logger)
    );
  }
  if (typeof onMessage === 'function') {
    bot.on('message', onMessage);
  }
  if (typeof onPhoto === 'function') {
    bot.on('photo', onPhoto);
  }
  if (typeof onChatMember === 'function') {
    bot.on('chat_member', onChatMember);
  }
  if (typeof onPollingError === 'function') {
    bot.on('polling_error', onPollingError);
  }
  if (typeof onWebhookError === 'function') {
    bot.on('webhook_error', onWebhookError);
  }
  if (typeof onError === 'function') {
    bot.on('error', onError);
  }
}

module.exports = { registerBotEvents };
