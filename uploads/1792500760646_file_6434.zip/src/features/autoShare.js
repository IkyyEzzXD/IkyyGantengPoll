const { withLock, mapPool } = require('../system/concurrency');
const { promoQueue } = require('../system/jobQueue');

function createAutoShare(deps) {
  const {
    getDb,
    getBot,
    getUserbots,
    promosiProgress,
    promoRoundLocks,
    lazyUbot,
    logger,
    saveKvState,
    loadKvState,
    withTimeout,
    telegramGuards,
    resolveGroupPeer,
    isMediaForbiddenError,
    isPermanentGroupError,
    canUseMediaForPromo,
    getMediaUpgradeRequiredMessage,
    promoAccessLapsed,
    haltPromoForLapsedAccess,
    buildAccessExpiredKeyboard,
  } = deps;

  const GUARDIAN_CONCURRENCY = 8;
  const GUARDIAN_RETRY_DELAYS_MS = [20000, 60000];
  const guardianRetryPending = new Set();

  function executePromoRound(userId, chatId, isRestart = false) {
    const p = promoQueue
      .add(() => withLock(`promo:${userId}`, () => _executePromoRoundInner(userId, chatId, isRestart)))
      .catch((e) => {
        if (e && e.code === 'QUEUE_FULL') {
          try {
            logger.warn(`executePromoRound user ${userId} ditolak: antrian penuh`);
          } catch (_) {}
          return;
        }
        try {
          logger.error(`executePromoRound user ${userId} gagal: ${e && e.message ? e.message : e}`);
        } catch (_) {}
      });
    return p;
  }

  async function _executePromoRoundInner(userId, chatId, isRestart = false) {
    return deps.executeInner(userId, chatId, isRestart);
  }

  function isGuardianTransient(e) {
    try {
      return logger.isTransientInfraError(String((e && e.message) || e), {
        error: String((e && e.message) || e),
      });
    } catch (_) {
      return false;
    }
  }

  function scheduleGuardianRetry(row, attempt) {
    const key = String(row.owner_id);
    if (attempt >= GUARDIAN_RETRY_DELAYS_MS.length || guardianRetryPending.has(key)) return;
    guardianRetryPending.add(key);
    const delay = GUARDIAN_RETRY_DELAYS_MS[attempt] + Math.floor(Math.random() * 3000);
    const timer = setTimeout(() => {
      guardianRetryPending.delete(key);
      guardianProcessUser(row, attempt + 1).catch(() => {});
    }, delay);
    if (typeof timer.unref === 'function') timer.unref();
  }

  async function guardianProcessUser(row, attempt = 0) {
    return deps.guardianProcessUser(row, attempt, {
      scheduleGuardianRetry,
      isGuardianTransient,
      executePromoRound,
    });
  }

  async function autoShareGuardian() {
    try {
      if (!global.promoNextRunAt) global.promoNextRunAt = {};
      if (!global.promoCompletedOk) global.promoCompletedOk = {};
      const db = getDb();
      const activeSettings = await db.all(
        'SELECT owner_id, jeda FROM settings WHERE promosi_status = "ON"'
      );
      await mapPool(activeSettings, GUARDIAN_CONCURRENCY, (row) =>
        guardianProcessUser(row, 0)
      );
    } catch (e) {
      logger.error(
        'autoShareGuardian siklus gagal:',
        e && e.stack ? e.stack : e
      );
    }
  }

  async function savePromosiStateToFile() {
    try {
      const states = {};
      for (const [userId, promo] of Object.entries(promosiProgress)) {
        if (promo && promo.running !== undefined) {
          states[userId] = {
            validGroups: promo.validGroups,
            current: promo.current,
            success: promo.success,
            failed: promo.failed,
            errors: promo.errors ? promo.errors.slice(0, 20) : [],
            startTime: promo.startTime,
            lastRunTime: promo.lastRunTime || Date.now(),
            settings: promo.settings,
            selectedMessage: promo.selectedMessage,
            messageContent: promo.messageContent,
            estimasi: promo.estimasi,
            running: promo.running,
            roundStartTime: promo.roundStartTime || Date.now(),
            chatId: promo.chatId,
          };
        }
      }
      await saveKvState('promo_state', states);
    } catch (error) {
      logger.error('Failed to save promo state to file:', error);
    }
  }

  async function savePromosiState(userId) {
    const promo = promosiProgress[userId];
    if (!promo) return;
    const state = {
      validGroups: promo.validGroups,
      current: promo.current,
      success: promo.success,
      failed: promo.failed,
      errors: promo.errors.slice(0, 20),
      startTime: promo.startTime,
      settings: promo.settings,
      selectedMessage: promo.selectedMessage,
      messageContent: promo.messageContent,
      estimasi: promo.estimasi,
      roundStartTime: Date.now(),
    };
    promo.lastActivity = Date.now();
    try {
      const db = getDb();
      await withTimeout(
        db.run(
          'UPDATE settings SET promosi_active = 1, promosi_round_data = ? WHERE owner_id = ?',
          JSON.stringify(state),
          userId
        ),
        8000,
        'savePromosiState'
      );
    } catch (e) {
      try {
        logger.warn(
          `savePromosiState ${userId} best-effort gagal: ${e && e.message ? e.message : e}`
        );
      } catch (_) {}
    }
  }

  function getQueueStats() {
    return promoQueue.stats;
  }

  function clearGuardianPending() {
    guardianRetryPending.clear();
  }

  return {
    executePromoRound,
    autoShareGuardian,
    savePromosiStateToFile,
    savePromosiState,
    getQueueStats,
    clearGuardianPending,
    setExecuteInner(fn) {
      deps.executeInner = fn;
    },
    setGuardianProcessUser(fn) {
      deps.guardianProcessUser = fn;
    },
  };
}

module.exports = { createAutoShare };
