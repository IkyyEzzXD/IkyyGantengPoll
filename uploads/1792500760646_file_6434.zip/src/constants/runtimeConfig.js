function boolEnv(name, fallback = false) {
  const v = process.env[name];
  if (v === undefined || v === '') return fallback;
  return v === '1' || v === 'true' || v === 'yes';
}

function intEnv(name, fallback) {
  const v = process.env[name];
  if (v === undefined || v === '') return fallback;
  const n = parseInt(v, 10);
  return Number.isFinite(n) ? n : fallback;
}

module.exports = {
  UBOT_VERIFY_ON_LOAD: boolEnv('UBOT_VERIFY_ON_LOAD', false),
  CACHE_CLEAN_INTERVAL_MS: intEnv('CACHE_CLEAN_INTERVAL_MS', 30 * 1000),
  PROMO_QUEUE_CONCURRENCY: intEnv('PROMO_QUEUE_CONCURRENCY', 6),
  SEBAR_QUEUE_CONCURRENCY: intEnv('SEBAR_QUEUE_CONCURRENCY', 4),
  UBOT_CONNECT_CONCURRENCY: intEnv('UBOT_CONNECT_CONCURRENCY', 4),
  UBOT_IDLE_DISCONNECT_MS: intEnv('UBOT_IDLE_DISCONNECT_MS', 3 * 60 * 1000),
  STATE_TTL_MS: intEnv('STATE_TTL_MS', 5 * 60 * 1000),
  MEMORY_ELEVATED_RATIO: Number(process.env.MEMORY_ELEVATED_RATIO || 0.60),
  MEMORY_HIGH_RATIO: Number(process.env.MEMORY_HIGH_RATIO || 0.75),
  MEMORY_CRITICAL_RATIO: Number(process.env.MEMORY_CRITICAL_RATIO || 0.88),
};
