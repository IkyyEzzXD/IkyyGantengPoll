function escapeHtml(text) {
  if (typeof text !== 'string') return text ?? '';
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function parseFloodWaitSeconds(error) {
  const msg = (error && error.message) ? String(error.message) : '';
  let match = msg.match(/FLOOD_WAIT_(\d+)/i);
  if (match) return parseInt(match[1], 10);
  match = msg.match(/A wait of (\d+) seconds/i);
  if (match) return parseInt(match[1], 10);
  return null;
}

function formatDurationHuman(totalSeconds) {
  const seconds = Math.max(0, parseInt(totalSeconds, 10) || 0);
  if (seconds < 60) return `${seconds} detik`;
  if (seconds < 3600) return `${Math.ceil(seconds / 60)} menit`;
  const hours = Math.floor(seconds / 3600);
  const mins = Math.ceil((seconds % 3600) / 60);
  return mins > 0 ? `${hours} jam ${mins} menit` : `${hours} jam`;
}

function isBotBlockedError(err) {
  if (!err) return false;
  const code = err.response && err.response.error_code;
  if (code === 429) return false;
  const msg = String(err.message || err.description || '').toLowerCase();
  return (
    code === 403 ||
    msg.includes('bot was blocked') ||
    msg.includes('user is deactivated') ||
    msg.includes('chat not found') ||
    msg.includes('have no rights') ||
    msg.includes('peer_id_invalid')
  );
}

function isMediaForbiddenError(msg) {
  const s = String(msg || '').toLowerCase();
  return (
    s.includes('chat_send_media_forbidden') ||
    s.includes('chat_send_photos_forbidden') ||
    s.includes('chat_send_videos_forbidden') ||
    s.includes('chat_send_stickers_forbidden') ||
    s.includes('chat_send_gifs_forbidden') ||
    s.includes('chat_send_audios_forbidden') ||
    s.includes('chat_send_voices_forbidden') ||
    s.includes('chat_send_docs_forbidden') ||
    s.includes('media_empty') ||
    s.includes('photo_invalid') ||
    s.includes('video_content_type_invalid')
  );
}

function isPermanentGroupError(msg) {
  const s = String(msg || '').toLowerCase();
  return (
    s.includes('channel_private') ||
    s.includes('chat_write_forbidden') ||
    s.includes('user_banned_in_channel') ||
    s.includes('chat_admin_required') ||
    s.includes('peer_id_invalid') ||
    s.includes('channel_invalid') ||
    s.includes('chat_id_invalid') ||
    s.includes('username_not_occupied') ||
    s.includes('username_invalid')
  );
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

module.exports = {
  escapeHtml,
  parseFloodWaitSeconds,
  formatDurationHuman,
  isBotBlockedError,
  isMediaForbiddenError,
  isPermanentGroupError,
  sleep,
};
