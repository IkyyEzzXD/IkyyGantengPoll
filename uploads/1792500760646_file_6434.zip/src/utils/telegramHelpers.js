const { Api } = require('telegram');

async function resolveForwardPeer(client, selectedMessage) {
  if (selectedMessage.from_chat_username) {
    try {
      return await client.getEntity(selectedMessage.from_chat_username);
    } catch (e) {}
  }
  if (selectedMessage.from_chat_hash) {
    const rawId = selectedMessage.from_chat.toString();
    try {
      if (rawId.startsWith('-100')) {
        const channelId = rawId.replace('-100', '');
        return new Api.InputPeerChannel({
          channelId: BigInt(channelId),
          accessHash: BigInt(selectedMessage.from_chat_hash),
        });
      } else if (rawId.startsWith('-')) {
        return new Api.InputPeerChat({ chatId: BigInt(rawId.replace('-', '')) });
      } else {
        return new Api.InputPeerUser({
          userId: BigInt(rawId),
          accessHash: BigInt(selectedMessage.from_chat_hash),
        });
      }
    } catch (e) {}
  }
  return selectedMessage.from_chat;
}

async function resolveGroupPeer(client, group) {
  const tryGet = async (target) => {
    try {
      return await client.getEntity(target);
    } catch (e) {
      const msg = (e && e.message) ? String(e.message) : '';
      if (/FLOOD|TIMEOUT|NETWORK|CONNECTION|WAIT/i.test(msg)) {
        return await client.getEntity(target);
      }
      throw e;
    }
  };

  const username = (group.group_username || '').toString().replace(/^@/, '').trim();
  if (username) {
    try {
      return await tryGet(username);
    } catch (e) {}
  }

  const hash = group.access_hash || group.group_hash || null;
  const rawId = group.group_id != null ? group.group_id.toString() : '';
  if (hash && rawId) {
    try {
      if (rawId.startsWith('-100')) {
        const channelId = rawId.replace('-100', '');
        return new Api.InputPeerChannel({
          channelId: BigInt(channelId),
          accessHash: BigInt(hash),
        });
      } else if (rawId.startsWith('-')) {
        return new Api.InputPeerChat({ chatId: BigInt(rawId.replace('-', '')) });
      }
    } catch (e) {}
  }

  if (rawId) {
    try {
      const asNum = Number(rawId);
      if (!Number.isNaN(asNum)) {
        return await tryGet(asNum);
      }
    } catch (e) {}
    try {
      return await tryGet(rawId);
    } catch (e) {}
  }
  return group.group_id;
}

function isMediaForbiddenError(msg) {
  const s = String(msg || '').toLowerCase();
  return (
    s.includes('chat_send_media_forbidden') ||
    s.includes('chat_send_photos_forbidden') ||
    s.includes('chat_send_videos_forbidden') ||
    s.includes('chat_send_stickers_forbidden') ||
    s.includes('chat_send_gifs_forbidden') ||
    s.includes('chat_send_audios_forbidden') ||
    s.includes('chat_send_voices_forbidden') ||
    s.includes('chat_send_docs_forbidden') ||
    s.includes('media_empty') ||
    s.includes('photo_invalid') ||
    s.includes('video_content_type_invalid')
  );
}

function isPermanentGroupError(msg) {
  const s = String(msg || '').toLowerCase();
  return (
    s.includes('channel_private') ||
    s.includes('chat_write_forbidden') ||
    s.includes('user_banned_in_channel') ||
    s.includes('chat_admin_required') ||
    s.includes('peer_id_invalid') ||
    s.includes('channel_invalid') ||
    s.includes('chat_id_invalid') ||
    s.includes('username_not_occupied') ||
    s.includes('username_invalid')
  );
}

const PROMO_MEDIA_TYPES = ['photo', 'video', 'animation', 'document', 'audio', 'voice', 'sticker'];
const MEDIA_ALLOWED_ROLES = ['PREMIUM_WM', 'PREMIUM_NO_WM', 'RESELLER', 'OWNER'];

function canUseMediaForPromo(role) {
  if (!role) return false;
  const r = String(role).toUpperCase();
  return MEDIA_ALLOWED_ROLES.includes(r) || r === 'PRO' || r === 'RESELLER' || r === 'OWNER';
}

function getMediaUpgradeRequiredMessage() {
  return 'Fitur media promo hanya untuk paket Premium / Reseller. Upgrade dulu di menu Toko.';
}

module.exports = {
  resolveForwardPeer,
  resolveGroupPeer,
  isMediaForbiddenError,
  isPermanentGroupError,
  PROMO_MEDIA_TYPES,
  MEDIA_ALLOWED_ROLES,
  canUseMediaForPromo,
  getMediaUpgradeRequiredMessage,
};
