const os = require('os');
const fs = require('fs');
const path = require('path');

const logsDir = path.join(__dirname, 'logs');
try {
  fs.mkdirSync(logsDir, { recursive: true });
} catch (_) {}

const totalMb = Math.floor(os.totalmem() / 1048576);
const heapMb = Math.max(512, Math.min(8192, Math.floor(totalMb * 0.7)));

module.exports = {
  apps: [
    {
      name: 'jaseb',
      script: './src/index.js',
      cwd: __dirname,
      node_args: `--max-old-space-size=${heapMb} --max-semi-space-size=32 --expose-gc`,
      autorestart: false,
      watch: false,
      max_restarts: 0,
      kill_timeout: 15000,
      env: {
        NODE_ENV: 'production'
      },
      out_file: path.join(logsDir, 'pm2-out.log'),
      error_file: path.join(logsDir, 'pm2-error.log'),
      merge_logs: true,
      time: true
    }
  ]
};
