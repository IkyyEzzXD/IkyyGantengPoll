#!/bin/bash
cd "$(dirname "$0")"

echo "=== [$(date '+%Y-%m-%d %H:%M:%S')] JASEB Resource Monitor ==="

if command -v pm2 &> /dev/null; then
  PM2_CMD="pm2"
else
  PM2_CMD="npx pm2"
fi

STATUS=$($PM2_CMD jlist 2>/dev/null | node -e '
  let data = "";
  process.stdin.on("data", d => data += d);
  process.stdin.on("end", () => {
    try {
      const app = JSON.parse(data).find(a => a.name === "jaseb");
      if (!app) { console.log("NOT_FOUND"); return; }
      const m = app.monit || {};
      const e = app.pm2_env || {};
      console.log([e.status || "?", m.memory || 0, m.cpu || 0, e.pm_uptime || 0].join("|"));
    } catch (e) { console.log("ERROR"); }
  });
' 2>/dev/null)

if [ "$STATUS" = "NOT_FOUND" ] || [ -z "$STATUS" ] || [ "$STATUS" = "ERROR" ]; then
  echo "Proses jaseb tidak ditemukan"
else
  IFS='|' read -r PM2_STATUS MEM_BYTES CPU_PCT UPTIME_MS <<< "$STATUS"
  NOW_MS=$(( $(date +%s) * 1000 ))
  UPTIME_SEC=$(( (NOW_MS - UPTIME_MS) / 1000 ))
  echo "Status : $PM2_STATUS"
  echo "RAM    : $((MEM_BYTES / 1024 / 1024)) MB"
  echo "CPU    : ${CPU_PCT}%"
  echo "Uptime : $((UPTIME_SEC / 3600))h $(( (UPTIME_SEC % 3600) / 60 ))m"
fi

if command -v free &> /dev/null; then
  free -h | awk '/Mem:/ {printf "RAM host: %s dipakai / %s total (avail %s)\n", $3, $2, $7}'
fi
if [ -r /proc/loadavg ]; then
  read -r L1 L5 L15 _ < /proc/loadavg
  echo "Load avg: $L1 $L5 $L15 ($(nproc 2>/dev/null || echo 1) core)"
fi
df -h / 2>/dev/null | awk 'NR==2 {printf "Disk /: %s dipakai / %s (%s)\n", $3, $2, $5}'
[ -d "logs" ] && echo "Log: $(du -sh logs 2>/dev/null | cut -f1)"
[ -d "database/media" ] && echo "Media: $(du -sh database/media 2>/dev/null | cut -f1)"
