const fs = require('fs');
const os = require('os');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

let failed = 0;
async function t(name, fn) {
  try { await fn(); console.log('ok   :', name); }
  catch (e) { failed++; console.log('GAGAL:', name, '-', e.message); }
}

const src = fs.readFileSync(path.join(__dirname, '../src/index.js'), 'utf8');

function slice(from, to) {
  const a = src.indexOf(from), b = src.indexOf(to, a);
  assert(a >= 0 && b > a, `potongan tidak ketemu: ${from}`);
  return src.slice(a, b);
}

async function isolatedModule(file, dbFiles) {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'jaseb-'));
  fs.mkdirSync(path.join(tmp, 'src/system'), { recursive: true });
  fs.mkdirSync(path.join(tmp, 'database'));
  fs.mkdirSync(path.join(tmp, 'src/storage'), { recursive: true });
  for (const f of ['mongoAdapter.js', 'sqlParser.js']) fs.copyFileSync(path.join(__dirname, '../src/storage', f), path.join(tmp, 'src/storage', f));
  fs.copyFileSync(path.join(__dirname, '../src/system', file), path.join(tmp, 'src/system', file));
  fs.copyFileSync(path.join(__dirname, '../src/system', 'kvDoc.js'), path.join(tmp, 'src/system', 'kvDoc.js'));
  const seeds = {};
  for (const [name, content] of Object.entries(dbFiles || {})) seeds[name.replace(/\.json$/, '')] = content;
  if (Object.keys(seeds).length) {
    fs.writeFileSync(path.join(tmp, 'src/storage/mongoAdapter.js'), `
const seeds = ${JSON.stringify(seeds)};
module.exports = {
  getDatabase: () => ({
    collection: () => ({
      findOne: async (f) => (seeds[f._id] ? { payload: seeds[f._id] } : null),
      updateOne: async () => ({})
    })
  })
};
`);
  }
  const mod = require(path.join(tmp, 'src/system', file));
  if (Object.keys(seeds).length && typeof mod.reloadFromMongo === 'function') await mod.reloadFromMongo();
  return mod;
}

function payoutSandbox({ failFor = [], ghostFail = [] } = {}) {
  const balances = {};
  const sent = [];
  const sandbox = {
    logger: { warn() {}, info() {}, error() {} },
    getProdukBalance: (u) => balances[u] || 0,
    updateProdukBalance: async (u, amt) => {
      if (ghostFail.includes(u)) { balances[u] = (balances[u] || 0) + amt; return false; }
      if (failFor.includes(u)) return false;
      balances[u] = (balances[u] || 0) + amt;
      return true;
    },
    bot: { sendMessage: async (id, text) => { sent.push({ id, text }); } },
  };
  vm.createContext(sandbox);
  vm.runInContext(slice('async function payoutRankedRewards(', 'async function runRewardPayouts()') + '\nthis.api={payoutRankedRewards};', sandbox);
  return { api: sandbox.api, balances, sent };
}

function revokeSandbox({ client, dead = false, row = { session_string: 'SESS', phone: '62' }, behaviors = {}, dbRows = [], reusedSessions = [] } = {}) {
  const inserted = [];
  const updated = [];
  const deleted = [];
  const calls = { invoke: 0 };
  class FakeClient {
    constructor(sess) { this.sess = sess && sess.s; }
    async connect() {}
    async invoke() {
      calls.invoke++;
      const b = behaviors[this.sess] || 'ok';
      if (b === 'gone') throw new Error('AUTH_KEY_UNREGISTERED');
      if (b === 'fail') throw new Error('NETWORK_ERR');
    }
    async disconnect() {}
    async destroy() {}
  }
  const sandbox = {
    Api: { auth: { LogOut: class {} } },
    TelegramClient: FakeClient,
    StringSession: class { constructor(s) { this.s = s; } },
    API_ID: 1, API_HASH: 'h', getTelegramClientConfig: () => ({}),
    OWNER_ID: '1',
    escapeHtml: (x) => x,
    cryptoUtil: { encrypt: (x) => `enc:${x}` },
    sleepMs: async () => {},
    setTimeout, clearTimeout,
    global: {},
    userbots: client ? [{ owner_id: '42', client }] : [],
    lazyUbot: { isDead: () => dead },
    logger: { warn() {}, info() {}, error() {} },
    bot: { sendMessage: async () => {} },
    db: {
      async get(sql) { if (/FROM userbots/.test(sql)) return row; },
      async all(sql) {
        if (/FROM pending_session_revoke/.test(sql)) return dbRows;
        if (/FROM userbots/.test(sql)) return reusedSessions.map((s) => ({ session_string: s }));
        return [];
      },
      async run(sql, ...a) {
        if (/INSERT OR REPLACE INTO pending_session_revoke/.test(sql)) inserted.push(a);
        else if (/DELETE FROM pending_session_revoke/.test(sql)) deleted.push(a[0]);
        else if (/UPDATE pending_session_revoke/.test(sql)) updated.push(a);
      },
    },
  };
  vm.createContext(sandbox);
  vm.runInContext(
    slice('const SESSION_REVOKE_SKIP_REASONS', '// ===== PENANDA AKSES HABIS (v5.4.1) =====') +
    '\nthis.api={terminateUserbotSession,processPendingSessionRevokes,SESSION_REVOKE_SKIP_REASONS};', sandbox);
  return { api: sandbox.api, inserted, updated, deleted, calls, sandbox };
}

function discountSandbox({ expired, pct }) {
  const sandbox = {
    OWNER_ID: '1',
    logger: { warn() {} },
    retention: { getExpiryDiscount: () => pct },
    db: { async get(sql) { return expired === null ? undefined : { expired }; } },
  };
  vm.createContext(sandbox);
  vm.runInContext(slice('async function getManualExpiryDiscount(', 'async function carryOverRemainingAccess(') + '\n' +
    slice('function applyDiscountToPrice(', 'async function carryOverRemainingAccess(') + '\nthis.api={getManualExpiryDiscount,applyDiscountToPrice};', sandbox);
  return sandbox.api;
}

(async () => {
  await t('leaderboard: minggu lama diarsipkan lalu hadiah top 3 siap dibayar', async () => {
    const r = await isolatedModule('retention.js', {
      'retention.json': { leaderboardWeek: { weekKey: '2000-W01', scores: { a: 5, b: 9, c: 7, d: 1 }, rewardsPaid: false } },
    });
    const weeks = r.getUnpaidLeaderboardWeeks();
    assert.strictEqual(weeks.length, 1);
    assert.strictEqual(weeks[0].weekKey, '2000-W01');
    assert.deepStrictEqual(weeks[0].winners.map((w) => [w.userId, w.rank, w.amount]), [['b', 1, 3500], ['c', 2, 2100], ['a', 3, 1050]]);
  });
  await t('leaderboard: setelah ditandai lunas tidak muncul lagi & pembayaran per user tercatat', async () => {
    const r = await isolatedModule('retention.js', {
      'retention.json': { leaderboardWeek: { weekKey: '2000-W01', scores: { a: 5 }, rewardsPaid: false } },
    });
    assert.strictEqual(r.getUnpaidLeaderboardWeeks()[0].winners[0].paid, false);
    r.recordLeaderboardPayout('2000-W01', 'a', 5000);
    assert.strictEqual(r.getUnpaidLeaderboardWeeks()[0].winners[0].paid, true);
    r.markLeaderboardRewardsPaid('2000-W01');
    assert.strictEqual(r.getUnpaidLeaderboardWeeks().length, 0);
  });
  await t('leaderboard: minggu berjalan tidak ikut dibayar', async () => {
    const r = await isolatedModule('retention.js');
    r.recordPromoRun('77');
    assert.strictEqual(r.getUnpaidLeaderboardWeeks().length, 0);
    assert.strictEqual(r.getLeaderboard(10).entries[0].userId, '77');
  });
  await t('contest: hanya bulan yang sudah lewat & belum lunas', async () => {
    const cur = (await isolatedModule('referral.js')).currentMonthKey();
    const rf = await isolatedModule('referral.js', {
      'referral.json': { contest: {
        '2000-01': { scores: { x: 3, y: 8 }, rewardsPaid: false },
        '2000-02': { scores: { x: 3 }, rewardsPaid: true },
        [cur]: { scores: { z: 99 }, rewardsPaid: false },
      } },
    });
    const months = rf.getUnpaidContestMonths();
    assert.strictEqual(months.length, 1);
    assert.strictEqual(months[0].monthKey, '2000-01');
    assert.deepStrictEqual(months[0].winners.map((w) => [w.userId, w.amount]), [['y', 10000], ['x', 5000]]);
    rf.recordContestPayout('2000-01', 'y', 10000);
    assert.strictEqual(rf.getUnpaidContestMonths()[0].winners[0].paid, true);
    rf.markContestRewardsPaid('2000-01');
    assert.strictEqual(rf.getUnpaidContestMonths().length, 0);
  });

  await t('payout: saldo bertambah, notif terkirim, periode ditandai lunas', async () => {
    const { api, balances, sent } = payoutSandbox();
    const recorded = []; let marked = null;
    const winners = [{ userId: 'a', rank: 1, score: 9, amount: 5000, paid: false }, { userId: 'b', rank: 2, score: 4, amount: 3000, paid: false }];
    const r = await api.payoutRankedRewards('leaderboard', '2000-W01', winners, (...x) => recorded.push(x), (k) => { marked = k; });
    assert.strictEqual(balances.a, 5000);
    assert.strictEqual(balances.b, 3000);
    assert.strictEqual(r.paid, 2);
    assert.strictEqual(marked, '2000-W01');
    assert.strictEqual(recorded.length, 2);
    assert(sent.every((m) => /Rp/.test(m.text)));
  });
  await t('payout: pemenang yang sudah dibayar tidak dibayar dua kali', async () => {
    const { api, balances } = payoutSandbox();
    await api.payoutRankedRewards('contest', '2000-01', [{ userId: 'a', rank: 1, score: 1, amount: 10000, paid: true }], () => {}, () => {});
    assert.strictEqual(balances.a, undefined);
  });
  await t('payout: gagal -> tidak ditandai lunas supaya dicoba lagi', async () => {
    const { api } = payoutSandbox({ failFor: ['b'] });
    let marked = null;
    const winners = [{ userId: 'a', rank: 1, score: 1, amount: 100, paid: false }, { userId: 'b', rank: 2, score: 1, amount: 100, paid: false }];
    const r = await api.payoutRankedRewards('leaderboard', 'W', winners, () => {}, (k) => { marked = k; });
    assert.strictEqual(r.failed, 1);
    assert.strictEqual(marked, null);
  });
  await t('payout: saldo sudah masuk walau fungsi balik false -> dihitung berhasil (tanpa dobel)', async () => {
    const { api, balances } = payoutSandbox({ ghostFail: ['a'] });
    const r = await api.payoutRankedRewards('leaderboard', 'W', [{ userId: 'a', rank: 1, score: 1, amount: 500, paid: false }], () => {}, () => {});
    assert.strictEqual(r.paid, 1);
    assert.strictEqual(balances.a, 500);
  });
  await t('payout: runRewardPayouts terpasang di runRetentionJobs', async () => {
    const a = src.indexOf('async function runRetentionJobs()');
    assert(/runRewardPayouts\(\)/.test(src.slice(a, a + 300)));
  });

  const now = Math.floor(Date.now() / 1000);
  await t('diskon beli manual: aktif di window 72 jam untuk Basic/Pro', async () => {
    const api = discountSandbox({ expired: now + 3600, pct: 15 });
    const d = await api.getManualExpiryDiscount('5', 'wm');
    assert.strictEqual(d.pct, 15);
    assert.strictEqual(d.prevExpired, now + 3600);
    assert.strictEqual((await api.getManualExpiryDiscount('5', 'nowm')).pct, 15);
  });
  await t('diskon beli manual: tidak berlaku untuk reseller, owner, atau tanpa paket', async () => {
    const api = discountSandbox({ expired: now + 3600, pct: 15 });
    assert.strictEqual((await api.getManualExpiryDiscount('5', 'reseller')).pct, 0);
    assert.strictEqual((await api.getManualExpiryDiscount('1', 'wm')).pct, 0);
    assert.strictEqual((await discountSandbox({ expired: null, pct: 15 }).getManualExpiryDiscount('5', 'wm')).pct, 0);
  });
  await t('diskon beli manual: di luar window (pct 0) tidak ada diskon', async () => {
    const api = discountSandbox({ expired: now + 99 * 3600, pct: 0 });
    assert.strictEqual((await api.getManualExpiryDiscount('5', 'wm')).pct, 0);
  });
  await t('harga setelah diskon sama rumusnya dengan Auto-Renew', async () => {
    const api = discountSandbox({ expired: null, pct: 0 });
    assert.strictEqual(api.applyDiscountToPrice(6000, 15), 5100);
    assert.strictEqual(api.applyDiscountToPrice(2000, 15), 1700);
    assert.strictEqual(api.applyDiscountToPrice(6000, 0), 6000);
    assert.strictEqual(api.applyDiscountToPrice(500, 15), 500);
  });
  for (const fn of ['handleWmPayNow', 'handleNowmPayNow', 'handleExtend']) {
    await t(`diskon terpasang di ${fn}`, async () => {
      const a = src.indexOf(`async function ${fn}(`);
      assert(a >= 0);
      assert(/getManualExpiryDiscount\(/.test(src.slice(a, a + 1800)));
      assert(/applyDiscountToPrice\(/.test(src.slice(a, a + 1800)));
    });
  }
  await t('auto-renew memakai carryOverRemainingAccess bersama', async () => {
    const a = src.indexOf('async function runRetentionJobs()');
    assert(/carryOverRemainingAccess\(ar\.userId/.test(src.slice(a, a + 9000)));
  });

  await t('logout berhasil -> loggedOut, tidak masuk antrean', async () => {
    const { api, inserted } = revokeSandbox({ client: { invoke: async () => {} } });
    const r = await api.terminateUserbotSession('42', 50);
    assert.strictEqual(r.loggedOut, true);
    assert.strictEqual(inserted.length, 0);
  });
  await t('logout timeout 2x -> sesi dijadwalkan ulang (terenkripsi), bukan dilepas', async () => {
    const { api, inserted, calls } = revokeSandbox({ client: { invoke: () => new Promise(() => {}) } });
    const r = await api.terminateUserbotSession('42', 20);
    assert.strictEqual(r.loggedOut, false);
    assert.strictEqual(r.queued, true);
    assert.strictEqual(r.reason, 'timeout');
    assert.strictEqual(inserted.length, 1);
    assert.strictEqual(inserted[0][1], 'enc:SESS');
  });
  await t('logout gagal sekali lalu berhasil -> tidak masuk antrean', async () => {
    let n = 0;
    const { api, inserted } = revokeSandbox({ client: { invoke: async () => { if (n++ === 0) throw new Error('NETWORK_ERR'); } } });
    const r = await api.terminateUserbotSession('42', 50);
    assert.strictEqual(r.loggedOut, true);
    assert.strictEqual(inserted.length, 0);
  });
  await t('device sudah dikeluarkan (AUTH_KEY_UNREGISTERED) -> selesai tanpa antrean', async () => {
    const { api, inserted } = revokeSandbox({ client: { invoke: async () => { throw new Error('AUTH_KEY_UNREGISTERED'); } } });
    const r = await api.terminateUserbotSession('42', 50);
    assert.strictEqual(r.alreadyGone, true);
    assert.strictEqual(r.loggedOut, false);
    assert.strictEqual(inserted.length, 0);
  });
  await t('sesi sudah ditandai mati -> tanpa logout & tanpa antrean', async () => {
    const { api, inserted, calls } = revokeSandbox({ client: { invoke: async () => { calls.invoke++; } }, dead: true });
    const r = await api.terminateUserbotSession('42', 50);
    assert.strictEqual(r.alreadyGone, true);
    assert.strictEqual(inserted.length, 0);
  });
  await t('client tidak ada di memori tapi baris userbot ada -> tetap diantrekan', async () => {
    const { api, inserted } = revokeSandbox({});
    const r = await api.terminateUserbotSession('42', 50);
    assert.strictEqual(r.queued, true);
    assert.strictEqual(inserted.length, 1);
  });
  await t('antrean: berhasil dicabut -> baris dihapus', async () => {
    const { api, deleted } = revokeSandbox({ dbRows: [{ owner_id: '42', session_string: 'S1', attempts: 0, phone: '62' }] });
    await api.processPendingSessionRevokes();
    assert.deepStrictEqual(deleted, ['42']);
  });
  await t('antrean: sesi sudah tidak valid -> baris dihapus', async () => {
    const { api, deleted } = revokeSandbox({ behaviors: { S1: 'gone' }, dbRows: [{ owner_id: '42', session_string: 'S1', attempts: 2 }] });
    await api.processPendingSessionRevokes();
    assert.deepStrictEqual(deleted, ['42']);
  });
  await t('antrean: gagal -> percobaan bertambah & jadwal diundur', async () => {
    const { api, updated, deleted } = revokeSandbox({ behaviors: { S1: 'fail' }, dbRows: [{ owner_id: '42', session_string: 'S1', attempts: 1 }] });
    await api.processPendingSessionRevokes();
    assert.strictEqual(deleted.length, 0);
    assert.strictEqual(updated.length, 1);
    assert.strictEqual(updated[0][0], 2);
  });
  await t('antrean: menyerah setelah batas percobaan', async () => {
    const { api, deleted } = revokeSandbox({ behaviors: { S1: 'fail' }, dbRows: [{ owner_id: '42', session_string: 'S1', attempts: 9 }] });
    await api.processPendingSessionRevokes();
    assert.deepStrictEqual(deleted, ['42']);
  });
  await t('antrean: sesi yang sedang dipakai userbot/sender lain tidak dicabut', async () => {
    const { api, deleted, calls } = revokeSandbox({ dbRows: [{ owner_id: '42', session_string: 'S1', attempts: 0 }], reusedSessions: ['S1'] });
    await api.processPendingSessionRevokes();
    assert.deepStrictEqual(deleted, ['42']);
    assert.strictEqual(calls.invoke, 0);
  });
  await t('alasan yang dikecualikan dari pencabutan sesi', async () => {
    const { api } = revokeSandbox({});
    for (const reason of ['invalid_session', 'logout', 'convert_to_jasa_sender']) assert(api.SESSION_REVOKE_SKIP_REASONS.has(reason));
    for (const reason of ['expired', 'manual_logout', 'manual_delete_by_owner', 'removed_premium']) assert(!api.SESSION_REVOKE_SKIP_REASONS.has(reason));
  });
  await t('cleanupUserData mencabut sesi sebelum data dihapus, kecuali alasan yang dikecualikan', async () => {
    const a = src.indexOf('async function cleanupUserData(');
    const body = src.slice(a, a + 4000);
    assert(body.indexOf('terminateUserbotSession(') > 0);
    assert(body.indexOf('terminateUserbotSession(') < body.indexOf("DELETE FROM groups"));
    assert(/SESSION_REVOKE_SKIP_REASONS\.has\(reason\)/.test(body));
  });
  await t('tabel antrean dibuat & worker dijadwalkan', async () => {
    assert(/CREATE TABLE IF NOT EXISTS pending_session_revoke/.test(src));
    assert(/setInterval\(\(\) => \{ processPendingSessionRevokes\(\)/.test(src));
  });

  console.log(failed ? `\n${failed} TES GAGAL` : '\nSEMUA LOLOS');
  process.exit(failed ? 1 : 0);
})();
