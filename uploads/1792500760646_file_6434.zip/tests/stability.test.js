const st = require(require('path').join(__dirname, '../src/system/stability.js'));
let fail = 0;
const ok = (c, m) => { if (!c) { fail++; console.log('GAGAL:', m); } else console.log('ok   :', m); };

ok(st.extractRetryAfterMs({ response: { body: { parameters: { retry_after: 3 } } } }) === 3000, 'retry_after dari response.body');
ok(st.extractRetryAfterMs({ message: '429 Too Many Requests: retry after 5' }) === 5000, 'retry_after dari teks');
ok(st.extractRetryAfterMs({ response: { statusCode: 429 } }) === 1000, '429 tanpa retry_after -> default 1s');
ok(st.extractRetryAfterMs({ response: { body: { parameters: { retry_after: 999 } } } }) === 15000, 'dibatasi maks 15s');
ok(st.extractRetryAfterMs({ message: 'chat not found' }) === null, 'error lain tidak di-retry');
ok(st.extractRetryAfterMs({ message: 'Forbidden: bot was blocked by the user' }) === null, 'bot diblokir tidak di-retry');
ok(st.extractRetryAfterMs(null) === null, 'null aman');

(async () => {
  let calls = 0;
  const bot = { sendMessage: async () => { calls++; if (calls < 3) { const e = new Error('x'); e.response = { body: { parameters: { retry_after: 0.01 } } }; throw e; } return 'sent'; } };
  st.wrapFloodRetry(bot, ['sendMessage', 'tidakAda']);
  ok((await bot.sendMessage()) === 'sent' && calls === 3, '429 diulang lalu sukses (3 panggilan)');

  let c2 = 0;
  const bot2 = { sendMessage: async () => { c2++; throw new Error('chat not found'); } };
  st.wrapFloodRetry(bot2, ['sendMessage']);
  let threw = false; try { await bot2.sendMessage(); } catch (_) { threw = true; }
  ok(threw && c2 === 1, 'error non-429 langsung dilempar tanpa retry');

  let c3 = 0;
  const bot3 = { sendMessage: async () => { c3++; const e = new Error('429'); e.response = { body: { parameters: { retry_after: 0.01 } } }; throw e; } };
  st.wrapFloodRetry(bot3, ['sendMessage']);
  let threw3 = false; try { await bot3.sendMessage(); } catch (_) { threw3 = true; }
  ok(threw3 && c3 === 3, '429 terus-menerus berhenti setelah 3 percobaan');

  ok(typeof st.isDuplicateClick === 'undefined', 'tidak ada pembuangan klik ganda (semua klik diproses)');

  st.lockCacheSet('7', false);
  ok(st.lockCacheGet('7') === false, 'cache lock terbaca');
  const calls2 = [];
  const fakeDb = { run: async (sql, ...p) => { calls2.push([sql, p]); return { changes: 1 }; } };
  st.watchSettingsWrites(fakeDb);
  await fakeDb.run('UPDATE settings SET promosi_status = "ON" WHERE owner_id = ?', '7');
  ok(st.lockCacheGet('7') === undefined, 'UPDATE settings -> cache user 7 dibersihkan');

  st.lockCacheSet('8', true); st.lockCacheSet('9', true);
  await fakeDb.run('UPDATE settings SET promosi_status = ? WHERE owner_id = ?', 'PAUSE', '8');
  ok(st.lockCacheGet('8') === undefined && st.lockCacheGet('9') === true, 'hanya user 8 dibersihkan, user 9 tetap');

  await fakeDb.run('UPDATE settings SET promosi_status = "OFF" WHERE promosi_status = "ON"');
  ok(st.lockCacheGet('9') === undefined, 'UPDATE tanpa owner_id -> seluruh cache dibersihkan');

  st.lockCacheSet('5', false);
  await fakeDb.run('UPDATE users SET username = ? WHERE user_id = ?', 'a', '5');
  ok(st.lockCacheGet('5') === false, 'tabel lain tidak menyentuh cache');

  await fakeDb.run('DELETE FROM settings WHERE owner_id = ?', '5');
  ok(st.lockCacheGet('5') === undefined, 'DELETE settings juga membersihkan');

  st.lockCacheSet('6', true);
  await fakeDb.run('UPDATE settings SET promosi_status = "OFF", promosi_active = 0, promosi_round_data = NULL WHERE owner_id = ?', ['6']);
  ok(st.lockCacheGet('6') === undefined, 'parameter berbentuk array juga dikenali');

  st.watchSettingsWrites(fakeDb);
  const before = calls2.length;
  await fakeDb.run('SELECT 1');
  ok(calls2.length === before + 1, 'watch tidak terpasang ganda');

  st.lockCacheSet('11', true);
  await new Promise(r => setTimeout(r, 8100));
  ok(st.lockCacheGet('11') === undefined, 'cache lock kedaluwarsa setelah TTL 8s');

  console.log(fail === 0 ? '\nSEMUA LOLOS' : `\n${fail} GAGAL`);
  process.exit(fail ? 1 : 0);
})();
