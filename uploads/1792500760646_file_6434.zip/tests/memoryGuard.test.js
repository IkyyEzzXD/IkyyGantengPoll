const assert = require('assert');
const { create } = require('../src/system/memoryGuard.js');
const calls = { cleanup: 0, clear: 0, release: 0 };
const logs = [];
const log = { warn: m => logs.push(m), info: m => logs.push(m) };
(async () => {
  // critical: semua ambang 0 -> pressure menyala, semua aksi jalan
  const g = create({
    logger: log,
    config: { elevatedRatio: 0, highRatio: 0, criticalRatio: 0, actionCooldownMs: 500, leakSampleMs: 1, leakSamplesNeeded: 3, leakMinGrowthMb: 0 },
    cleanup: () => calls.cleanup++, clearCaches: () => calls.clear++, releaseIdle: async () => { calls.release++; return 3; },
    describe: () => ({ x: 1 }),
  });
  assert.strictEqual(g.tick(), 'critical');
  assert.strictEqual(g.isUnderPressure(), true);
  await new Promise(r => setTimeout(r, 100));
  assert.deepStrictEqual(calls, { cleanup: 1, clear: 1, release: 1 });
  assert.ok(logs.some(l => l.includes('Tekanan memori [critical]')));

  // cooldown: tick cepat tidak mengulang aksi
  g.tick(); await new Promise(r => setTimeout(r, 10));
  assert.strictEqual(calls.cleanup, 1);

  // normal: ambang tinggi -> tidak ada aksi, pressure padam
  const calls2 = { cleanup: 0 };
  const n = create({ logger: log, config: { elevatedRatio: 2, highRatio: 3, criticalRatio: 4, rssCriticalRatio: 9 }, cleanup: () => calls2.cleanup++ });
  assert.strictEqual(n.tick(), 'normal');
  assert.strictEqual(n.isUnderPressure(), false);
  assert.strictEqual(calls2.cleanup, 0);

  // elevated: hanya cleanup (tanpa clearCaches/releaseIdle)
  const c3 = { cleanup: 0, clear: 0, release: 0 };
  const e = create({ logger: log, config: { elevatedRatio: 0, highRatio: 3, criticalRatio: 4, rssCriticalRatio: 9 },
    cleanup: () => c3.cleanup++, clearCaches: () => c3.clear++, releaseIdle: async () => { c3.release++; return 0; } });
  assert.strictEqual(e.tick(), 'elevated');
  await new Promise(r => setTimeout(r, 50));
  assert.deepStrictEqual(c3, { cleanup: 1, clear: 0, release: 0 });
  assert.strictEqual(e.isUnderPressure(), false);

  // deteksi leak: heap setelah GC naik terus -> WARN "Indikasi LEAK"
  const keep = [];
  const l = create({ logger: log, config: { elevatedRatio: 9, highRatio: 9, criticalRatio: 9, rssCriticalRatio: 9, leakSampleMs: 0, leakSamplesNeeded: 3, leakMinGrowthMb: 1 }, describe: () => ({ keep: keep.length }) });
  for (let i = 0; i < 4; i++) { keep.push(Buffer.alloc(3 * 1024 * 1024, i)); l.tick(); }
  assert.ok(logs.some(m => m.includes('Indikasi LEAK')), 'leak harus terdeteksi: ' + logs.join('|'));
  console.log('memoryGuard OK');
})().catch(e => { console.error('GAGAL', e); process.exit(1); });
