// Uji lazyUbot dengan mock 'telegram' (tanpa jaringan)
const Module = require('module');
const origLoad = Module._load;
let created = 0, destroyed = 0, connects = 0, maxConcurrentConnect = 0, activeConnect = 0;
class FakeSession { constructor(s){ this.s = s; } save(){ return this.s + '+'; } }
class FakeClient {
  constructor(session){ this.session = session; this._c = false; this.id = ++created; }
  get connected(){ return this._c; }
  async connect(){ activeConnect++; maxConcurrentConnect = Math.max(maxConcurrentConnect, activeConnect); await new Promise(r=>setTimeout(r,30)); this._c = true; connects++; activeConnect--; }
  async disconnect(){ this._c = false; }
  async destroy(){ destroyed++; }
  async getMe(){ return { id: 1, via: this.id }; }
}
Module._load = function(req, ...a){
  if (req === 'telegram') return { TelegramClient: FakeClient };
  if (req === 'telegram/sessions') return { StringSession: FakeSession };
  return origLoad.call(this, req, ...a);
};
const assert = require('assert');
const lazy = require('../src/system/lazyUbot.js');
lazy.setLogger({ info(){}, warn(){}, error(){} });
lazy.setIdleMs(10001);
(async () => {
  // 1. recycle setelah idle: client lama di-destroy, proxy tetap bekerja
  const c = lazy.createLazyClient('1', 'sess', 1, 'h', {});
  const me1 = await c.getMe();
  assert.strictEqual(me1.via, 1);
  assert.strictEqual(created, 1);
  const n = await lazy.releaseIdle();
  assert.strictEqual(n, 1, 'releaseIdle harus melepas 1');
  assert.strictEqual(destroyed, 1, 'client lama harus di-destroy');
  assert.strictEqual(created, 2, 'client baru dibuat');
  const me2 = await c.getMe();
  assert.strictEqual(me2.via, 2, 'proxy harus memakai client baru');
  assert.ok(c.session.s.endsWith('+'), 'session yang disimpan dipakai ulang');

  // 2. pin -> tidak dilepas
  lazy.pin('1');
  const n2 = await lazy.releaseIdle();
  assert.strictEqual(n2, 0, 'client yang pin tidak boleh dilepas');
  assert.ok(lazy.isConnected('1'));
  lazy.unpin('1');

  // 3. batas connect bersamaan
  const many = [];
  for (let i = 10; i < 30; i++) many.push(lazy.createLazyClient(String(i), 's', 1, 'h', {}).getMe());
  await Promise.all(many);
  assert.ok(maxConcurrentConnect <= 4, 'connect bersamaan maks 4, aktual ' + maxConcurrentConnect);

  // 4. remove -> destroy + proxy lama berhenti
  const before = destroyed;
  lazy.remove('1');
  await new Promise(r=>setTimeout(r,20));
  assert.ok(destroyed > before);
  await assert.rejects(() => c.getMe(), /dinonaktifkan/);

  // 5. pressure hook: connect non-pin ditahan lalu lanjut (tidak reject)
  let p = true; lazy.setPressureCheck(() => p);
  setTimeout(() => { p = false; }, 1500);
  const t0 = Date.now();
  await lazy.createLazyClient('99', 's', 1, 'h', {}).getMe();
  assert.ok(Date.now() - t0 >= 1000, 'harus menunggu saat pressure');

  console.log('lazyUbot OK | created', created, 'destroyed', destroyed, 'maxConcurrentConnect', maxConcurrentConnect);
  process.exit(0);
})().catch(e => { console.error('GAGAL:', e); process.exit(1); });
