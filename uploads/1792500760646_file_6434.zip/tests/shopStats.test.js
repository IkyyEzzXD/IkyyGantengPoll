const path = require('path');
const mongoAdapter = require(path.join(__dirname, '../src/storage/mongoAdapter.js'));

let fail = 0;
const ok = (c, m) => { if (!c) { fail++; console.log('GAGAL:', m); } else console.log('ok   :', m); };

const store = { shop_stats: { _id: 'shop_stats', ordersCompleted: 5, incomeTotal: 10000 } };
let failNext = 0;
mongoAdapter.getDatabase = () => ({
  collection: () => ({
    findOne: async ({ _id }) => (store[_id] ? Object.assign({}, store[_id]) : null),
    updateOne: async ({ _id }, upd) => {
      if (failNext > 0) { failNext--; throw new Error('timeout'); }
      const doc = store[_id] || (store[_id] = { _id });
      for (const [k, v] of Object.entries(upd.$inc || {})) doc[k] = (doc[k] || 0) + v;
      Object.assign(doc, upd.$set || {});
      return {};
    }
  })
});

const stats = require(path.join(__dirname, '../src/system/shopStats.js'));
const wait = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  stats.recordIncome(4000);
  stats.recordOrderCompleted();
  await stats.initFromMongo();
  let s = stats.getStats();
  ok(s.incomeTotal === 14000 && s.ordersCompleted === 6, 'increment sebelum load tidak hilang saat data dimuat');
  await stats.flush();
  ok(store.shop_stats.incomeTotal === 14000 && store.shop_stats.ordersCompleted === 6, 'tersimpan ke Mongo dengan $inc');

  stats.recordIncome(4000);
  stats.recordOrderCompleted();
  stats.recordIncome(6000);
  stats.recordOrderCompleted();
  await stats.flush();
  ok(store.shop_stats.incomeTotal === 24000 && store.shop_stats.ordersCompleted === 8, 'beberapa pembelian beruntun semuanya terakumulasi');

  failNext = 1;
  stats.recordIncome(1000);
  await stats.flush();
  ok(store.shop_stats.incomeTotal === 24000, 'gagal simpan tidak menghilangkan data di memori');
  ok(stats.getStats().incomeTotal === 25000, 'angka menu tetap benar saat Mongo gagal sesaat');
  await wait(2200);
  ok(store.shop_stats.incomeTotal === 25000, 'penyimpanan ulang otomatis berhasil setelah Mongo pulih');

  stats.recordIncome(0);
  stats.recordIncome(-5);
  ok(stats.getStats().incomeTotal === 25000, 'nominal nol/negatif diabaikan');

  stats.recordDeposit(50000);
  await stats.flush();
  ok(store.shop_stats.depositTotal === 50000 && store.shop_stats.incomeTotal === 25000, 'deposit dicatat terpisah, tidak menggandakan pendapatan');

  console.log(fail ? `\n${fail} GAGAL` : '\nSEMUA LOLOS');
  process.exit(fail ? 1 : 0);
})();
