// Tes pembayaran Pakasir yang tahan restart + rollback akses saat pembelian gagal.
// Potongan kode diambil dari src/index.js lalu dijalankan dengan db palsu (tanpa node_modules),
// jadi yang diuji adalah kode ASLI, bukan salinan.
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');
const { withLock } = require('../src/system/concurrency');

let failed = 0;
async function t(name, fn) {
  try { await fn(); console.log('ok   :', name); }
  catch (e) { failed++; console.log('GAGAL:', name, '-', e.message); }
}

const src = fs.readFileSync(path.join(__dirname, '../src/index.js'), 'utf8');
function slice(from, to) {
  const a = src.indexOf(from), b = src.indexOf(to, a);
  assert(a >= 0 && b > a, `potongan tidak ketemu: ${from}`);
  return src.slice(a, b);
}
const quiet = { warn() {}, info() {}, error() {} };

// ---------- db palsu untuk tabel pakasir_payments ----------
function fakePakasirDb() {
  const rows = new Map();
  return {
    rows,
    jasa: {},
    async run(sql, ...p) {
      if (/INSERT OR IGNORE INTO pakasir_payments/.test(sql)) {
        const [order_id, txn_id, user_id, chat_id, type, jasa_order_id, amount, base_amount, created_at, expired_at, updated_at] = p;
        if (!rows.has(order_id)) rows.set(order_id, { order_id, txn_id, user_id, chat_id, type, jasa_order_id, amount, base_amount, status: 'pending', balance_before: null, created_at, expired_at, updated_at });
        return { changes: 1 };
      }
      if (/SET status = 'crediting'/.test(sql)) {
        const [bal, , orderId] = p;
        const r = rows.get(orderId);
        if (r && (r.status === 'pending' || r.status === 'expired')) { r.status = 'crediting'; r.balance_before = bal; return { changes: 1 }; }
        return { changes: 0 };
      }
      if (/UPDATE pakasir_payments SET status = \?, updated_at = \? WHERE order_id = \? AND status = \?/.test(sql)) {
        const [st, , orderId, from] = p;
        const r = rows.get(orderId);
        if (r && r.status === from) { r.status = st; return { changes: 1 }; }
        return { changes: 0 };
      }
      if (/UPDATE pakasir_payments SET status = \?, updated_at = \? WHERE order_id = \?/.test(sql)) {
        const [st, , orderId] = p;
        const r = rows.get(orderId);
        if (r) { r.status = st; return { changes: 1 }; }
        return { changes: 0 };
      }
      throw new Error('SQL tidak dikenal: ' + sql);
    },
    async get(sql, ...p) {
      if (/FROM pakasir_payments WHERE order_id/.test(sql)) return rows.get(p[0]);
      if (/FROM jasa_orders/.test(sql)) return this.jasa[p[0]];
      throw new Error('SQL tidak dikenal: ' + sql);
    },
    async all(sql) {
      if (/status = 'expired'/.test(String(sql))) return [...rows.values()].filter((r) => r.status === 'expired');
      return [...rows.values()].filter((r) => ['pending', 'crediting'].includes(r.status));
    },
  };
}

function depositSandbox({ db, ledger = [], creditOk = true }) {
  const calls = { credit: [], sent: [], referral: [], polled: [], adopted: [], jasa: [], notifyDeposit: 0 };
  const balances = { 5: 1000 };
  const sandbox = {
    db, logger: quiet, produkTransactions: ledger, calls, balances,
    PAKASIR_ENABLED: true, PAKASIR_EXPIRY_MS: 600000, OWNER_ID: 1,
    pakasir: { adoptOrder: (...a) => { calls.adopted.push(a); return true; } },
    checkFelixStatus: async (orderId) => ({ status: sandbox.remoteStatus || 'PENDING' }),
    remoteStatus: 'PENDING',
    startFelixAutoCheck: (id) => calls.polled.push(id),
    getProdukBalance: (id) => balances[id] || 0,
    updateProdukBalance: async (uid, amt, isAdd, orderId, details) => {
      if (!creditOk) return false;
      calls.credit.push({ uid, amt, orderId, details });
      balances[uid] = (balances[uid] || 0) + amt;
      ledger.push({ type: 'DEPOSIT', order_id: orderId, user_id: uid, details });
      return true;
    },
    bot: {
      sendMessage: async (chat, text, opts) => { calls.sent.push([chat, String(text)]); calls.sentOpts = (calls.sentOpts || []); calls.sentOpts.push(opts); return { message_id: 900 }; },
      sendPhoto: async (chat, buf, opts) => { calls.photos = (calls.photos || []); calls.photos.push({ chat, opts }); return { message_id: 777 }; },
    },
    PAKASIR_ADMIN_FEE: 200,
    createFelixOrder: async (amount) => ({
      success: true, txn_id: 'txn-new', order_id: 'ORD-NEW', amount, totalTransfer: sandbox.totalTransfer || amount,
      qrBuffer: Buffer.from('x'), expired_at: Date.UTC(2026, 9, 16, 9, 21), // 16:21 WIB
    }),
    totalTransfer: 5299,
    removeTrackedMenuForPayment: async () => {},
    safeDeleteMessage: async (chat, id) => { (calls.deleted = calls.deleted || []).push([chat, id]); },
    cancelFelixOrder: async (oid) => { (calls.cancel = calls.cancel || []).push(oid); return sandbox.cancelResult || { success: true }; },
    cancelResult: null,
    rewardReferralOnFirstDeposit: async (u, a) => { calls.referral.push([u, a]); },
    notifyDepositSuccess: async () => { calls.notifyDeposit++; },
    handleJasaPaymentSettled: async (o) => { calls.jasa.push(o); },
  };
  sandbox.global = sandbox;
  sandbox.global.activePayments = {};
  vm.createContext(sandbox);
  vm.runInContext(
    slice('function _idFromDb(', '/**\n * Bikin deposit otomatis end-to-end:') +
      slice('async function createAutoDepositOrder(', '// ------------------------------------------------------------------\n// PEMBAYARAN TELAT') +
      slice('const PAKASIR_LATE_WINDOW_MS', '/**\n * Job polling background') +
      slice('async function handleFelixPaymentSettled(', '// Handle user kirim bukti deposit') +
      '\nthis.api={persistPakasirPayment,claimPakasirPayment,setPakasirStatus,recoverPakasirPayments,handleFelixPaymentSettled,recheckExpiredPakasirOrder,sweepLatePakasirPayments,createAutoDepositOrder,replacePendingDeposits,formatWib};',
    sandbox
  );
  return sandbox;
}

const newPayment = (extra = {}) => ({ userId: 5, chatId: 5, amount: 5200, baseAmount: 5000, createdAt: Date.now(), expiredAt: Date.now() + 600000, status: 'PENDING', ...extra });

(async () => {
  // ---------- Pakasir: kredit ganda ----------
  await t('pakasir: dua panggilan hampir bersamaan -> saldo masuk sekali', async () => {
    const sb = depositSandbox({ db: fakePakasirDb() });
    const pay = newPayment();
    await sb.api.persistPakasirPayment('ORD-1', pay, 'txn-1');
    await Promise.all([sb.api.handleFelixPaymentSettled('ORD-1', pay), sb.api.handleFelixPaymentSettled('ORD-1', pay)]);
    assert.strictEqual(sb.calls.credit.length, 1);
    assert.strictEqual(sb.db.rows.get('ORD-1').status, 'credited');
  });
  await t('pakasir: SETELAH RESTART (penanda memori hilang) tidak dikreditkan lagi', async () => {
    const db = fakePakasirDb();
    const sb1 = depositSandbox({ db });
    await sb1.api.persistPakasirPayment('ORD-2', newPayment(), 'txn-2');
    await sb1.api.handleFelixPaymentSettled('ORD-2', newPayment());
    assert.strictEqual(sb1.calls.credit.length, 1);
    // "restart": proses baru, memori kosong, database sama, polling menemukan SETTLED lagi
    const sb2 = depositSandbox({ db, ledger: [] });
    await sb2.api.handleFelixPaymentSettled('ORD-2', newPayment());
    assert.strictEqual(sb2.calls.credit.length, 0);
  });
  await t('pakasir: referral hanya dipicu oleh kredit yang benar-benar terjadi', async () => {
    const sb = depositSandbox({ db: fakePakasirDb() });
    await sb.api.persistPakasirPayment('ORD-3', newPayment(), 'txn-3');
    await sb.api.handleFelixPaymentSettled('ORD-3', newPayment());
    await sb.api.handleFelixPaymentSettled('ORD-3', newPayment());
    assert.deepStrictEqual(sb.calls.referral, [[5, 5000]]); // nominal tanpa biaya layanan
  });
  await t('pakasir: order tanpa baris di DB (dibuat sebelum update) tetap dikredit sekali lewat penanda memori', async () => {
    const sb = depositSandbox({ db: fakePakasirDb() });
    const pay = newPayment();
    await Promise.all([sb.api.handleFelixPaymentSettled('LAMA-1', pay), sb.api.handleFelixPaymentSettled('LAMA-1', pay)]);
    assert.strictEqual(sb.calls.credit.length, 1);
  });
  await t('pakasir: gagal menambah saldo -> status failed, tidak diulang otomatis', async () => {
    const sb = depositSandbox({ db: fakePakasirDb(), creditOk: false });
    await sb.api.persistPakasirPayment('ORD-4', newPayment(), 'txn-4');
    await sb.api.handleFelixPaymentSettled('ORD-4', newPayment());
    assert.strictEqual(sb.db.rows.get('ORD-4').status, 'failed');
    assert(sb.calls.sent.some(([, m]) => /ORD-4/.test(m)), 'user diberi tahu order id');
    await sb.api.handleFelixPaymentSettled('ORD-4', newPayment());
    assert.strictEqual(sb.db.rows.get('ORD-4').status, 'failed');
  });
  await t('pakasir: pembayaran jasa sebar -> aktivasi dipanggil sekali walau settle datang dua kali', async () => {
    const sb = depositSandbox({ db: fakePakasirDb() });
    const mk = () => newPayment({ type: 'jasa', jasaOrderId: 'JASA-1' });
    await sb.api.persistPakasirPayment('ORD-5', mk(), 'txn-5');
    await sb.api.handleFelixPaymentSettled('ORD-5', mk());
    await sb.api.handleFelixPaymentSettled('ORD-5', mk());
    assert.deepStrictEqual(sb.calls.jasa, ['ORD-5']);
    assert.strictEqual(sb.calls.credit.length, 0);
    assert.strictEqual(sb.db.rows.get('ORD-5').status, 'credited');
  });

  // ---------- Pakasir: pemulihan saat startup ----------
  await t('pemulihan: order pending dipasang lagi ke polling (txn_id dipakai ulang), tipe id dikembalikan ke angka', async () => {
    const db = fakePakasirDb();
    const sb = depositSandbox({ db });
    await sb.api.persistPakasirPayment('ORD-6', newPayment(), 'txn-6');
    sb.global.activePayments = {}; // restart
    await sb.api.recoverPakasirPayments();
    assert.deepStrictEqual(sb.calls.polled, ['ORD-6']);
    assert.strictEqual(sb.calls.adopted[0][1], 'txn-6');
    const p = sb.global.activePayments['ORD-6'];
    assert.strictEqual(p.userId, 5);
    assert.strictEqual(p.baseAmount, 5000);
    assert.strictEqual(p.status, 'PENDING');
  });
  await t('pemulihan: order yang sudah credited/expired tidak dipasang lagi', async () => {
    const db = fakePakasirDb();
    const sb = depositSandbox({ db });
    await sb.api.persistPakasirPayment('ORD-7', newPayment(), 'txn-7');
    await sb.api.persistPakasirPayment('ORD-8', newPayment(), 'txn-8');
    await sb.api.setPakasirStatus('ORD-7', 'credited');
    await sb.api.setPakasirStatus('ORD-8', 'expired');
    await sb.api.recoverPakasirPayments();
    assert.deepStrictEqual(sb.calls.polled, []);
  });
  await t('pemulihan: mati di tengah kredit, riwayat sudah mencatat -> credited, tidak diulang', async () => {
    const db = fakePakasirDb();
    const ledger = [{ type: 'DEPOSIT', order_id: 'ORD-9' }];
    const sb = depositSandbox({ db, ledger });
    await sb.api.persistPakasirPayment('ORD-9', newPayment(), 'txn-9');
    await sb.api.claimPakasirPayment('ORD-9', 1000); // sudah "crediting" saat bot mati
    await sb.api.recoverPakasirPayments();
    assert.strictEqual(db.rows.get('ORD-9').status, 'credited');
    assert.deepStrictEqual(sb.calls.polled, []);
    assert.strictEqual(sb.calls.credit.length, 0);
  });
  await t('pemulihan: mati di tengah kredit, tidak ada catatan -> review + owner diberi tahu, TIDAK dikredit otomatis', async () => {
    const db = fakePakasirDb();
    const sb = depositSandbox({ db });
    await sb.api.persistPakasirPayment('ORD-10', newPayment(), 'txn-10');
    await sb.api.claimPakasirPayment('ORD-10', 1000);
    await sb.api.recoverPakasirPayments();
    assert.strictEqual(db.rows.get('ORD-10').status, 'review');
    assert.strictEqual(sb.calls.credit.length, 0);
    assert.deepStrictEqual(sb.calls.polled, []);
    assert(sb.calls.sent.some(([chat, m]) => chat === 1 && /ORD-10/.test(m)), 'owner dikirimi ringkasan order');
  });
  await t('pemulihan: jasa yang mati sebelum aktivasi dimulai -> dipantau lagi; yang sudah jalan -> credited', async () => {
    const db = fakePakasirDb();
    const sb = depositSandbox({ db });
    const mk = (id) => newPayment({ type: 'jasa', jasaOrderId: id });
    await sb.api.persistPakasirPayment('ORD-11', mk('J-A'), 'txn-11');
    await sb.api.persistPakasirPayment('ORD-12', mk('J-B'), 'txn-12');
    await sb.api.claimPakasirPayment('ORD-11');
    await sb.api.claimPakasirPayment('ORD-12');
    db.jasa['J-A'] = { status: 'pending' };
    db.jasa['J-B'] = { status: 'active' };
    await sb.api.recoverPakasirPayments();
    assert.deepStrictEqual(sb.calls.polled, ['ORD-11']);
    assert.strictEqual(db.rows.get('ORD-12').status, 'credited');
  });

  // ---------- Pembayaran telat (masuk setelah QR kedaluwarsa) ----------
  await t('telat: order kedaluwarsa tapi ternyata sudah dibayar -> saldo masuk SEKALI', async () => {
    const db = fakePakasirDb();
    const sb = depositSandbox({ db });
    await sb.api.persistPakasirPayment('ORD-L1', newPayment(), 'txn-l1');
    await sb.api.setPakasirStatus('ORD-L1', 'expired', 'pending');
    sb.remoteStatus = 'SETTLED';
    await Promise.all([sb.api.recheckExpiredPakasirOrder('ORD-L1'), sb.api.recheckExpiredPakasirOrder('ORD-L1')]);
    await sb.api.recheckExpiredPakasirOrder('ORD-L1'); // sesudahnya sudah credited -> tidak diulang
    assert.strictEqual(sb.calls.credit.length, 1);
    assert.strictEqual(db.rows.get('ORD-L1').status, 'credited');
    assert(sb.calls.sent.some(([, m]) => /setelah QR kedaluwarsa/.test(m)), 'user diberi tahu bahwa pembayaran terlambat sudah diproses');
  });
  await t('telat: belum dibayar -> tetap expired, tidak dikredit', async () => {
    const db = fakePakasirDb();
    const sb = depositSandbox({ db });
    await sb.api.persistPakasirPayment('ORD-L2', newPayment(), 'txn-l2');
    await sb.api.setPakasirStatus('ORD-L2', 'expired', 'pending');
    const r = await sb.api.recheckExpiredPakasirOrder('ORD-L2');
    assert.strictEqual(r.status, 'PENDING');
    assert.strictEqual(sb.calls.credit.length, 0);
    assert.strictEqual(db.rows.get('ORD-L2').status, 'expired');
  });
  await t('telat: dibatalkan Pakasir -> berhenti dipantau', async () => {
    const db = fakePakasirDb();
    const sb = depositSandbox({ db });
    await sb.api.persistPakasirPayment('ORD-L3', newPayment(), 'txn-l3');
    await sb.api.setPakasirStatus('ORD-L3', 'expired', 'pending');
    sb.remoteStatus = 'CANCELED';
    await sb.api.recheckExpiredPakasirOrder('ORD-L3');
    assert.strictEqual(db.rows.get('ORD-L3').status, 'canceled');
  });
  await t('telat: sweeper mengkreditkan order kedaluwarsa yang sudah dibayar', async () => {
    const db = fakePakasirDb();
    const sb = depositSandbox({ db });
    await sb.api.persistPakasirPayment('ORD-L4', newPayment(), 'txn-l4');
    await sb.api.setPakasirStatus('ORD-L4', 'expired', 'pending');
    sb.remoteStatus = 'SETTLED';
    await sb.api.sweepLatePakasirPayments();
    assert.strictEqual(sb.calls.credit.length, 1);
    assert.strictEqual(db.rows.get('ORD-L4').status, 'credited');
  });

  // ---------- Deposit simpel (ala tgX): QR tanpa tombol, auto cek, auto saldo ----------
  await t('deposit: pesan QR ringkas, total dari Pakasir, tanpa tombol', async () => {
    const db = fakePakasirDb();
    const sb = depositSandbox({ db });
    const order = await sb.api.createAutoDepositOrder(5, 5, 5000);
    assert.strictEqual(order.order_id, 'ORD-NEW');
    const { opts } = sb.calls.photos[0];
    assert(!opts.reply_markup, 'tidak boleh ada tombol');
    assert(/Detail Isi Saldo \(QRIS\)/.test(opts.caption));
    assert(/Nominal: Rp 5\.000/.test(opts.caption), opts.caption);
    assert(/Biaya: Rp 299/.test(opts.caption), opts.caption);
    assert(/Total bayar: <b>Rp 5\.299<\/b>/.test(opts.caption), opts.caption);
    assert(/Kadaluarsa: 2026-10-16 16:21 WIB/.test(opts.caption), opts.caption);
    assert.deepStrictEqual(sb.calls.polled, ['ORD-NEW']);
    assert.strictEqual(db.rows.get('ORD-NEW').status, 'pending');
    assert.strictEqual(sb.global.activePayments['ORD-NEW'].qrMessageId, 777);
  });
  await t('deposit: invoice lama user yang sama dibatalkan otomatis, user lain tidak disentuh', async () => {
    const db = fakePakasirDb();
    const sb = depositSandbox({ db });
    await sb.api.persistPakasirPayment('ORD-OLD', newPayment({ qrMessageId: 55 }), 'txn-old');
    sb.global.activePayments['ORD-OLD'] = newPayment({ qrMessageId: 55 });
    await sb.api.persistPakasirPayment('ORD-OTHER', newPayment({ userId: 6, chatId: 6 }), 'txn-o');
    sb.global.activePayments['ORD-OTHER'] = newPayment({ userId: 6, chatId: 6 });
    await sb.api.replacePendingDeposits(5, 'ORD-NEW');
    assert.deepStrictEqual(sb.calls.cancel, ['ORD-OLD']);
    assert.strictEqual(db.rows.get('ORD-OLD').status, 'canceled');
    assert(!sb.global.activePayments['ORD-OLD']);
    assert.deepStrictEqual(sb.calls.deleted, [[5, 55]]);
    assert(sb.global.activePayments['ORD-OTHER'], 'order user lain tetap aktif');
  });
  await t('deposit: gagal membatalkan di Pakasir -> ditandai expired (tetap dipantau pembayaran telat)', async () => {
    const db = fakePakasirDb();
    const sb = depositSandbox({ db });
    sb.cancelResult = { success: false };
    await sb.api.persistPakasirPayment('ORD-OLD2', newPayment(), 'txn-old2');
    sb.global.activePayments['ORD-OLD2'] = newPayment();
    await sb.api.replacePendingDeposits(5, 'ORD-NEW');
    assert.strictEqual(db.rows.get('ORD-OLD2').status, 'expired');
  });
  await t('deposit: invoice lama ternyata sudah lunas -> saldo tetap masuk, tidak dibatalkan', async () => {
    const db = fakePakasirDb();
    const sb = depositSandbox({ db });
    sb.remoteStatus = 'SETTLED';
    await sb.api.persistPakasirPayment('ORD-OLD3', newPayment(), 'txn-old3');
    sb.global.activePayments['ORD-OLD3'] = newPayment();
    await sb.api.replacePendingDeposits(5, 'ORD-NEW');
    assert.strictEqual(sb.calls.credit.length, 1);
    assert(!sb.calls.cancel, 'tidak boleh membatalkan order yang sudah lunas');
    assert.strictEqual(db.rows.get('ORD-OLD3').status, 'credited');
  });

  // ---------- Jaring pengaman ledger ----------
  function ledgerSandbox() {
    const sb = { produkBalance: {}, produkTransactions: [], logger: quiet, saveProdukBalance: async () => {}, saveProdukTransactions: async () => {} };
    vm.createContext(sb);
    vm.runInContext(slice('async function updateProdukBalance(', 'async function getProdukUserTransactions(') + '\nthis.api={updateProdukBalance};', sb);
    return sb;
  }
  await t('ledger: deposit dengan order_id sama tidak menambah saldo dua kali', async () => {
    const sb = ledgerSandbox();
    assert.strictEqual(await sb.api.updateProdukBalance(5, 1000, true, 'ORD-X', 'deposit_otomatis_pakasir'), true);
    assert.strictEqual(await sb.api.updateProdukBalance(5, 1000, true, 'ORD-X', 'deposit_otomatis_pakasir'), true);
    assert.strictEqual(sb.produkBalance[5], 1000);
  });
  await t('ledger: jaring pengaman tidak mengganggu pembelian, hadiah referral, dan deposit order lain', async () => {
    const sb = ledgerSandbox();
    await sb.api.updateProdukBalance(5, 1000, true, 'ORD-A', 'deposit_manual');
    await sb.api.updateProdukBalance(5, 1000, true, 'ORD-B', 'deposit_manual');
    await sb.api.updateProdukBalance(5, 200, true, null, 'referral:9');
    await sb.api.updateProdukBalance(5, 200, true, null, 'referral:9');
    assert.strictEqual(await sb.api.updateProdukBalance(5, 500, false, null, 'purchase_BASIC'), true);
    assert.strictEqual(sb.produkBalance[5], 2000 + 400 - 500);
  });

  // ---------- Rollback akses ----------
  function purchaseSandbox({ restoreErrs = [], snapshotFails = false } = {}) {
    const events = [];
    const balances = { 7: 10000 };
    const sb = {
      events, balances, withLock, logger: quiet, OWNER_ID: 1,
      escapeHtml: (x) => String(x),
      getProdukBalance: (id) => balances[id] || 0,
      updateProdukBalance: async (id, amt, isAdd, orderId, details) => {
        if (isAdd) balances[id] += amt; else balances[id] -= amt;
        events.push(isAdd ? `refund:${details}` : `debit:${details}`);
        return true;
      },
      db: { run: async (sql) => { events.push('db:' + sql.trim().split(/\s+/).slice(0, 2).join(' ')); return { changes: 1 }; } },
      snapshotAccessState: async (id) => { events.push(`snapshot:${id}`); if (snapshotFails) throw new Error('db terkunci'); return { uid: String(id) }; },
      restoreAccessState: async (snap) => { events.push(`restore:${snap.uid}`); return restoreErrs; },
      recordPurchaseStats: () => events.push('stats'),
      bot: { sendMessage: async (chat, text) => { events.push('owner:' + String(text).replace(/\s+/g, ' ')); } },
    };
    vm.createContext(sb);
    vm.runInContext(slice('async function createPayment(', 'async function createProductPayment(') + '\nthis.api={createPayment};', sb);
    return sb;
  }
  await t('rollback: onSuccess gagal -> akses dipulihkan SEBELUM saldo dikembalikan', async () => {
    const sb = purchaseSandbox();
    const r = await sb.api.createPayment(7, 7, 3000, 'BASIC', '', async () => { sb.events.push('grant'); throw new Error('boom'); }, { accessTargetId: 42 });
    assert.strictEqual(r.ok, false);
    const order = sb.events.filter((e) => /^(snapshot|grant|restore|refund|debit)/.test(e));
    assert.deepStrictEqual(order, ['debit:purchase_BASIC', 'snapshot:42', 'grant', 'restore:42', 'refund:rollback_failed']);
    assert.strictEqual(sb.balances[7], 10000);
    assert(sb.events.some((e) => /owner:.*dipulihkan/.test(e)));
  });
  await t('rollback: berhasil -> tidak ada pemulihan, saldo terpotong', async () => {
    const sb = purchaseSandbox();
    const r = await sb.api.createPayment(7, 7, 3000, 'PRO', '', async () => {}, { accessTargetId: 7 });
    assert.strictEqual(r.ok, true);
    assert(!sb.events.some((e) => /^(restore|refund)/.test(e)));
    assert.strictEqual(sb.balances[7], 7000);
  });
  await t('rollback: pemulihan gagal sebagian -> saldo tetap kembali, owner dapat daftar yang gagal', async () => {
    const sb = purchaseSandbox({ restoreErrs: ['list_access: gagal menulis list_access'] });
    const r = await sb.api.createPayment(7, 7, 3000, 'EXTEND', '', async () => { throw new Error('x'); }, { accessTargetId: 7 });
    assert.strictEqual(r.ok, false);
    assert.strictEqual(sb.balances[7], 10000);
    assert(sb.events.some((e) => /owner:.*PEMULIHAN SEBAGIAN GAGAL.*list_access/.test(e)));
  });
  await t('rollback: snapshot gagal (belum ada yang diubah) -> onSuccess tidak jalan, tidak ada restore, saldo kembali', async () => {
    const sb = purchaseSandbox({ snapshotFails: true });
    let ran = false;
    const r = await sb.api.createPayment(7, 7, 3000, 'BASIC', '', async () => { ran = true; }, { accessTargetId: 7 });
    assert.strictEqual(r.ok, false);
    assert.strictEqual(ran, false);
    assert(!sb.events.some((e) => /^restore/.test(e)));
    assert.strictEqual(sb.balances[7], 10000);
  });
  await t('rollback: onRollback (stok produk) dipanggil, pembelian tanpa akses tidak membuat snapshot', async () => {
    const sb = purchaseSandbox();
    let rolled = 0;
    await sb.api.createPayment(7, 7, 3000, 'PROD', '', async () => { throw new Error('stok habis'); }, { onRollback: async () => { rolled++; } });
    assert.strictEqual(rolled, 1);
    assert(!sb.events.some((e) => /^snapshot/.test(e)));
    assert.strictEqual(sb.balances[7], 10000);
  });

  // ---------- snapshot/restore akses ----------
  function accessSandbox() {
    const calls = [];
    let list = [{ id: 42, role: 'basic', expired_at: 111 }, { id: 99, role: 'pro', expired_at: 222 }];
    const sb = {
      calls,
      db: {
        async all(sql, ...p) {
          const m = /FROM (\w+)/.exec(sql)[1];
          if (m === 'premium_wm') return [{ user_id: '42', expired: 111, added_by: 'AUTO', created_at: 1 }];
          if (m === 'reseller_list') return [{ user_id: '42', added_by: 'AUTO', added_at: 1, expired: 500 }];
          if (m === 'reseller_added') { calls.push({ sql, p }); return [{ id: 5, reseller_id: '42', user_id: '77', type: 'wm', expired: 400, added_at: 2 }]; }
          if (m === 'userbots') return [{ ubot_id: 'U1', expired: 111 }];
          if (m === 'tokens') return [{ token: 'T1', role: 'PREMIUM_WM', expired_at: 111 }];
          return [];
        },
        async get(sql) { return /FROM users/.test(sql) ? { role: 'PREMIUM_WM', expired: 111 } : undefined; },
        async run(sql, ...p) { calls.push({ sql: sql.replace(/\s+/g, ' ').trim(), p }); if (sb.failOn && sb.failOn.test(sql)) throw new Error('disk penuh'); return { changes: 1 }; },
      },
      loadListAccess: () => list,
      saveListAccess: (l) => { list = l; return true; },
      getList: () => list,
      retention: { hasFirstPurchase: () => false, clearFirstPurchase: (id) => calls.push({ sql: 'clearFirstPurchase', p: [id] }) },
      invalidateUserRoleCache: () => {},
    };
    vm.createContext(sb);
    vm.runInContext(slice('async function snapshotAccessState(', '/**\n * Aktifkan / upgrade akses user setelah pembayaran sukses.') + '\nthis.api={snapshotAccessState,restoreAccessState};', sb);
    return sb;
  }
  await t('snapshot: menangkap semua tabel akses (termasuk reseller_added kedua arah) dan salinan list_access', async () => {
    const sb = accessSandbox();
    const snap = await sb.api.snapshotAccessState(42);
    assert.strictEqual(snap.uid, '42');
    assert.strictEqual(snap.premium_wm.length, 1);
    assert.strictEqual(snap.reseller_added.length, 1);
    assert(/reseller_id = \? OR user_id = \?/.test(sb.calls[0].sql));
    assert.strictEqual(snap.hadFirstPurchase, false);
    sb.getList()[0].expired_at = 999; // perubahan setelah snapshot tidak boleh ikut
    assert.strictEqual(snap.listAccess[0].expired_at, 111);
  });
  await t('restore: hapus hasil pembelian lalu tulis ulang kondisi lama; reseller_list sebelum reseller_added', async () => {
    const sb = accessSandbox();
    const snap = await sb.api.snapshotAccessState(42);
    sb.calls.length = 0;
    sb.getList().splice(0, 1, { id: 42, role: 'reseller', expired_at: 777 }); // kondisi "sesudah pembelian gagal"
    const errs = await sb.api.restoreAccessState(snap);
    assert.strictEqual(errs.length, 0, errs.join('; '));
    const sqls = sb.calls.map((c) => c.sql);
    const idx = (re) => sqls.findIndex((q) => re.test(q));
    assert(idx(/DELETE FROM premium_wm/) < idx(/INSERT INTO premium_wm/));
    assert(idx(/INSERT INTO reseller_list/) < idx(/INSERT OR IGNORE INTO reseller_added/));
    assert(idx(/UPDATE users SET role/) >= 0 && idx(/UPDATE userbots SET expired/) >= 0 && idx(/UPDATE tokens SET role/) >= 0);
    const l = sb.getList();
    assert.strictEqual(l.find((i) => i.id === 42).role, 'basic');
    assert.strictEqual(l.find((i) => i.id === 42).expired_at, 111);
    assert.strictEqual(l.find((i) => i.id === 99).expired_at, 222, 'user lain tidak tersentuh');
    assert(sqls.includes('clearFirstPurchase'), 'diskon pembelian pertama tidak hangus oleh pembelian yang gagal');
  });
  await t('restore: satu langkah gagal tidak menghentikan langkah lain dan dilaporkan', async () => {
    const sb = accessSandbox();
    const snap = await sb.api.snapshotAccessState(42);
    sb.failOn = /INSERT INTO premium_wm/;
    const errs = await sb.api.restoreAccessState(snap);
    assert(errs.length === 1 && /premium_wm/.test(errs[0]));
    assert(sb.calls.some((c) => /UPDATE users SET role/.test(c.sql)));
  });

  // ---------- Terpasang di tempat yang benar ----------
  await t('pemanggil: Basic/Pro/Reseller memakai accessTargetId = penerima, Perpanjang = pembeli', async () => {
    for (const label of ['BASIC', 'PRO', 'RESELLER']) {
      const body = slice(`createPayment(userId, chatId, amount, '${label}'`, '\n  if (!result.ok) {');
      assert(/\}, \{ accessTargetId: targetUserId \}\);/.test(body), label);
    }
    const ext = slice("createPayment(userId, chatId, totalPrice, 'EXTEND'", '\n  if (!result.ok) {');
    assert(/\}, \{ accessTargetId: userId \}\);/.test(ext));
  });
  await t('pemanggil: produk memulihkan stok & order, notifikasi channel tidak membatalkan pembelian', async () => {
    const body = slice("createPayment(userId, chatId, totalPrice, 'PROD'", 'async function produkBaruShowDepositMenu(');
    assert(/onRollback/.test(body) && /produkBaruRestoreStock/.test(body));
    assert(/try \{\s*await produkBaruSendPaymentNotification/.test(body));
  });
  await t('pemanggil: auto-renew memulihkan akses sebelum mengembalikan saldo', async () => {
    const body = slice('let renewSnap = null;', 'const finalExpired = await carryOverRemainingAccess(ar.userId');
    assert(body.indexOf('restoreAccessState(') > 0 && body.indexOf('restoreAccessState(') < body.indexOf('auto_renew_refund_'));
  });
  await t('startup: recoverPakasirPayments dipanggil setelah saldo & riwayat dimuat', async () => {
    const body = slice('async function startBot()', 'logger.info(\'Bot Actived...\')');
    const iBal = body.indexOf('await loadProdukBalance()'), iTx = body.indexOf('await loadProdukTransactions()'), iRec = body.indexOf('await recoverPakasirPayments()');
    assert(iBal > 0 && iTx > iBal && iRec > iTx);
  });
  await t('tombol batal: pembayaran yang sudah masuk dikreditkan, gagal batal tidak membuang order', async () => {
    const body = slice("if (data.startsWith('felix_cancel_')) {", '// FITUR: /ticket');
    assert(/result\.settled/.test(body) && /handleFelixPaymentSettled\(orderId, payment\)/.test(body));
    assert(/if \(result\.success\) \{[^}]*delete global\.activePayments\[orderId\]/.test(body));
  });
  await t('polling: cek terakhir sebelum order dinyatakan kedaluwarsa', async () => {
    const body = slice('function startFelixAutoCheck(', 'async function handleFelixPaymentSettled(');
    assert(body.indexOf('const last = await checkFelixStatus(orderId)') > 0);
    assert(body.indexOf('const last = await checkFelixStatus(orderId)') < body.indexOf("current.status = 'EXPIRED'"));
  });

  console.log(failed ? `\n${failed} GAGAL` : '\nSEMUA LOLOS');
  process.exit(failed ? 1 : 0);
})();
