const assert = require('assert');
const { createEngine } = require('../src/storage/mongoAdapter');
const { parseSql } = require('../src/storage/sqlParser');

let seqId = 0;

function getField(doc, f) {
  return doc[f];
}

function eqVal(a, b) {
  return String(a) === String(b) && typeof a === typeof b;
}

function matchCond(val, cond) {
  const isOp = cond && typeof cond === 'object' && !(cond instanceof RegExp) && Object.keys(cond).some(k => k.startsWith('$'));
  if (!isOp) {
    if (cond === null) return val === null || val === undefined;
    return val !== undefined && val !== null && eqVal(val, cond);
  }
  for (const [op, arg] of Object.entries(cond)) {
    switch (op) {
      case '$in': if (!arg.some(x => (x === null ? val === null || val === undefined : val !== undefined && val !== null && eqVal(val, x)))) return false; break;
      case '$nin': if (arg.some(x => (x === null ? val === null || val === undefined : val !== undefined && val !== null && eqVal(val, x)))) return false; break;
      case '$ne': if (arg === null ? (val === null || val === undefined) : (val !== undefined && val !== null && eqVal(val, arg))) return false; break;
      case '$gt': if (!(val !== undefined && val !== null && typeof val === typeof arg && val > arg)) return false; break;
      case '$gte': if (!(val !== undefined && val !== null && typeof val === typeof arg && val >= arg)) return false; break;
      case '$lt': if (!(val !== undefined && val !== null && typeof val === typeof arg && val < arg)) return false; break;
      case '$lte': if (!(val !== undefined && val !== null && typeof val === typeof arg && val <= arg)) return false; break;
      case '$exists': if ((val !== undefined) !== arg) return false; break;
      case '$regex': {
        if (typeof val !== 'string') return false;
        if (!new RegExp(arg, cond.$options || '').test(val)) return false;
        break;
      }
      case '$options': break;
      case '$not': if (typeof val === 'string' && arg.test(val)) return false; break;
      case '$type': if (arg === 'null' && val !== null) return false; break;
      default: throw new Error(`fake: operator ${op}`);
    }
  }
  return true;
}

function matches(doc, filter) {
  for (const [k, v] of Object.entries(filter || {})) {
    if (k === '$and') {
      if (!v.every(f => matches(doc, f))) return false;
    } else if (k === '$or') {
      if (!v.some(f => matches(doc, f))) return false;
    } else if (k === '$nor') {
      if (v.some(f => matches(doc, f))) return false;
    } else if (!matchCond(getField(doc, k), v)) return false;
  }
  return true;
}

class FakeCol {
  constructor(name) {
    this.name = name;
    this.docs = [];
    this.uniques = [];
    this.indexes = [];
  }

  find(filter, opts = {}) {
    let res = this.docs.filter(d => matches(d, filter));
    const cur = {
      sort(s) {
        const [[k, dir]] = Object.entries(s);
        res = res.slice().sort((a, b) => {
          const x = a[k] === undefined ? null : a[k];
          const y = b[k] === undefined ? null : b[k];
          if (x === y) return 0;
          if (x === null) return -dir;
          if (y === null) return dir;
          return (x < y ? -1 : 1) * dir;
        });
        return cur;
      },
      skip(n) {
        res = res.slice(n);
        return cur;
      },
      limit(n) {
        res = res.slice(0, n);
        return cur;
      },
      async toArray() {
        return res.map(d => {
          if (!opts.projection) return Object.assign({}, d);
          const o = { _id: d._id };
          for (const k of Object.keys(opts.projection)) if (d[k] !== undefined) o[k] = d[k];
          return o;
        });
      }
    };
    return cur;
  }

  async findOne(filter) {
    const d = this.docs.find(x => matches(x, filter));
    return d ? Object.assign({}, d) : null;
  }

  async countDocuments(filter) {
    return this.docs.filter(d => matches(d, filter)).length;
  }

  checkUnique(doc, skip) {
    for (const cols of this.uniques) {
      if (!cols.every(c => doc[c] !== undefined && doc[c] !== null)) continue;
      const clash = this.docs.find(d => d !== skip && cols.every(c => eqVal(d[c], doc[c])));
      if (clash) {
        const e = new Error('E11000 duplicate key');
        e.code = 11000;
        throw e;
      }
    }
  }

  async insertOne(doc) {
    const d = Object.assign({ _id: `oid${++seqId}` }, doc);
    this.checkUnique(d, null);
    this.docs.push(d);
    return { insertedId: d._id };
  }

  apply(doc, update) {
    for (const [k, v] of Object.entries(update.$set || {})) doc[k] = v;
    for (const [k, v] of Object.entries(update.$inc || {})) doc[k] = (doc[k] || 0) + v;
  }

  async updateOne(filter, update, opts = {}) {
    const d = this.docs.find(x => matches(x, filter));
    if (d) {
      this.apply(d, update);
      return { matchedCount: 1, modifiedCount: 1, upsertedCount: 0 };
    }
    if (opts.upsert) {
      const base = {};
      for (const [k, v] of Object.entries(filter)) if (!k.startsWith('$') && (typeof v !== 'object' || v === null)) base[k] = v;
      const nd = Object.assign({ _id: `oid${++seqId}` }, base, update.$setOnInsert || {});
      this.apply(nd, update);
      this.checkUnique(nd, null);
      this.docs.push(nd);
      return { matchedCount: 0, modifiedCount: 0, upsertedCount: 1 };
    }
    return { matchedCount: 0, modifiedCount: 0, upsertedCount: 0 };
  }

  async updateMany(filter, update) {
    const hit = this.docs.filter(x => matches(x, filter));
    hit.forEach(d => this.apply(d, update));
    return { matchedCount: hit.length, modifiedCount: hit.length, upsertedCount: 0 };
  }

  async replaceOne(filter, doc, opts = {}) {
    const i = this.docs.findIndex(x => matches(x, filter));
    if (i >= 0) {
      this.docs[i] = Object.assign({ _id: this.docs[i]._id }, doc);
      return { matchedCount: 1 };
    }
    if (opts.upsert) {
      const nd = Object.assign({ _id: `oid${++seqId}` }, doc);
      this.checkUnique(nd, null);
      this.docs.push(nd);
      return { matchedCount: 0, upsertedCount: 1 };
    }
    return { matchedCount: 0 };
  }

  async deleteMany(filter) {
    const before = this.docs.length;
    this.docs = this.docs.filter(d => !matches(d, filter));
    return { deletedCount: before - this.docs.length };
  }

  async bulkWrite(ops) {
    for (const op of ops) {
      const u = op.updateOne;
      await this.updateOne(u.filter, u.update);
    }
    return {};
  }

  async findOneAndUpdate(filter, update, opts = {}) {
    let d = this.docs.find(x => matches(x, filter));
    if (!d && opts.upsert) {
      d = { _id: filter._id };
      this.docs.push(d);
    }
    if (d) this.apply(d, update);
    if (d && update.$max) for (const [k, v] of Object.entries(update.$max)) d[k] = Math.max(d[k] || 0, v);
    return d;
  }

  async createIndex(keys, opts = {}) {
    this.indexes.push({ keys, opts });
    if (opts.unique) this.uniques.push(Object.keys(keys));
    return opts.name;
  }
}

class FakeDb {
  constructor() {
    this.cols = new Map();
  }

  collection(name) {
    if (!this.cols.has(name)) this.cols.set(name, new FakeCol(name));
    return this.cols.get(name);
  }
}

const results = [];
let failed = 0;

async function t(name, fn) {
  try {
    await fn();
    results.push(`ok   : ${name}`);
  } catch (e) {
    failed++;
    results.push(`GAGAL: ${name} - ${e.message}`);
  }
}

async function setup() {
  const fake = new FakeDb();
  const { adapter, engine } = createEngine(fake);
  const lcol = fake.collection('_counters');
  const orig = lcol.updateOne.bind(lcol);
  lcol.updateOne = async (f, u, o) => {
    let d = lcol.docs.find(x => x._id === f._id);
    if (!d) {
      d = { _id: f._id };
      lcol.docs.push(d);
    }
    if (u.$max) for (const [k, v] of Object.entries(u.$max)) d[k] = Math.max(d[k] || 0, v);
    void orig;
    return { matchedCount: 1 };
  };
  await adapter.exec(`
    CREATE TABLE IF NOT EXISTS users (
      user_id TEXT PRIMARY KEY, username TEXT, full_name TEXT, role TEXT DEFAULT 'FREE',
      expired INTEGER, trial_used INTEGER DEFAULT 0, created_at INTEGER
    );
    CREATE TABLE IF NOT EXISTS settings (
      owner_id TEXT PRIMARY KEY, promosi_status TEXT DEFAULT 'OFF', delay INTEGER DEFAULT 300,
      FOREIGN KEY (owner_id) REFERENCES users(user_id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS reseller_list (
      id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT NOT NULL UNIQUE, added_by TEXT, added_at INTEGER, expired INTEGER
    );
    CREATE TABLE IF NOT EXISTS admin_controls (
      id INTEGER PRIMARY KEY AUTOINCREMENT, owner_id TEXT NOT NULL, admin_id TEXT NOT NULL, created_at INTEGER,
      UNIQUE(owner_id, admin_id)
    );
    CREATE TABLE IF NOT EXISTS promo_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT, owner_id TEXT, success INTEGER, finished_at INTEGER
    );
    CREATE TABLE IF NOT EXISTS userbots (
      ubot_id TEXT PRIMARY KEY, owner_id TEXT, status TEXT DEFAULT 'AKTIF', expired INTEGER, total_sent INTEGER DEFAULT 0
    );
    CREATE INDEX IF NOT EXISTS idx_userbots_owner ON userbots(owner_id);
  `);
  return { fake, adapter, engine };
}

(async () => {
  await t('semua bentuk SQL yang dipakai bot bisa di-parse', () => {
    const samples = [
      "SELECT * FROM users WHERE user_id = ?",
      "SELECT ac.*, u.full_name, u.username FROM admin_controls ac LEFT JOIN users u ON ac.admin_id = u.user_id WHERE ac.owner_id = ? ORDER BY ac.created_at DESC",
      "SELECT * FROM premium_wm WHERE user_id = ? UNION SELECT * FROM premium_no_wm WHERE user_id = ?",
      "SELECT s.owner_id FROM settings s WHERE NOT EXISTS (SELECT 1 FROM users u WHERE u.user_id = s.owner_id)",
      "UPDATE userbots SET total_sent = MAX(COALESCE(total_sent, 0), ?) WHERE owner_id = ?",
      "INSERT INTO reseller_list (user_id, added_by, added_at, expired) VALUES (?, ?, ?, ?) ON CONFLICT(user_id) DO UPDATE SET added_by = excluded.added_by, expired = excluded.expired",
      "SELECT user_id, expired FROM users WHERE expired IS NOT NULL AND expired > 0 AND expired > strftime('%s','now') AND expired < strftime('%s','now') + 72 * 3600",
      "SELECT COALESCE(SUM(success), 0) as total FROM promo_logs WHERE owner_id = ?"
    ];
    for (const s of samples) parseSql(s);
  });

  await t('insert, default kolom, dan coercion tipe (angka ke kolom TEXT)', async () => {
    const { adapter } = await setup();
    await adapter.run('INSERT INTO users (user_id, username) VALUES (?, ?)', 12345, 'budi');
    const u = await adapter.get('SELECT * FROM users WHERE user_id = ?', '12345');
    assert.strictEqual(u.user_id, '12345');
    assert.strictEqual(u.role, 'FREE');
    assert.strictEqual(u.trial_used, 0);
    const u2 = await adapter.get('SELECT user_id FROM users WHERE user_id = ?', 12345);
    assert.strictEqual(u2.user_id, '12345');
  });

  await t('default kolom berlaku untuk dokumen lama yang tidak punya field itu', async () => {
    const { fake, adapter } = await setup();
    await fake.collection('settings').insertOne({ owner_id: 'a' });
    const r = await adapter.get('SELECT promosi_status, delay FROM settings WHERE owner_id = ?', 'a');
    assert.strictEqual(r.promosi_status, 'OFF');
    const n = await adapter.all("SELECT owner_id FROM settings WHERE promosi_status = 'OFF'");
    assert.strictEqual(n.length, 1);
    const none = await adapter.all("SELECT owner_id FROM settings WHERE promosi_status = 'ON'");
    assert.strictEqual(none.length, 0);
  });

  await t('INSERT OR IGNORE / OR REPLACE / ON CONFLICT memakai kunci primer & unik', async () => {
    const { adapter } = await setup();
    await adapter.run('INSERT OR IGNORE INTO users (user_id, role) VALUES (?, ?)', 'u1', 'FREE');
    const ig = await adapter.run('INSERT OR IGNORE INTO users (user_id, role) VALUES (?, ?)', 'u1', 'PRO');
    assert.strictEqual(ig.changes, 0);
    assert.strictEqual((await adapter.get('SELECT role FROM users WHERE user_id = ?', 'u1')).role, 'FREE');
    await adapter.run('INSERT OR REPLACE INTO users (user_id, role) VALUES (?, ?)', 'u1', 'PRO');
    assert.strictEqual((await adapter.get('SELECT role FROM users WHERE user_id = ?', 'u1')).role, 'PRO');
    assert.strictEqual((await adapter.all('SELECT * FROM users')).length, 1);
    await adapter.run('INSERT INTO reseller_list (user_id, added_by, expired) VALUES (?, ?, ?)', 'r1', 'o', 10);
    await adapter.run('INSERT INTO reseller_list (user_id, added_by, expired) VALUES (?, ?, ?) ON CONFLICT(user_id) DO UPDATE SET added_by = excluded.added_by, expired = excluded.expired', 'r1', 'o2', 99);
    const rows = await adapter.all('SELECT * FROM reseller_list');
    assert.strictEqual(rows.length, 1);
    assert.strictEqual(rows[0].expired, 99);
    assert.strictEqual(rows[0].added_by, 'o2');
    await adapter.run('INSERT INTO settings (owner_id) VALUES (?) ON CONFLICT(owner_id) DO NOTHING', 'x');
    await adapter.run('INSERT INTO settings (owner_id) VALUES (?) ON CONFLICT(owner_id) DO NOTHING', 'x');
    assert.strictEqual((await adapter.all('SELECT * FROM settings')).length, 1);
  });

  await t('unique dilanggar melempar SQLITE_CONSTRAINT', async () => {
    const { adapter } = await setup();
    await adapter.run('INSERT INTO admin_controls (owner_id, admin_id, created_at) VALUES (?, ?, ?)', 'o', 'a', 1);
    await assert.rejects(() => adapter.run('INSERT INTO admin_controls (owner_id, admin_id, created_at) VALUES (?, ?, ?)', 'o', 'a', 2), e => e.code === 'SQLITE_CONSTRAINT');
    const ig = await adapter.run('INSERT OR IGNORE INTO admin_controls (owner_id, admin_id, created_at) VALUES (?, ?, ?)', 'o', 'a', 3);
    assert.strictEqual(ig.changes, 0);
    assert.strictEqual((await adapter.all('SELECT * FROM admin_controls')).length, 1);
  });

  await t('id autoincrement berlanjut dari data lama dan lastID benar', async () => {
    const { fake, adapter } = await setup();
    await fake.collection('promo_logs').insertOne({ id: 41, owner_id: 'z', success: 1 });
    const r = await adapter.run('INSERT INTO promo_logs (owner_id, success, finished_at) VALUES (?, ?, ?)', 'z', 2, 5);
    assert.strictEqual(r.lastID, 42);
  });

  await t('UPDATE: set konstanta, increment, MAX/COALESCE per dokumen', async () => {
    const { adapter } = await setup();
    await adapter.run('INSERT INTO userbots (ubot_id, owner_id, total_sent) VALUES (?, ?, ?)', 'b1', 'o1', 5);
    await adapter.run('UPDATE userbots SET total_sent = total_sent + ? WHERE owner_id = ?', 3, 'o1');
    assert.strictEqual((await adapter.get('SELECT total_sent FROM userbots WHERE owner_id = ?', 'o1')).total_sent, 8);
    await adapter.run('UPDATE userbots SET total_sent = MAX(COALESCE(total_sent, 0), ?) WHERE owner_id = ?', 100, 'o1');
    assert.strictEqual((await adapter.get('SELECT total_sent FROM userbots WHERE owner_id = ?', 'o1')).total_sent, 100);
    const r = await adapter.run("UPDATE userbots SET status = 'INACTIVE', expired = NULL WHERE ubot_id = ?", 'b1');
    assert.strictEqual(r.changes, 1);
    const row = await adapter.get('SELECT status, expired FROM userbots WHERE ubot_id = ?', 'b1');
    assert.strictEqual(row.status, 'INACTIVE');
    assert.strictEqual(row.expired, null);
  });

  await t('JOIN, LEFT JOIN, GROUP BY, SUM, COUNT DISTINCT', async () => {
    const { adapter } = await setup();
    await adapter.run('INSERT INTO users (user_id, username, full_name, role) VALUES (?, ?, ?, ?)', 'a', 'ua', 'A', 'PREMIUM_WM');
    await adapter.run('INSERT INTO users (user_id, username, full_name, role) VALUES (?, ?, ?, ?)', 'b', 'ub', 'B', 'FREE');
    await adapter.run('INSERT INTO userbots (ubot_id, owner_id, status, expired) VALUES (?, ?, ?, ?)', '1', 'a', 'AKTIF', null);
    await adapter.run('INSERT INTO userbots (ubot_id, owner_id, status, expired) VALUES (?, ?, ?, ?)', '2', 'b', 'AKTIF', null);
    await adapter.run('INSERT INTO admin_controls (owner_id, admin_id, created_at) VALUES (?, ?, ?)', 'a', 'b', 2);
    await adapter.run('INSERT INTO admin_controls (owner_id, admin_id, created_at) VALUES (?, ?, ?)', 'a', 'zz', 3);
    const j = await adapter.all("SELECT ub.owner_id AS owner_id, u.role AS role FROM userbots ub JOIN users u ON u.user_id = ub.owner_id WHERE ub.status = 'AKTIF' AND ub.expired IS NULL AND u.role IN ('PREMIUM_WM', 'PREMIUM_NO_WM')");
    assert.deepStrictEqual(j, [{ owner_id: 'a', role: 'PREMIUM_WM' }]);
    const l = await adapter.all('SELECT ac.*, u.full_name, u.username FROM admin_controls ac LEFT JOIN users u ON ac.admin_id = u.user_id WHERE ac.owner_id = ? ORDER BY ac.created_at DESC', 'a');
    assert.strictEqual(l.length, 2);
    assert.strictEqual(l[0].admin_id, 'zz');
    assert.strictEqual(l[0].full_name, null);
    assert.strictEqual(l[1].full_name, 'B');
    await adapter.run('INSERT INTO promo_logs (owner_id, success) VALUES (?, ?)', 'a', 4);
    await adapter.run('INSERT INTO promo_logs (owner_id, success) VALUES (?, ?)', 'a', 6);
    await adapter.run('INSERT INTO promo_logs (owner_id, success) VALUES (?, ?)', 'b', 1);
    const g = await adapter.all('SELECT owner_id, COALESCE(SUM(success), 0) as total FROM promo_logs GROUP BY owner_id');
    const m = Object.fromEntries(g.map(r => [r.owner_id, r.total]));
    assert.deepStrictEqual(m, { a: 10, b: 1 });
    const tot = await adapter.get('SELECT COALESCE(SUM(success), 0) as total FROM promo_logs');
    assert.strictEqual(tot.total, 11);
    const empty = await adapter.get('SELECT COALESCE(SUM(success), 0) as total FROM promo_logs WHERE owner_id = ?', 'nobody');
    assert.strictEqual(empty.total, 0);
    const mx = await adapter.get('SELECT MAX(id) as max FROM promo_logs WHERE owner_id = ?', 'a');
    assert.ok(mx.max >= 1);
    const cd = await adapter.get('SELECT COUNT(DISTINCT owner_id) AS c FROM promo_logs');
    assert.strictEqual(cd.c, 2);
  });

  await t('COUNT(*) memakai countDocuments dan NOT EXISTS / IN subquery bekerja', async () => {
    const { adapter } = await setup();
    await adapter.run('INSERT INTO users (user_id, role) VALUES (?, ?)', 'a', 'TRIAL');
    await adapter.run('INSERT INTO settings (owner_id) VALUES (?)', 'a');
    await adapter.run('INSERT INTO settings (owner_id) VALUES (?)', 'ghost');
    const c = await adapter.get('SELECT COUNT(*) AS c FROM settings');
    assert.strictEqual(c.c, 2);
    const orphan = await adapter.all('SELECT s.owner_id FROM settings s WHERE NOT EXISTS (SELECT 1 FROM users u WHERE u.user_id = s.owner_id)');
    assert.deepStrictEqual(orphan, [{ owner_id: 'ghost' }]);
    await adapter.run('INSERT INTO userbots (ubot_id, owner_id, expired) VALUES (?, ?, ?)', 'x', 'a', 999);
    const r = await adapter.run("UPDATE userbots SET expired = NULL WHERE owner_id IN (SELECT user_id FROM users WHERE role = 'TRIAL') AND expired IS NOT NULL AND expired > ?", 10);
    assert.strictEqual(r.changes, 1);
    assert.strictEqual((await adapter.get('SELECT expired FROM userbots WHERE ubot_id = ?', 'x')).expired, null);
  });

  await t('OR, LIKE, LOWER, UNION, LIMIT/OFFSET dengan parameter', async () => {
    const { adapter } = await setup();
    for (const [id, name] of [['1', 'Alpha'], ['2', 'alfa'], ['3', 'Beta']]) {
      await adapter.run('INSERT INTO users (user_id, username) VALUES (?, ?)', id, name);
    }
    assert.strictEqual((await adapter.all('SELECT user_id FROM users WHERE username LIKE ?', 'al%')).length, 2);
    assert.strictEqual((await adapter.all('SELECT user_id FROM users WHERE LOWER(username) = LOWER(?)', 'ALPHA')).length, 1);
    assert.strictEqual((await adapter.all('SELECT user_id FROM users WHERE user_id = ? OR user_id = ?', '1', '3')).length, 2);
    const page = await adapter.all('SELECT user_id FROM users ORDER BY user_id DESC LIMIT ? OFFSET ?', 2, 1);
    assert.deepStrictEqual(page.map(r => r.user_id), ['2', '1']);
    const un = await adapter.all('SELECT user_id FROM users WHERE user_id = ? UNION SELECT user_id FROM users WHERE user_id = ?', '1', '1');
    assert.strictEqual(un.length, 1);
  });

  await t('rowid dipakai untuk delete baris tertentu', async () => {
    const { adapter } = await setup();
    await adapter.run('INSERT INTO promo_logs (owner_id, success) VALUES (?, ?)', 'k', 1);
    await adapter.run('INSERT INTO promo_logs (owner_id, success) VALUES (?, ?)', 'k', 2);
    const rows = await adapter.all('SELECT rowid FROM promo_logs WHERE owner_id = ?', 'k');
    assert.strictEqual(rows.length, 2);
    const r = await adapter.run('DELETE FROM promo_logs WHERE rowid = ?', rows[0].rowid);
    assert.strictEqual(r.changes, 1);
    assert.strictEqual((await adapter.all('SELECT * FROM promo_logs')).length, 1);
  });

  await t('cache baca dibatalkan oleh tulis, hasil cache tidak bisa dimutasi pemanggil', async () => {
    const { adapter } = await setup();
    await adapter.run('INSERT INTO users (user_id, role) VALUES (?, ?)', 'c', 'FREE');
    const a = await adapter.get('SELECT * FROM users WHERE user_id = ?', 'c');
    a.role = 'HACK';
    const b = await adapter.get('SELECT * FROM users WHERE user_id = ?', 'c');
    assert.strictEqual(b.role, 'FREE');
    await adapter.run('UPDATE users SET role = ? WHERE user_id = ?', 'PRO', 'c');
    const c = await adapter.get('SELECT * FROM users WHERE user_id = ?', 'c');
    assert.strictEqual(c.role, 'PRO');
    const st = adapter.stats();
    assert.ok(st.hits >= 1);
  });

  await t('query identik yang bersamaan digabung jadi satu pembacaan', async () => {
    const { adapter, fake } = await setup();
    await adapter.run('INSERT INTO users (user_id) VALUES (?)', 'p');
    let finds = 0;
    const col = fake.collection('users');
    const orig = col.find.bind(col);
    col.find = (...a) => {
      finds++;
      return orig(...a);
    };
    const all = await Promise.all(Array.from({ length: 20 }, () => adapter.get('SELECT user_id FROM users WHERE user_id = ?', 'p')));
    assert.strictEqual(all.length, 20);
    assert.strictEqual(finds, 1);
  });

  await t('PRAGMA table_info dan ALTER TABLE ADD COLUMN mengikuti skema', async () => {
    const { adapter } = await setup();
    let cols = await adapter.all('PRAGMA table_info(settings)');
    assert.ok(cols.some(c => c.name === 'delay'));
    assert.ok(!cols.some(c => c.name === 'notif_to_saved'));
    await adapter.exec('ALTER TABLE settings ADD COLUMN notif_to_saved INTEGER DEFAULT 0');
    cols = await adapter.all('PRAGMA table_info(settings)');
    assert.ok(cols.some(c => c.name === 'notif_to_saved'));
  });

  await t('indeks dibuat untuk kunci primer, unik, dan kolom owner/user', async () => {
    const { fake } = await setup();
    const idx = fake.collection('userbots').indexes.map(i => Object.keys(i.keys).join(','));
    assert.ok(idx.includes('ubot_id'));
    assert.ok(idx.includes('owner_id'));
    const adm = fake.collection('admin_controls').indexes.map(i => Object.keys(i.keys).join(','));
    assert.ok(adm.includes('owner_id,admin_id'));
    assert.ok(fake.collection('users').indexes.some(i => i.opts.unique && i.keys.user_id));
  });

  await t('DELETE dengan subquery dan tanpa WHERE', async () => {
    const { adapter } = await setup();
    await adapter.run('INSERT INTO users (user_id, role) VALUES (?, ?)', 'a', 'FREE');
    await adapter.run('INSERT INTO settings (owner_id) VALUES (?)', 'a');
    await adapter.run('INSERT INTO settings (owner_id) VALUES (?)', 'g');
    const r = await adapter.run('DELETE FROM settings WHERE owner_id NOT IN (SELECT user_id FROM users)');
    assert.strictEqual(r.changes, 1);
    const all = await adapter.run('DELETE FROM settings');
    assert.strictEqual(all.changes, 1);
  });

  console.log(results.join('\n'));
  console.log(failed ? `\n${failed} TES GAGAL` : '\nSEMUA LOLOS');
  process.exit(failed ? 1 : 0);
})();
