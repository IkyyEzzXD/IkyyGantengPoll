const fs = require('fs');
const path = require('path');
let acorn, walk;
try { acorn = require('acorn'); walk = require('acorn-walk'); }
catch (e) {
  console.log('LEWAT : acorn belum terpasang. Jalankan: npm install --save-dev acorn acorn-walk');
  process.exit(0);
}
const file = process.argv[2] || path.join(__dirname, '../src/index.js');
const src = fs.readFileSync(file, 'utf8');
const ast = acorn.parse(src, { ecmaVersion: 'latest', sourceType: 'script', locations: true, allowAwaitOutsideFunction: true, allowReturnOutsideFunction: true });

const GLOBALS = new Set(['undefined','NaN','Infinity','globalThis','global','process','console','require','module','exports','__dirname','__filename','Buffer','setTimeout','setInterval','setImmediate','clearTimeout','clearInterval','clearImmediate','queueMicrotask','structuredClone','URL','URLSearchParams','TextEncoder','TextDecoder','AbortController','AbortSignal','fetch','performance','Object','Array','String','Number','Boolean','Symbol','BigInt','Math','JSON','Date','RegExp','Error','TypeError','RangeError','SyntaxError','ReferenceError','EvalError','URIError','AggregateError','Promise','Map','Set','WeakMap','WeakSet','WeakRef','FinalizationRegistry','Proxy','Reflect','Intl','ArrayBuffer','SharedArrayBuffer','DataView','Atomics','Uint8Array','Int8Array','Uint16Array','Int16Array','Uint32Array','Int32Array','Float32Array','Float64Array','BigInt64Array','BigUint64Array','Uint8ClampedArray','parseInt','parseFloat','isNaN','isFinite','encodeURIComponent','decodeURIComponent','encodeURI','decodeURI','escape','unescape','eval','arguments','Function','atob','btoa','WebAssembly','Blob','Event','EventTarget']);

class Scope { constructor(p, fn) { this.p = p; this.names = new Set(); this.fn = fn; } has(n) { for (let s = this; s; s = s.p) if (s.names.has(n)) return true; return false; } }
function patNames(p, out) {
  if (!p) return;
  switch (p.type) {
    case 'Identifier': out.push(p.name); break;
    case 'ObjectPattern': p.properties.forEach(x => patNames(x.type === 'RestElement' ? x.argument : x.value, out)); break;
    case 'ArrayPattern': p.elements.forEach(e => patNames(e, out)); break;
    case 'RestElement': patNames(p.argument, out); break;
    case 'AssignmentPattern': patNames(p.left, out); break;
  }
}
const issues = [];
function hoistVar(node, scope) {
  walk.recursive(node, null, {
    VariableDeclaration(n, _s, c) { if (n.kind === 'var') n.declarations.forEach(d => { const o = []; patNames(d.id, o); o.forEach(x => scope.names.add(x)); }); n.declarations.forEach(d => d.init && c(d.init, _s)); },
    FunctionDeclaration() {}, FunctionExpression() {}, ArrowFunctionExpression() {}, ClassDeclaration() {}, ClassExpression() {},
  });
}
function declareBlock(body, scope) {
  for (const st of body) {
    if (st.type === 'FunctionDeclaration' && st.id) scope.names.add(st.id.name);
    else if (st.type === 'ClassDeclaration' && st.id) scope.names.add(st.id.name);
    else if (st.type === 'VariableDeclaration' && st.kind !== 'var') st.declarations.forEach(d => { const o = []; patNames(d.id, o); o.forEach(x => scope.names.add(x)); });
  }
}
function visit(node, scope, parent, key) {
  if (!node || typeof node.type !== 'string') return;
  switch (node.type) {
    case 'Program': { const s = new Scope(null, true); hoistVar(node, s); declareBlock(node.body, s); node.body.forEach(n => visit(n, s)); return; }
    case 'FunctionDeclaration': case 'FunctionExpression': case 'ArrowFunctionExpression': {
      const s = new Scope(scope, true);
      if (node.type === 'FunctionExpression' && node.id) s.names.add(node.id.name);
      const o = []; node.params.forEach(p => patNames(p, o)); o.forEach(x => s.names.add(x));
      if (node.body.type === 'BlockStatement') { hoistVar(node.body, s); declareBlock(node.body.body, s); node.params.forEach(p => visit(p, s)); node.body.body.forEach(n => visit(n, s)); }
      else { node.params.forEach(p => visit(p, s)); visit(node.body, s); }
      return;
    }
    case 'ClassDeclaration': case 'ClassExpression': { if (node.superClass) visit(node.superClass, scope); const s = new Scope(scope); if (node.id) s.names.add(node.id.name); node.body.body.forEach(m => { if (m.computed) visit(m.key, s); if (m.value) visit(m.value, s); if (m.type === 'StaticBlock') m.body.forEach(n => visit(n, s)); }); return; }
    case 'BlockStatement': { const s = new Scope(scope); declareBlock(node.body, s); node.body.forEach(n => visit(n, s)); return; }
    case 'ForStatement': case 'ForInStatement': case 'ForOfStatement': { const s = new Scope(scope); const init = node.init || node.left; if (init && init.type === 'VariableDeclaration' && init.kind !== 'var') init.declarations.forEach(d => { const o = []; patNames(d.id, o); o.forEach(x => s.names.add(x)); }); ['init','test','update','left','right','body'].forEach(k => node[k] && visit(node[k], s)); return; }
    case 'CatchClause': { const s = new Scope(scope); if (node.param) { const o = []; patNames(node.param, o); o.forEach(x => s.names.add(x)); } visit(node.body, s); return; }
    case 'SwitchStatement': { visit(node.discriminant, scope); const s = new Scope(scope); node.cases.forEach(c => declareBlock(c.consequent, s)); node.cases.forEach(c => { c.test && visit(c.test, s); c.consequent.forEach(n => visit(n, s)); }); return; }
    case 'VariableDeclarator': { visit(node.init, scope); if (node.id.type !== 'Identifier') visitPattern(node.id, scope); return; }
    case 'MemberExpression': visit(node.object, scope); if (node.computed) visit(node.property, scope); return;
    case 'Property': if (node.computed) visit(node.key, scope); visit(node.value, scope); return;
    case 'PropertyDefinition': return;
    case 'LabeledStatement': visit(node.body, scope); return;
    case 'BreakStatement': case 'ContinueStatement': return;
    case 'Identifier': {
      if (!scope.has(node.name) && !GLOBALS.has(node.name)) issues.push({ name: node.name, line: node.loc.start.line, col: node.loc.start.column });
      return;
    }
    case 'AssignmentExpression': case 'UpdateExpression': default: break;
  }
  for (const k of Object.keys(node)) {
    if (k === 'type' || k === 'loc' || k === 'start' || k === 'end') continue;
    const v = node[k];
    if (Array.isArray(v)) v.forEach(x => x && typeof x.type === 'string' && visit(x, scope));
    else if (v && typeof v.type === 'string') visit(v, scope);
  }
}
function visitPattern(p, scope) { if (p.type === 'ObjectPattern') p.properties.forEach(x => { if (x.computed) visit(x.key, scope); const v = x.type === 'RestElement' ? x.argument : x.value; if (v && v.type === 'AssignmentPattern') visit(v.right, scope); else if (v && v.type !== 'Identifier') visitPattern(v, scope); }); else if (p.type === 'ArrayPattern') p.elements.forEach(e => { if (!e) return; if (e.type === 'AssignmentPattern') visit(e.right, scope); else if (e.type !== 'Identifier') visitPattern(e, scope); }); }
visit(ast, null);
const byName = {};
issues.forEach(i => (byName[i.name] = byName[i.name] || []).push(i));
const names = Object.keys(byName);
// Pengecualian yang sudah DIVERIFIKASI aman (dipakai lewat `typeof x !== 'undefined'`)
const ALLOWED = new Set(['backup']);
const real = names.filter(n => !ALLOWED.has(n));
if (real.length === 0) {
  console.log('ok   : tidak ada variabel yang dipakai tanpa dideklarasikan di ' + path.basename(file));
  process.exit(0);
}
console.log(`GAGAL: ${real.length} variabel dipakai tanpa dideklarasikan (penyebab error "X is not defined"):`);
real.sort().forEach(n => console.log(`  ${n}  ->  baris ${byName[n].slice(0, 6).map(i => i.line).join(', ')}${byName[n].length > 6 ? ' ...' : ''}`));
process.exit(1);
