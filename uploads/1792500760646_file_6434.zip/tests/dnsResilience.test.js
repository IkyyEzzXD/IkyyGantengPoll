const { install } = require(require('path').join(__dirname, '../src/system/dnsResilience.js'));
let fail = 0;
const ok = (c, m) => { if (!c) { fail++; console.log('GAGAL:', m); } else console.log('ok   :', m); };
const eai = () => { const e = new Error('getaddrinfo EAI_AGAIN x'); e.code = 'EAI_AGAIN'; return e; };
const mk = (behaviour) => {
  const calls = { n: 0 };
  const fake = { promises: require('dns').promises, lookup(h, o, cb) { calls.n++; behaviour(calls.n, h, o, cb); } };
  return { fake, calls };
};
const look = (dns, h, o) => new Promise((res) => dns.lookup(h, o, (err, a, f) => res({ err, a, f })));
const env = { DNS_RETRY_DELAY_MS: '1', DNS_FALLBACK_SERVERS: '' };

(async () => {
  // 1) sukses setelah 2x EAI_AGAIN
  let t = mk((n, h, o, cb) => (n < 3 ? cb(eai()) : cb(null, [{ address: '1.2.3.4', family: 4 }])));
  install(t.fake, { env });
  let r = await look(t.fake, 'a.example', { family: 4 });
  ok(!r.err && r.a === '1.2.3.4' && r.f === 4 && t.calls.n === 3, 'EAI_AGAIN diulang lalu sukses (all=false)');

  // 2) opsi all:true
  r = await look(t.fake, 'a.example', { all: true });
  ok(Array.isArray(r.a) && r.a[0].address === '1.2.3.4', 'all:true mengembalikan array');

  // 3) ENOTFOUND tidak diulang
  t = mk((n, h, o, cb) => { const e = new Error('nf'); e.code = 'ENOTFOUND'; cb(e); });
  install(t.fake, { env });
  r = await look(t.fake, 'b.example', {});
  ok(r.err && r.err.code === 'ENOTFOUND' && t.calls.n === 1, 'ENOTFOUND langsung gagal tanpa ulang');

  // 4) stale cache dipakai saat DNS mati
  let down = false;
  t = mk((n, h, o, cb) => (down ? cb(eai()) : cb(null, [{ address: '9.9.9.9', family: 4 }])));
  install(t.fake, { env });
  await look(t.fake, 'c.example', {});
  down = true;
  r = await look(t.fake, 'c.example', {});
  ok(!r.err && r.a === '9.9.9.9', 'DNS mati -> pakai IP terakhir yang berhasil');

  // 5) tanpa cache -> error asli
  r = await look(t.fake, 'belum-pernah.example', {});
  ok(r.err && r.err.code === 'EAI_AGAIN', 'tanpa cache -> error asli dilempar');

  // 6) IP literal & idempotent
  r = await look(t.fake, '127.0.0.1', {});
  ok(install(t.fake, { env }) === false, 'install tidak terpasang ganda');

  // 7) bentuk (hostname, callback)
  t = mk((n, h, o, cb) => cb(null, [{ address: '5.6.7.8', family: 4 }]));
  install(t.fake, { env });
  r = await new Promise((res) => t.fake.lookup('d.example', (err, a, f) => res({ err, a, f })));
  ok(r.a === '5.6.7.8', 'bentuk (host, callback) didukung');

  console.log(fail ? `\n${fail} GAGAL` : '\nSEMUA LOLOS');
  process.exit(fail ? 1 : 0);
})();
