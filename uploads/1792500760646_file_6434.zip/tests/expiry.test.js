// Tes alur "akses habis": penanda expired, gerbang promosi, auto-renew dedupe.
// Tidak butuh node_modules: potongan kode diambil dari src/index.js lalu dijalankan
// dengan db palsu (Map), jadi yang diuji adalah kode ASLI, bukan salinan.
const fs = require('fs');
const os = require('os');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

let failed = 0;
async function t(name, fn) {
  try { await fn(); console.log('ok   :', name); }
  catch (e) { failed++; console.log('GAGAL:', name, '-', e.message); }
}

const src = fs.readFileSync(path.join(__dirname, '../src/index.js'), 'utf8');

function slice(from, to) {
  const a = src.indexOf(from), b = src.indexOf(to, a);
  assert(a >= 0 && b > a, `potongan tidak ketemu: ${from}`);
  return src.slice(a, b);
}

function makeSandbox({ validUntil = null, hasUserbotRow = false, inMemory = false } = {}) {
  const rows = new Map(); // expired_access
  const sent = [];
  const sandbox = {
    OWNER_ID: '1',
    userbots: inMemory ? [{ owner_id: '42' }] : [],
    logger: { warn() {}, info() {}, error() {} },
    getValidAccessExpiry: async () => validUntil,
    buildAccessExpiredKeyboard: () => ({ inline_keyboard: [[{ callback_data: 'beli_userbot' }]] }),
    editOrSendMenu: async (chatId, msgId, text, opts) => { sent.push({ chatId, text, opts }); },
    bot: { sendMessage: async (chatId, text, opts) => { sent.push({ chatId, text, opts }); } },
    db: {
      async run(sql, ...a) {
        if (/INSERT OR REPLACE INTO expired_access/.test(sql)) rows.set(a[0], { expired_at: a[1], reason: a[2] });
        else if (/DELETE FROM expired_access/.test(sql)) rows.delete(a[0]);
      },
      async get(sql, ...a) {
        if (/FROM expired_access/.test(sql)) return rows.get(a[0]) || undefined;
        if (/FROM userbots/.test(sql)) return hasUserbotRow ? { x: 1 } : undefined;
      },
    },
  };
  const code = slice('const EXPIRED_MARKER_TTL_SEC', 'function buildAccessExpiredKeyboard()');
  vm.createContext(sandbox);
  vm.runInContext(code + '\nthis.api={markAccessExpired,clearAccessExpired,isAccessExpiredUser,guardExpiredAccess};', sandbox);
  return { api: sandbox.api, rows, sent };
}

(async () => {
  await t('tanpa penanda -> tidak diblok', async () => {
    const { api } = makeSandbox();
    assert.strictEqual(await api.isAccessExpiredUser('42'), false);
  });
  await t('penanda + tanpa userbot + tanpa langganan -> diblok & notif beli ulang terkirim', async () => {
    const { api, sent } = makeSandbox();
    await api.markAccessExpired('42', 'expired');
    assert.strictEqual(await api.guardExpiredAccess('42', 100, 5), true);
    assert.strictEqual(sent.length, 1);
    assert(/MASA AKTIF SUDAH HABIS/.test(sent[0].text));
    assert(/beli/i.test(sent[0].text));
    assert.strictEqual(sent[0].opts.reply_markup.inline_keyboard[0][0].callback_data, 'beli_userbot');
  });
  await t('sudah beli lagi (langganan berlaku) -> tidak diblok', async () => {
    const { api, sent } = makeSandbox({ validUntil: Math.floor(Date.now() / 1000) + 99999 });
    await api.markAccessExpired('42');
    assert.strictEqual(await api.guardExpiredAccess('42', 100), false);
    assert.strictEqual(sent.length, 0);
  });
  await t('punya userbot aktif (memori) -> tidak diblok', async () => {
    const { api } = makeSandbox({ inMemory: true });
    await api.markAccessExpired('42');
    assert.strictEqual(await api.isAccessExpiredUser('42'), false);
  });
  await t('punya baris userbot AKTIF di DB -> tidak diblok', async () => {
    const { api } = makeSandbox({ hasUserbotRow: true });
    await api.markAccessExpired('42');
    assert.strictEqual(await api.isAccessExpiredUser('42'), false);
  });
  await t('owner tidak pernah diblok', async () => {
    const { api } = makeSandbox();
    await api.markAccessExpired('1');
    assert.strictEqual(await api.isAccessExpiredUser('1'), false);
  });
  await t('penanda kedaluwarsa > 90 hari dibuang', async () => {
    const { api, rows } = makeSandbox();
    rows.set('42', { expired_at: Math.floor(Date.now() / 1000) - 91 * 86400, reason: 'expired' });
    assert.strictEqual(await api.isAccessExpiredUser('42'), false);
    assert.strictEqual(rows.has('42'), false);
  });
  await t('clearAccessExpired menghapus penanda', async () => {
    const { api } = makeSandbox();
    await api.markAccessExpired('42');
    await api.clearAccessExpired('42');
    assert.strictEqual(await api.isAccessExpiredUser('42'), false);
  });

  // --- wiring: gerbang harus ada di semua pintu masuk "jalankan promosi" ---
  const fnBody = (name) => {
    const a = src.indexOf(`async function ${name}(`);
    assert(a >= 0, `fungsi ${name} tidak ada`);
    return src.slice(a, a + 900);
  };
  for (const fn of ['handleMenuBroadcast', 'handleMulaiBroadcast', 'handleRestartRound', 'handleBroadcastPM']) {
    await t(`gerbang akses habis terpasang di ${fn}`, async () => {
      assert(/guardExpiredAccess\(/.test(fnBody(fn)));
    });
  }
  await t('expireUserAccess mencatat penanda sebelum data dihapus', async () => {
    const a = src.indexOf('async function expireUserAccess(');
    const body = src.slice(a, a + 6000);
    assert(body.indexOf('markAccessExpired(') > 0);
    assert(body.indexOf('markAccessExpired(') < body.indexOf('cleanupUserData('));
  });
  await t('pembelian akses menghapus penanda', async () => {
    const a = src.indexOf('async function applyPurchasedAccess(');
    assert(/clearAccessExpired\(targetUserId\)/.test(src.slice(a, a + 5000)));
  });
  await t('handleUserbotLogout tidak jalan saat expire sedang diproses', async () => {
    const a = src.indexOf('async function handleUserbotLogout(');
    assert(/_expireInProgress/.test(src.slice(a, a + 500)));
  });
  await t('auto-renew memakai applyPurchasedAccess (bukan cuma users.expired)', async () => {
    const a = src.indexOf('async function runRetentionJobs()');
    const body = src.slice(a, a + 9000);
    assert(/applyPurchasedAccess\(ar\.userId/.test(body));
  });

  // --- retention.js: pesan saldo kurang hanya sekali per tanggal habis ---
  await t('auto-renew gagal: notifikasi hanya sekali per tanggal habis', async () => {
    const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'jaseb-'));
    fs.mkdirSync(path.join(tmp, 'src/system'), { recursive: true });
    fs.mkdirSync(path.join(tmp, 'database'));
    fs.mkdirSync(path.join(tmp, 'src/storage'), { recursive: true });
    for (const f of ['mongoAdapter.js', 'sqlParser.js']) fs.copyFileSync(path.join(__dirname, '../src/storage', f), path.join(tmp, 'src/storage', f));
    fs.copyFileSync(path.join(__dirname, '../src/system/retention.js'), path.join(tmp, 'src/system/retention.js'));
    fs.copyFileSync(path.join(__dirname, '../src/system/kvDoc.js'), path.join(tmp, 'src/system/kvDoc.js'));
    const r = require(path.join(tmp, 'src/system/retention.js'));
    assert.strictEqual(r.shouldNotifyAutoRenewFail('7', 1000), true);
    assert.strictEqual(r.shouldNotifyAutoRenewFail('7', 1000), false);
    assert.strictEqual(r.shouldNotifyAutoRenewFail('7', 2000), true);
    assert.strictEqual(r.shouldNotifyAutoRenewFail('8', 1000), true);
  });

  console.log(failed ? `\n${failed} TES GAGAL` : '\nSEMUA LOLOS');
  process.exit(failed ? 1 : 0);
})();
