/*! Copyright (c) 2011 Piotr Rochala (http://rocha.la)
 * Dual licensed under the MIT (http://www.opensource.org/licenses/mit-license.php)
 * and GPL (http://www.opensource.org/licenses/gpl-license.php) licenses.
 *
 * Version: 1.3.8
 *
*/
!function (e) {
    e.fn.extend({
        slimScroll: function (i) {
            var o = e.extend({
                width: "auto",
                height: "250px",
                size: "7px",
                color: "#000",
                position: "right",
                distance: "1px",
                start: "top",
                opacity: .4,
                alwaysVisible: !1,
                disableFadeOut: !1,
                railVisible: !1,
                railColor: "#333",
                railOpacity: .2,
                railDraggable: !0,
                railClass: "slimScrollRail",
                barClass: "slimScrollBar",
                wrapperClass: "slimScrollDiv",
                allowPageScroll: !1,
                wheelStep: 20,
                touchScrollStep: 200,
                borderRadius: "7px",
                railBorderRadius: "7px"
            }, i);
            return this.each(function () {
                function s(i) {
                    if (c) {
                        i = i || window.event;
                        var s = 0;
                        i.wheelDelta && (s = -i.wheelDelta / 120), i.detail && (s = i.detail / 3), e(i.target || i.srcTarget || i.srcElement).closest("." + o.wrapperClass).is(b.parent()) && l(s, !0), i.preventDefault && !m && i.preventDefault(), m || (i.returnValue = !1)
                    }
                }

                function l(e, i, s) {
                    m = !1;
                    var l = b.outerHeight() - w.outerHeight();
                    i && (i = Math.min(Math.max(i = parseInt(w.css("top")) + e * parseInt(o.wheelStep) / 100 * w.outerHeight(), 0), l), i = 0 < e ? Math.ceil(i) : Math.floor(i), w.css({top: i + "px"})), i = (f = parseInt(w.css("top")) / (b.outerHeight() - w.outerHeight())) * (b[0].scrollHeight - b.outerHeight()), s && (e = Math.min(Math.max(e = (i = e) / b[0].scrollHeight * b.outerHeight(), 0), l), w.css({top: e + "px"})), b.scrollTop(i), b.trigger("slimscrolling", ~~i), n(), a()
                }

                function r() {
                    g = Math.max(b.outerHeight() / b[0].scrollHeight * b.outerHeight(), 30), w.css({height: g + "px"});
                    var e = g == b.outerHeight() ? "none" : "block";
                    w.css({display: e})
                }

                function n() {
                    r(), clearTimeout(h), f == ~~f ? (m = o.allowPageScroll, v != f && b.trigger("slimscroll", 0 == ~~f ? "top" : "bottom")) : m = !1, v = f, g >= b.outerHeight() ? m = !0 : (w.stop(!0, !0).fadeIn("fast"), o.railVisible && y.stop(!0, !0).fadeIn("fast"))
                }

                function a() {
                    o.alwaysVisible || (h = setTimeout(function () {
                        o.disableFadeOut && c || p || d || (w.fadeOut("slow"), y.fadeOut("slow"))
                    }, 1e3))
                }

                var c, p, d, h, u, g, f, v, m = !1, b = e(this);
                if (b.parent().hasClass(o.wrapperClass)) {
                    var $ = b.scrollTop(), w = b.siblings("." + o.barClass), y = b.siblings("." + o.railClass);
                    if (r(), e.isPlainObject(i)) {
                        if ("height" in i && "auto" == i.height) {
                            b.parent().css("height", "auto"), b.css("height", "auto");
                            var x = b.parent().parent().height();
                            b.parent().css("height", x), b.css("height", x)
                        } else "height" in i && (x = i.height, b.parent().css("height", x), b.css("height", x));
                        if ("scrollTo" in i) $ = parseInt(o.scrollTo); else if ("scrollBy" in i) $ += parseInt(o.scrollBy); else if ("destroy" in i) {
                            w.remove(), y.remove(), b.unwrap();
                            return
                        }
                        l($, !1, !0)
                    }
                } else if (!(e.isPlainObject(i) && "destroy" in i)) {
                    o.height = "auto" == o.height ? b.parent().height() : o.height, $ = e("<div></div>").addClass(o.wrapperClass).css({
                        position: "relative",
                        overflow: "hidden",
                        width: o.width,
                        height: o.height
                    }), b.css({overflow: "hidden", width: o.width, height: o.height});
                    var y = e("<div></div>").addClass(o.railClass).css({
                        width: o.size,
                        height: "100%",
                        position: "absolute",
                        top: 0,
                        display: o.alwaysVisible && o.railVisible ? "block" : "none",
                        "border-radius": o.railBorderRadius,
                        background: o.railColor,
                        opacity: o.railOpacity,
                        zIndex: 90
                    }), w = e("<div></div>").addClass(o.barClass).css({
                        background: o.color,
                        width: o.size,
                        position: "absolute",
                        top: 0,
                        opacity: o.opacity,
                        display: o.alwaysVisible ? "block" : "none",
                        "border-radius": o.borderRadius,
                        BorderRadius: o.borderRadius,
                        MozBorderRadius: o.borderRadius,
                        WebkitBorderRadius: o.borderRadius,
                        zIndex: 99
                    }), x = "right" == o.position ? {right: o.distance} : {left: o.distance};
                    y.css(x), w.css(x), b.wrap($), b.parent().append(w), b.parent().append(y), o.railDraggable && w.bind("mousedown", function (i) {
                        var o = e(document);
                        return d = !0, t = parseFloat(w.css("top")), pageY = i.pageY, o.bind("mousemove.slimscroll", function (e) {
                            currTop = t + e.pageY - pageY, w.css("top", currTop), l(0, w.position().top, !1)
                        }), o.bind("mouseup.slimscroll", function (e) {
                            d = !1, a(), o.unbind(".slimscroll")
                        }), !1
                    }).bind("selectstart.slimscroll", function (e) {
                        return e.stopPropagation(), e.preventDefault(), !1
                    }), y.hover(function () {
                        n()
                    }, function () {
                        a()
                    }), w.hover(function () {
                        p = !0
                    }, function () {
                        p = !1
                    }), b.hover(function () {
                        c = !0, n(), a()
                    }, function () {
                        c = !1, a()
                    }), b.bind("touchstart", function (e, i) {
                        e.originalEvent.touches.length && (u = e.originalEvent.touches[0].pageY)
                    }), b.bind("touchmove", function (e) {
                        m || e.originalEvent.preventDefault(), e.originalEvent.touches.length && (l((u - e.originalEvent.touches[0].pageY) / o.touchScrollStep, !0), u = e.originalEvent.touches[0].pageY)
                    }), r(), "bottom" === o.start ? (w.css({top: b.outerHeight() - w.outerHeight()}), l(0, !0)) : "top" !== o.start && (l(e(o.start).position().top, null, !0), o.alwaysVisible || w.hide()), window.addEventListener ? (this.addEventListener("DOMMouseScroll", s, !1), this.addEventListener("mousewheel", s, !1)) : document.attachEvent("onmousewheel", s)
                }
            }), this
        }
    }), e.fn.extend({slimscroll: e.fn.slimScroll})
}(jQuery), function (e, i, o) {
    "use strict";
    e.fn.scrollUp = function (i) {
        e.data(o.body, "scrollUp") || (e.data(o.body, "scrollUp", !0), e.fn.scrollUp.init(i))
    }, e.fn.scrollUp.init = function (s) {
        var l, r, n, a, c, p, d, h = e.fn.scrollUp.settings = e.extend({}, e.fn.scrollUp.defaults, s), u = !1;
        switch (d = h.scrollTrigger ? e(h.scrollTrigger) : e("<a/>", {
            id: h.scrollName,
            href: "#top"
        }), h.scrollTitle && d.attr("title", h.scrollTitle), d.appendTo("body"), h.scrollImg || h.scrollTrigger || d.html(h.scrollText), d.css({
            display: "none",
            position: "fixed",
            zIndex: h.zIndex
        }), h.activeOverlay && e("<div/>", {id: h.scrollName + "-active"}).css({
            position: "absolute",
            top: h.scrollDistance + "px",
            width: "100%",
            borderTop: "1px dotted" + h.activeOverlay,
            zIndex: h.zIndex
        }).appendTo("body"), h.animation) {
            case"fade":
                l = "fadeIn", r = "fadeOut", n = h.animationSpeed;
                break;
            case"slide":
                l = "slideDown", r = "slideUp", n = h.animationSpeed;
                break;
            default:
                l = "show", r = "hide", n = 0
        }
        a = "top" === h.scrollFrom ? h.scrollDistance : e(o).height() - e(i).height() - h.scrollDistance, c = e(i).scroll(function () {
            e(i).scrollTop() > a ? u || (d[l](n), u = !0) : u && (d[r](n), u = !1)
        }), h.scrollTarget ? "number" == typeof h.scrollTarget ? p = h.scrollTarget : "string" == typeof h.scrollTarget && (p = Math.floor(e(h.scrollTarget).offset().top)) : p = 0, d.click(function (i) {
            i.preventDefault(), e("html, body").animate({scrollTop: p}, h.scrollSpeed, h.easingType)
        })
    }, e.fn.scrollUp.defaults = {
        scrollName: "scrollUp",
        scrollDistance: 300,
        scrollFrom: "top",
        scrollSpeed: 300,
        easingType: "linear",
        animation: "fade",
        animationSpeed: 200,
        scrollTrigger: !1,
        scrollTarget: !1,
        scrollText: "Scroll to top",
        scrollTitle: !1,
        scrollImg: !1,
        activeOverlay: !1,
        zIndex: 2147483647
    }, e.fn.scrollUp.destroy = function (s) {
        e.removeData(o.body, "scrollUp"), e("#" + e.fn.scrollUp.settings.scrollName).remove(), e("#" + e.fn.scrollUp.settings.scrollName + "-active").remove(), e.fn.jquery.split(".")[1] >= 7 ? e(i).off("scroll", s) : e(i).unbind("scroll", s)
    }, e.scrollUp = e.fn.scrollUp
}(jQuery, window, document), function (e) {
    "use strict";
    var i = "lte.tree", o = {animationSpeed: 500, accordion: !0, followLink: !1, trigger: ".treeview a"}, s = {
            tree: ".tree",
            treeview: ".treeview",
            treeviewMenu: ".treeview-menu",
            open: ".menu-open, .active",
            li: "li",
            data: '[data-widget="tree"]',
            active: ".active"
        }, l = {open: "menu-open", tree: "tree"}, r = {collapsed: "collapsed.tree", expanded: "expanded.tree"},
        n = function (i, o) {
            this.element = i, this.options = o, e(this.element).addClass(l.tree), e(s.treeview + s.active, this.element).addClass(l.open), this._setUpListeners()
        };

    function a(s) {
        return this.each(function () {
            var l = e(this);
            if (!l.data(i)) {
                var r = e.extend({}, o, l.data(), "object" == typeof s && s);
                l.data(i, new n(l, r))
            }
        })
    }

    n.prototype.toggle = function (e, i) {
        var o = e.next(s.treeviewMenu), r = e.parent(), n = r.hasClass(l.open);
        r.is(s.treeview) && (this.options.followLink && "#" !== e.attr("href") || i.preventDefault(), n ? this.collapse(o, r) : this.expand(o, r))
    }, n.prototype.expand = function (i, o) {
        var n = e.Event(r.expanded);
        if (this.options.accordion) {
            var a = o.siblings(s.open), c = a.children(s.treeviewMenu);
            this.collapse(c, a)
        }
        o.addClass(l.open), i.slideDown(this.options.animationSpeed, (function () {
            e(this.element).trigger(n)
        }).bind(this))
    }, n.prototype.collapse = function (i, o) {
        var s = e.Event(r.collapsed);
        o.removeClass(l.open), i.slideUp(this.options.animationSpeed, (function () {
            e(this.element).trigger(s)
        }).bind(this))
    }, n.prototype._setUpListeners = function () {
        var i = this;
        e(this.element).on("click", this.options.trigger, function (o) {
            i.toggle(e(this), o)
        })
    };
    var c = e.fn.tree;
    e.fn.tree = a, e.fn.tree.Constructor = n, e.fn.tree.noConflict = function () {
        return e.fn.tree = c, this
    }, e(window).on("load", function () {
        e(s.data).each(function () {
            a.call(e(this))
        })
    })
}(jQuery);
